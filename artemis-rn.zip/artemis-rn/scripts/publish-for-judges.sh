#!/usr/bin/env bash
# Publishes the current code as an EAS Update on the "judges" branch, so anyone with Expo Go can open it
# from a link or QR code without your computer being on. Run once you are signed in (`npx expo login`).
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="$HOME/.local/node/bin:$PATH"

if ! npx expo whoami >/dev/null 2>&1; then
  echo "Not signed in to Expo. Run:  npx expo login   (then run this script again)"; exit 1
fi

# The app reads EXPO_PUBLIC_NESSIE_KEY / EXPO_PUBLIC_GODADDY_ANS_KEY / _SECRET from .env when it is bundled. Those values end
# up inside the published update, so anyone who opens it can read them: use sandbox/test keys only, and rotate them afterwards.
[ -f .env ] || echo "No .env found: the update will run with simulated services only."

npx tsc --noEmit
VITE_CONFIG_NATIVE_IGNORE_WARNING=true npx vitest run

# One-time project setup (creates the project on your Expo account and wires expo-updates). Safe to repeat.
npx eas-cli@latest init --non-interactive --force
npx eas-cli@latest update:configure --non-interactive || true

npx eas-cli@latest update --branch judges --message "Artemis demo for judges" --non-interactive
echo
echo "Done. Open the 'Preview' link printed above (or the branch 'judges' on expo.dev) and share its QR code."
