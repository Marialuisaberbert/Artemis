import { useLocalSearchParams } from 'expo-router';
import { TripMode } from '../src/features/trip/TripMode';

export default function TripModeRoute() {
  const { id } = useLocalSearchParams<{ id: string }>();
  return <TripMode tripID={id} />;
}
