import { PlannerSheet } from '../src/features/create/PlannerSheet';

export default function PlannerRoute() {
  return <PlannerSheet />;
}
