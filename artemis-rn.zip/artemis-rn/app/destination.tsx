import { router, useLocalSearchParams } from 'expo-router';
import { DestinationViewer, useDestinations } from '../src/features/destination/DestinationViewer';

/** The viewer opened from the world, full screen. */
export default function DestinationRoute() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const destinations = useDestinations();
  return (
    <DestinationViewer
      destinations={destinations} startID={id} showsClose onClose={() => router.back()}
      onStart={(d) => router.replace({ pathname: '/create', params: { preset: d.id } })}
    />
  );
}
