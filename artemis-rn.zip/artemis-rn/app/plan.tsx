import { useLocalSearchParams } from 'expo-router';
import { PlanningFlow } from '../src/features/planning/PlanningFlow';

export default function PlanRoute() {
  const { id } = useLocalSearchParams<{ id: string }>();
  return <PlanningFlow tripID={id} />;
}
