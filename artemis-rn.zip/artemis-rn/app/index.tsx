import { RootGate } from '../src/features/shell/RootGate';

export default function Index() {
  return <RootGate />;
}
