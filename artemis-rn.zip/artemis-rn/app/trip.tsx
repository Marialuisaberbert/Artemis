import { useLocalSearchParams } from 'expo-router';
import { TripDetail } from '../src/features/trip/TripDetail';

export default function TripRoute() {
  const { id } = useLocalSearchParams<{ id: string }>();
  return <TripDetail tripID={id} />;
}
