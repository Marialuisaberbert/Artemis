import { useLocalSearchParams } from 'expo-router';
import { CreateTripFlow } from '../src/features/create/CreateTripFlow';

export default function CreateRoute() {
  const { preset } = useLocalSearchParams<{ preset?: string }>();
  return <CreateTripFlow presetID={preset} />;
}
