import React, { useEffect } from 'react';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { Newsreader_400Regular, Newsreader_400Regular_Italic, Newsreader_500Medium, useFonts } from '@expo-google-fonts/newsreader';
import { colors } from '../src/design/theme';
import { NotificationBannerHost } from '../src/features/shell/NotificationBanner';
import { tripStore, useTripStore } from '../src/store/useTripStore';

SplashScreen.preventAutoHideAsync().catch(() => {});

export default function RootLayout() {
  const [fontsLoaded, fontError] = useFonts({ Newsreader_400Regular, Newsreader_400Regular_Italic, Newsreader_500Medium });
  const ready = useTripStore((s) => s.ready);
  useEffect(() => { void tripStore.getState().hydrate(); }, []);
  const go = (fontsLoaded || !!fontError) && ready;
  useEffect(() => { if (go) SplashScreen.hideAsync().catch(() => {}); }, [go]);
  if (!go) return null;
  return (
    <GestureHandlerRootView style={{ flex: 1, backgroundColor: colors.black }}>
      <SafeAreaProvider>
        <StatusBar style="light" />
        {/* Between scenes: crossfade, scale and parallax. No default push transitions. */}
        <Stack screenOptions={{ headerShown: false, animation: 'fade', contentStyle: { backgroundColor: colors.black } }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="create" options={{ presentation: 'fullScreenModal', animation: 'slide_from_bottom' }} />
          <Stack.Screen name="planner" options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
          <Stack.Screen name="plan" options={{ presentation: 'fullScreenModal', animation: 'slide_from_bottom' }} />
          <Stack.Screen name="destination" options={{ presentation: 'fullScreenModal', animation: 'fade' }} />
          <Stack.Screen name="ticket" options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
          <Stack.Screen name="inbox" options={{ presentation: 'modal', animation: 'slide_from_bottom' }} />
          <Stack.Screen name="tripmode" options={{ presentation: 'fullScreenModal', animation: 'fade', animationDuration: 900 }} />
        </Stack>
        <NotificationBannerHost />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
