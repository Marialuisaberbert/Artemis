import { useLocalSearchParams } from 'expo-router';
import {
  CreditsScreen, FriendsScreen, LocationScreen, PaymentScreen, PreferencesScreen, PrototypeToolsScreen, StyleScreen, TrustPolicyScreen,
} from '../src/features/profile/ProfileSubScreens';

export default function ProfileSubRoute() {
  const { section } = useLocalSearchParams<{ section: string }>();
  switch (section) {
    case 'preferences': return <PreferencesScreen />;
    case 'policy': return <TrustPolicyScreen />;
    case 'style': return <StyleScreen />;
    case 'payment': return <PaymentScreen />;
    case 'friends': return <FriendsScreen />;
    case 'tools': return <PrototypeToolsScreen />;
    case 'location': return <LocationScreen />;
    default: return <CreditsScreen />;
  }
}
