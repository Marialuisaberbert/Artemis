import { useLocalSearchParams } from 'expo-router';
import { TicketScreen } from '../src/features/ticket/TicketScreen';

export default function TicketRoute() {
  const { id } = useLocalSearchParams<{ id: string }>();
  return <TicketScreen tripID={id} />;
}
