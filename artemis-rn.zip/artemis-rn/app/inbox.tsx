import { InboxScreen } from '../src/features/home/InboxScreen';

export default function InboxRoute() {
  return <InboxScreen />;
}
