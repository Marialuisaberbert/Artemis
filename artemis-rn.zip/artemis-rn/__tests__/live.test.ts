import { describe, expect, it } from 'vitest';
import { AnsRegistryClient, ANS_STAND_IN_HOST, LiveIdentityService } from '../src/domain/trust/ans';
import { DecisionEngine } from '../src/domain/trust/decisionEngine';
import { agentFor, demoAccount, demoPolicy, impostorFor } from '../src/domain/trust/demoData';
import { KeyValueStorage, NessieError, NessieLedger } from '../src/domain/trust/nessie';
import { LedgerFinancialService, MockIdentityService, MockPolicyService, latencyNone } from '../src/domain/trust/services';
import { ArtemisTrustEngine, BookingIntent } from '../src/domain/trust/trustEngine';
import { MockTravelSearchService } from '../src/domain/trips/search';
import { InMemoryTripPersistence } from '../src/domain/trips/snapshot';
import { createTripStore, pacingInstant } from '../src/store/tripStore';
import { runDemoToDecision } from './helpers';

// ── A fake Nessie: it stores what it is given and never moves a balance, like the real sandbox. ──

function fakeNessie(opts: { down?: boolean } = {}) {
  const db = { customers: 0, accounts: new Map<string, { balance: number; account_number: string }>(), purchases: new Map<string, { amount: number; purchase_date: string; status?: string }[]>() };
  const calls: string[] = [];
  const respond = (status: number, body: unknown) => Promise.resolve({ ok: status < 400, status, json: async () => body } as Response);
  const impl = (async (url: string, init?: RequestInit) => {
    if (opts.down) throw new TypeError('network down');
    const u = new URL(url);
    const method = init?.method ?? 'GET';
    calls.push(`${method} ${u.pathname}`);
    if (u.searchParams.get('key') !== 'test-key') return respond(401, {});
    const body = init?.body ? JSON.parse(String(init.body)) : {};
    if (method === 'POST' && u.pathname === '/customers') return respond(201, { objectCreated: { _id: `cust-${++db.customers}` } });
    if (method === 'POST' && u.pathname.endsWith('/accounts')) {
      const id = `acct-${db.accounts.size + 1}`;
      db.accounts.set(id, { balance: body.balance, account_number: `00000000000${1000 + db.accounts.size}` });
      db.purchases.set(id, []);
      return respond(201, { objectCreated: { _id: id } });
    }
    if (method === 'POST' && u.pathname === '/merchants') return respond(201, { objectCreated: { _id: 'merchant-1' } });
    const purchases = u.pathname.match(/^\/accounts\/([^/]+)\/purchases$/);
    if (purchases) {
      const list = db.purchases.get(purchases[1]);
      if (!list) return respond(404, {});
      if (method === 'POST') { list.push({ amount: body.amount, purchase_date: body.purchase_date, status: body.status }); return respond(201, { objectCreated: { _id: `p-${list.length}` } }); }
      return respond(200, list);
    }
    const account = u.pathname.match(/^\/accounts\/([^/]+)$/);
    if (account) { const a = db.accounts.get(account[1]); return a ? respond(200, { _id: account[1], ...a }) : respond(404, {}); }
    return respond(404, {});
  }) as unknown as typeof fetch;
  return { impl, db, calls };
}

const memoryStorage = (): KeyValueStorage & { data: Map<string, string> } => {
  const data = new Map<string, string>();
  return { data, getItem: async (k) => data.get(k) ?? null, setItem: async (k, v) => { data.set(k, v); }, removeItem: async (k) => { data.delete(k); } };
};

const NOW = Date.UTC(2026, 8, 20, 12);
const ledgerWith = (server: ReturnType<typeof fakeNessie>, storage = memoryStorage()) =>
  new NessieLedger({ apiKey: 'test-key', storage, fetchImpl: server.impl, clock: () => NOW });

describe('Nessie: a real bank account behind the financial check', () => {
  it('opens an account once and reads back the same $4,820 available and $340 spent this month', async () => {
    const server = fakeNessie();
    const ledger = ledgerWith(server);
    const first = await ledger.state();
    expect(first).toMatchObject({ availableBalance: 4820, monthToDateTravelSpend: 340, source: 'nessie' });
    expect(first.accountName).toMatch(/^Checking ••\d{4}$/);
    await ledger.state();
    expect(server.calls.filter((c) => c === 'POST /customers')).toHaveLength(1);
  });

  it('every purchase it records carries a status, because Nessie will not list purchases without one', async () => {
    const server = fakeNessie();
    const ledger = ledgerWith(server);
    await ledger.record(1094, 'TAP Air Portugal');
    const all = [...server.db.purchases.values()].flat();
    expect(all.length).toBe(2); // the seed spend and the booking
    expect(all.every((p) => p.status === 'completed')).toBe(true);
  });

  it('a recorded booking lowers what is available and raises the month’s travel spend', async () => {
    const ledger = ledgerWith(fakeNessie());
    await ledger.record(1094, 'Flight');
    expect(await ledger.state()).toMatchObject({ availableBalance: 4820 - 1094, monthToDateTravelSpend: 340 + 1094 });
  });

  it('remembers the account across app launches, and reset opens a fresh one', async () => {
    const server = fakeNessie();
    const storage = memoryStorage();
    await ledgerWith(server, storage).state();
    await ledgerWith(server, storage).state();
    expect(server.db.accounts.size).toBe(1);
    const again = ledgerWith(server, storage);
    await again.reset();
    await again.state();
    expect(server.db.accounts.size).toBe(2);
  });

  it('opens a new account if the saved one has disappeared from Nessie', async () => {
    const server = fakeNessie();
    const storage = memoryStorage();
    const ledger = ledgerWith(server, storage);
    await ledger.state();
    server.db.accounts.clear();
    expect(await ledger.state()).toMatchObject({ availableBalance: 4820 });
  });

  it('throws a clear error when Nessie cannot be reached, or rejects the key', async () => {
    await expect(ledgerWith(fakeNessie({ down: true })).state()).rejects.toBeInstanceOf(NessieError);
    const wrong = new NessieLedger({ apiKey: 'wrong', storage: memoryStorage(), fetchImpl: fakeNessie().impl });
    await expect(wrong.state()).rejects.toMatchObject({ status: 401 });
  });

  it('the financial service reads the live account, and falls back to the demo account when offline', async () => {
    const live = new LedgerFinancialService(ledgerWith(fakeNessie()), demoAccount, latencyNone);
    expect((await live.currentState({} as never)).source).toBe('nessie');
    const offline = new LedgerFinancialService(ledgerWith(fakeNessie({ down: true })), demoAccount, latencyNone);
    const state = await offline.currentState({} as never);
    expect(state.source).toBeUndefined();
    expect(state.availableBalance).toBe(demoAccount().availableBalance);
  });
});

// ── A fake ANS registry: it answers by exact host, and only knows the stand-in agent. ──

function fakeAns(opts: { down?: boolean; known?: string[] } = {}) {
  const known = opts.known ?? [ANS_STAND_IN_HOST];
  const urls: string[] = [];
  const impl = (async (url: string, init?: RequestInit) => {
    if (opts.down) throw new TypeError('network down');
    urls.push(url);
    const auth = (init?.headers as Record<string, string>)?.Authorization;
    if (auth !== 'sso-key key:secret') return { ok: false, status: 401, json: async () => ({}) } as Response;
    const host = new URL(url).searchParams.get('agentHost') ?? '';
    const agents = known.includes(host)
      ? [{ ansName: `ans://v1.0.0.${host}`, agentId: 'agent-1', agentDisplayName: 'Travel Agent', agentHost: host, status: 'ACTIVE', registrationTimestamp: '2026-08-01T00:00:00Z', endpoints: [{ protocol: 'A2A' }] }]
      : [];
    return { ok: true, status: 200, json: async () => ({ agents, totalCount: agents.length }) } as Response;
  }) as unknown as typeof fetch;
  return { impl, urls };
}

const liveIdentity = (server: ReturnType<typeof fakeAns>) =>
  new LiveIdentityService(new AnsRegistryClient({ key: 'key', secret: 'secret', fetchImpl: server.impl }), new MockIdentityService());

describe('ANS: identity checked against a real agent registry', () => {
  it('verifies a legitimate provider agent through the registry, and marks the result live', async () => {
    const server = fakeAns();
    const result = await liveIdentity(server).verifyAgent(agentFor('TAP Air Portugal'));
    expect(result).toMatchObject({ status: 'passed', source: 'live' });
    expect(result.description).toContain('stands in for');
    expect(server.urls[0]).toContain(`agentHost=${encodeURIComponent(ANS_STAND_IN_HOST)}`);
    expect(result.metadata.find((m) => m.label === 'Status')?.value).toBe('ACTIVE');
  });

  it('blocks an impostor: the registry has no record of a lookalike domain', async () => {
    const result = await liveIdentity(fakeAns()).verifyAgent(impostorFor('TAP Air Portugal'));
    expect(result).toMatchObject({ status: 'failed', source: 'live' });
    expect(result.description).toContain('tapairportugal-agent.io');
    expect(result.metadata.find((m) => m.label === 'ANS registry')?.value).toBe('No record found');
  });

  it('blocks a provider Artemis does not work with when it calls from a host the registry has never heard of', async () => {
    const result = await liveIdentity(fakeAns()).verifyAgent({ name: 'X', claimedIdentity: 'Unknown Air', domain: 'unknown-air.io' });
    expect(result).toMatchObject({ status: 'failed', source: 'live' });
  });

  it('falls back to the simulated identity check, and says so, when the registry is unreachable', async () => {
    const result = await liveIdentity(fakeAns({ down: true })).verifyAgent(agentFor('TAP Air Portugal'));
    expect(result).toMatchObject({ status: 'passed', source: 'simulated' });
  });

  it('a rejected key is treated as unreachable, not as a failed identity', async () => {
    const bad = new LiveIdentityService(new AnsRegistryClient({ key: 'nope', secret: 'nope', fetchImpl: fakeAns().impl }), new MockIdentityService());
    expect((await bad.verifyAgent(agentFor('TAP Air Portugal'))).source).toBe('simulated');
  });
});

describe('Trust results say whether they were live or simulated', () => {
  const request = (impostor = false): BookingIntent => ({
    id: 'book-tap', kind: 'flight', provider: 'TAP Air Portugal', agent: impostor ? impostorFor('TAP Air Portugal') : agentFor('TAP Air Portugal'),
    unitAmount: 547, travelers: 2, detail: 'GIG → FCO · TAP Air Portugal',
  });

  it('with no keys, identity and the account are simulated and the policy runs on the device', async () => {
    const trust = ArtemisTrustEngine.simulated(latencyNone);
    const result = await trust.evaluateBooking(request(), demoPolicy(), demoAccount());
    expect([result.identity.source, result.policy.source, result.financial.source]).toEqual(['simulated', 'device', 'simulated']);
  });

  it('with live identity and a live account, those two say live and the policy runs on the device', async () => {
    const ledger = ledgerWith(fakeNessie());
    const engine = new ArtemisTrustEngine(new DecisionEngine(liveIdentity(fakeAns()), new MockPolicyService(), new LedgerFinancialService(ledger, demoAccount)));
    const result = await engine.evaluateBooking(request(), demoPolicy());
    expect(result.decision).toBe('autoApproved');
    expect([result.identity.source, result.policy.source, result.financial.source]).toEqual(['live', 'device', 'live']);
    expect(result.financial.metadata[0].value).toContain('Capital One Nessie');
  });

  it('an impostor is blocked by the live registry, and the account is never read', async () => {
    const nessie = fakeNessie();
    const engine = new ArtemisTrustEngine(new DecisionEngine(liveIdentity(fakeAns()), new MockPolicyService(), new LedgerFinancialService(ledgerWith(nessie), demoAccount)));
    const result = await engine.evaluateBooking(request(true), demoPolicy());
    expect(result.decision).toBe('blocked');
    expect(nessie.calls).toHaveLength(0);
  });
});

describe('The store with a real bank behind it', () => {
  const setup = async () => {
    const nessie = fakeNessie();
    const ledger = ledgerWith(nessie);
    const store = createTripStore({
      persistence: new InMemoryTripPersistence(), search: new MockTravelSearchService(latencyNone), pacing: pacingInstant, ledger,
      trust: new ArtemisTrustEngine(new DecisionEngine(new MockIdentityService(), new MockPolicyService(), new LedgerFinancialService(ledger, () => store.getState().financial))),
    });
    await store.getState().hydrate();
    return { store, nessie, ledger };
  };
  const settle = () => new Promise((r) => setTimeout(r, 20));

  it('pulls the live balance on launch', async () => {
    const { store } = await setup();
    await settle();
    expect(store.getState().financial).toMatchObject({ source: 'nessie', availableBalance: 4820, monthToDateTravelSpend: 340 });
  });

  it('books through the trust check and posts the purchase to the account', async () => {
    const { store, nessie } = await setup();
    const id = await runDemoToDecision(store);
    store.getState().chooseFlight(id, 'tap');
    await store.getState().bookFlight(id);
    await settle();
    const posted = [...nessie.db.purchases.values()].flat().filter((p) => p.amount === 1094);
    expect(posted).toHaveLength(1);
    expect(store.getState().financial.availableBalance).toBe(4820 - 1094);
    expect(store.getState().financial.source).toBe('nessie');
  });

  it('reset demo data opens a fresh account', async () => {
    const { store, nessie } = await setup();
    await settle();
    store.getState().resetDemo();
    await settle();
    expect(nessie.db.accounts.size).toBe(2);
  });

  it('keeps working on the demo account when the bank is unreachable', async () => {
    const down = fakeNessie({ down: true });
    const ledger = ledgerWith(down);
    const store = createTripStore({
      persistence: new InMemoryTripPersistence(), search: new MockTravelSearchService(latencyNone), pacing: pacingInstant, ledger,
      trust: new ArtemisTrustEngine(new DecisionEngine(new MockIdentityService(), new MockPolicyService(), new LedgerFinancialService(ledger, () => store.getState().financial))),
    });
    await store.getState().hydrate();
    const id = await runDemoToDecision(store);
    store.getState().chooseFlight(id, 'tap');
    await store.getState().bookFlight(id);
    expect(store.getState().trip(id)?.stage).toBe('booked');
    expect(store.getState().activeCheck?.result?.financial.source).toBe('simulated');
  });
});
