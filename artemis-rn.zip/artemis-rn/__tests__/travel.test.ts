import { beforeAll, describe, expect, it } from 'vitest';
import { makeStore, runDemoToDecision } from './helpers';
import { TripMatchingService, TravelerPreferences, overlapRows } from '../src/domain/matching/matchingService';
import { anyTime, mariaDemo, sofiaDemo, windowLabel } from '../src/domain/matching/preferences';
import { Travelers } from '../src/domain/matching/traveler';
import { MockTravelSearchService, generatedFlights, romeFlights } from '../src/domain/trips/search';
import { romeStart, seedParis, seedRome } from '../src/domain/trips/seed';
import { HotelCatalog } from '../src/domain/destinations/hotels';
import { Airports } from '../src/domain/destinations/geo';
import { Destinations } from '../src/domain/destinations/destinations';
import { DestinationService } from '../src/domain/destinations/destinationService';
import { nearestPlace, rioPlace } from '../src/domain/destinations/place';
import { DailyContextService, greetingText } from '../src/domain/daily/dailyContext';
import { TicketCutModel, CutEvent } from '../src/domain/ticket/cutModel';
import { DecisionEngine } from '../src/domain/trust/decisionEngine';
import { demoAccount, demoPolicy } from '../src/domain/trust/demoData';
import { AgentRequest, FinancialState, VerificationResult } from '../src/domain/trust/models';
import { MockFinancialService, MockIdentityService, MockPolicyService, PolicyService, FinancialService } from '../src/domain/trust/services';
import { TrustPolicy, PolicyAnswers } from '../src/domain/trust/policy';
import { ArtemisTrustEngine, flightIntent } from '../src/domain/trust/trustEngine';
import { arrivalDayOffset, arrivalLocal, departureLocal, flightDuration, flightArrival, flightDeparture, layovers, legArriveLocal } from '../src/domain/trips/flights';
import { JourneySimulator } from '../src/domain/trips/journey';
import { ItineraryBuilder } from '../src/domain/trips/itinerary';
import { TripPlanner } from '../src/domain/trips/planner';
import { Zoned, countdown, deviceTimeZone, hoursMinutes, parts, timeZone } from '../src/domain/shared/time';
import { InMemoryTripPersistence } from '../src/domain/trips/snapshot';
import { usd } from '../src/domain/shared/money';
import { Booking, flightBooking, hotelBooking, isBooked, travelerCount, everyoneJoined, everyoneSubmittedPreferences, ticketLabel, tripTitle, isSoloPlanning, soloTrail } from '../src/domain/trips/trip';
import { hotelNights } from '../src/domain/trips/itinerary';
import { selectedFlight } from '../src/domain/trips/trip';
import type { TripStore } from '../src/store/tripStore';
import type { ItineraryEvent } from '../src/domain/trips/trip';

const NOW0 = 1_789_000_000 * 1000;
const start = romeStart(NOW0);
const matching = new TripMatchingService();
const maria: TravelerPreferences = { traveler: Travelers.maria, preferences: mariaDemo() };
const sofia: TravelerPreferences = { traveler: Travelers.sofia, preferences: sofiaDemo() };
const shared = matching.combinePreferences([maria, sofia]);
const flights = romeFlights(start);
const byId = (id: string) => flights.find((f) => f.id === id)!;
const tap = byId('tap'), ita = byId('ita'), latam = byId('latam');

describe('Preference intersection', () => {
  it('shared flight budget is the lower limit ($600)', () => expect(shared.flightBudget).toBe(600));
  it('shared hotel budget is $200/night', () => expect(shared.hotelBudget).toBe(200));
  it('0 stops preferred, 1 stop acceptable', () => { expect(shared.stopsPreferred).toBe(0); expect(shared.stopsAcceptable).toBe(1); });
  it('central location is shared (and a MUST HAVE)', () => { expect(shared.location).toBe('central'); expect(shared.locationStrength).toBe('must'); });
  it('departure is after 10 AM', () => expect(shared.window).toEqual({ startHour: 10, endHour: 24 }));
  it("hotel style is 'Boutique or Modern', a NICE TO HAVE", () => {
    expect(shared.hotelStyles).toEqual(['boutique', 'modern']);
    expect(shared.constraints.find((c) => c.field === 'hotelStyle')?.strength).toBe('nice');
  });
  it("budgets are MUST HAVE, stops cap comes from Maria's MUST", () => {
    expect(shared.flightBudgetStrength).toBe('must');
    expect(shared.constraints.find((c) => c.field === 'maxStops')?.strength).toBe('must');
  });
  it('no conflicts in the demo', () => expect(shared.conflicts).toEqual([]));
  const rows = overlapRows(shared);
  it('overlap reads SHARED then FLEXIBLE, with stops split in two', () => {
    expect(rows.map((r) => r.agreement)).toEqual(['shared', 'shared', 'shared', 'shared', 'flexible', 'flexible', 'flexible']);
    expect(rows.some((r) => r.id === 'stops-pref' && r.value === 'Nonstop preferred' && r.agreement === 'flexible')).toBe(true);
    expect(rows.some((r) => r.id === 'stops-ok' && r.agreement === 'shared')).toBe(true);
  });
  it('different departure windows and hotel styles are FLEXIBLE, not averaged', () => {
    expect(rows.find((r) => r.id === 'departureWindow')?.agreement).toBe('flexible');
    expect(rows.find((r) => r.id === 'hotelStyle')?.agreement).toBe('flexible');
  });
  it("brief's example: 10 AM–8 PM ∩ 8 AM–6 PM = 10 AM–6 PM", () => {
    const m2 = mariaDemo(); m2.departureWindow = { startHour: 10, endHour: 20 };
    const s2 = sofiaDemo(); s2.departureWindow = { startHour: 8, endHour: 18 };
    const example = matching.combinePreferences([{ traveler: Travelers.maria, preferences: m2 }, { traveler: Travelers.sofia, preferences: s2 }]);
    expect(example.window && windowLabel(example.window)).toBe('10 AM–6 PM');
  });
  it('disjoint departure windows are reported as a conflict, not averaged', () => {
    const s3 = sofiaDemo(); s3.departureWindow = { startHour: 5, endHour: 9 };
    const disjoint = matching.combinePreferences([maria, { traveler: Travelers.sofia, preferences: s3 }]);
    expect(disjoint.window).toBeUndefined();
    expect(disjoint.conflicts.some((c) => c.id === 'window')).toBe(true);
    expect(overlapRows(disjoint).some((r) => r.agreement === 'conflict')).toBe(true);
  });
  it('if Sofia makes nonstop a MUST, nonstop becomes the cap', () => {
    const s4 = sofiaDemo(); s4.strengths.maxStops = 'must';
    expect(matching.combinePreferences([maria, { traveler: Travelers.sofia, preferences: s4 }]).stopsAcceptable).toBe(0);
  });
  it('two MUST HAVE locations that differ are a conflict', () => {
    const s5 = sofiaDemo(); s5.location = 'quiet'; s5.strengths.location = 'must';
    const m5 = mariaDemo(); m5.strengths.location = 'must';
    const c = matching.combinePreferences([{ traveler: Travelers.maria, preferences: m5 }, { traveler: Travelers.sofia, preferences: s5 }]);
    expect(c.conflicts.some((x) => x.id === 'location')).toBe(true);
  });
});

describe('Flights: times, fares and match scores', () => {
  it('TAP: Rio 10:45 PM → Lisbon → Rome 6:20 PM, 1 stop, 14h 35m', () => {
    expect(departureLocal(tap)).toBe('10:45 PM');
    expect(arrivalLocal(tap)).toBe('6:20 PM');
    expect(tap.legs.length - 1).toBe(1);
    expect(hoursMinutes(flightDuration(tap))).toBe('14h 35m');
  });
  it('TAP lands in Lisbon at 12:20 PM local, with a 2h 15m connection', () => {
    expect(legArriveLocal(tap.legs[0])).toBe('12:20 PM');
    expect(hoursMinutes(layovers(tap)[0].duration)).toBe('2h 15m');
  });
  it('ITA is nonstop, 11h 35m, lands 7:05 AM the next day', () => {
    expect(ita.legs.length).toBe(1);
    expect(hoursMinutes(flightDuration(ita))).toBe('11h 35m');
    expect(arrivalLocal(ita)).toBe('7:05 AM');
    expect(arrivalDayOffset(ita)).toBe(1);
  });
  it('LATAM: 11:10 AM via São Paulo, 17h 55m', () => {
    expect(departureLocal(latam)).toBe('11:10 AM');
    expect(hoursMinutes(flightDuration(latam))).toBe('17h 55m');
  });
  it('fares are $547 / $589 / $512', () => {
    expect([tap.farePerTraveler, ita.farePerTraveler, latam.farePerTraveler]).toEqual([547, 589, 512]);
  });

  const pick = matching.recommendHotel(HotelCatalog.hotels('rome'), shared, 5);
  const rec = matching.recommendFlights(flights, shared, [maria, sofia], pick?.hotel);
  it('hotel pick is The Hoxton Rome (central, ≤ $200)', () => expect(pick?.hotel.name).toBe('The Hoxton Rome'));
  it('hotel excludes Casa Monti ($228, over budget) and the quiet loft (not central)', () => expect(pick).toBeDefined());
  it('three options fit the shared constraints', () => expect(rec.matches.map((m) => m.option.id).sort()).toEqual(['ita', 'latam', 'tap']));
  it('scores: TAP 93 · ITA 91 · LATAM 87', () => {
    const p = (id: string) => rec.matches.find((m) => m.option.id === id)?.match.percent;
    expect([p('tap'), p('ita'), p('latam')]).toEqual([93, 91, 87]);
  });
  it('best group match is TAP', () => expect(rec.matches[0].option.id).toBe('tap'));
  it('the $850 premium fare is kept out of the matches and says why', () => {
    expect(rec.outside[0].option.id).toBe('ita-premium');
    expect(rec.outside[0].match.violation).toContain('$250');
  });
  const tapReasons = rec.matches.find((m) => m.option.id === 'tap')!.match.reasons;
  it('every score is explained (met and partial reasons)', () => {
    expect(tapReasons.some((r) => r.kind === 'met')).toBe(true);
    expect(tapReasons.some((r) => r.kind === 'partial')).toBe(true);
  });
  it("TAP reasons name Sofia's nonstop preference honestly", () => expect(tapReasons.some((r) => r.text.includes('Sofia prefers nonstop'))).toBe(true));

  describe('Group ranking', () => {
    const ranks = { maria: ['tap', 'ita', 'latam'], sofia: ['ita', 'tap', 'latam'] };
    const order = matching.groupOrder(ranks, rec.matches);
    it('group order is TAP, ITA, LATAM', () => expect(order.map((o) => o.optionID)).toEqual(['tap', 'ita', 'latam']));
    it('TAP and ITA tie on points; the tie is labelled as broken by match', () => {
      expect(order[0].points).toBe(order[1].points);
      expect(order[0].brokenByMatch).toBe(true);
    });
    it("aligned decision: 'ARTEMIS FOUND A MATCH' → TAP", () => {
      const d = matching.decide(order, ranks, rec.matches, [Travelers.maria, Travelers.sofia], [maria, sofia]);
      expect(d?.kind).toBe('aligned'); expect(d?.primaryOptionID).toBe('tap'); expect(d?.headline).toBe('ARTEMIS FOUND A MATCH');
    });
    const clash = { maria: ['latam', 'ita', 'tap'], sofia: ['tap', 'ita', 'latam'] };
    const clashOrder = matching.groupOrder(clash, rec.matches);
    const tradeoff = matching.decide(clashOrder, clash, rec.matches, [Travelers.maria, Travelers.sofia], [maria, sofia]);
    it("if the leading option is someone's last choice, Artemis shows a trade-off", () => {
      expect(tradeoff?.kind).toBe('tradeoff'); expect(tradeoff?.alternativeOptionID).toBeDefined();
    });
    it('the trade-off names both choices and refuses to pick', () => {
      expect(new Set([tradeoff?.primaryOptionID, tradeoff?.alternativeOptionID])).toEqual(new Set(['tap', 'latam']));
      expect(tradeoff?.chosenOptionID).toBeUndefined();
    });
    it('the trade-off explains the difference in dollars and time', () => expect(tradeoff?.explanation.some((l) => l.includes('saves $35'))).toBe(true));
  });
});

describe('End-to-end: the 60-second demo, through the store', () => {
  let store: TripStore;
  const st = () => store.getState();
  const id = 'trip-rome';
  beforeAll(async () => { store = await makeStore(); });

  it('app opens on ROME WITH SOFIA, not yet planned', () => {
    expect(st().featuredTrip()?.id).toBe('trip-rome');
    expect(st().featuredTrip()?.stage).toBe('draft');
    expect(tripTitle(st().featuredTrip()!)).toBe('ROME WITH SOFIA');
  });
  it('Plan a trip → inviting', () => { st().beginPlanning(id); expect(st().trip(id)?.stage).toBe('inviting'); });
  it('invitation sent', () => { st().invite('sofia', id, 'messages'); expect(st().trip(id)?.members.find((m) => m.traveler.id === 'sofia')?.invite).toBe('invited'); });
  it('Sofia joined', () => { st().acceptInvitation('sofia', id); expect(everyoneJoined(st().trip(id)!)).toBe(true); });
  it('notification: Sofia joined the trip', () => expect(st().inbox[0]?.title).toBe('Sofia joined the trip'));
  it('preferences are private until submitted: nothing shared yet', () => {
    st().continueToPreferences(id);
    expect(st().sharedProfile(id)).toBeUndefined();
  });
  it('Maria submitted; the trip is still waiting on Sofia', async () => {
    await st().submitPreferences(id, 'maria');
    expect(st().trip(id)?.stage).toBe('preferences');
    expect(everyoneSubmittedPreferences(st().trip(id)!)).toBe(false);
  });
  it("after only Maria submits, the shared profile is just hers (no leakage of Sofia's values)", () => {
    expect(st().sharedProfile(id)?.flightBudget).toBe(600);
    expect(st().sharedProfile(id)?.stopsPreferred).toBe(1);
  });
  it('both submitted → overlap, with options found', async () => {
    await st().submitPreferences(id, 'sofia');
    expect(st().trip(id)?.stage).toBe('overlap');
    expect(st().trip(id)?.flightOptions.length).toBe(4);
  });
  it('the notification says Artemis found 3 flights that match you and Sofia', () =>
    expect(st().inbox[0]?.body).toBe('Artemis found 3 flights that match you and Sofia.'));
  it("Sofia's suggested ranking follows HER preferences: ITA, TAP, LATAM", () => {
    st().goTo('options', id); st().goTo('ranking', id);
    st().setRanking(id, 'maria', ['tap', 'ita', 'latam']); st().submitRanking(id, 'maria');
    expect(st().suggestedRanking(id, 'sofia')).toEqual(['ita', 'tap', 'latam']);
  });
  it('notification: Sofia ranked ITA #1', () => {
    st().setRanking(id, 'sofia', st().suggestedRanking(id, 'sofia')); st().submitRanking(id, 'sofia');
    expect(st().inbox.some((n) => n.title === 'Sofia ranked ITA #1')).toBe(true);
  });
  it('everyone ranked → BEST GROUP MATCH: TAP, $547', () => {
    expect(st().trip(id)?.stage).toBe('decision');
    expect(st().trip(id)?.decision?.primaryOptionID).toBe('tap');
  });
  it('group order is shown from BOTH rankings', () => expect(st().groupOrder(id).map((o) => o.optionID)).toEqual(['tap', 'ita', 'latam']));
  it('continue → booking with The Hoxton pre-selected', () => {
    st().chooseFlight(id, 'tap');
    expect(st().trip(id)?.stage).toBe('booking');
    expect(st().trip(id)?.selectedHotelID).toBe('hoxton');
  });
  it('trust check: identity ✓ policy ✓ financial ✓ → AUTO_APPROVED', async () => {
    await st().bookFlight(id);
    const run = st().activeCheck;
    expect(run?.result?.decision).toBe('autoApproved');
    expect(run?.completed.identity?.status).toBe('passed');
    expect(run?.completed.policy?.status).toBe('passed');
    expect(run?.completed.financial?.status).toBe('passed');
  });
  it('booking confirmed: 2 travelers, $1,094, ART-724918, no human needed', () => {
    const run = st().activeCheck;
    expect(run?.phase).toBe('booked');
    expect(run?.booking?.total).toBe(1094);
    expect(run?.booking?.reference).toBe('ART-724918');
    expect(run?.booking?.status).toBe('confirmed');
  });
  it('trip is now booked, with the flight attached', () => {
    expect(st().trip(id)?.stage).toBe('booked');
    expect(flightBooking(st().trip(id)!)?.travelerCount).toBe(2);
  });
  it('the simulated account moved: spent $340 → $1,434', () => expect(st().financial.monthToDateTravelSpend).toBe(1434));
  it('hotel: The Hoxton, 7 nights, $1,323, auto-approved', async () => {
    await st().bookHotel(id);
    expect(hotelBooking(st().trip(id)!)?.total).toBe(1323);
    expect(hotelNights(st().trip(id)!)).toBe(7);
    expect(st().activeCheck?.result?.decision).toBe('autoApproved');
  });
  it('hotel reference follows the flight: ART-724919', () => expect(hotelBooking(st().trip(id)!)?.reference).toBe('ART-724919'));

  describe('Prototype tool: force a trade-off', () => {
    let sT: TripStore;
    const t = () => sT.getState();
    beforeAll(async () => {
      sT = await makeStore();
      t().beginPlanning(id); t().invite('sofia', id, 'link'); t().acceptInvitation('sofia', id); t().continueToPreferences(id);
      await t().submitPreferences(id, 'maria'); await t().submitPreferences(id, 'sofia');
      t().goTo('options', id);
      t().forceTradeoff(id);
    });
    it('forcing a trade-off lands on a TRADE-OFF decision that does not choose for the group', () => {
      expect(t().trip(id)?.stage).toBe('decision');
      expect(t().trip(id)?.decision?.kind).toBe('tradeoff');
      expect(t().trip(id)?.decision?.chosenOptionID).toBeUndefined();
      expect(t().trip(id)?.selectedFlightID).toBeUndefined();
    });
    it('after the group picks one, booking still goes through the trust check', async () => {
      t().chooseFlight(id, 'latam');
      await t().bookFlight(id);
      expect(t().activeCheck?.result?.decision).toBe('autoApproved');
      expect(t().trip(id)?.selectedFlightID).toBe('latam');
    });
  });
});

describe('Trust layer: approval required', () => {
  let s6: TripStore;
  const st = () => s6.getState();
  let id6: string;
  beforeAll(async () => { s6 = await makeStore(); id6 = await runDemoToDecision(s6); st().chooseFlight(id6, 'ita-premium'); await st().bookFlight(id6); });

  it('$850 fare: identity ✓, policy ✕ → APPROVAL_REQUIRED, financial never runs', () => {
    const over = st().activeCheck;
    expect(over?.result?.decision).toBe('approvalRequired');
    expect(over?.result?.failedAt).toBe('policy');
    expect(over?.completed.financial).toBeUndefined();
    expect(over?.completed.identity?.status).toBe('passed');
  });
  it('Artemis holds the booking: nothing booked yet', () => {
    expect(st().activeCheck?.phase).toBe('awaitingApproval');
    expect(st().trip(id6)?.bookings).toEqual([]);
  });
  it('the reason says $250 over the limit', () => expect(st().activeCheck?.result?.policy.description).toContain('$250'));
  it('declining books nothing', () => {
    st().declineActiveCheck();
    expect(st().activeCheck?.phase).toBe('declined');
    expect(st().trip(id6)?.bookings.length).toBe(0);
    expect(st().financial.monthToDateTravelSpend).toBe(340);
  });
  it('approving books it as APPROVED BY YOU', async () => {
    await st().bookFlight(id6);
    await st().approveActiveCheck();
    expect(st().activeCheck?.phase).toBe('booked');
    expect(st().activeCheck?.booking?.status).toBe('approvedByYou');
    expect(st().trip(id6)?.stage).toBe('booked');
  });
});

describe('Trust layer: blocked', () => {
  let s7: TripStore;
  const st = () => s7.getState();
  let id7: string;
  beforeAll(async () => {
    s7 = await makeStore(); id7 = await runDemoToDecision(s7);
    st().chooseFlight(id7, 'tap'); await st().bookFlight(id7, { impostor: true });
  });
  it('lookalike domain → BLOCKED at identity', () => {
    expect(st().activeCheck?.result?.decision).toBe('blocked');
    expect(st().activeCheck?.result?.failedAt).toBe('identity');
  });
  it('policy and financial were never evaluated', () => {
    const blocked = st().activeCheck;
    expect(blocked?.completed.policy).toBeUndefined();
    expect(blocked?.completed.financial).toBeUndefined();
    expect(blocked?.result?.policy.status).toBe('notReached');
    expect(blocked?.result?.financial.status).toBe('notReached');
  });
  it('approve on a BLOCKED booking does nothing', async () => {
    await st().approveActiveCheck();
    expect(st().activeCheck?.phase).toBe('blocked');
    expect(st().trip(id7)?.bookings).toEqual([]);
  });
  it('the domain mismatch is named', () =>
    expect(st().activeCheck?.result?.identity.metadata.some((m) => m.label === 'Domain' && m.value === 'tapairportugal-agent.io')).toBe(true));

  describe('monthly cap and standalone demos', () => {
    let s8: TripStore;
    beforeAll(async () => { s8 = await makeStore(); await s8.getState().runTrustDemo('capReached'); });
    it('monthly cap: policy passes, financial fails → APPROVAL_REQUIRED', () => {
      expect(s8.getState().activeCheck?.result?.failedAt).toBe('financial');
      expect(s8.getState().activeCheck?.completed.policy?.status).toBe('passed');
    });
    it('a standalone demo never creates a booking or moves money', () => {
      expect(s8.getState().activeCheck?.phase).toBe('finished');
      expect(s8.getState().financial.monthToDateTravelSpend).toBe(340);
    });
    it('standalone auto-approved demo finishes without booking', async () => {
      await s8.getState().runTrustDemo('autoApproved');
      expect(s8.getState().activeCheck?.result?.decision).toBe('autoApproved');
      expect(s8.getState().activeCheck?.phase).toBe('finished');
    });
  });

  it('engine: an impostor is blocked and the policy and financial services are never called', async () => {
    const log: string[] = [];
    class SpyPolicy implements PolicyService {
      private inner = new MockPolicyService();
      async evaluateTransaction(r: AgentRequest, p: TrustPolicy): Promise<VerificationResult> { log.push('policy'); return this.inner.evaluateTransaction(r, p); }
      generatePolicy(a: PolicyAnswers): Promise<TrustPolicy> { return this.inner.generatePolicy(a); }
    }
    class SpyFinancial implements FinancialService {
      private inner = new MockFinancialService();
      async currentState(r: AgentRequest): Promise<FinancialState> { log.push('financial.state'); return this.inner.currentState(r); }
      async checkTransaction(r: AgentRequest, p: TrustPolicy, s: FinancialState): Promise<VerificationResult> { log.push('financial.check'); return this.inner.checkTransaction(r, p, s); }
    }
    const spied = new DecisionEngine(new MockIdentityService(), new SpyPolicy(), new SpyFinancial());
    const bad = await new ArtemisTrustEngine(spied).evaluateBooking(flightIntent(tap, 2, true), demoPolicy(), demoAccount());
    expect(bad.decision).toBe('blocked');
    expect(log).toEqual([]);
  });
});

describe('Journey clock and itinerary', () => {
  const sim = new JourneySimulator(tap);
  it('not departed: flight in 4h 32m, boarding in 3h 48m', () => {
    const before = sim.state(sim.time('notDeparted'));
    expect(before.phase).toBe('notDeparted');
    expect(countdown(before.untilDeparture)).toBe('4H 32M');
    expect(countdown(before.untilBoarding)).toBe('3H 48M');
  });
  it('boarding phase', () => expect(sim.state(sim.time('boarding')).phase).toBe('boarding'));
  it('in flight: 5h 42m remaining, still on the first leg', () => {
    const flying = sim.state(sim.time('inFlight'));
    expect(flying.phase).toBe('inFlight');
    expect(countdown(flying.remaining)).toBe('5H 42M');
    expect(flying.legIndex).toBe(0);
    expect(flying.position).toBeGreaterThan(0.9);
    expect(flying.position).toBeLessThan(1.0);
  });
  it('landed: position at the final station', () => {
    const landed = sim.state(sim.time('landed'));
    expect(landed.phase).toBe('landed'); expect(landed.position).toBe(2); expect(landed.remaining).toBe(0);
  });
  it('during the Lisbon connection the plane waits at Lisbon', () => {
    const connecting = sim.state(tap.legs[0].arrive + 3_600_000);
    expect(connecting.isConnecting).toBe(true); expect(connecting.position).toBe(1); expect(connecting.phase).toBe('inFlight');
  });
  it('position never goes backwards over time', () => {
    let last = -1;
    for (let t = sim.departure - 3_600_000; t < sim.arrival + 3_600_000; t += 600_000) {
      const p = sim.state(t).position; expect(p).toBeGreaterThanOrEqual(last); last = p;
    }
  });

  describe('through the store', () => {
    let s: TripStore; let id: string; let events: ItineraryEvent[];
    const st = () => s.getState();
    beforeAll(async () => {
      s = await makeStore(); id = await runDemoToDecision(s);
      st().chooseFlight(id, 'tap'); await st().bookFlight(id); await st().bookHotel(id);
      events = st().itineraryEvents(id);
    });
    it('itinerary is chronological', () => expect(events.every((e, i) => i === 0 || events[i - 1].date <= e.date)).toBe(true));
    it('itinerary: depart Rio, arrive/connect Lisbon, depart Lisbon, arrive Rome, check in, check out', () => {
      expect(events[0].title).toBe('Depart Rio de Janeiro');
      expect(events.some((e) => e.title === 'Connection in Lisbon')).toBe(true);
      expect(events.some((e) => e.title.startsWith('Check in'))).toBe(true);
      expect(events[events.length - 1].title).toBe('Check out');
    });
    it('hotel check-in is after landing', () => expect(events.find((e) => e.kind === 'checkIn')!.date).toBeGreaterThan(flightArrival(byId('tap'))));
    it('Trip Mode starts before departure, then the next event is the Rio departure', () => {
      st().startJourney(id);
      expect(st().journeyState(id)?.phase).toBe('notDeparted');
      expect(st().nextEvent(id)?.kind).toBe('depart');
    });
    it('after landing the next thing is the hotel', () => {
      st().setJourneyPhase('landed', id);
      expect(st().nextEvent(id)?.kind).toBe('checkIn');
    });
  });
});

describe('Natural-language planner', () => {
  const planner = new TripPlanner();
  const draft = planner.parse(TripPlanner.examples[0], Travelers.demoFriends, NOW0);
  it('destination: Rome', () => expect(draft.destination?.id).toBe('rome'));
  it('6 days, with Sofia, $2,000 each', () => {
    expect(draft.days).toBe(6); expect(draft.travelers.map((t) => t.id)).toEqual(['sofia']); expect(draft.budgetPerPerson).toBe(2000);
  });
  it('interests: food and museums', () => { expect(draft.interests).toContain('Food'); expect(draft.interests).toContain('Museums'); });
  it("'in September' becomes a Thursday", () => {
    const tz = timeZone(Airports.gig.timeZoneID);
    expect(parts(draft.start!, tz).weekday).toBe(5); expect(parts(draft.start!, tz).month).toBe(9);
  });
  it('a total budget is split between travelers', () => {
    const two = planner.parse('Lisbon for a long weekend, food and nightlife, $1,000 total', Travelers.demoFriends);
    expect(two.budgetPerPerson).toBe(1000); expect(two.days).toBe(4); expect(two.destination?.id).toBe('lisbon');
  });
  it("a sentence with no destination isn't plannable", () => expect(planner.parse('somewhere warm', []).destination).toBeUndefined());
  it('creating from a draft makes a trip with Sofia invited-to-be', async () => {
    const s = await makeStore();
    const tripID = s.getState().createTripFromDraft(draft);
    expect(tripID && s.getState().trip(tripID)?.members.length).toBe(2);
    expect(tripID && s.getState().trip(tripID)?.stage).toBe('draft');
  });
});

describe('Morning greeting and the ticket', () => {
  const daily = new DailyContextService();
  const romeTrip = seedRome(NOW0);
  it("a trip ahead: 'Rome is N days away'", () => {
    const ctx = daily.context([romeTrip], NOW0);
    expect(ctx.kind).toBe('upcoming');
    if (ctx.kind === 'upcoming') { expect(ctx.city).toBe('Rome'); expect(ctx.daysAway).toBeGreaterThan(0); }
  });
  it("no trip: 'Where are we going?'", () => expect(daily.context([], NOW0)).toEqual({ kind: 'noTrip' }));
  it('a past trip alone counts as no trip', () => expect(daily.context([seedParis(NOW0)], NOW0)).toEqual({ kind: 'noTrip' }));
  it('greeting shows on the first open of a day, once', () => {
    const day0 = DailyContextService.dayKey(NOW0, deviceTimeZone);
    expect(daily.shouldShowGreeting(undefined, NOW0)).toBe(true);
    expect(daily.shouldShowGreeting(day0, NOW0)).toBe(false);
    expect(daily.shouldShowGreeting(day0, NOW0 + 86_400_000)).toBe(true);
  });
  it("mid-trip: 'You're in Rome' with today's plan", () => {
    const booking: Booking = { id: 'b', kind: 'flight', provider: 'TAP', title: 't', subtitle: 's', total: 1, perTraveler: 1, travelerCount: 1, status: 'confirmed', reference: 'ART-1', bookedAt: NOW0 };
    const travelling = { ...seedRome(NOW0), stage: 'booked' as const, bookings: [booking] };
    const ctx = daily.context([travelling], travelling.startDate + 2 * 86_400_000);
    expect(ctx).toEqual({ kind: 'traveling', tripID: 'trip-rome', city: 'Rome', plan: 'Colosseum at blue hour', time: '2:00 PM' });
  });

  it('the ticket starts whole and untouched', () => {
    const cut = new TicketCutModel();
    expect(cut.progress).toBe(0); expect(cut.separation).toBe(0); expect(cut.isCut).toBe(false);
  });
  it('cutting fires ticks, then resistance, then separation, then a single snap, in order', () => {
    const cut = new TicketCutModel();
    const events: CutEvent[] = [];
    for (let i = 1; i <= 20; i++) events.push(...cut.update(i * 0.05));
    const idx = (t: CutEvent['type']) => events.findIndex((e) => e.type === t);
    expect(events.some((e) => e.type === 'tick')).toBe(true);
    expect(events.filter((e) => e.type === 'snap').length).toBe(1);
    expect(idx('resistance')).toBeGreaterThanOrEqual(0);
    expect(idx('resistance')).toBeLessThan(idx('separating'));
    expect(idx('separating')).toBeLessThan(idx('snap'));
  });
  it('the paper resists in the middle: half the drag is less than half the cut', () => {
    expect(TicketCutModel.ease(0.6)).toBeLessThan(0.6); expect(TicketCutModel.ease(1)).toBe(1); expect(TicketCutModel.ease(0.3)).toBe(0.3);
  });
  it('letting go early settles the ticket back', () => {
    const early = new TicketCutModel(); early.update(0.5); early.release();
    expect(early.progress).toBe(0); expect(early.isCut).toBe(false);
  });
  it('the accessible alternative cuts in one step', () => {
    const access = new TicketCutModel();
    expect(access.cutNow().some((e) => e.type === 'snap')).toBe(true); expect(access.isCut).toBe(true); expect(access.separation).toBe(1);
  });
  describe('bookings, greeting and starting point', () => {
    let sN: TripStore; let idN: string;
    const st = () => sN.getState();
    beforeAll(async () => { sN = await makeStore(); idN = await runDemoToDecision(sN); st().chooseFlight(idN, 'tap'); await st().bookFlight(idN); });
    it('the first booked trip is TRIP 001', () => {
      expect(st().trip(idN)?.ticketNumber).toBe(1); expect(st().ticketCounter).toBe(2);
      expect(ticketLabel(st().trip(idN)!.ticketNumber!)).toBe('TRIP 001');
    });
    it('the greeting is marked shown and stays quiet until tomorrow', () => { st().markGreetingShown(); expect(st().shouldShowMorningGreeting()).toBe(false); });
    it('choosing a starting point changes where new trips depart', () => {
      st().chooseLocation({ name: 'Lisbon', country: 'Portugal', latitude: 38.7, longitude: -9.1, airportCode: 'LIS', isDemo: true });
      expect(st().currentPlace.airportCode).toBe('LIS');
    });
  });
  it('the cut is persisted the instant it snaps (ticketCutAt)', async () => {
    const s = await makeStore();
    s.getState().cutTicket('trip-rome');
    expect(s.getState().trip('trip-rome')?.ticketCutAt).toBeTypeOf('number');
  });
});

describe('Other destinations, persistence', () => {
  for (const dest of Destinations.all.filter((d) => d.id !== 'rio')) {
    it(`${dest.city}: four simulated options, all landing after they leave`, () => {
      const f = generatedFlights(Airports.gig, dest, start);
      expect(f.length).toBe(4);
      expect(f.every((o) => flightArrival(o) > flightDeparture(o) && o.farePerTraveler > 0)).toBe(true);
    });
  }
  it('catalogue: ten real destinations, each with a bundled photo slot, coordinates and a description', () => {
    expect(Destinations.all.length).toBe(10);
    expect(Destinations.all.every((d) => d.blurb.length > 0 && d.highlights.length >= 3 && d.photo.file.length > 0)).toBe(true);
  });
  it('discover never suggests where you already are, and ranks by fit', () => {
    const ds = new DestinationService();
    const profile = { styles: ['Culture', 'Food', 'Architecture'], flightPreference: '', hotelPreference: '', budgetLevel: '', favoriteAirports: [], preferredAirlines: [] };
    const ranked = ds.discover(rioPlace, profile, 600);
    expect(ranked.some((d) => d.id === 'rio')).toBe(false);
    expect(ranked.length).toBe(9);
    expect(ds.match(ranked[0], profile, 600).percent).toBeGreaterThanOrEqual(ds.match(ranked[8], profile, 600).percent);
  });
  it('nearest-airport mapping: Lisbon coordinates → Lisbon', () => expect(nearestPlace(38.7, -9.1).airportCode).toBe('LIS'));
  describe('relaunch and reset', () => {
    const disk = new InMemoryTripPersistence();
    let reloaded: TripStore; let id9: string;
    const st = () => reloaded.getState();
    beforeAll(async () => {
      const s9 = await makeStore(disk);
      id9 = await runDemoToDecision(s9);
      s9.getState().chooseFlight(id9, 'tap'); await s9.getState().bookFlight(id9);
      reloaded = await makeStore(disk);
    });
    it('state survives a relaunch (bookings, references, account)', () => {
      expect(flightBooking(st().trip(id9)!)?.reference).toBe('ART-724918');
      expect(st().financial.monthToDateTravelSpend).toBe(1434);
      expect(st().referenceCounter).toBe(724_919);
    });
    it('a live trust check is never persisted', () => {
      expect(st().activeCheck).toBeUndefined();
      expect(JSON.stringify(disk.load())).not.toContain('activeCheck');
    });
    it('reset restores ROME WITH SOFIA in one call', () => {
      st().resetDemo();
      expect(st().trip('trip-rome')?.stage).toBe('draft');
      expect(st().trip('trip-rome')?.bookings).toEqual([]);
      expect(st().financial.monthToDateTravelSpend).toBe(340);
      expect(st().referenceCounter).toBe(724_918);
      expect(isBooked(st().trip('trip-rome')!)).toBe(false);
      expect(travelerCount(st().trip('trip-rome')!)).toBe(1);
    });
  });
});

describe('Traveling alone (TypeScript port additions)', () => {
  const soloProfile = matching.combinePreferences([maria]);
  it('a solo profile is just her preferences, worded for one person', () => {
    expect(soloProfile.travelerCount).toBe(1);
    expect(soloProfile.flightBudget).toBe(600);
    expect(soloProfile.conflicts).toEqual([]);
    const text = overlapRows(soloProfile).map((r) => r.detail).join(' | ');
    expect(text).not.toMatch(/You all|Everyone|both/);
    expect(overlapRows(soloProfile).every((r) => r.agreement === 'shared')).toBe(true);
  });
  it('solo flight reasons never say "both"', () => {
    const pick = matching.recommendHotel(HotelCatalog.hotels('rome'), soloProfile, 5);
    const rec = matching.recommendFlights(flights, soloProfile, [maria], pick?.hotel);
    expect(rec.matches.length).toBeGreaterThan(0);
    for (const m of rec.matches) expect(m.match.reasons.map((r) => r.text).join(' ')).not.toMatch(/both|Both/);
    expect(pick?.reasons.map((r) => r.text).join(' ')).toContain('under your');
  });
  it('the group wording is unchanged for two travelers', () => {
    expect(shared.travelerCount).toBe(2);
    expect(matching.recommendHotel(HotelCatalog.hotels('rome'), shared, 5)?.reasons.some((r) => r.text.includes('shared limit'))).toBe(true);
  });
  it('a solo ranking is a clear match, worded for one', () => {
    const pick = matching.recommendHotel(HotelCatalog.hotels('rome'), soloProfile, 5);
    const rec = matching.recommendFlights(flights, soloProfile, [maria], pick?.hotel);
    const ranks = { maria: rec.matches.map((m) => m.option.id) };
    const order = matching.groupOrder(ranks, rec.matches);
    const d = matching.decide(order, ranks, rec.matches, [Travelers.maria], [maria]);
    expect(d?.kind).toBe('aligned');
    expect(d?.explanation.join(' ')).not.toMatch(/Everyone|group/);
  });
  it('the whole trip works with just you: go solo → preferences → options → book → ticket, with no overlap or ranking steps', async () => {
    const s = await makeStore(); const st = () => s.getState(); const id = 'trip-rome';
    st().beginPlanning(id);
    expect(st().trip(id)?.members.length).toBe(2);
    expect(isSoloPlanning(st().trip(id)!)).toBe(false); // still on the invite step
    st().goSolo(id);
    expect(st().trip(id)?.members.map((m) => m.traveler.id)).toEqual(['maria']);
    expect(st().trip(id)?.stage).toBe('preferences');
    expect(isSoloPlanning(st().trip(id)!)).toBe(true);
    expect(tripTitle(st().trip(id)!)).toBe('ROME');
    await st().submitPreferences(id, 'maria');
    expect(st().trip(id)?.stage).toBe('options'); // nobody to overlap with
    const matches = st().flightMatches(id)!.matches;
    expect(matches.length).toBeGreaterThan(0);
    expect(st().inbox[0]).toMatchObject({ title: 'Your matches are ready', body: `Artemis found ${matches.length} flights that match you.` });
    st().chooseFlight(id, matches[0].option.id); // no ranking, no group decision
    expect(st().trip(id)?.stage).toBe('booking');
    await st().bookFlight(id);
    expect(st().activeCheck?.result?.decision).toBe('autoApproved');
    expect(travelerCount(st().trip(id)!)).toBe(1);
    expect(st().activeCheck?.booking?.total).toBe(selectedFlightFare(st().trip(id)!));
    expect(st().trip(id)?.ticketNumber).toBe(1);
  });
  it('planning with someone still goes through overlap, ranking and a group decision', async () => {
    const s = await makeStore(); const id = await runDemoToDecision(s);
    expect(s.getState().trip(id)?.stage).toBe('decision');
    expect(isSoloPlanning(s.getState().trip(id)!)).toBe(false);
  });
  it('the solo trail is three steps: preferences, options, book', () => {
    expect(soloTrail).toEqual(['preferences', 'options', 'booking']);
  });
  it('going solo keeps friends who already joined and only applies before preferences', async () => {
    const s = await makeStore(); const st = () => s.getState(); const id = 'trip-rome';
    st().beginPlanning(id); st().invite('sofia', id, 'link'); st().acceptInvitation('sofia', id);
    st().goSolo(id);
    expect(st().trip(id)?.members.length).toBe(2);
    st().goTo('options', id); st().goSolo(id);
    expect(st().trip(id)?.stage).toBe('options');
  });
});

describe('Greeting copy (TypeScript port additions)', () => {
  const daily = new DailyContextService();
  it('reads the four contexts exactly', () => {
    expect(greetingText({ kind: 'noTrip' }, 'GOOD MORNING', 'Maria')).toEqual({ eyebrow: 'GOOD MORNING, MARIA', headline: 'WHERE ARE WE GOING?' });
    expect(greetingText({ kind: 'upcoming', tripID: 't', city: 'Rome', daysAway: 12 }, 'GOOD MORNING', 'Maria').headline).toBe('ROME IN 12 DAYS');
    expect(greetingText({ kind: 'upcoming', tripID: 't', city: 'Rome', daysAway: 1 }, 'GOOD MORNING', 'Maria').headline).toBe('ROME TOMORROW');
    expect(greetingText({ kind: 'departingToday', tripID: 't', city: 'Rome' }, 'GOOD MORNING', 'Maria').headline).toBe('ROME. TODAY.');
    expect(greetingText({ kind: 'traveling', tripID: 't', city: 'Rome', plan: 'Colosseum at blue hour', time: '2:00 PM' }, 'GOOD MORNING', 'Maria'))
      .toEqual({ eyebrow: "YOU'RE IN ROME.", headline: 'TODAY: COLOSSEUM AT BLUE HOUR 2:00 PM' });
  });
  it('picks the greeting word by hour', () => {
    const at = (h: number) => Date.UTC(2026, 8, 20, h, 0);
    expect(daily.greetingWord(at(9), timeZone('UTC'))).toBe('GOOD MORNING');
    expect(daily.greetingWord(at(13), timeZone('UTC'))).toBe('GOOD AFTERNOON');
    expect(daily.greetingWord(at(20), timeZone('UTC'))).toBe('GOOD EVENING');
    expect(daily.greetingWord(at(3), timeZone('UTC'))).toBe('GOOD EVENING');
  });
  it('one day away reads as tomorrow through the real context service', () => {
    const trip = seedRome(NOW0);
    const ctx = daily.context([trip], trip.startDate - 86_400_000);
    expect(ctx.kind).toBe('upcoming');
    if (ctx.kind === 'upcoming') expect(greetingText(ctx, 'GOOD MORNING', 'Maria').headline).toBe('ROME TOMORROW');
  });
});

describe('Time and money (TypeScript port additions)', () => {
  it('formats dollars like the Swift app', () => {
    expect(usd(1094)).toBe('$1,094'); expect(usd(4820.55)).toBe('$4,820.55'); expect(usd(340)).toBe('$340'); expect(usd(0)).toBe('$0');
  });
  it('resolves EU/US daylight saving and fixed zones', () => {
    const t = Date.UTC(2026, 8, 25, 12, 0);
    expect(Zoned.time(t, timeZone('Europe/Lisbon'))).toBe('1:00 PM');
    expect(Zoned.time(t, timeZone('Europe/Rome'))).toBe('2:00 PM');
    expect(Zoned.time(t, timeZone('America/New_York'))).toBe('8:00 AM');
    expect(Zoned.time(t, timeZone('America/Sao_Paulo'))).toBe('9:00 AM');
    const winter = Date.UTC(2026, 0, 15, 12, 0);
    expect(Zoned.time(winter, timeZone('Europe/Rome'))).toBe('1:00 PM');
    expect(Zoned.time(winter, timeZone('America/New_York'))).toBe('7:00 AM');
  });
  it('the Rome seed departs the next Sept 24 at midnight in Rio and returns Oct 2 (8 days)', () => {
    const r = seedRome(NOW0);
    const tz = timeZone(Airports.gig.timeZoneID);
    expect(Zoned.day(r.startDate, tz)).toBe('Sep 24'); expect(Zoned.minuteOfDay(r.startDate, tz)).toBe(0);
    expect(Zoned.day(r.endDate, tz)).toBe('Oct 2');
    expect(Zoned.dayUpper(r.startDate, tz) + ' — ' + Zoned.dayUpper(r.endDate, tz)).toBe('SEP 24 — OCT 2');
  });
  it('the anyTime window reads "Any time"', () => expect(windowLabel(anyTime)).toBe('Any time'));
});

const selectedFlightFare = (t: import('../src/domain/trips/trip').Trip): number => (selectedFlight(t)?.farePerTraveler ?? 0) * travelerCount(t);
