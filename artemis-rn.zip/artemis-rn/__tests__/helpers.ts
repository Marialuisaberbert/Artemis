import { ArtemisTrustEngine } from '../src/domain/trust/trustEngine';
import { latencyNone } from '../src/domain/trust/services';
import { MockTravelSearchService } from '../src/domain/trips/search';
import { InMemoryTripPersistence, TripPersistence } from '../src/domain/trips/snapshot';
import { createTripStore, pacingInstant, TripStore } from '../src/store/tripStore';

export async function makeStore(persistence: TripPersistence = new InMemoryTripPersistence()): Promise<TripStore> {
  const store = createTripStore({
    persistence, search: new MockTravelSearchService(latencyNone), trust: ArtemisTrustEngine.simulated(latencyNone), pacing: pacingInstant,
  });
  await store.getState().hydrate();
  return store;
}

/** Runs the whole 60-second demo through the store, up to (not including) booking. */
export async function runDemoToDecision(store: TripStore, mariaRanks: string[] = ['tap', 'ita', 'latam']): Promise<string> {
  const id = 'trip-rome';
  const s = store.getState();
  s.beginPlanning(id);
  s.invite('sofia', id, 'messages');
  s.acceptInvitation('sofia', id);
  s.continueToPreferences(id);
  await s.submitPreferences(id, 'maria');
  await s.submitPreferences(id, 'sofia');
  s.goTo('options', id);
  s.goTo('ranking', id);
  s.setRanking(id, 'maria', mariaRanks);
  s.submitRanking(id, 'maria');
  const sofia = s.suggestedRanking(id, 'sofia');
  s.setRanking(id, 'sofia', sofia);
  s.submitRanking(id, 'sofia');
  return id;
}
