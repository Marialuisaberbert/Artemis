import { describe, expect, it } from 'vitest';
import { AnsRegistryClient, LiveIdentityService } from '../src/domain/trust/ans';
import { agentFor, impostorFor } from '../src/domain/trust/demoData';
import { NessieLedger } from '../src/domain/trust/nessie';
import { MockIdentityService } from '../src/domain/trust/services';

// Talks to the real Nessie sandbox and the real ANS test registry. Skipped unless the keys are in the environment:
//   set -a; source .env; set +a; VITE_CONFIG_NATIVE_IGNORE_WARNING=true npx vitest run live.integration
const nessieKey = process.env.EXPO_PUBLIC_NESSIE_KEY;
const ansKey = process.env.EXPO_PUBLIC_GODADDY_ANS_KEY;
const ansSecret = process.env.EXPO_PUBLIC_GODADDY_ANS_SECRET;

describe.skipIf(!nessieKey)('real Capital One Nessie sandbox', () => {
  it('opens an account, records a booking, and reads it back', async () => {
    const memory = new Map<string, string>();
    const ledger = new NessieLedger({
      apiKey: nessieKey!, storage: { getItem: async (k) => memory.get(k) ?? null, setItem: async (k, v) => void memory.set(k, v), removeItem: async (k) => void memory.delete(k) },
    });
    const before = await ledger.state();
    expect(before).toMatchObject({ availableBalance: 4820, monthToDateTravelSpend: 340, source: 'nessie' });
    await ledger.record(1, 'Artemis integration test');
    const after = await ledger.state();
    expect(after.availableBalance).toBe(4819);
    expect(after.monthToDateTravelSpend).toBe(341);
  }, 60_000);
});

describe.skipIf(!ansKey || !ansSecret)('real GoDaddy ANS test registry', () => {
  const identity = () => new LiveIdentityService(new AnsRegistryClient({ key: ansKey!, secret: ansSecret! }), new MockIdentityService());

  it('verifies a legitimate provider agent through the live registry', async () => {
    const result = await identity().verifyAgent(agentFor('TAP Air Portugal'));
    expect(result).toMatchObject({ status: 'passed', source: 'live' });
  }, 30_000);

  it('blocks an impostor: a lookalike domain has no registry record', async () => {
    const result = await identity().verifyAgent(impostorFor('TAP Air Portugal'));
    expect(result).toMatchObject({ status: 'failed', source: 'live' });
  }, 30_000);
});
