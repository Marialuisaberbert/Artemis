import { isLand, maskCoordinate, WorldMask } from '../worldMask';

/** Sphere maths. A point on the Earth is a unit vector; z is north. All functions are worklets so they can run on the UI thread. */

export type Vec3 = readonly [number, number, number];

export function vecFromLatLon(lat: number, lon: number): Vec3 {
  'worklet';
  const p = (lat * Math.PI) / 180;
  const l = (lon * Math.PI) / 180;
  return [Math.cos(p) * Math.cos(l), Math.cos(p) * Math.sin(l), Math.sin(p)];
}

export function slerp(a: Vec3, b: Vec3, t: number): Vec3 {
  'worklet';
  const d = Math.min(1, Math.max(-1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2]));
  const omega = Math.acos(d);
  if (omega < 1e-6) return a;
  const s = Math.sin(omega);
  const ka = Math.sin((1 - t) * omega) / s;
  const kb = Math.sin(t * omega) / s;
  return [a[0] * ka + b[0] * kb, a[1] * ka + b[1] * kb, a[2] * ka + b[2] * kb];
}

export function latLonOf(v: Vec3): { lat: number; lon: number } {
  'worklet';
  return { lat: (Math.asin(Math.max(-1, Math.min(1, v[2]))) * 180) / Math.PI, lon: (Math.atan2(v[1], v[0]) * 180) / Math.PI };
}

/** The great-circle midpoint, for framing a route. */
export function midpoint(a: { lat: number; lon: number }, b: { lat: number; lon: number }): { lat: number; lon: number } {
  'worklet';
  return latLonOf(slerp(vecFromLatLon(a.lat, a.lon), vecFromLatLon(b.lat, b.lon), 0.5));
}

/** Shortest signed longitude difference, in −180…180. */
export function shortestLon(from: number, to: number): number {
  'worklet';
  let d = to - from;
  while (d > 180) d -= 360;
  while (d < -180) d += 360;
  return d;
}

/** Land as flat unit vectors [x,y,z, x,y,z, …], from the 2° mask. Built once. */
export const LAND: number[] = (() => {
  const out: number[] = [];
  for (let row = 0; row < WorldMask.rows; row++) {
    for (let col = 0; col < WorldMask.columns; col++) {
      if (!isLand(col, row)) continue;
      const c = maskCoordinate(col, row);
      if (c.lat < -60) continue;
      const v = vecFromLatLon(c.lat, c.lon);
      out.push(v[0], v[1], v[2]);
    }
  }
  return out;
})();

/** The projection for one frame. */
export interface View3D {
  cosL: number;
  sinL: number;
  cosP: number;
  sinP: number;
  cx: number;
  cy: number;
  r: number;
}

export function makeView(lat: number, lon: number, width: number, height: number, radius: number, centerY: number): View3D {
  'worklet';
  const l = (lon * Math.PI) / 180;
  const p = (lat * Math.PI) / 180;
  return { cosL: Math.cos(l), sinL: Math.sin(l), cosP: Math.cos(p), sinP: Math.sin(p), cx: width / 2, cy: height * centerY, r: width * radius };
}

/** Screen x, y and depth (> 0 faces the viewer) for a unit vector. */
export function project(v: View3D, x: number, y: number, z: number): { x: number; y: number; depth: number } {
  'worklet';
  const x1 = x * v.cosL + y * v.sinL;
  const y1 = -x * v.sinL + y * v.cosL;
  const depth = x1 * v.cosP + z * v.sinP;
  const up = -x1 * v.sinP + z * v.cosP;
  return { x: v.cx + v.r * y1, y: v.cy - v.r * up, depth };
}

/** A route sampled along its great circles, as flat [x,y,z,leg] quadruples, each lifted above the surface. */
export function sampleRoute(stops: { lat: number; lon: number }[]): number[] {
  const vs = stops.map((s) => vecFromLatLon(s.lat, s.lon));
  const out: number[] = [];
  for (let i = 0; i < vs.length - 1; i++) {
    const a = vs[i];
    const b = vs[i + 1];
    const arc = Math.acos(Math.min(1, Math.max(-1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2])));
    const steps = Math.max(24, Math.floor(arc * 40));
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const lift = 1 + 0.1 * Math.sin(t * Math.PI) * Math.min(1, arc / 1.2 + 0.25);
      const p = slerp(a, b, t);
      out.push(p[0] * lift, p[1] * lift, p[2] * lift, i + t);
    }
  }
  return out;
}

/** The marker nearest a screen point, if it is close enough to mean it. */
export function hitTest(
  px: number, py: number, view: View3D, markers: readonly { id: string; lat: number; lon: number }[],
): string | undefined {
  'worklet';
  let best: string | undefined;
  let bestDist = 34;
  for (let i = 0; i < markers.length; i++) {
    const m = markers[i];
    const v = vecFromLatLon(m.lat, m.lon);
    const p = project(view, v[0], v[1], v[2]);
    if (p.depth <= 0.08) continue;
    const d = Math.hypot(p.x - px, p.y - py);
    if (d < bestDist) { bestDist = d; best = m.id; }
  }
  return best;
}
