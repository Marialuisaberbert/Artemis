import React, { useEffect, useMemo } from 'react';
import { StyleSheet } from 'react-native';
import {
  BlurMask, Canvas, Circle, DashPathEffect, Group, matchFont, Path, Points, RadialGradient, Skia, Text as SkText, vec,
} from '@shopify/react-native-skia';
import type { SkPoint } from '@shopify/react-native-skia';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  cancelAnimation, Easing, SharedValue, useDerivedValue, useFrameCallback, useSharedValue, withDecay, withTiming,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { colors } from '../theme';
import { planePath } from './plane';
import { hitTest, LAND, makeView, project, sampleRoute, shortestLon, vecFromLatLon, View3D } from './math';

// MARK: - Camera

/** The camera: latitude, longitude, size (fraction of width) and height (fraction of height). All animate. */
export interface GlobeCamera {
  lat: SharedValue<number>;
  lon: SharedValue<number>;
  /** Globe radius as a fraction of the view's width. */
  radius: SharedValue<number>;
  /** Where the globe's centre sits, as a fraction of the view's height. */
  centerY: SharedValue<number>;
}

export function useGlobeCamera(initial: { lat: number; lon: number; radius?: number; centerY?: number }): GlobeCamera {
  const lat = useSharedValue(initial.lat);
  const lon = useSharedValue(initial.lon);
  const radius = useSharedValue(initial.radius ?? 0.6);
  const centerY = useSharedValue(initial.centerY ?? 0.5);
  return useMemo(() => ({ lat, lon, radius, centerY }), [lat, lon, radius, centerY]);
}

export interface FlyOptions {
  lat?: number;
  lon?: number;
  radius?: number;
  centerY?: number;
  duration?: number;
  /** cubic-bezier control points; defaults to a gentle ease in-out. */
  curve?: readonly [number, number, number, number];
}

/** Glides the camera. Longitude takes the short way round. */
export function flyCamera(cam: GlobeCamera, o: FlyOptions): void {
  const duration = o.duration ?? 1500;
  const easing = Easing.bezier(...(o.curve ?? [0.4, 0, 0.2, 1]));
  const cfg = { duration, easing };
  if (o.lat !== undefined) { cancelAnimation(cam.lat); cam.lat.value = withTiming(o.lat, cfg); }
  if (o.lon !== undefined) { cancelAnimation(cam.lon); cam.lon.value = withTiming(cam.lon.value + shortestLon(cam.lon.value, o.lon), cfg); }
  if (o.radius !== undefined) { cancelAnimation(cam.radius); cam.radius.value = withTiming(o.radius, cfg); }
  if (o.centerY !== undefined) { cancelAnimation(cam.centerY); cam.centerY.value = withTiming(o.centerY, cfg); }
}

// MARK: - The globe

export interface GlobeMarker {
  id: string;
  label: string;
  lat: number;
  lon: number;
}

export interface GlobeRouteProps {
  stops: { lat: number; lon: number }[];
  /** 0 … stops.length − 1. The plane sits here. */
  position: SharedValue<number>;
  emphasis?: number;
}

interface Props {
  width: number;
  height: number;
  camera: GlobeCamera;
  markers?: GlobeMarker[];
  selectedId?: string;
  you?: { lat: number; lon: number };
  route?: GlobeRouteProps;
  /** Fades the land dots (a shared value so it can animate). */
  dotOpacity?: SharedValue<number>;
  /** The world never quite holds still: degrees of longitude per second. */
  driftDegPerSec?: number;
  /** Drag to rotate, tap markers. */
  interactive?: boolean;
  onSelectMarker?: (id: string) => void;
  /** Called when a drag starts, so the owner can stop scripted camera moves. */
  onDragStart?: () => void;
}

const LABEL_FONT = matchFont({ fontFamily: 'Helvetica Neue', fontSize: 9, fontWeight: 'bold' });
const LABEL_FONT_SELECTED = matchFont({ fontFamily: 'Helvetica Neue', fontSize: 11, fontWeight: 'bold' });
const YOU_FONT = matchFont({ fontFamily: 'Helvetica Neue', fontSize: 9, fontWeight: 'bold' });

/** Land dots are grouped by depth so each group is one draw call. */
const BUCKETS = [0.14, 0.38, 0.62, 0.86] as const;

/**
 * An art-directed globe: dotted land on near-black, thin flight arcs, a pulse where you are. Not a map. The camera
 * (`lat`, `lon`, `radius`, `centerY`) and `route.position` are shared values, so it glides and the plane travels
 * without re-rendering React — projection and paths are built on the UI thread.
 */
export function Globe({
  width, height, camera, markers = [], selectedId, you, route, dotOpacity, driftDegPerSec = 0, interactive = false, onSelectMarker, onDragStart,
}: Props) {
  const time = useSharedValue(0);
  useFrameCallback((f) => {
    time.value = (f.timeSinceFirstFrame ?? 0) / 1000;
  });

  // One projection per frame, shared by everything below.
  const view = useDerivedValue<View3D>(() => {
    const lon = camera.lon.value + driftDegPerSec * time.value;
    return makeView(camera.lat.value, lon, width, height, camera.radius.value, camera.centerY.value);
  });

  // Atmosphere, body, limb
  const cx = useDerivedValue(() => view.value.cx);
  const cy = useDerivedValue(() => view.value.cy);
  const r = useDerivedValue(() => view.value.r);
  const atmoR = useDerivedValue(() => view.value.r * 1.16);
  const bodyCenter = useDerivedValue(() => vec(view.value.cx - view.value.r * 0.3, view.value.cy - view.value.r * 0.35));
  const bodyR = useDerivedValue(() => view.value.r * 1.4);
  const atmoCenter = useDerivedValue(() => vec(view.value.cx, view.value.cy));
  const atmoStart = useDerivedValue(() => view.value.r * 0.96);

  // Land, in depth buckets.
  const dots = useDerivedValue<SkPoint[][]>(() => {
    const v = view.value;
    const out: SkPoint[][] = [[], [], [], []];
    for (let i = 0; i < LAND.length; i += 3) {
      const p = project(v, LAND[i], LAND[i + 1], LAND[i + 2]);
      if (p.depth <= 0.02) continue;
      const b = p.depth < 0.26 ? 0 : p.depth < 0.5 ? 1 : p.depth < 0.74 ? 2 : 3;
      out[b].push({ x: p.x, y: p.y });
    }
    return out;
  });
  const b0 = useDerivedValue(() => dots.value[0]);
  const b1 = useDerivedValue(() => dots.value[1]);
  const b2 = useDerivedValue(() => dots.value[2]);
  const b3 = useDerivedValue(() => dots.value[3]);
  const bucketPoints = [b0, b1, b2, b3];

  // Route
  const samples = useMemo(() => (route && route.stops.length >= 2 ? sampleRoute(route.stops) : []), [route?.stops]);
  const stopVecs = useMemo(() => (route ? route.stops.map((s) => vecFromLatLon(s.lat, s.lon)) : []), [route?.stops]);
  const emphasis = route?.emphasis ?? 1;
  const routePos = route?.position;
  const endPos = Math.max(0, (route?.stops.length ?? 1) - 1);

  const strokePaths = useDerivedValue(() => {
    const v = view.value;
    const dashed = Skia.PathBuilder.Make();
    const solid = Skia.PathBuilder.Make();
    if (samples.length === 0) return { dashed: dashed.build(), solid: solid.build() };
    const pos = routePos ? routePos.value : 0;
    let penD = false;
    let penS = false;
    for (let i = 0; i < samples.length; i += 4) {
      const p = project(v, samples[i], samples[i + 1], samples[i + 2]);
      const leg = samples[i + 3];
      if (p.depth > 0) {
        if (penD) dashed.lineTo(p.x, p.y); else { dashed.moveTo(p.x, p.y); penD = true; }
        if (leg <= pos) { if (penS) solid.lineTo(p.x, p.y); else { solid.moveTo(p.x, p.y); penS = true; } } else penS = false;
      } else { penD = false; penS = false; }
    }
    return { dashed: dashed.build(), solid: solid.build() };
  });
  const dashedPath = useDerivedValue(() => strokePaths.value.dashed);
  const solidPath = useDerivedValue(() => strokePaths.value.solid);

  // The plane: position, heading, visibility.
  const plane = useDerivedValue(() => {
    if (samples.length === 0 || !routePos) return { x: 0, y: 0, angle: 0, on: 0 };
    const v = view.value;
    const pos = Math.min(endPos - 0.0001, Math.max(0, routePos.value));
    let i = -1;
    for (let k = 0; k < samples.length; k += 4) { if (samples[k + 3] <= pos) i = k; else break; }
    if (i < 0 || i + 4 >= samples.length) return { x: 0, y: 0, angle: 0, on: 0 };
    const a = project(v, samples[i], samples[i + 1], samples[i + 2]);
    const b = project(v, samples[i + 4], samples[i + 5], samples[i + 6]);
    if (a.depth <= 0) return { x: 0, y: 0, angle: 0, on: 0 };
    const f = (pos - samples[i + 3]) / Math.max(0.0001, samples[i + 7] - samples[i + 3]);
    return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, angle: Math.atan2(b.y - a.y, b.x - a.x), on: 1 };
  });
  const planeTransform = useDerivedValue(() => [
    { translateX: plane.value.x }, { translateY: plane.value.y }, { rotate: plane.value.angle }, { scale: 26 },
  ]);
  const planeOpacity = useDerivedValue(() => plane.value.on);
  const glowX = useDerivedValue(() => plane.value.x);
  const glowY = useDerivedValue(() => plane.value.y);
  const glowOpacity = useDerivedValue(() => plane.value.on * 0.6);

  // Stops along the route (all but the first).
  const stopDots = useDerivedValue(() => {
    const v = view.value;
    const pos = routePos ? routePos.value : 0;
    return stopVecs.map((s, i) => {
      const p = project(v, s[0], s[1], s[2]);
      return { x: p.x, y: p.y, on: p.depth > 0.02 && i > 0 ? 1 : 0, reached: i <= pos + 0.001 ? 1 : 0 };
    });
  });

  // You
  const youVec = you ? vecFromLatLon(you.lat, you.lon) : undefined;
  const youState = useDerivedValue(() => {
    if (!youVec) return { x: 0, y: 0, on: 0 };
    const p = project(view.value, youVec[0], youVec[1], youVec[2]);
    return { x: p.x, y: p.y, on: p.depth > 0.05 ? 1 : 0 };
  });
  const youX = useDerivedValue(() => youState.value.x);
  const youY = useDerivedValue(() => youState.value.y);
  const youOn = useDerivedValue(() => youState.value.on);
  const ring0 = useDerivedValue(() => 6 + 30 * ((time.value * 0.55) % 1));
  const ring1 = useDerivedValue(() => 6 + 30 * ((time.value * 0.55 + 0.5) % 1));
  const ring0Op = useDerivedValue(() => youState.value.on * 0.5 * (1 - ((time.value * 0.55) % 1)));
  const ring1Op = useDerivedValue(() => youState.value.on * 0.5 * (1 - ((time.value * 0.55 + 0.5) % 1)));
  const youLabelX = useDerivedValue(() => youState.value.x - 36);
  const youLabelY = useDerivedValue(() => youState.value.y + 26);

  // Gestures
  const pan = useMemo(
    () =>
      Gesture.Pan()
        .enabled(interactive)
        .minDistance(4)
        .onStart(() => {
          cancelAnimation(camera.lon);
          cancelAnimation(camera.lat);
          if (onDragStart) scheduleOnRN(onDragStart);
        })
        .onChange((e) => {
          const degPerPx = 57.2958 / Math.max(1, view.value.r);
          camera.lon.value -= e.changeX * degPerPx;
          camera.lat.value = Math.min(65, Math.max(-60, camera.lat.value + e.changeY * degPerPx));
        })
        .onEnd((e) => {
          const degPerPx = 57.2958 / Math.max(1, view.value.r);
          camera.lon.value = withDecay({ velocity: -e.velocityX * degPerPx, deceleration: 0.996 });
        }),
    [interactive, camera, view, onDragStart],
  );
  const tap = useMemo(
    () =>
      Gesture.Tap()
        .enabled(interactive && markers.length > 0)
        .maxDistance(10)
        .onEnd((e, ok) => {
          if (!ok || !onSelectMarker) return;
          const hit = hitTest(e.x, e.y, view.value, markers);
          if (hit) scheduleOnRN(onSelectMarker, hit);
        }),
    [interactive, markers, view, onSelectMarker],
  );
  const gesture = useMemo(() => Gesture.Race(tap, pan), [tap, pan]);

  useEffect(() => () => { cancelAnimation(camera.lon); }, [camera]);

  const canvas = (
    <Canvas style={{ width, height }} pointerEvents="none">
      {/* Atmosphere and body */}
      <Circle cx={cx} cy={cy} r={atmoR}>
        <RadialGradient c={atmoCenter} r={atmoR} colors={['rgba(255,255,255,0.10)', 'rgba(255,255,255,0)']} positions={[0.83, 1]} />
      </Circle>
      <Circle cx={cx} cy={cy} r={r}>
        <RadialGradient c={bodyCenter} r={bodyR} colors={['rgb(29,29,29)', 'rgb(10,10,10)']} />
      </Circle>
      <Circle cx={cx} cy={cy} r={r} style="stroke" strokeWidth={0.8} color="rgba(255,255,255,0.14)" />

      {/* Land */}
      {BUCKETS.map((d, i) => (
        <LandDots key={i} points={bucketPoints[i]} depth={d} dotOpacity={dotOpacity} />
      ))}

      {/* Route */}
      {samples.length > 0 && (
        <>
          <Path path={dashedPath} style="stroke" strokeWidth={1.4} strokeCap="round" color={colors.white} opacity={0.5 * emphasis}>
            <DashPathEffect intervals={[1, 5]} />
          </Path>
          <Path path={solidPath} style="stroke" strokeWidth={1.8} strokeCap="round" color={colors.white} opacity={0.95 * emphasis} />
          {stopVecs.map((_, i) => (i === 0 ? null : <StopDot key={i} index={i} dots={stopDots} />))}
          <Circle cx={glowX} cy={glowY} r={15} color={colors.white} opacity={glowOpacity}>
            <BlurMask blur={9} style="normal" />
          </Circle>
          <Group transform={planeTransform} opacity={planeOpacity}>
            <Path path={planePath()} color={colors.white} />
          </Group>
        </>
      )}

      {/* Markers */}
      {markers.map((m) => (
        <MarkerDot key={m.id} marker={m} selected={m.id === selectedId} view={view} time={time} />
      ))}

      {/* You */}
      {you && (
        <>
          <Circle cx={youX} cy={youY} r={ring0} style="stroke" strokeWidth={1.2} color={colors.white} opacity={ring0Op} />
          <Circle cx={youX} cy={youY} r={ring1} style="stroke" strokeWidth={1.2} color={colors.white} opacity={ring1Op} />
          <Circle cx={youX} cy={youY} r={9} color="rgba(255,255,255,0.18)" opacity={youOn} />
          <Circle cx={youX} cy={youY} r={4.5} color={colors.white} opacity={youOn} />
          <Circle cx={youX} cy={youY} r={2} color={colors.habanero} opacity={youOn} />
          {YOU_FONT && <SkText x={youLabelX} y={youLabelY} text="YOU ARE HERE" font={YOU_FONT} color="rgba(255,255,255,0.8)" opacity={youOn} />}
        </>
      )}
    </Canvas>
  );

  return (
    <Animated.View style={[styles.fill, { width, height }]} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      {interactive ? <GestureDetector gesture={gesture}>{canvas}</GestureDetector> : canvas}
    </Animated.View>
  );
}

/** One depth bucket of land dots: nearer land is larger and brighter. */
function LandDots({ points, depth, dotOpacity }: { points: SharedValue<SkPoint[]>; depth: number; dotOpacity?: SharedValue<number> }) {
  const base = 0.1 + 0.62 * Math.pow(depth, 0.7);
  const opacity = useDerivedValue(() => base * (dotOpacity ? dotOpacity.value : 1));
  return (
    <Points points={points} mode="points" style="stroke" strokeCap="round" strokeWidth={2 * (0.9 + 1.1 * depth)} color={colors.white} opacity={opacity} />
  );
}

function StopDot({ index, dots }: { index: number; dots: SharedValue<{ x: number; y: number; on: number; reached: number }[]> }) {
  const x = useDerivedValue(() => dots.value[index]?.x ?? 0);
  const y = useDerivedValue(() => dots.value[index]?.y ?? 0);
  const on = useDerivedValue(() => dots.value[index]?.on ?? 0);
  const fill = useDerivedValue(() => (dots.value[index]?.reached ? 'rgb(255,255,255)' : 'rgb(0,0,0)'));
  return (
    <>
      <Circle cx={x} cy={y} r={3.5} color={fill} opacity={on} />
      <Circle cx={x} cy={y} r={3.5} style="stroke" strokeWidth={1} color="rgba(255,255,255,0.8)" opacity={on} />
    </>
  );
}

function MarkerDot({ marker, selected, view, time }: { marker: GlobeMarker; selected: boolean; view: SharedValue<View3D>; time: SharedValue<number> }) {
  const v = useMemo(() => vecFromLatLon(marker.lat, marker.lon), [marker.lat, marker.lon]);
  const font = selected ? LABEL_FONT_SELECTED : LABEL_FONT;
  const label = marker.label.toUpperCase();
  const halfWidth = useMemo(() => (font ? font.measureText(label).width / 2 : 0), [font, label]);
  const p = useDerivedValue(() => {
    const pr = project(view.value, v[0], v[1], v[2]);
    return { x: pr.x, y: pr.y, d: pr.depth };
  });
  const x = useDerivedValue(() => p.value.x);
  const y = useDerivedValue(() => p.value.y);
  const visible = useDerivedValue(() => (p.value.d > 0.08 ? 1 : 0));
  const dotOpacity = useDerivedValue(() => visible.value * (selected ? 1 : Math.min(1, 0.6 * p.value.d + 0.2)));
  const ring = useDerivedValue(() => 9 + 4 * Math.sin(time.value * 2.4));
  const labelOn = useDerivedValue(() => (selected || p.value.d > 0.55 ? visible.value : 0));
  const labelX = useDerivedValue(() => p.value.x - halfWidth);
  const labelY = useDerivedValue(() => p.value.y + (selected ? 24 : 17));
  return (
    <>
      {selected && <Circle cx={x} cy={y} r={ring} style="stroke" strokeWidth={1} color="rgba(255,255,255,0.45)" opacity={visible} />}
      <Circle cx={x} cy={y} r={selected ? 4.5 : 2.8} color={colors.white} opacity={dotOpacity} />
      {font && <SkText x={labelX} y={labelY} text={label} font={font} color={selected ? colors.white : 'rgba(255,255,255,0.6)'} opacity={labelOn} />}
    </>
  );
}

const styles = StyleSheet.create({ fill: { position: 'absolute', left: 0, top: 0 } });
