import { Skia, SkPath } from '@shopify/react-native-skia';

/**
 * A slim, top-down jet in a unit square centred on the origin, nose pointing right (+x). Deliberately architectural:
 * no windows, no outline, just the silhouette. Scale it by the size you want.
 */
const UPPER: [number, number][] = [
  [0.93, 0.05], [0.62, 0.06], [0.52, 0.07], [0.3, 0.48], [0.22, 0.48], [0.34, 0.075], [0.16, 0.06], [0.06, 0.2], [0.0, 0.2], [0.05, 0.03], [0.0, 0.0],
];

export function planeSvgPath(size: number): string {
  const p = (x: number, y: number) => `${((x - 0.5) * size).toFixed(3)} ${(y * size).toFixed(3)}`;
  let d = `M${p(1, 0)}`;
  for (const [x, y] of UPPER) d += ` L${p(x, y)}`;
  for (const [x, y] of UPPER.slice(0, -1).reverse()) d += ` L${p(x, -y)}`;
  return `${d} Z`;
}

let cached: SkPath | undefined;
/** The plane as a Skia path in unit size. Scale with a transform. */
export function planePath(): SkPath {
  if (!cached) cached = Skia.Path.MakeFromSVGString(planeSvgPath(1))!;
  return cached;
}
