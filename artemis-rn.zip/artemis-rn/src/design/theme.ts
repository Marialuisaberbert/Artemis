import { Platform } from 'react-native';

/**
 * Neutral by default, colour from photography. The interface is white, near-black and translucent glass.
 * `habanero` is the one warm accent, used sparingly (a pulse, a warning, a highlighted number).
 */
export const colors = {
  black: '#000000',
  field: '#131313', // the logo's field
  cream: '#FFFFE3', // the logo's cream
  luster: '#F5F3EF',
  aster: '#C9CCD3',
  habanero: '#F98513',
  jodhpur: '#DAD1C8',
  royal: '#2C2E37',
  depths: '#0B0B0E',
  white: '#FFFFFF',
  // Paper
  paper: '#F2EBDC',
  paperLight: '#F9F4E8',
  paperShade: '#E2D8C2',
  ink: '#1C1915',
} as const;

export const alpha = (hex: string, a: number): string => {
  const h = hex.replace('#', '');
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${a})`;
};

export const white = (a: number): string => `rgba(255,255,255,${a})`;
export const black = (a: number): string => `rgba(0,0,0,${a})`;

/** Font families. Newsreader is loaded in the root layout; the rest are system faces. */
export const fonts = {
  serif: 'Newsreader_500Medium',
  serifRegular: 'Newsreader_400Regular',
  serifItalic: 'Newsreader_400Regular_Italic',
  mono: Platform.select({ ios: 'Menlo', default: 'monospace' }) as string,
} as const;

/** Motion language: quiet, cinematic. Nothing bounces. */
export const motion = {
  calm: 550,
  slow: 900,
  glide: 700,
  /** cubic-bezier(0.22, 1, 0.36, 1) */
  glideCurve: [0.22, 1, 0.36, 1] as const,
  /** cubic-bezier(0.45, 0, 0.15, 1) — the camera pull-back */
  pullCurve: [0.45, 0, 0.15, 1] as const,
} as const;

export const hitSlop = { top: 8, bottom: 8, left: 8, right: 8 } as const;
