import React, { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import Svg, { Circle, Defs, RadialGradient, Stop } from 'react-native-svg';
import { LinearGradient } from 'expo-linear-gradient';

interface Props {
  glow?: number;
  showStars?: boolean;
}

/** Near-black with a whisper of light. The canvas under the globe and behind glass, until a photograph takes over. */
export function NightBackdrop({ glow = 0.5, showStars = true }: Props) {
  const stars = useMemo(() => {
    const out: { x: number; y: number; r: number; o: number }[] = [];
    for (let i = 0; i < 90; i++) {
      const a = Math.sin(i * 12.9898) * 43758.5453;
      const b = Math.sin(i * 78.233) * 12345.6789;
      out.push({ x: a - Math.floor(a), y: b - Math.floor(b), r: i % 11 === 0 ? 1.3 : 0.7, o: i % 5 === 0 ? 0.42 : 0.18 });
    }
    return out;
  }, []);
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none" accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      <LinearGradient colors={['#050505', '#0f0f0f', '#080808']} style={StyleSheet.absoluteFill} />
      <Svg style={StyleSheet.absoluteFill} width="100%" height="100%">
        <Defs>
          <RadialGradient id="glow" cx="50%" cy="35%" rx="60%" ry="40%" fx="50%" fy="35%">
            <Stop offset="0" stopColor="#fff" stopOpacity={0.06 * (glow / 0.5)} />
            <Stop offset="1" stopColor="#fff" stopOpacity={0} />
          </RadialGradient>
        </Defs>
        <Circle cx="50%" cy="35%" r="70%" fill="url(#glow)" />
        {showStars && stars.map((s, i) => <Circle key={i} cx={`${s.x * 100}%`} cy={`${s.y * 100}%`} r={s.r} fill="#fff" opacity={s.o} />)}
      </Svg>
    </View>
  );
}
