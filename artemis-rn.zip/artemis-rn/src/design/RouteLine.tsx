import React, { useMemo } from 'react';
import { View } from 'react-native';
import Svg, { Circle, Path, Text as SvgText } from 'react-native-svg';
import { planeSvgPath } from './globe/plane';
import { colors } from './theme';

interface Pt { x: number; y: number }

/** One curved leg between two points, as a quadratic Bézier. */
interface Quad { p0: Pt; c: Pt; p1: Pt }
const quadPoint = (q: Quad, t: number): Pt => {
  const u = 1 - t;
  return { x: u * u * q.p0.x + 2 * u * t * q.c.x + t * t * q.p1.x, y: u * u * q.p0.y + 2 * u * t * q.c.y + t * t * q.p1.y };
};
const quadTangent = (q: Quad, t: number): Pt => {
  const u = 1 - t;
  return { x: 2 * u * (q.c.x - q.p0.x) + 2 * t * (q.p1.x - q.c.x), y: 2 * u * (q.c.y - q.p0.y) + 2 * t * (q.p1.y - q.c.y) };
};
const quadHead = (q: Quad, t: number): Quad => ({ p0: q.p0, c: { x: q.p0.x + (q.c.x - q.p0.x) * t, y: q.p0.y + (q.c.y - q.p0.y) * t }, p1: quadPoint(q, t) });
const quadPath = (q: Quad): string => `M${q.p0.x} ${q.p0.y} Q${q.c.x} ${q.c.y} ${q.p1.x} ${q.p1.y}`;

/** Arcs that bulge "up" between consecutive stations, like flight paths on a map. */
export function arcs(stations: Pt[], bulge = 0.22): Quad[] {
  const out: Quad[] = [];
  for (let i = 0; i < stations.length - 1; i++) {
    const a = stations[i];
    const b = stations[i + 1];
    const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const len = Math.max(1, Math.hypot(dx, dy));
    let nx = -dy / len;
    let ny = dx / len;
    if (ny > 0) { nx = -nx; ny = -ny; } // always lift the arc toward the top of the screen
    out.push({ p0: a, c: { x: mid.x + nx * len * bulge, y: mid.y + ny * len * bulge }, p1: b });
  }
  return out;
}

const PLANE = planeSvgPath(1);

interface Props {
  codes: string[];
  /** 0 … codes.length − 1. The plane sits here. */
  position: number;
  width: number;
  height?: number;
  color?: string;
  planeSize?: number;
}

/** GIG ──●── LIS ──✈── FCO, drawn to fit its box. */
export function RouteLine({ codes, position, width, height = 46, color = colors.luster, planeSize = 20 }: Props) {
  const inset = 26;
  const y = height * 0.62;
  const xs = codes.map((_, i) => inset + ((width - inset * 2) * i) / Math.max(1, codes.length - 1));
  const segs = useMemo(() => arcs(xs.map((x) => ({ x, y })), 0.28), [width, height, codes.length]); // eslint-disable-line react-hooks/exhaustive-deps
  const clamped = Math.min(segs.length - 0.0001, Math.max(0, position));
  const idx = Math.floor(clamped);
  const t = clamped - idx;
  const seg = segs[idx];
  const at = seg ? quadPoint(seg, t) : { x: xs[0], y };
  const tan = seg ? quadTangent(seg, t) : { x: 1, y: 0 };
  const angle = (Math.atan2(tan.y, tan.x) * 180) / Math.PI;
  return (
    <View style={{ width, height: height + 10 }} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      <Svg width={width} height={height + 10}>
        {segs.map((s, i) => <Path key={`d${i}`} d={quadPath(s)} stroke={color} strokeOpacity={0.4} strokeWidth={1.6} strokeLinecap="round" strokeDasharray="1 6" fill="none" />)}
        {segs.map((s, i) => {
          const f = Math.min(1, Math.max(0, position - i));
          return f > 0 ? <Path key={`t${i}`} d={quadPath(f >= 1 ? s : quadHead(s, f))} stroke={color} strokeOpacity={0.9} strokeWidth={2} strokeLinecap="round" fill="none" /> : null;
        })}
        {xs.map((x, i) => (
          <React.Fragment key={i}>
            <Circle cx={x} cy={y} r={3.5} fill={i <= position + 0.001 ? color : colors.depths} stroke={color} strokeOpacity={0.9} strokeWidth={1.5} />
            <SvgText x={x} y={y + 19} fill={color} fillOpacity={0.85} fontSize={10} fontWeight="800" textAnchor="middle" letterSpacing={1}>{codes[i]}</SvgText>
          </React.Fragment>
        ))}
        <Path d={PLANE} fill={color} transform={`translate(${at.x} ${at.y}) rotate(${angle}) scale(${planeSize})`} />
      </Svg>
    </View>
  );
}
