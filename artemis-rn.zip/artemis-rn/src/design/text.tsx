import React from 'react';
import { Text as RNText, TextProps, TextStyle } from 'react-native';
import { colors, fonts } from './theme';

/** Every piece of text scales with the user's text size, up to a sensible limit, so nothing clips. */
export const MAX_SCALE = 1.5;

export function T(props: TextProps) {
  return <RNText maxFontSizeMultiplier={MAX_SCALE} {...props} />;
}

interface CapsProps extends TextProps {
  size?: number;
  tracking?: number;
  weight?: TextStyle['fontWeight'];
  opacity?: number;
  color?: string;
}

/** Small, tracked capitals: the voice of labels and captions. */
export function Caps({ size = 11, tracking = 3, weight = '600', opacity = 0.7, color = colors.white, style, ...rest }: CapsProps) {
  return <T {...rest} style={[{ fontSize: size, letterSpacing: tracking, fontWeight: weight, color, opacity }, style]} />;
}

interface DisplayProps extends TextProps {
  size?: number;
  tracking?: number;
  color?: string;
  shrink?: boolean;
}

/** The headline voice: large serif capitals. */
export function Display({ size = 40, tracking = 2, color = colors.white, shrink = false, style, ...rest }: DisplayProps) {
  return (
    <T
      {...(shrink ? { adjustsFontSizeToFit: true, minimumFontScale: 0.5 } : null)}
      {...rest}
      style={[{ fontFamily: fonts.serif, fontSize: size, letterSpacing: tracking, color, lineHeight: size * 1.12 }, style]}
    />
  );
}

/** Editorial serif, for destination lines and quotes. */
export function Editorial({ size = 17, color = colors.white, style, ...rest }: TextProps & { size?: number; color?: string }) {
  return <T {...rest} style={[{ fontFamily: fonts.serifRegular, fontSize: size, color }, style]} />;
}

export function Mono({ size = 13, weight = '600', color = colors.white, style, ...rest }: TextProps & { size?: number; weight?: TextStyle['fontWeight']; color?: string }) {
  return <T {...rest} style={[{ fontFamily: fonts.mono, fontSize: size, fontWeight: weight, color }, style]} />;
}

export function Body({ size = 16, opacity = 0.75, color = colors.white, style, ...rest }: TextProps & { size?: number; opacity?: number; color?: string }) {
  return <T {...rest} style={[{ fontSize: size, color, opacity }, style]} />;
}

/** Small uppercase label — the Artemis "eyebrow". */
export function Eyebrow({ children, color = colors.white, opacity = 0.55, ...rest }: TextProps & { color?: string; opacity?: number }) {
  return (
    <T accessibilityRole="header" numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.75} {...rest}
      style={{ fontSize: 12, fontWeight: '600', letterSpacing: 1.6, color, opacity }}>
      {typeof children === 'string' ? children.toUpperCase() : children}
    </T>
  );
}
