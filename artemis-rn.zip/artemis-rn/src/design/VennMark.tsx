import React from 'react';
import { StyleSheet, View } from 'react-native';
import { Canvas, Circle, Group, Skia } from '@shopify/react-native-skia';
import Animated, { SharedValue, useAnimatedStyle, useDerivedValue } from 'react-native-reanimated';
import { Caps } from './text';

interface Props {
  progress: SharedValue<number>;
  width: number;
  height: number;
  leftLabel?: string;
  rightLabel?: string;
}

/** Two circles that slide together into one shared profile. */
export function VennMark({ progress, width, height, leftLabel = '', rightLabel = '' }: Props) {
  const d = Math.min(height, width * 0.52);
  const gap = (width - d * 2) / 2;
  const cy = height / 2;
  const lx = useDerivedValue(() => width / 2 - d * 0.5 - gap * (1 - progress.value) * 0.45 + d * 0.55 * progress.value * 0.5);
  const rx = useDerivedValue(() => width / 2 + d * 0.5 + gap * (1 - progress.value) * 0.45 - d * 0.55 * progress.value * 0.5);
  const lens = useDerivedValue(() => Skia.PathBuilder.Make().addCircle(rx.value, cy, d / 2).build());
  const lensOpacity = useDerivedValue(() => progress.value);
  const lStyle = useAnimatedStyle(() => ({ transform: [{ translateX: lx.value - d * 0.24 - 40 }] }));
  const rStyle = useAnimatedStyle(() => ({ transform: [{ translateX: rx.value + d * 0.24 - 40 }] }));
  const r = d / 2;
  return (
    <View style={{ width, height }} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      <Canvas style={StyleSheet.absoluteFill}>
        <Circle cx={lx} cy={cy} r={r} color="rgba(255,255,255,0.10)" />
        <Circle cx={lx} cy={cy} r={r} style="stroke" strokeWidth={1.2} color="rgba(255,255,255,0.8)" />
        <Circle cx={rx} cy={cy} r={r} color="rgba(255,255,255,0.10)" />
        <Circle cx={rx} cy={cy} r={r} style="stroke" strokeWidth={1.2} color="rgba(255,255,255,0.8)" />
        <Group clip={lens} opacity={lensOpacity}>
          <Circle cx={lx} cy={cy} r={r} color="rgba(255,255,255,0.85)" />
        </Group>
      </Canvas>
      {!!leftLabel && (
        <>
          <Animated.View style={[{ position: 'absolute', top: cy - 8, width: 80, alignItems: 'center' }, lStyle]}><Caps size={11} tracking={2} opacity={1}>{leftLabel}</Caps></Animated.View>
          <Animated.View style={[{ position: 'absolute', top: cy - 8, width: 80, alignItems: 'center' }, rStyle]}><Caps size={11} tracking={2} opacity={1}>{rightLabel}</Caps></Animated.View>
        </>
      )}
    </View>
  );
}

