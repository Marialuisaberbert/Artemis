import type { ImageSourcePropType } from 'react-native';

/** The ten destination photographs, bundled with the app so they work offline. One file maps every `require`. */
export const PHOTOS: Record<string, ImageSourcePropType> = {
  rome: require('../../assets/photos/rome.jpg'),
  paris: require('../../assets/photos/paris.jpg'),
  tokyo: require('../../assets/photos/tokyo.jpg'),
  'new-york': require('../../assets/photos/new-york.jpg'),
  rio: require('../../assets/photos/rio.jpg'),
  lisbon: require('../../assets/photos/lisbon.jpg'),
  london: require('../../assets/photos/london.jpg'),
  'cape-town': require('../../assets/photos/cape-town.jpg'),
  dubai: require('../../assets/photos/dubai.jpg'),
  bali: require('../../assets/photos/bali.jpg'),
};

export const photoSource = (file: string): ImageSourcePropType | undefined => PHOTOS[file];
