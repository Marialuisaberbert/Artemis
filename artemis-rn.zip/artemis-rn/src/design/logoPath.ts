/**
 * The Artemis mark: two offset blocks, cut on the diagonal. Traced from the supplied logo sheet (104 × 114 units).
 * Rounded outer corners, sharp diagonals. This is the only place the geometry lives; draw it with <ArtemisLogo />.
 */
export const LOGO_WIDTH = 104;
export const LOGO_HEIGHT = 114;

/** (x, y, cornerRadius) */
export const LOGO_POINTS: readonly (readonly [number, number, number])[] = [
  [0, 0, 3], [72, 0, 3], [72, 33, 0], [41, 64, 0], [104, 64, 3], [104, 114, 3], [0, 114, 3], [0, 102, 0], [33, 70, 0], [0, 70, 0],
];

interface Pt { x: number; y: number }

/** The SVG path of the mark inside a box of (width × height), centred, matching `addArc(tangent1End:tangent2End:radius:)`. */
export function logoPathData(width: number = LOGO_WIDTH, height: number = LOGO_HEIGHT): string {
  const scale = Math.min(width / LOGO_WIDTH, height / LOGO_HEIGHT);
  const ox = width / 2 - (LOGO_WIDTH * scale) / 2;
  const oy = height / 2 - (LOGO_HEIGHT * scale) / 2;
  const pts: Pt[] = LOGO_POINTS.map(([x, y]) => ({ x: ox + x * scale, y: oy + y * scale }));
  const n = pts.length;
  const f = (v: number) => Number(v.toFixed(3));
  let d = `M${f((pts[0].x + pts[n - 1].x) / 2)} ${f((pts[0].y + pts[n - 1].y) / 2)}`;
  for (let i = 0; i < n; i++) {
    const p = pts[i];
    const next = pts[(i + 1) % n];
    const prev = i === 0 ? pts[n - 1] : pts[i - 1];
    const r = LOGO_POINTS[i][2] * scale;
    if (r <= 0) { d += ` L${f(p.x)} ${f(p.y)}`; continue; }
    // Tangent points at distance `t` from the vertex along each edge.
    const v1 = { x: prev.x - p.x, y: prev.y - p.y };
    const v2 = { x: next.x - p.x, y: next.y - p.y };
    const l1 = Math.hypot(v1.x, v1.y);
    const l2 = Math.hypot(v2.x, v2.y);
    const cos = (v1.x * v2.x + v1.y * v2.y) / (l1 * l2);
    const angle = Math.acos(Math.max(-1, Math.min(1, cos)));
    const t = r / Math.tan(angle / 2);
    const a = { x: p.x + (v1.x / l1) * t, y: p.y + (v1.y / l1) * t };
    const b = { x: p.x + (v2.x / l2) * t, y: p.y + (v2.y / l2) * t };
    const cross = v1.x * v2.y - v1.y * v2.x;
    d += ` L${f(a.x)} ${f(a.y)} A${f(r)} ${f(r)} 0 0 ${cross > 0 ? 0 : 1} ${f(b.x)} ${f(b.y)}`;
  }
  return `${d} Z`;
}
