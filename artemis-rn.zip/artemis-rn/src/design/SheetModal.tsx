import React from 'react';
import { Modal, View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { colors } from './theme';

/** A page sheet. Gesture handlers need their own root inside a native modal. */
export function SheetModal({ visible, onClose, children }: { visible: boolean; onClose: () => void; children: React.ReactNode }) {
  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet" onRequestClose={onClose}>
      <GestureHandlerRootView style={{ flex: 1, backgroundColor: colors.black }}>
        <SafeAreaProvider>
          <View style={{ flex: 1, backgroundColor: colors.black }}>{children}</View>
        </SafeAreaProvider>
      </GestureHandlerRootView>
    </Modal>
  );
}
