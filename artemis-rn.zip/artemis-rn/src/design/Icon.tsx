import React from 'react';
import Svg, { Circle, Path } from 'react-native-svg';
import { planeSvgPath } from './globe/plane';

/** A small set of line icons on a 24 × 24 grid, drawn with react-native-svg (no icon font, so nothing to load). */
export type IconName =
  | 'chevronLeft' | 'chevronRight' | 'chevronDown' | 'close' | 'check' | 'arrowRight' | 'scissors' | 'plane' | 'location' | 'globe'
  | 'compass' | 'person' | 'search' | 'message' | 'link' | 'contacts' | 'star' | 'starFill' | 'bed' | 'bell' | 'list' | 'plus'
  | 'exclamation' | 'sparkles' | 'calendar' | 'wallet' | 'shield' | 'clock' | 'pin' | 'ticket' | 'play' | 'moon' | 'info' | 'refresh' | 'sound';

const PLANE = planeSvgPath(20);

const PATHS: Record<IconName, { d: string; fill?: boolean; extra?: string[] }> = {
  chevronLeft: { d: 'M15 5 8 12l7 7' },
  chevronRight: { d: 'm9 5 7 7-7 7' },
  chevronDown: { d: 'm5 9 7 7 7-7' },
  close: { d: 'M6 6l12 12M18 6 6 18' },
  check: { d: 'm5 12.5 4.5 4.5L19 7.5' },
  arrowRight: { d: 'M4 12h15m-6-6 6 6-6 6' },
  scissors: { d: 'M6.5 8.2a2.7 2.7 0 1 0 0-5.4 2.7 2.7 0 0 0 0 5.4Zm0 13a2.7 2.7 0 1 0 0-5.4 2.7 2.7 0 0 0 0 5.4ZM8.6 6.6 20 18M8.6 17.4 20 6' },
  plane: { d: PLANE, fill: true },
  location: { d: 'M12 21s7-6.2 7-11.2A7 7 0 0 0 5 9.8C5 14.8 12 21 12 21Z', extra: ['M12 12.3a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z'] },
  globe: { d: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM3 12h18M12 3c2.6 2.5 3.8 5.5 3.8 9S14.6 18.5 12 21c-2.6-2.5-3.8-5.5-3.8-9S9.4 5.5 12 3Z' },
  compass: { d: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm3.6-12.6-2 5.2-5.2 2 2-5.2 5.2-2Z' },
  person: { d: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 8.5c.6-3.4 3.4-5.5 7-5.5s6.4 2.1 7 5.5' },
  search: { d: 'M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13Zm5 -1.5L20 20' },
  message: { d: 'M5 5h14a1.5 1.5 0 0 1 1.5 1.5v9A1.5 1.5 0 0 1 19 17h-7l-4.5 3.5V17H5a1.5 1.5 0 0 1-1.5-1.5v-9A1.5 1.5 0 0 1 5 5Z' },
  link: { d: 'M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3A4 4 0 0 0 11 18.7l1-1' },
  contacts: { d: 'M12 12a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm-8 8c.6-3 3.6-5 8-5s7.4 2 8 5' },
  star: { d: 'm12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.8l-5.2 2.8 1-5.8L3.5 9.7l5.9-.8L12 3.5Z' },
  starFill: { d: 'm12 3.5 2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.8l-5.2 2.8 1-5.8L3.5 9.7l5.9-.8L12 3.5Z', fill: true },
  bed: { d: 'M3 18V6M3 14h18v4M21 14v-2a3 3 0 0 0-3-3h-7v5M7 12.2a1.7 1.7 0 1 0 0-3.4 1.7 1.7 0 0 0 0 3.4Z' },
  bell: { d: 'M6 16.5V11a6 6 0 1 1 12 0v5.5l1.5 1.5h-15L6 16.5ZM10 20.5a2.2 2.2 0 0 0 4 0' },
  list: { d: 'M9 6h11M9 12h11M9 18h11M4.5 6h.01M4.5 12h.01M4.5 18h.01' },
  plus: { d: 'M12 5v14M5 12h14' },
  exclamation: { d: 'M12 6v8m0 3.5h.01' },
  sparkles: { d: 'M11 4l1.8 5.2L18 11l-5.2 1.8L11 18l-1.8-5.2L4 11l5.2-1.8L11 4ZM18.5 15.5l.7 1.8 1.8.7-1.8.7-.7 1.8-.7-1.8-1.8-.7 1.8-.7.7-1.8Z' },
  calendar: { d: 'M5 6h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Zm0 5h15M8 3.5V7M16 3.5V7' },
  wallet: { d: 'M4 7.5A1.5 1.5 0 0 1 5.5 6H18v3M4 7.5V18a1.5 1.5 0 0 0 1.5 1.5H19a1 1 0 0 0 1-1V10a1 1 0 0 0-1-1H5.5A1.5 1.5 0 0 1 4 7.5ZM16 14.5h.01' },
  shield: { d: 'M12 3.5 5 6v5.5c0 4.2 2.8 7.4 7 9 4.2-1.6 7-4.8 7-9V6l-7-2.5Zm-3 8.5 2.2 2.2L15.5 10' },
  clock: { d: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-13v4.5l3 1.8' },
  pin: { d: 'M12 21v-6m0 0-4-4V5h8v6l-4 4Z' },
  ticket: { d: 'M4 8a1.5 1.5 0 0 1 1.5-1.5h13A1.5 1.5 0 0 1 20 8v2.2a1.8 1.8 0 0 0 0 3.6V16a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 16v-2.2a1.8 1.8 0 0 0 0-3.6V8Z' },
  play: { d: 'M8 5.5v13L19 12 8 5.5Z', fill: true },
  moon: { d: 'M19.5 14.5A8 8 0 0 1 9.5 4.5a8 8 0 1 0 10 10Z', fill: true },
  info: { d: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-9.5V17m0-9.5h.01' },
  refresh: { d: 'M19 12a7 7 0 1 1-2.1-5M19 4.5V8h-3.5' },
  sound: { d: 'M4 9.5h3.5L12 6v12l-4.5-3.5H4v-5ZM15.5 9a4 4 0 0 1 0 6M17.8 6.8a7 7 0 0 1 0 10.4' },
};

interface Props {
  name: IconName;
  size?: number;
  color?: string;
  strokeWidth?: number;
}

export function Icon({ name, size = 20, color = '#fff', strokeWidth = 1.8 }: Props) {
  const g = PATHS[name];
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" accessibilityElementsHidden importantForAccessibility="no">
      {g.fill ? (
        <Path d={g.d} fill={color} transform={name === 'plane' ? 'translate(12 12)' : undefined} />
      ) : (
        <Path d={g.d} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" fill="none" />
      )}
      {g.extra?.map((d, i) => <Path key={i} d={d} stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" fill="none" />)}
      {name === 'exclamation' && <Circle cx={12} cy={12} r={9} stroke={color} strokeWidth={strokeWidth} fill="none" />}
    </Svg>
  );
}
