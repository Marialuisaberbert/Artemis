import React, { useEffect, useMemo } from 'react';
import { StyleSheet } from 'react-native';
import { BlurMask, Canvas, Circle, Group, Path, Skia } from '@shopify/react-native-skia';
import { Easing, SharedValue, useDerivedValue, useSharedValue, withDelay, withTiming } from 'react-native-reanimated';
import { planePath } from './globe/plane';
import { colors } from './theme';

/**
 * A plane that crosses the screen along a curve, leaving a fading trail. The airplane is the hero of the motion
 * language: smooth and fast, with a slight acceleration and deceleration.
 */
interface Props {
  width: number;
  height: number;
  /** Change this to fly again. */
  flightKey: number | string;
  duration: number; // seconds
  /** Start and end points, as fractions of the view (they may lie outside 0…1 so the plane enters and leaves the screen). */
  from: { x: number; y: number };
  to: { x: number; y: number };
  /** How far the path bows, as a fraction of the height. Negative bows upward. */
  bow?: number;
  size?: number;
  /** The plane recedes as it goes: 1 keeps its size, 0.5 halves it by the end. */
  recede?: number;
  easing?: 'accelerate' | 'smooth';
  delay?: number;
  onDone?: () => void;
}

const SEGMENTS = 6;

export function PlaneFlyby({
  width, height, flightKey, duration, from, to, bow = -0.12, size = 56, recede = 0.8, easing = 'smooth', delay = 0,
}: Props) {
  const raw = useSharedValue(-1);
  useEffect(() => {
    raw.value = -1;
    raw.value = withDelay(delay * 1000, withTiming(1.02, { duration: duration * 1000, easing: Easing.linear }));
  }, [flightKey, duration, delay, raw]);

  const geo = useMemo(() => {
    const a = { x: from.x * width, y: from.y * height };
    const b = { x: to.x * width, y: to.y * height };
    const c = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 + bow * height };
    return { a, b, c };
  }, [from.x, from.y, to.x, to.y, bow, width, height]);

  const head = useDerivedValue(() => Math.min(1, Math.max(0, raw.value)));
  const active = useDerivedValue<number>(() => (raw.value > 0 && raw.value < 1.02 ? 1 : 0));

  const pose = useDerivedValue(() => {
    const ease = (t: number) => {
      const x = Math.min(1, Math.max(0, t));
      return easing === 'accelerate' ? Math.pow(x, 2) * 0.85 + x * 0.15 : x * x * (3 - 2 * x) * 0.8 + x * 0.2;
    };
    const at = (t: number) => {
      const e = ease(t);
      const u = 1 - e;
      return {
        x: u * u * geo.a.x + 2 * u * e * geo.c.x + e * e * geo.b.x,
        y: u * u * geo.a.y + 2 * u * e * geo.c.y + e * e * geo.b.y,
      };
    };
    const h = head.value;
    const p = at(h);
    const q = at(Math.min(1, h + 0.01));
    const s = size * (1 - (1 - recede) * h);
    return { x: p.x, y: p.y, angle: Math.atan2(q.y - p.y, q.x - p.x), s };
  });
  const transform = useDerivedValue(() => [
    { translateX: pose.value.x }, { translateY: pose.value.y }, { rotate: pose.value.angle }, { scale: pose.value.s },
  ]);
  const glowX = useDerivedValue(() => pose.value.x);
  const glowY = useDerivedValue(() => pose.value.y);
  const glowR = useDerivedValue(() => pose.value.s * 0.5);
  const glowOpacity = useDerivedValue(() => active.value * 0.5);

  return (
    <Canvas style={[StyleSheet.absoluteFill, { width, height }]} pointerEvents="none">
      {Array.from({ length: SEGMENTS }, (_, i) => (
        <TrailSegment key={i} index={i} head={head} active={active} easing={easing} geo={geo} />
      ))}
      <Circle cx={glowX} cy={glowY} r={glowR} color={colors.white} opacity={glowOpacity}>
        <BlurMask blur={size * 0.32} style="normal" />
      </Circle>
      <Group transform={transform} opacity={active}>
        <Path path={planePath()} color={colors.white} />
      </Group>
    </Canvas>
  );
}

function TrailSegment({ index, head, active, easing, geo }: {
  index: number;
  head: SharedValue<number>;
  active: SharedValue<number>;
  easing: 'accelerate' | 'smooth';
  geo: { a: { x: number; y: number }; b: { x: number; y: number }; c: { x: number; y: number } };
}) {
  // The trail is 34 steps of 1.1% in the original; six tapered segments read the same and draw far less.
  const per = 34 / SEGMENTS;
  const path = useDerivedValue(() => {
    const ease = (t: number) => {
      const x = Math.min(1, Math.max(0, t));
      return easing === 'accelerate' ? Math.pow(x, 2) * 0.85 + x * 0.15 : x * x * (3 - 2 * x) * 0.8 + x * 0.2;
    };
    const at = (t: number) => {
      const e = ease(t);
      const u = 1 - e;
      return { x: u * u * geo.a.x + 2 * u * e * geo.c.x + e * e * geo.b.x, y: u * u * geo.a.y + 2 * u * e * geo.c.y + e * e * geo.b.y };
    };
    const p = Skia.PathBuilder.Make();
    const t0 = Math.max(0, head.value - index * per * 0.011);
    const t1 = Math.max(0, head.value - (index + 1) * per * 0.011);
    const steps = 4;
    for (let s = 0; s <= steps; s++) {
      const pt = at(t0 + ((t1 - t0) * s) / steps);
      if (s === 0) p.moveTo(pt.x, pt.y); else p.lineTo(pt.x, pt.y);
    }
    return p.build();
  });
  const f = 1 - (index + 0.5) / SEGMENTS;
  const opacity = useDerivedValue(() => active.value * 0.5 * f * f);
  return <Path path={path} style="stroke" strokeCap="round" strokeWidth={Math.max(0.6, 2.6 * f)} color={colors.white} opacity={opacity} />;
}
