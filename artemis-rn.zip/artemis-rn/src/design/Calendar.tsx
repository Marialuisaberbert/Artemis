import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { HapticsService } from '../services/HapticsService';
import { Icon } from './Icon';
import { Caps, T } from './text';
import { alpha, colors } from './theme';

export interface YMD { y: number; m: number; d: number }
export const ymdKey = (v: YMD): number => v.y * 10000 + v.m * 100 + v.d;
export const ymdFromDate = (d: Date): YMD => ({ y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate() });
export const addDaysYMD = (v: YMD, n: number): YMD => ymdFromDate(new Date(v.y, v.m - 1, v.d + n));
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
export const formatYMD = (v: YMD): string => `${MONTHS[v.m - 1].slice(0, 3)} ${v.d}, ${v.y}`;

interface Props {
  value: YMD;
  min: YMD;
  /** The other end of the trip, drawn as a range. */
  rangeFrom?: YMD;
  rangeTo?: YMD;
  onChange: (v: YMD) => void;
}

/** A quiet month calendar for choosing a date. */
export function Calendar({ value, min, rangeFrom, rangeTo, onChange }: Props) {
  const [view, setView] = useState({ y: value.y, m: value.m });
  const first = new Date(view.y, view.m - 1, 1);
  const lead = first.getDay();
  const days = new Date(view.y, view.m, 0).getDate();
  const cells: (YMD | undefined)[] = [...Array(lead).fill(undefined), ...Array.from({ length: days }, (_, i) => ({ y: view.y, m: view.m, d: i + 1 }))];
  while (cells.length % 7) cells.push(undefined);
  const step = (n: number) => { const d = new Date(view.y, view.m - 1 + n, 1); setView({ y: d.getFullYear(), m: d.getMonth() + 1 }); };
  const inRange = (c: YMD) => rangeFrom && rangeTo && ymdKey(c) > ymdKey(rangeFrom) && ymdKey(c) < ymdKey(rangeTo);
  return (
    <View style={{ gap: 6 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Pressable accessibilityRole="button" accessibilityLabel="Previous month" onPress={() => step(-1)} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="chevronLeft" size={18} color={colors.luster} strokeWidth={2.2} />
        </Pressable>
        <T style={{ color: colors.luster, fontSize: 16, fontWeight: '600' }}>{MONTHS[view.m - 1]} {view.y}</T>
        <Pressable accessibilityRole="button" accessibilityLabel="Next month" onPress={() => step(1)} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="chevronRight" size={18} color={colors.luster} strokeWidth={2.2} />
        </Pressable>
      </View>
      <View style={{ flexDirection: 'row' }}>
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => <View key={i} style={{ flex: 1, alignItems: 'center' }}><Caps size={11} tracking={1} opacity={0.5}>{d}</Caps></View>)}
      </View>
      {Array.from({ length: cells.length / 7 }, (_, r) => (
        <View key={r} style={{ flexDirection: 'row' }}>
          {cells.slice(r * 7, r * 7 + 7).map((c, i) => {
            if (!c) return <View key={i} style={{ flex: 1, height: 44 }} />;
            const disabled = ymdKey(c) < ymdKey(min);
            const on = ymdKey(c) === ymdKey(value);
            return (
              <Pressable key={i} disabled={disabled} accessibilityRole="button" accessibilityState={{ selected: on, disabled }} accessibilityLabel={formatYMD(c)}
                onPress={() => { HapticsService.select(); onChange(c); }} style={{ flex: 1, height: 44, alignItems: 'center', justifyContent: 'center' }}>
                <View style={{ width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? colors.luster : inRange(c) ? alpha(colors.luster, 0.14) : 'transparent' }}>
                  <T style={{ color: on ? colors.depths : colors.luster, opacity: disabled ? 0.25 : 1, fontSize: 16, fontWeight: on ? '700' : '400' }}>{c.d}</T>
                </View>
              </Pressable>
            );
          })}
        </View>
      ))}
    </View>
  );
}
