import React from 'react';
import { Text, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { colors } from './theme';
import { LOGO_HEIGHT, LOGO_WIDTH, logoPathData } from './logoPath';

const PATH = logoPathData();

interface Props {
  style?: 'mark' | 'lockup';
  /** The height of the mark. */
  size?: number;
  color?: string;
}

/** The single place the logo is drawn. Use this everywhere; never draw a logo inline. */
export function ArtemisLogo({ style = 'mark', size = 28, color = colors.cream }: Props) {
  const w = (size * LOGO_WIDTH) / LOGO_HEIGHT;
  return (
    <View accessible accessibilityLabel="Artemis" style={{ flexDirection: 'row', alignItems: 'center', gap: size * 0.5 }}>
      <Svg width={w} height={size} viewBox={`0 0 ${LOGO_WIDTH} ${LOGO_HEIGHT}`}>
        <Path d={PATH} fill={color} />
      </Svg>
      {style === 'lockup' && (
        <Text style={{ color, fontSize: size * 0.5, fontWeight: '500', letterSpacing: size * 0.16 }}>ARTEMIS</Text>
      )}
    </View>
  );
}
