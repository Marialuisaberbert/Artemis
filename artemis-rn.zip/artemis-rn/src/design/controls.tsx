import React from 'react';
import { GestureResponderEvent, Pressable, StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import Animated, { useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { HapticsService } from '../services/HapticsService';
import { Icon, IconName } from './Icon';
import { Caps, T } from './text';
import { alpha, colors, white } from './theme';

// MARK: - Buttons

export type CTAKind = 'light' | 'ghost' | 'royal';

interface CTAProps {
  title: string;
  onPress?: (e: GestureResponderEvent) => void;
  kind?: CTAKind;
  compact?: boolean;
  disabled?: boolean;
  icon?: IconName;
  style?: StyleProp<ViewStyle>;
  accessibilityLabel?: string;
  haptic?: boolean;
}

/** Luster on a dark canvas — the default hero action. Capsule, 58 pt tall, tracked heavy capitals. */
export function CTAButton({ title, onPress, kind = 'light', compact = false, disabled = false, icon, style, accessibilityLabel, haptic = false }: CTAProps) {
  const pressed = useSharedValue(0);
  const anim = useAnimatedStyle(() => ({ opacity: withTiming(pressed.value ? 0.88 : 1, { duration: 120 }), transform: [{ scale: withTiming(pressed.value ? 0.98 : 1, { duration: 140 }) }] }));
  const c = kind === 'light' ? { fill: colors.luster, ink: colors.depths, border: 'transparent' }
    : kind === 'royal' ? { fill: colors.royal, ink: colors.luster, border: 'transparent' }
    : { fill: 'transparent', ink: colors.luster, border: alpha(colors.luster, 0.4) };
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? title}
      accessibilityState={{ disabled }}
      disabled={disabled}
      onPressIn={() => { pressed.value = 1; }}
      onPressOut={() => { pressed.value = 0; }}
      onPress={(e) => { if (haptic) HapticsService.tap(); onPress?.(e); }}
      style={[{ alignSelf: compact ? 'auto' : 'stretch' }, disabled && { opacity: 0.4 }, style]}
    >
      <Animated.View
        style={[{
          minHeight: compact ? 44 : 58, paddingHorizontal: compact ? 20 : 24, borderRadius: 999, backgroundColor: c.fill,
          borderWidth: kind === 'ghost' ? 1.5 : 0, borderColor: c.border, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
        }, anim]}
      >
        {icon && <Icon name={icon} size={compact ? 15 : 17} color={c.ink} />}
        <T numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7} style={{ color: c.ink, fontSize: compact ? 13 : 15, fontWeight: '800', letterSpacing: 1.4 }}>{title}</T>
      </Animated.View>
    </Pressable>
  );
}

interface RoundIconProps {
  icon: IconName;
  label: string;
  onPress: () => void;
  size?: number;
}

/** A round icon button, for close and back on cinematic screens. */
export function RoundIconButton({ icon, label, onPress, size = 44 }: RoundIconProps) {
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} hitSlop={6} style={{ width: size, height: size }}>
      <View style={[styles.round, { width: size, height: size, borderRadius: size / 2 }]}>
        <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
        <Icon name={icon} size={17} color={colors.luster} strokeWidth={2.2} />
      </View>
    </Pressable>
  );
}

// MARK: - Panels

interface GlassProps {
  children?: React.ReactNode;
  radius?: number;
  padding?: number;
  style?: StyleProp<ViewStyle>;
  intensity?: number;
}

/** A translucent panel for dark, cinematic screens: blur, a whisper of white, a hairline border. */
export function GlassPanel({ children, radius = 24, padding = 20, style, intensity = 28 }: GlassProps) {
  return (
    <View style={[{ borderRadius: radius, overflow: 'hidden', borderWidth: 1, borderColor: alpha(colors.luster, 0.16) }, style]}>
      <BlurView intensity={intensity} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.3)' }]} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: alpha(colors.luster, 0.07) }]} />
      <View style={{ padding }}>{children}</View>
    </View>
  );
}

export function Hairline({ color = white(0.16) }: { color?: string }) {
  return <View accessibilityElementsHidden style={{ height: StyleSheet.hairlineWidth * 2, backgroundColor: color }} />;
}

// MARK: - Chips

interface ChipProps {
  title: string;
  selected: boolean;
  onPress: () => void;
  icon?: IconName;
}

export function SelectableChip({ title, selected, onPress, icon }: ChipProps) {
  return (
    <Pressable
      accessibilityRole="button" accessibilityState={{ selected }} accessibilityLabel={title}
      onPress={() => { HapticsService.select(); onPress(); }}
      style={{
        minHeight: 44, paddingHorizontal: 16, borderRadius: 999, flexDirection: 'row', alignItems: 'center', gap: 6, justifyContent: 'center',
        backgroundColor: selected ? colors.luster : alpha(colors.luster, 0.08), borderWidth: 1, borderColor: selected ? 'transparent' : alpha(colors.luster, 0.25),
      }}
    >
      {icon && <Icon name={icon} size={14} color={selected ? colors.depths : colors.luster} />}
      <T style={{ color: selected ? colors.depths : colors.luster, fontSize: 15, fontWeight: '600' }}>{title}</T>
    </Pressable>
  );
}

export { Caps };

const styles = StyleSheet.create({
  round: { alignItems: 'center', justifyContent: 'center', overflow: 'hidden', backgroundColor: alpha(colors.depths, 0.55), borderWidth: 1, borderColor: alpha(colors.luster, 0.22) },
});
