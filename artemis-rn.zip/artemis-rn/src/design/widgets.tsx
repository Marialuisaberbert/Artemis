import React, { useEffect, useState } from 'react';
import { LayoutChangeEvent, Pressable, StyleSheet, View } from 'react-native';
import { BlurView } from 'expo-blur';
import Svg, { Circle } from 'react-native-svg';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  Easing, useAnimatedProps, useAnimatedStyle, useReducedMotion, useSharedValue, withDelay, withRepeat, withTiming,
} from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import { hourLabel, DepartureWindow, Strength, strengthLabel, strengthShort, nextStrength, windowLabel } from '../domain/matching/preferences';
import { Traveler, fullName, initials } from '../domain/matching/traveler';
import { usd } from '../domain/shared/money';
import { HapticsService } from '../services/HapticsService';
import { Icon, IconName } from './Icon';
import { Caps, Eyebrow, Mono, T } from './text';
import { alpha, colors, white } from './theme';

// MARK: - Avatars

export type AvatarBadge = 'none' | 'pending' | 'joined' | 'done';
const TINTS = [
  { bg: colors.royal, fg: colors.luster }, { bg: colors.habanero, fg: colors.depths },
  { bg: colors.aster, fg: colors.depths }, { bg: colors.jodhpur, fg: colors.depths },
];

export function TravelerAvatar({ traveler, size = 44, badge = 'none' }: { traveler: Traveler; size?: number; badge?: AvatarBadge }) {
  const tint = TINTS[traveler.tint % 4];
  const reduce = useReducedMotion();
  const pulse = useSharedValue(0);
  useEffect(() => {
    if (badge === 'pending' && !reduce) pulse.value = withRepeat(withTiming(1, { duration: 1300, easing: Easing.out(Easing.ease) }), -1, false);
    else pulse.value = 0;
  }, [badge, reduce, pulse]);
  const ring = useAnimatedStyle(() => ({ opacity: 0.9 - pulse.value * 0.75, transform: [{ scale: 1 + pulse.value * 0.22 }] }));
  return (
    <View accessible accessibilityLabel={fullName(traveler)} style={{ width: size, height: size }}>
      <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: tint.bg, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: alpha(colors.luster, 0.25) }}>
        <T style={{ color: tint.fg, fontSize: size * 0.36, fontWeight: '700', letterSpacing: 0.5 }} maxFontSizeMultiplier={1.1}>{initials(traveler)}</T>
      </View>
      {badge === 'pending' && <Animated.View style={[StyleSheet.absoluteFill, { borderRadius: size / 2, borderWidth: 2, borderColor: colors.habanero }, ring]} />}
      {(badge === 'joined' || badge === 'done') && (
        <View style={{ position: 'absolute', right: -2, bottom: -2, width: size * 0.36, height: size * 0.36, borderRadius: size * 0.18, backgroundColor: colors.luster, borderWidth: 2, borderColor: colors.depths, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="check" size={size * 0.2} color={colors.depths} strokeWidth={3.2} />
        </View>
      )}
    </View>
  );
}

// MARK: - Match ring

const AnimatedCircle = Animated.createAnimatedComponent(Circle);

export function MatchRing({ percent, size = 64, lineWidth = 5 }: { percent: number; size?: number; lineWidth?: number }) {
  const r = (size - lineWidth) / 2;
  const c = 2 * Math.PI * r;
  const shown = useSharedValue(0);
  useEffect(() => { shown.value = withDelay(150, withTiming(percent / 100, { duration: 1000, easing: Easing.out(Easing.ease) })); }, [percent, shown]);
  const props = useAnimatedProps(() => ({ strokeDashoffset: c * (1 - shown.value) }));
  return (
    <View accessible accessibilityLabel={`${percent} percent group match`} style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Svg width={size} height={size} style={StyleSheet.absoluteFill}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={alpha(colors.luster, 0.14)} strokeWidth={lineWidth} fill="none" />
        <AnimatedCircle cx={size / 2} cy={size / 2} r={r} stroke={colors.luster} strokeWidth={lineWidth} strokeLinecap="round" fill="none"
          strokeDasharray={`${c} ${c}`} animatedProps={props} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      </Svg>
      <Mono size={size * 0.34} weight="700" color={colors.luster} style={{ lineHeight: size * 0.38 }} maxFontSizeMultiplier={1.1}>{percent}</Mono>
      <T style={{ color: alpha(colors.luster, 0.6), fontSize: size * 0.16, fontWeight: '700', marginTop: -2 }} maxFontSizeMultiplier={1.1}>%</T>
    </View>
  );
}

// MARK: - Chips and pills

export function StrengthChip({ strength, onChange }: { strength: Strength; onChange: (s: Strength) => void }) {
  const dot = strength === 'must' ? colors.habanero : strength === 'preferred' ? colors.aster : alpha(colors.luster, 0.4);
  return (
    <Pressable
      accessibilityRole="button" accessibilityLabel={`How much this matters: ${strengthLabel(strength).toLowerCase()}`} accessibilityHint="Double tap to change"
      onPress={() => { HapticsService.select(); onChange(nextStrength(strength)); }} hitSlop={{ top: 6, bottom: 6, left: 4, right: 4 }}
      style={{ minHeight: 32, paddingHorizontal: 10, borderRadius: 999, flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: alpha(colors.luster, 0.1), borderWidth: 1, borderColor: alpha(colors.luster, 0.22) }}
    >
      <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: dot }} />
      <T style={{ color: alpha(colors.luster, 0.92), fontSize: 11, fontWeight: '800', letterSpacing: 1 }}>{strengthShort(strength).toUpperCase()}</T>
    </Pressable>
  );
}

export function StarRating({ title, value, onChange, max = 5 }: { title: string; value: number; onChange: (v: number) => void; max?: number }) {
  return (
    <View
      accessible accessibilityRole="adjustable" accessibilityLabel={`${title} priority`} accessibilityValue={{ text: `${value} of ${max} stars` }}
      accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
      onAccessibilityAction={(e) => onChange(e.nativeEvent.actionName === 'increment' ? Math.min(max, value + 1) : Math.max(1, value - 1))}
      style={{ flexDirection: 'row', gap: 4 }}
    >
      {Array.from({ length: max }, (_, k) => k + 1).map((i) => (
        <Pressable key={i} accessible={false} onPress={() => { HapticsService.select(); onChange(i); }} style={{ width: 32, height: 44, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name={i <= value ? 'starFill' : 'star'} size={20} color={i <= value ? colors.habanero : alpha(colors.luster, 0.35)} />
        </Pressable>
      ))}
    </View>
  );
}

export function SegmentedPill<V extends string | number>({ items, selection, onChange }: { items: { value: V; label: string }[]; selection: V; onChange: (v: V) => void }) {
  return (
    <View style={{ flexDirection: 'row', padding: 4, gap: 4, borderRadius: 999, backgroundColor: alpha(colors.luster, 0.08), borderWidth: 1, borderColor: alpha(colors.luster, 0.2) }}>
      {items.map((item) => {
        const on = item.value === selection;
        return (
          <Pressable key={String(item.value)} accessibilityRole="button" accessibilityState={{ selected: on }} accessibilityLabel={item.label}
            onPress={() => { if (!on) { HapticsService.select(); onChange(item.value); } }}
            style={{ flex: 1, minHeight: 44, borderRadius: 999, alignItems: 'center', justifyContent: 'center', backgroundColor: on ? colors.luster : 'transparent' }}>
            <T style={{ color: on ? colors.depths : colors.luster, fontSize: 15, fontWeight: '600' }}>{item.label}</T>
          </Pressable>
        );
      })}
    </View>
  );
}

/** A frosted pill for small facts over photography. */
export function GlassPill({ text, icon }: { text: string; icon?: IconName }) {
  return (
    <View style={{ borderRadius: 999, overflow: 'hidden', borderWidth: 1, borderColor: white(0.2), alignSelf: 'flex-start' }}>
      <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 11, paddingVertical: 7 }}>
        {icon && <Icon name={icon} size={11} color="#fff" strokeWidth={2.2} />}
        <T style={{ color: '#fff', fontSize: 10.5, fontWeight: '600', letterSpacing: 1.2 }}>{text}</T>
      </View>
    </View>
  );
}

/** A frosted pill button for chrome over photography. */
export function GlassButton({ title, icon, onPress }: { title: string; icon?: IconName; onPress: () => void }) {
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={title} onPress={() => { HapticsService.tap(); onPress(); }}
      style={{ minHeight: 44, borderRadius: 999, overflow: 'hidden', borderWidth: 1, borderColor: white(0.22), justifyContent: 'center' }}>
      <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14 }}>
        {icon && <Icon name={icon} size={13} color="#fff" strokeWidth={2.2} />}
        <T style={{ color: '#fff', fontSize: 11, fontWeight: '600', letterSpacing: 1.4 }}>{title}</T>
      </View>
    </Pressable>
  );
}

// MARK: - Spinner

export function Spinner({ size = 40 }: { size?: number }) {
  const spin = useSharedValue(0);
  const reduce = useReducedMotion();
  useEffect(() => { if (!reduce) spin.value = withRepeat(withTiming(360, { duration: 900, easing: Easing.linear }), -1, false); }, [reduce, spin]);
  const style = useAnimatedStyle(() => ({ transform: [{ rotate: `${spin.value}deg` }] }));
  const r = size / 2 - 2;
  const c = 2 * Math.PI * r;
  return (
    <Animated.View style={[{ width: size, height: size }, style]}>
      <Svg width={size} height={size}>
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={alpha(colors.luster, 0.18)} strokeWidth={2} fill="none" />
        <Circle cx={size / 2} cy={size / 2} r={r} stroke={colors.habanero} strokeWidth={2.5} strokeLinecap="round" fill="none" strokeDasharray={`${c * 0.28} ${c}`} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      </Svg>
    </Animated.View>
  );
}

// MARK: - Sliders

const THUMB = 30;

/** A single-thumb slider with a fixed step. */
function useTrack() {
  const [w, setW] = useState(0);
  return { w, onLayout: (e: LayoutChangeEvent) => setW(e.nativeEvent.layout.width) };
}

interface SliderProps {
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  label: string;
  valueText?: string;
}

export function Slider({ value, min, max, step, onChange, label, valueText }: SliderProps) {
  const { w, onLayout } = useTrack();
  const track = Math.max(1, w - THUMB);
  const frac = (value - min) / (max - min);
  const set = (x: number) => {
    const raw = min + Math.min(1, Math.max(0, (x - THUMB / 2) / track)) * (max - min);
    const v = Math.min(max, Math.max(min, Math.round(raw / step) * step));
    if (v !== value) { HapticsService.select(); onChange(v); }
  };
  const gesture = Gesture.Pan().minDistance(0).onBegin((e) => { scheduleOnRN(set, e.x); }).onChange((e) => { scheduleOnRN(set, e.x); });
  return (
    <GestureDetector gesture={gesture}>
      <View
        onLayout={onLayout} accessible accessibilityRole="adjustable" accessibilityLabel={label} accessibilityValue={{ text: valueText ?? String(value) }}
        accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
        onAccessibilityAction={(e) => onChange(Math.min(max, Math.max(min, value + (e.nativeEvent.actionName === 'increment' ? step : -step))))}
        style={{ height: 44, justifyContent: 'center' }}
      >
        <View style={{ height: 6, borderRadius: 3, backgroundColor: alpha(colors.luster, 0.14), marginHorizontal: THUMB / 2 }} />
        <View style={{ position: 'absolute', left: THUMB / 2, width: frac * track, height: 6, borderRadius: 3, backgroundColor: colors.aster }} />
        <View style={[styles.thumb, { left: frac * track }]} />
      </View>
    </GestureDetector>
  );
}

/** A big number over a slider. For budgets. */
export function BudgetSlider({ title, unit = '', value, min, max, step = 25, compact = false, trailing, onChange }: {
  title: string; unit?: string; value: number; min: number; max: number; step?: number; compact?: boolean; trailing?: React.ReactNode; onChange: (v: number) => void;
}) {
  return (
    <View style={{ gap: 8 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <Eyebrow color={alpha(colors.luster, 0.6)} opacity={1}>{title}</Eyebrow>
        {trailing}
      </View>
      <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 6 }}>
        <Mono size={compact ? 30 : 40} weight="600" color={colors.luster} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6} style={{ letterSpacing: -1 }}>{usd(value)}</Mono>
        {!!unit && <T style={{ color: alpha(colors.luster, 0.55), fontSize: 15 }}>{unit}</T>}
      </View>
      <Slider value={value} min={min} max={max} step={step} onChange={onChange} label={title} valueText={`${usd(value)} ${unit}`} />
    </View>
  );
}

/** Two thumbs on a 24-hour track. For departure windows. */
export function HourRangeSlider({ window: win, onChange }: { window: DepartureWindow; onChange: (w: DepartureWindow) => void }) {
  const { w, onLayout } = useTrack();
  const track = Math.max(1, w - THUMB);
  const x0 = (track * win.startHour) / 24;
  const x1 = (track * win.endHour) / 24;
  const active = useSharedValue<0 | 1>(0);
  const move = (which: 0 | 1, x: number) => {
    const h = Math.round(((x - THUMB / 2) / track) * 24);
    if (which === 0) {
      const s = Math.min(Math.max(0, h), win.endHour - 2);
      if (s !== win.startHour) { HapticsService.select(); onChange({ ...win, startHour: s }); }
    } else {
      const e = Math.max(Math.min(24, h), win.startHour + 2);
      if (e !== win.endHour) { HapticsService.select(); onChange({ ...win, endHour: e }); }
    }
  };
  const pick = (x: number) => { const which: 0 | 1 = Math.abs(x - (x0 + THUMB / 2)) <= Math.abs(x - (x1 + THUMB / 2)) ? 0 : 1; active.value = which; move(which, x); };
  const gesture = Gesture.Pan().minDistance(0).onBegin((e) => { scheduleOnRN(pick, e.x); }).onChange((e) => { scheduleOnRN(move, active.value, e.x); });
  return (
    <View style={{ gap: 10 }}>
      <Mono size={26} weight="600" color={colors.luster}>{windowLabel(win)}</Mono>
      <GestureDetector gesture={gesture}>
        <View onLayout={onLayout} style={{ height: 44, justifyContent: 'center' }}>
          <View style={{ height: 6, borderRadius: 3, backgroundColor: alpha(colors.luster, 0.14), marginHorizontal: THUMB / 2 }} />
          <View style={{ position: 'absolute', left: x0 + THUMB / 2, width: Math.max(0, x1 - x0), height: 6, borderRadius: 3, backgroundColor: colors.aster }} />
          <View accessible accessibilityRole="adjustable" accessibilityLabel="Earliest departure" accessibilityValue={{ text: hourLabel(win.startHour) }}
            accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
            onAccessibilityAction={(e) => onChange({ ...win, startHour: Math.min(Math.max(0, win.startHour + (e.nativeEvent.actionName === 'increment' ? 1 : -1)), win.endHour - 2) })}
            style={[styles.thumb, { left: x0 }]} />
          <View accessible accessibilityRole="adjustable" accessibilityLabel="Latest departure" accessibilityValue={{ text: hourLabel(win.endHour) }}
            accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
            onAccessibilityAction={(e) => onChange({ ...win, endHour: Math.max(Math.min(24, win.endHour + (e.nativeEvent.actionName === 'increment' ? 1 : -1)), win.startHour + 2) })}
            style={[styles.thumb, { left: x1 }]} />
        </View>
      </GestureDetector>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }} accessibilityElementsHidden>
        {['12 AM', '6 AM', '12 PM', '6 PM', '12 AM'].map((l, i) => <Caps key={i} size={10} tracking={0} weight="400" opacity={0.45}>{l}</Caps>)}
      </View>
    </View>
  );
}

// MARK: - Status

export type BannerTone = 'good' | 'neutral' | 'warning';

export function StatusBanner({ icon, title, message, tone = 'good' }: { icon: IconName; title: string; message: string; tone?: BannerTone }) {
  return (
    <View style={{
      flexDirection: 'row', alignItems: 'center', gap: 14, padding: 16, borderRadius: 24, borderWidth: 1,
      backgroundColor: tone === 'good' ? alpha(colors.royal, 0.55) : alpha(colors.luster, 0.08), borderColor: tone === 'good' ? alpha(colors.aster, 0.7) : alpha(colors.luster, 0.3),
    }} accessible accessibilityLabel={`${title}. ${message}`}>
      <View style={{ width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', backgroundColor: tone === 'warning' ? colors.habanero : colors.luster }}>
        <Icon name={icon} size={17} color={colors.depths} strokeWidth={3} />
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <T style={{ color: colors.luster, fontSize: 20, fontWeight: '800', letterSpacing: 0.2 }}>{title}</T>
        <T style={{ color: alpha(colors.luster, 0.8), fontSize: 15 }}>{message}</T>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  thumb: {
    position: 'absolute', top: 7, width: THUMB, height: THUMB, borderRadius: THUMB / 2, backgroundColor: colors.luster,
    shadowColor: colors.depths, shadowOpacity: 0.4, shadowRadius: 4, shadowOffset: { width: 0, height: 2 },
  },
});
