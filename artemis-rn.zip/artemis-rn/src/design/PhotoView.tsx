import React, { useEffect, useState } from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { Easing, useAnimatedStyle, useReducedMotion, useSharedValue, withRepeat, withTiming } from 'react-native-reanimated';
import type { Destination, DestinationPhoto } from '../domain/destinations/destinations';
import { photoSource } from './photos';
import { Caps } from './text';

interface PhotoProps {
  photo: DestinationPhoto;
  title?: string;
  /** A slow push-in, like a film frame that is alive. */
  drift?: boolean;
  blur?: number;
  style?: StyleProp<ViewStyle>;
}

/**
 * A destination photograph, filling its frame. The subject stays in view when the image is cropped (`focusX/Y`), the
 * photograph fades in, and a missing image degrades to a quiet dark tile rather than a gap.
 */
export function DestinationPhotoView({ photo, title = '', drift = false, blur = 0, style }: PhotoProps) {
  const source = photoSource(photo.file);
  const [failed, setFailed] = useState(!source);
  const reduce = useReducedMotion();
  const scale = useSharedValue(1);
  useEffect(() => {
    if (drift && !reduce) scale.value = withRepeat(withTiming(1.07, { duration: 14000, easing: Easing.inOut(Easing.ease) }), -1, true);
    else scale.value = 1;
  }, [drift, reduce, scale]);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <View style={[styles.fill, { backgroundColor: '#0d0d0d', overflow: 'hidden' }, style]} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      <LinearGradient colors={['#292929', '#0d0d0d']} style={StyleSheet.absoluteFill} />
      {failed ? (
        <View style={[StyleSheet.absoluteFill, { padding: 24, justifyContent: 'flex-start' }]}>
          <Caps size={44} tracking={0} opacity={0.14} weight="800">{title.toUpperCase()}</Caps>
        </View>
      ) : (
        <Animated.View style={[StyleSheet.absoluteFill, anim, { transformOrigin: `${photo.focusX * 100}% ${photo.focusY * 100}%` }]}>
          <Image
            source={source}
            style={StyleSheet.absoluteFill}
            contentFit="cover"
            contentPosition={{ left: `${photo.focusX * 100}%`, top: `${photo.focusY * 100}%` }}
            transition={500}
            blurRadius={blur}
            onError={() => setFailed(true)}
          />
        </Animated.View>
      )}
    </View>
  );
}

interface BackdropProps {
  destination: Destination;
  blur?: number;
  dim?: number;
  bottomScrim?: number;
  drift?: boolean;
}

/** A photograph as an environment: full-screen, with adjustable blur and dimming, and a scrim so type stays legible. */
export function PhotoBackdrop({ destination, blur = 0, dim = 0.25, bottomScrim = 0.6, drift = true }: BackdropProps) {
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      <DestinationPhotoView photo={destination.photo} title={destination.city} drift={drift} blur={blur} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: `rgba(0,0,0,${dim})` }]} />
      <LinearGradient colors={['rgba(0,0,0,0.35)', 'rgba(0,0,0,0)', `rgba(0,0,0,${bottomScrim})`]} style={StyleSheet.absoluteFill} />
    </View>
  );
}

const styles = StyleSheet.create({ fill: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 } });
