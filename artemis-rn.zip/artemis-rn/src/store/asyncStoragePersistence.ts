import AsyncStorage from '@react-native-async-storage/async-storage';
import type { TripPersistence, TripStoreSnapshot } from '../domain/trips/snapshot';

const KEY = 'artemis-state-v1';

/** A JSON snapshot in AsyncStorage. If it can't be read, the app simply starts from the demo trip. */
export class AsyncStorageTripPersistence implements TripPersistence {
  async load(): Promise<TripStoreSnapshot | undefined> {
    try {
      const raw = await AsyncStorage.getItem(KEY);
      if (!raw) return undefined;
      const parsed = JSON.parse(raw) as TripStoreSnapshot;
      return parsed && parsed.version === 1 && Array.isArray(parsed.trips) ? parsed : undefined;
    } catch {
      return undefined;
    }
  }
  async save(snapshot: TripStoreSnapshot): Promise<void> {
    try { await AsyncStorage.setItem(KEY, JSON.stringify(snapshot)); } catch { /* the app carries on without saving */ }
  }
  async clear(): Promise<void> {
    try { await AsyncStorage.removeItem(KEY); } catch { /* ignore */ }
  }
}
