import { useMemo } from 'react';
import type { GroupOrderEntry, ScoredFlight, ScoredHotel, SharedProfile } from '../domain/matching/matchingService';
import type { ItineraryEvent, Trip } from '../domain/trips/trip';
import { getTripStore, useTripStore } from './useTripStore';

/** One trip, live from the store. */
export const useTrip = (id: string | undefined): Trip | undefined => useTripStore((s) => (id ? s.trips.find((t) => t.id === id) : undefined));

// Derived views are computed from the trip, memoised on it, so components never select a fresh object from the store.

export function useSharedProfile(tripID: string): SharedProfile | undefined {
  const trip = useTrip(tripID);
  return useMemo(() => getTripStore().sharedProfile(tripID), [trip, tripID]); // eslint-disable-line react-hooks/exhaustive-deps
}

export function useFlightMatches(tripID: string): { matches: ScoredFlight[]; outside: ScoredFlight[] } | undefined {
  const trip = useTrip(tripID);
  return useMemo(() => getTripStore().flightMatches(tripID), [trip, tripID]); // eslint-disable-line react-hooks/exhaustive-deps
}

export function useHotelPick(tripID: string): ScoredHotel | undefined {
  const trip = useTrip(tripID);
  return useMemo(() => getTripStore().hotelPick(tripID), [trip, tripID]); // eslint-disable-line react-hooks/exhaustive-deps
}

export function useGroupOrder(tripID: string): GroupOrderEntry[] {
  const trip = useTrip(tripID);
  return useMemo(() => getTripStore().groupOrder(tripID), [trip, tripID]); // eslint-disable-line react-hooks/exhaustive-deps
}

export function useItinerary(tripID: string): ItineraryEvent[] {
  const trip = useTrip(tripID);
  return useMemo(() => getTripStore().itineraryEvents(tripID), [trip, tripID]); // eslint-disable-line react-hooks/exhaustive-deps
}
