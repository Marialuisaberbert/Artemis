import AsyncStorage from '@react-native-async-storage/async-storage';
import { useStore } from 'zustand';
import { AnsRegistryClient, LiveIdentityService } from '../domain/trust/ans';
import { DecisionEngine } from '../domain/trust/decisionEngine';
import { NessieLedger } from '../domain/trust/nessie';
import { LedgerFinancialService, MockFinancialService, MockIdentityService, MockPolicyService, latencyDemo } from '../domain/trust/services';
import { ArtemisTrustEngine } from '../domain/trust/trustEngine';
import { ExpoLocationService } from '../services/LocationService';
import { AsyncStorageTripPersistence } from './asyncStoragePersistence';
import { TripStoreState, createTripStore } from './tripStore';

// Expo only inlines `process.env.EXPO_PUBLIC_*` when written out in full like this.
const NESSIE_KEY = process.env.EXPO_PUBLIC_NESSIE_KEY;
const ANS_KEY = process.env.EXPO_PUBLIC_GODADDY_ANS_KEY;
const ANS_SECRET = process.env.EXPO_PUBLIC_GODADDY_ANS_SECRET;

// Live where a key is configured, simulated everywhere else. Every trust result says which it was.
const ledger = NESSIE_KEY ? new NessieLedger({ apiKey: NESSIE_KEY, storage: AsyncStorage }) : undefined;
const identity = ANS_KEY && ANS_SECRET
  ? new LiveIdentityService(new AnsRegistryClient({ key: ANS_KEY, secret: ANS_SECRET }), new MockIdentityService(latencyDemo))
  : new MockIdentityService(latencyDemo);
const financial = ledger
  ? new LedgerFinancialService(ledger, () => tripStore.getState().financial, latencyDemo)
  : new MockFinancialService(latencyDemo);

/** Which services are real in this build. Shown in Prototype tools. */
export const liveServices = { financial: ledger !== undefined, identity: ANS_KEY !== undefined && ANS_SECRET !== undefined };

/** The one store, bound to the device: AsyncStorage for persistence, expo-location for the traveler's place. */
export const tripStore = createTripStore({
  persistence: new AsyncStorageTripPersistence(),
  location: new ExpoLocationService(),
  trust: new ArtemisTrustEngine(new DecisionEngine(identity, new MockPolicyService(latencyDemo), financial)),
  ledger,
});

export function useTripStore<T>(selector: (s: TripStoreState) => T): T {
  return useStore(tripStore, selector);
}

export const getTripStore = (): TripStoreState => tripStore.getState();
