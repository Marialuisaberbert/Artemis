import { create } from 'zustand';

/** The four sections of the app, and what is showing on top of them. Navigation state only — no rules. */
export type AppTab = 'home' | 'explore' | 'trips' | 'profile';
export const appTabs: AppTab[] = ['home', 'explore', 'trips', 'profile'];
export const tabTitle = (t: AppTab): string => ({ home: 'WORLD', explore: 'DISCOVER', trips: 'TRIPS', profile: 'YOU' })[t];

interface RouterState {
  tab: AppTab;
  setTab(tab: AppTab): void;
  /** Bumped by Profile → Prototype tools to play the morning greeting again. */
  replayGreeting: number;
  bumpReplayGreeting(): void;
}

export const useRouterState = create<RouterState>((set) => ({
  tab: 'home',
  setTab: (tab) => set({ tab }),
  replayGreeting: 0,
  bumpReplayGreeting: () => set((s) => ({ replayGreeting: s.replayGreeting + 1 })),
}));
