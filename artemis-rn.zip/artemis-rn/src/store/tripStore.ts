import { createStore, StoreApi } from 'zustand/vanilla';
import { DAY_MS, Instant, Zoned, addDays, deviceTimeZone, timeZone } from '../domain/shared/time';
import { Money, cents, usd } from '../domain/shared/money';
import { Destination } from '../domain/destinations/destinations';
import { DemoLocationService, LocationService, LocationStatus } from '../domain/destinations/locationService';
import { Place, placeAirport, rioPlace } from '../domain/destinations/place';
import { HotelOption } from '../domain/destinations/hotels';
import { DailyContext, DailyContextService } from '../domain/daily/dailyContext';
import {
  TravelPreferences, TravelStyleProfile, friendDefault, mariaDemo, mariaProfile, sofiaDemo,
} from '../domain/matching/preferences';
import {
  GroupOrderEntry, ScoredFlight, ScoredHotel, SharedProfile, TravelerPreferences, TripMatchingService,
} from '../domain/matching/matchingService';
import { Traveler, Travelers } from '../domain/matching/traveler';
import { demoAccount, demoPolicy } from '../domain/trust/demoData';
import { EvaluationResult, FinancialState, Layer, VerificationResult } from '../domain/trust/models';
import { TrustPolicy } from '../domain/trust/policy';
import { SimulatedLatency, latencyDemo, latencyDemoShort, latencyNone, waitLatency } from '../domain/trust/services';
import type { FinancialLedger } from '../domain/trust/nessie';
import { ArtemisTrustEngine, BookingIntent, flightIntent, hotelIntent, intentTotal } from '../domain/trust/trustEngine';
import { FlightOption, routeCodes } from '../domain/trips/flights';
import { ItineraryBuilder, hotelNights } from '../domain/trips/itinerary';
import { JourneySimulator, JourneyState } from '../domain/trips/journey';
import { TripDraft } from '../domain/trips/planner';
import { MockTravelSearchService, TravelSearchService, romeFlights } from '../domain/trips/search';
import { seedSnapshot, romeStart } from '../domain/trips/seed';
import { InMemoryTripPersistence, TripPersistence, TripStoreSnapshot } from '../domain/trips/snapshot';
import {
  Booking, BookingStatus, ItineraryEvent, Trip, TripPhase, TripStage, dateRange, everyoneRanked, everyoneSubmittedPreferences,
  memberIsInTrip, newMember, newTrip, selectedFlight, selectedHotel, stageAtMost, travelerCount, tripNights, tripTravelers,
} from '../domain/trips/trip';

// MARK: - Live trust check

/** One booking going through Identity → Policy → Financial. Screens render this; they never decide it. */
export interface TrustCheckRun {
  id: string;
  tripID?: string;
  intent: BookingIntent;
  title: string;
  subtitle: string;
  completed: Partial<Record<Layer, VerificationResult>>;
  active?: Layer;
  result?: EvaluationResult;
  /** `awaitingApproval`: APPROVAL_REQUIRED and waiting for the traveler. `finished`: a standalone demo (no booking attached). */
  phase: 'running' | 'awaitingApproval' | 'blocked' | 'booked' | 'declined' | 'finished';
  booking?: Booking;
}

export const isStandalone = (r: TrustCheckRun): boolean => r.tripID === undefined;

/** The prototype's built-in trust scenarios (Profile → Prototype tools). */
export type TrustDemo = 'autoApproved' | 'overPolicy' | 'impostor' | 'capReached';
export const trustDemos: TrustDemo[] = ['autoApproved', 'overPolicy', 'impostor', 'capReached'];
export const trustDemoTitle = (d: TrustDemo): string =>
  ({ autoApproved: 'Within your policy', overPolicy: 'Over your policy', impostor: 'Impostor provider', capReached: 'Monthly cap reached' })[d];
export const trustDemoDetail = (d: TrustDemo): string =>
  ({
    autoApproved: 'TAP Air Portugal · $547 × 2', overPolicy: 'ITA Premium · $850 × 2',
    impostor: '“TAP Air Portugal” from a lookalike domain', capReached: 'Five travelers · $590 each',
  })[d];
export const trustDemoOutcome = (d: TrustDemo): string =>
  ({ autoApproved: 'AUTO-APPROVED', overPolicy: 'APPROVAL REQUIRED', capReached: 'APPROVAL REQUIRED', impostor: 'BLOCKED' })[d];

export type InviteChannel = 'messages' | 'link' | 'contacts';
export const inviteChannels: InviteChannel[] = ['messages', 'link', 'contacts'];
export const inviteChannelTitle = (c: InviteChannel): string => ({ messages: 'Messages', link: 'Share link', contacts: 'Contacts' })[c];

/** Timing knobs. Tests use `pacingInstant`. */
export interface StorePacing {
  joinDelay: number;
  autoAcceptInvites: boolean;
  /** A held beat on "AUTO-APPROVED · READY TO BOOK" before the booking completes. */
  approvedBeat: number;
}
export const pacingDemo: StorePacing = { joinDelay: 1.6, autoAcceptInvites: true, approvedBeat: 1.1 };
export const pacingInstant: StorePacing = { joinDelay: 0, autoAcceptInvites: false, approvedBeat: 0 };

// MARK: - Notifications

export interface ArtemisNotification {
  id: string;
  title: string;
  body: string;
  date: Instant;
  tone: 'info' | 'good' | 'attention';
  symbol: string;
  tripID?: string;
}

// MARK: - Store

export interface TripStoreDeps {
  persistence?: TripPersistence;
  search?: TravelSearchService;
  trust?: ArtemisTrustEngine;
  bookingService?: BookingService;
  pacing?: StorePacing;
  location?: LocationService;
  /** A real bank account behind the financial check. Without one, the built-in demo account is used. */
  ledger?: FinancialLedger;
  clock?: () => Instant;
}

export interface BookingService {
  confirm(intent: BookingIntent, title: string, subtitle: string, status: BookingStatus, verification: EvaluationResult, reference: string): Promise<Booking>;
}

/** Creates a booking once the trust layer has allowed it. The prototype's version confirms instantly, offline, and never charges anything. */
export class MockBookingService implements BookingService {
  constructor(private latency: SimulatedLatency = latencyNone, private clock: () => Instant = Date.now) {}
  async confirm(intent: BookingIntent, title: string, subtitle: string, status: BookingStatus, verification: EvaluationResult, reference: string): Promise<Booking> {
    await waitLatency(this.latency);
    return {
      id: `bk-${reference}`, kind: intent.kind === 'hotel' ? 'hotel' : 'flight', provider: intent.provider, title, subtitle,
      total: intentTotal(intent), perTraveler: intent.unitAmount, travelerCount: intent.travelers, status, reference, verification, bookedAt: this.clock(),
    };
  }
}

interface TripStoreData {
  ready: boolean;
  // Saved
  hasOnboarded: boolean;
  you: Traveler;
  policy: TrustPolicy;
  financial: FinancialState;
  trips: Trip[];
  referenceCounter: number;
  profile: TravelStyleProfile;
  defaultPreferences: TravelPreferences;
  useLiveLocation: boolean;
  ticketCounter: number;
  lastGreetingDay?: string;
  soundEnabled: boolean;
  /** Where the traveler is. Anchors the home screen and is the origin of new trips. */
  currentPlace: Place;
  locationStatus: LocationStatus;
  // Live
  activeCheck?: TrustCheckRun;
  /** The simulated "now" for Trip Mode; undefined means the real clock. */
  journeyNow?: Instant;
  banner?: ArtemisNotification;
  /** Everything delivered this session, newest first. */
  inbox: ArtemisNotification[];
}

export interface TripStoreActions {
  hydrate(): Promise<void>;
  // Lookup
  trip(id: string): Trip | undefined;
  upcoming(): Trip[];
  past(): Trip[];
  featuredTrip(): Trip | undefined;
  friends(): Traveler[];
  // Location, sound
  chooseLocation(place: Place): void;
  setUseLiveLocation(on: boolean): void;
  setSoundEnabled(on: boolean): void;
  // Morning greeting
  dailyContext(): DailyContext;
  greetingWord(): string;
  shouldShowMorningGreeting(): boolean;
  markGreetingShown(): void;
  // The bank: pulls the live balance when a ledger is configured; resolves quietly if it cannot be reached.
  syncFinancial(): Promise<void>;
  // Demo lifecycle
  resetDemo(): void;
  restartOnboarding(): void;
  completeOnboarding(policy: TrustPolicy, flightBudget?: Money, hotelBudget?: Money): void;
  setPolicy(p: TrustPolicy): void;
  setDefaultPreferences(p: TravelPreferences): void;
  setProfile(p: TravelStyleProfile): void;
  // Trips
  createTrip(args: { destination: Destination; start: Instant; end: Instant; friendIDs: string[]; note?: string }): string;
  createTripFromDraft(draft: TripDraft): string | undefined;
  cutTicket(tripID: string): void;
  deleteTrip(id: string): void;
  // Invite
  beginPlanning(id: string): void;
  invite(travelerID: string, tripID: string, channel: InviteChannel): void;
  acceptInvitation(travelerID: string, tripID: string): void;
  addMember(travelerID: string, tripID: string): void;
  continueToPreferences(id: string): void;
  /** Plan alone: drops anyone who hasn't joined (yet), so the trip is just you. */
  goSolo(tripID: string): void;
  // Preferences
  updatePreferences(tripID: string, travelerID: string, body: (p: TravelPreferences) => TravelPreferences): void;
  submitPreferences(tripID: string, travelerID: string): Promise<void>;
  autofillFriend(tripID: string, travelerID: string): Promise<void>;
  hasEveryonePrivatelySubmitted(tripID: string): boolean;
  // Overlap and options
  computeOverlap(tripID: string): Promise<void>;
  goTo(stage: TripStage, tripID: string): void;
  sharedProfile(tripID: string): SharedProfile | undefined;
  hotelPick(tripID: string): ScoredHotel | undefined;
  flightMatches(tripID: string): { matches: ScoredFlight[]; outside: ScoredFlight[] } | undefined;
  // Ranking
  setRanking(tripID: string, travelerID: string, order: string[]): void;
  suggestedRanking(tripID: string, travelerID: string): string[];
  submitRanking(tripID: string, travelerID: string): void;
  groupOrder(tripID: string): GroupOrderEntry[];
  finalizeDecision(tripID: string): void;
  forceTradeoff(tripID: string): void;
  // Choosing and booking
  chooseFlight(tripID: string, optionID: string): void;
  chooseHotelIfNeeded(tripID: string): void;
  bookFlight(tripID: string, opts?: { impostor?: boolean }): Promise<void>;
  bookHotel(tripID: string): Promise<void>;
  runTrustDemo(demo: TrustDemo): Promise<void>;
  approveActiveCheck(): Promise<void>;
  declineActiveCheck(): void;
  dismissCheck(): void;
  // Journey (Trip Mode)
  itineraryEvents(tripID: string): ItineraryEvent[];
  nextEvent(tripID: string): ItineraryEvent | undefined;
  simulator(tripID: string): JourneySimulator | undefined;
  journeyState(tripID: string): JourneyState | undefined;
  setJourneyPhase(phase: TripPhase, tripID: string): void;
  setJourneyTime(at: Instant): void;
  startJourney(tripID: string): void;
  endJourney(): void;
  announceFlightSoon(tripID: string, hours: number): void;
  // Notifications
  deliver(n: Omit<ArtemisNotification, 'id' | 'date' | 'symbol' | 'tone'> & Partial<Pick<ArtemisNotification, 'symbol' | 'tone'>>): void;
  dismissBanner(): void;
  clearNotifications(): void;
}

export type TripStoreState = TripStoreData & TripStoreActions;
export type TripStore = StoreApi<TripStoreState>;

const uid = (() => { let n = 0; return (p: string) => `${p}-${Date.now().toString(36)}-${(n++).toString(36)}`; })();

export function createTripStore(deps: TripStoreDeps = {}): TripStore {
  const clock = deps.clock ?? Date.now;
  const persistence = deps.persistence ?? new InMemoryTripPersistence();
  const search = deps.search ?? new MockTravelSearchService(latencyDemoShort);
  const trust = deps.trust ?? ArtemisTrustEngine.simulated(latencyDemo);
  const bookingService = deps.bookingService ?? new MockBookingService(latencyNone, clock);
  const pacing = deps.pacing ?? pacingDemo;
  const location = deps.location ?? new DemoLocationService();
  const ledger = deps.ledger;
  const matching = new TripMatchingService();
  const itinerary = new ItineraryBuilder();
  const daily = new DailyContextService();
  const bannerSeconds = pacing.joinDelay === 0 ? 0 : 4;
  let bannerTimer: ReturnType<typeof setTimeout> | undefined;

  const snap0 = seedSnapshot(clock());

  const store = createStore<TripStoreState>()((set, get) => {
    // ── helpers ─────────────────────────────────────────────
    const persist = (): void => {
      const s = get();
      const snapshot: TripStoreSnapshot = {
        version: 1, hasOnboarded: s.hasOnboarded, you: s.you, policy: s.policy, financial: s.financial, trips: s.trips,
        referenceCounter: s.referenceCounter, profile: s.profile, defaultPreferences: s.defaultPreferences, useLiveLocation: s.useLiveLocation,
        ticketCounter: s.ticketCounter, lastGreetingDay: s.lastGreetingDay, soundEnabled: s.soundEnabled,
      };
      try { void Promise.resolve(persistence.save(snapshot)).catch(() => {}); } catch { /* the app carries on without saving */ }
    };

    const mutate = (id: string, body: (t: Trip) => Trip): void => {
      const i = get().trips.findIndex((t) => t.id === id);
      if (i === -1) return;
      const trips = get().trips.slice();
      trips[i] = body(trips[i]);
      set({ trips });
      persist();
    };

    const mapMember = (t: Trip, travelerID: string, f: (m: Trip['members'][number]) => Trip['members'][number]): Trip =>
      ({ ...t, members: t.members.map((m) => (m.traveler.id === travelerID ? f(m) : m)) });

    const syncLocation = (): void => set({ currentPlace: location.place, locationStatus: location.status });
    location.onChange = syncLocation;

    const inputsFor = (t: Trip): TravelerPreferences[] =>
      t.members.filter((m) => memberIsInTrip(m) && m.hasSubmittedPreferences).map((m) => ({ traveler: m.traveler, preferences: m.preferences }));

    const rankingsFor = (t: Trip): Record<string, string[]> => {
      const r: Record<string, string[]> = {};
      for (const m of t.members) if (memberIsInTrip(m) && m.ranking.length > 0) r[m.traveler.id] = m.ranking;
      return r;
    };

    const deliver: TripStoreActions['deliver'] = (n) => {
      const note: ArtemisNotification = { id: uid('n'), date: clock(), tone: 'info', symbol: 'sparkles', ...n };
      const inbox = [note, ...get().inbox];
      if (bannerSeconds <= 0) { set({ inbox }); return; }
      set({ inbox, banner: note });
      if (bannerTimer) clearTimeout(bannerTimer);
      bannerTimer = setTimeout(() => set({ banner: undefined }), bannerSeconds * 1000);
    };

    const finalizeBooking = async (status: BookingStatus): Promise<void> => {
      const run = get().activeCheck;
      if (!run || !run.result || !run.tripID) return;
      const tripID = run.tripID;
      const referenceCounter = get().referenceCounter + 1;
      const number = get().ticketCounter;
      const ticketCounter = run.intent.kind === 'flight' ? number + 1 : number;
      set({ referenceCounter, ticketCounter });
      const booking = await bookingService.confirm(run.intent, run.title, run.subtitle, status, run.result, `ART-${referenceCounter - 1}`);
      // The simulated account moves, so the next check sees the new balance.
      const f = get().financial;
      set({ financial: { ...f, availableBalance: cents(f.availableBalance - booking.total), monthToDateTravelSpend: cents(f.monthToDateTravelSpend + booking.total) } });
      // With a real account, post the purchase there, then read the account back so the two agree.
      if (ledger) void ledger.record(booking.total, `${booking.title} · ${booking.reference}`).then(() => get().syncFinancial()).catch(() => undefined);
      mutate(tripID, (t) => ({
        ...t,
        bookings: [...t.bookings, booking],
        stage: booking.kind === 'flight' ? 'booked' : t.stage,
        ticketNumber: booking.kind === 'flight' ? t.ticketNumber ?? number : t.ticketNumber,
      }));
      set({ activeCheck: { ...run, phase: 'booked', booking, active: undefined } });
      deliver({
        title: 'Booked', tone: 'good', symbol: 'checkmark', tripID,
        body: booking.kind === 'flight' ? `Your flight is booked. Reference ${booking.reference}.` : `${booking.title} is booked. Reference ${booking.reference}.`,
      });
    };

    const runCheck = async (tripID: string | undefined, intent: BookingIntent, title: string, subtitle: string): Promise<void> => {
      let run: TrustCheckRun = { id: uid('run'), tripID, intent, title, subtitle, completed: {}, phase: 'running' };
      set({ activeCheck: run });
      let outcome: EvaluationResult | undefined;
      try {
        outcome = await trust.evaluateBooking(intent, get().policy, ledger ? undefined : get().financial, (event) => {
          if (event.type === 'started') run = { ...run, active: event.layer };
          else if (event.type === 'completed') run = { ...run, completed: { ...run.completed, [event.layer]: event.result }, active: undefined };
          else return;
          set({ activeCheck: run });
        });
      } catch { outcome = undefined; }
      if (!outcome) { set({ activeCheck: undefined }); return; }
      run = { ...run, result: outcome, active: undefined };
      switch (outcome.decision) {
        case 'autoApproved':
          if (tripID === undefined) { run = { ...run, phase: 'finished' }; set({ activeCheck: run }); }
          else {
            set({ activeCheck: run });
            if (pacing.approvedBeat > 0) await new Promise<void>((r) => setTimeout(r, pacing.approvedBeat * 1000));
            await finalizeBooking('confirmed');
          }
          break;
        case 'approvalRequired':
          run = { ...run, phase: tripID === undefined ? 'finished' : 'awaitingApproval' };
          set({ activeCheck: run });
          if (tripID !== undefined) {
            deliver({ title: 'Artemis needs your approval', body: `${usd(intentTotal(intent))} for ${intent.provider} is outside your policy.`, tone: 'attention', symbol: 'exclamationmark', tripID });
          }
          break;
        case 'blocked':
          run = { ...run, phase: 'blocked' };
          set({ activeCheck: run });
          deliver({ title: 'Booking blocked', body: `Artemis couldn't verify ${intent.provider}. Nothing was booked.`, tone: 'attention', symbol: 'xmark', tripID });
          break;
      }
    };

    const memberDefaults = (f: Traveler): TravelPreferences => (f.id === Travelers.sofia.id ? sofiaDemo() : friendDefault());

    return {
      ready: false,
      hasOnboarded: snap0.hasOnboarded, you: snap0.you, policy: snap0.policy, financial: snap0.financial, trips: snap0.trips,
      referenceCounter: snap0.referenceCounter, profile: snap0.profile, defaultPreferences: snap0.defaultPreferences,
      useLiveLocation: snap0.useLiveLocation, ticketCounter: snap0.ticketCounter, lastGreetingDay: snap0.lastGreetingDay,
      soundEnabled: snap0.soundEnabled, currentPlace: location.place ?? rioPlace, locationStatus: location.status,
      activeCheck: undefined, journeyNow: undefined, banner: undefined, inbox: [],

      async hydrate() {
        const snap = await persistence.load();
        if (snap) {
          set({
            hasOnboarded: snap.hasOnboarded, you: snap.you, policy: snap.policy, financial: snap.financial, trips: snap.trips,
            referenceCounter: snap.referenceCounter, profile: snap.profile, defaultPreferences: snap.defaultPreferences,
            useLiveLocation: snap.useLiveLocation, ticketCounter: snap.ticketCounter, lastGreetingDay: snap.lastGreetingDay,
            soundEnabled: snap.soundEnabled,
          });
          if (snap.useLiveLocation) location.useLiveLocation();
        }
        void get().syncFinancial();
        syncLocation();
        set({ ready: true });
      },

      // ── Lookup ──
      trip: (id) => get().trips.find((t) => t.id === id),
      upcoming: () => get().trips.filter((t) => !t.isPast).sort((a, b) => a.startDate - b.startDate),
      past: () => get().trips.filter((t) => t.isPast).sort((a, b) => b.startDate - a.startDate),
      featuredTrip: () => {
        const up = get().upcoming();
        return up.find((t) => t.bookings.some((b) => b.kind === 'flight')) ?? up[0];
      },
      friends: () => Travelers.demoFriends,

      // ── Location, sound ──
      chooseLocation(place) {
        set({ useLiveLocation: false });
        location.choose(place);
        syncLocation();
        persist();
      },
      setUseLiveLocation(on) {
        set({ useLiveLocation: on });
        if (on) location.useLiveLocation(); else location.useDemoLocation();
        syncLocation();
        persist();
      },
      setSoundEnabled(on) { set({ soundEnabled: on }); persist(); },

      // ── Morning greeting ──
      dailyContext: () => daily.context(get().trips, clock()),
      greetingWord: () => daily.greetingWord(clock()),
      shouldShowMorningGreeting: () => get().hasOnboarded && daily.shouldShowGreeting(get().lastGreetingDay, clock()),
      markGreetingShown() { set({ lastGreetingDay: DailyContextService.dayKey(clock(), deviceTimeZone) }); persist(); },

      // ── Demo lifecycle ──
      resetDemo() {
        if (bannerTimer) clearTimeout(bannerTimer);
        const snap = seedSnapshot(clock(), true);
        set({
          activeCheck: undefined, journeyNow: undefined, inbox: [], banner: undefined,
          you: snap.you, policy: snap.policy, financial: snap.financial, trips: snap.trips, referenceCounter: snap.referenceCounter,
          profile: snap.profile, defaultPreferences: snap.defaultPreferences, ticketCounter: snap.ticketCounter, lastGreetingDay: undefined,
          hasOnboarded: true,
        });
        persist();
        if (ledger) void ledger.reset().then(() => get().syncFinancial()).catch(() => undefined);
      },
      async syncFinancial() {
        if (!ledger) return;
        try {
          const financial = await ledger.state();
          set({ financial });
          persist();
        } catch { /* offline: keep the last known balance */ }
      },
      restartOnboarding() { set({ hasOnboarded: false, lastGreetingDay: undefined }); persist(); },
      completeOnboarding(policy, flightBudget, hotelBudget) {
        const defaults = { ...get().defaultPreferences };
        if (flightBudget !== undefined) defaults.flightBudget = flightBudget;
        if (hotelBudget !== undefined) defaults.hotelBudget = hotelBudget;
        const trips = get().trips.map((t) =>
          t.isPast ? t : { ...t, members: t.members.map((m) => (m.invite === 'you' && !m.hasSubmittedPreferences ? { ...m, preferences: defaults } : m)) });
        set({ policy, defaultPreferences: defaults, trips, hasOnboarded: true });
        persist();
      },
      setPolicy(p) { set({ policy: p }); persist(); },
      setDefaultPreferences(p) { set({ defaultPreferences: p }); persist(); },
      setProfile(p) { set({ profile: p }); persist(); },

      // ── Creating trips ──
      createTrip({ destination, start, end, friendIDs, note }) {
        const s = get();
        const id = `trip-${destination.id}-${Math.trunc(clock() / 1000)}-${s.trips.length}`;
        const members = [newMember(s.you, 'you', s.defaultPreferences)];
        for (const fid of friendIDs) {
          const f = get().friends().find((x) => x.id === fid);
          if (f) members.push(newMember(f, 'notInvited', memberDefaults(f)));
        }
        set({
          trips: [...s.trips, newTrip({
            id, destinationID: destination.id, originCode: s.currentPlace.airportCode, startDate: start, endDate: end, members, stage: 'draft',
            createdAt: clock(), note,
          })],
        });
        persist();
        return id;
      },
      createTripFromDraft(draft) {
        if (!draft.destination) return undefined;
        const s = get();
        const tz = timeZone(placeAirport(s.currentPlace).timeZoneID);
        const start = draft.start ?? Zoned.at(clock(), 0, 0, tz, 21);
        const end = draft.end ?? Zoned.at(start, 0, 0, tz, draft.days ?? draft.destination.suggestedDays);
        const id = s.createTrip({ destination: draft.destination, start, end, friendIDs: draft.travelers.map((t) => t.id), note: draft.original });
        if (draft.budgetPerPerson !== undefined) {
          // Roughly a third of a trip budget goes on the flight.
          const flight = Math.min(2000, Math.max(200, Math.round(draft.budgetPerPerson * 0.3)));
          mutate(id, (t) => ({
            ...t,
            members: t.members.map((m, i) => (i === 0 ? { ...m, preferences: { ...m.preferences, flightBudget: Math.min(get().defaultPreferences.flightBudget, flight) } } : m)),
          }));
        }
        return id;
      },
      cutTicket(tripID) { mutate(tripID, (t) => (t.ticketCutAt === undefined ? { ...t, ticketCutAt: clock() } : t)); },
      deleteTrip(id) { set({ trips: get().trips.filter((t) => t.id !== id) }); persist(); },

      // ── Invite ──
      beginPlanning(id) { mutate(id, (t) => (t.stage === 'draft' ? { ...t, stage: 'inviting' } : t)); },
      invite(travelerID, tripID, _channel) {
        mutate(tripID, (t) => {
          const m = t.members.find((x) => x.traveler.id === travelerID);
          if (!m || m.invite !== 'notInvited') return t;
          const next = mapMember(t, travelerID, (x) => ({ ...x, invite: 'invited' }));
          return t.stage === 'draft' ? { ...next, stage: 'inviting' } : next;
        });
        if (!pacing.autoAcceptInvites) return;
        setTimeout(() => get().acceptInvitation(travelerID, tripID), pacing.joinDelay * 1000);
      },
      acceptInvitation(travelerID, tripID) {
        let name = '';
        mutate(tripID, (t) => {
          const m = t.members.find((x) => x.traveler.id === travelerID);
          if (!m || m.invite !== 'invited') return t;
          name = m.traveler.firstName;
          return mapMember(t, travelerID, (x) => ({ ...x, invite: 'joined' }));
        });
        if (!name) return;
        deliver({ title: `${name} joined the trip`, body: `${name} accepted your invitation.`, tone: 'good', symbol: 'person.crop.circle.badge.checkmark', tripID });
      },
      addMember(travelerID, tripID) {
        const f = get().friends().find((x) => x.id === travelerID);
        if (!f) return;
        mutate(tripID, (t) => (t.members.some((m) => m.traveler.id === travelerID) ? t : { ...t, members: [...t.members, newMember(f, 'notInvited', memberDefaults(f))] }));
      },
      continueToPreferences(id) { mutate(id, (t) => (stageAtMost(t.stage, 'inviting') ? { ...t, stage: 'preferences' } : t)); },
      goSolo(tripID) {
        mutate(tripID, (t) => {
          if (!stageAtMost(t.stage, 'inviting')) return t;
          const members = t.members.filter(memberIsInTrip);
          // Joined friends stay; nobody who is still "not invited" or "invited" holds the trip up.
          return { ...t, members, stage: 'preferences' };
        });
      },

      // ── Preferences ──
      updatePreferences(tripID, travelerID, body) {
        mutate(tripID, (t) => {
          const m = t.members.find((x) => x.traveler.id === travelerID);
          if (!m || m.hasSubmittedPreferences) return t;
          return mapMember(t, travelerID, (x) => ({ ...x, preferences: body(x.preferences) }));
        });
      },
      async submitPreferences(tripID, travelerID) {
        mutate(tripID, (t) => mapMember(t, travelerID, (m) => ({ ...m, hasSubmittedPreferences: true })));
        const t = get().trip(tripID);
        if (t && t.stage === 'preferences' && everyoneSubmittedPreferences(t) && t.members.filter(memberIsInTrip).length > 0) {
          await get().computeOverlap(tripID);
        }
      },
      async autofillFriend(tripID, travelerID) {
        const m = get().trip(tripID)?.members.find((x) => x.traveler.id === travelerID);
        if (!m || !memberIsInTrip(m)) return;
        await get().submitPreferences(tripID, travelerID);
      },
      hasEveryonePrivatelySubmitted: (tripID) => { const t = get().trip(tripID); return t ? everyoneSubmittedPreferences(t) : false; },

      // ── Overlap and options ──
      async computeOverlap(tripID) {
        const t = get().trip(tripID);
        if (!t) return;
        const [flights, hotels] = await Promise.all([search.flights(t), search.hotels(t)]);
        // Alone there is nobody to overlap with, so the trip goes straight to the flights that fit.
        const solo = tripTravelers(t).length === 1;
        mutate(tripID, (x) => ({ ...x, flightOptions: flights, hotelOptions: hotels, stage: solo ? 'options' : 'overlap' }));
        const names = (get().trip(tripID) ? tripTravelers(get().trip(tripID)!) : []).filter((x) => !x.isYou).map((x) => x.firstName);
        const count = get().flightMatches(tripID)?.matches.length ?? 0;
        deliver({
          title: solo ? 'Your matches are ready' : 'Your overlap is ready', tone: 'good', symbol: 'sparkles', tripID,
          body: `Artemis found ${count} flights that match you${names.length === 0 ? '' : ` and ${names.join(' & ')}`}.`,
        });
      },
      goTo(stage, tripID) { mutate(tripID, (t) => ({ ...t, stage })); },
      sharedProfile(tripID) {
        const t = get().trip(tripID);
        if (!t) return undefined;
        const inputs = inputsFor(t);
        return inputs.length === 0 ? undefined : matching.combinePreferences(inputs);
      },
      hotelPick(tripID) {
        const t = get().trip(tripID);
        const profile = get().sharedProfile(tripID);
        return t && profile ? matching.recommendHotel(t.hotelOptions, profile, hotelNights(t)) : undefined;
      },
      flightMatches(tripID) {
        const t = get().trip(tripID);
        const profile = get().sharedProfile(tripID);
        if (!t || !profile || t.flightOptions.length === 0) return undefined;
        return matching.recommendFlights(t.flightOptions, profile, inputsFor(t), get().hotelPick(tripID)?.hotel);
      },

      // ── Ranking ──
      setRanking(tripID, travelerID, order) {
        mutate(tripID, (t) => {
          const m = t.members.find((x) => x.traveler.id === travelerID);
          return m && !m.hasRanked ? mapMember(t, travelerID, (x) => ({ ...x, ranking: order })) : t;
        });
      },
      suggestedRanking(tripID, travelerID) {
        const m = get().flightMatches(tripID)?.matches;
        if (!m) return [];
        return [...m].sort((a, b) => (b.match.perTraveler[travelerID] ?? 0) - (a.match.perTraveler[travelerID] ?? 0)).map((x) => x.option.id);
      },
      submitRanking(tripID, travelerID) {
        const t = get().trip(tripID);
        const m = t?.members.find((x) => x.traveler.id === travelerID);
        if (!t || !m || m.ranking.length === 0) return;
        mutate(tripID, (x) => mapMember(x, travelerID, (y) => ({ ...y, hasRanked: true })));
        const first = m.ranking[0];
        const opt = get().trip(tripID)?.flightOptions.find((o) => o.id === first);
        if (!m.traveler.isYou && opt) {
          deliver({ title: `${m.traveler.firstName} ranked ${opt.shortName} #1`, body: `${m.traveler.firstName} submitted their ranking.`, tone: 'info', symbol: 'list.number', tripID });
        }
        const after = get().trip(tripID);
        if (after && everyoneRanked(after)) get().finalizeDecision(tripID);
      },
      groupOrder(tripID) {
        const t = get().trip(tripID);
        const matches = get().flightMatches(tripID)?.matches;
        return t && matches ? matching.groupOrder(rankingsFor(t), matches) : [];
      },
      finalizeDecision(tripID) {
        const t = get().trip(tripID);
        const matches = get().flightMatches(tripID)?.matches;
        if (!t || !matches) return;
        const rankings = rankingsFor(t);
        const order = matching.groupOrder(rankings, matches);
        const decided = matching.decide(order, rankings, matches, tripTravelers(t), inputsFor(t));
        if (!decided) return;
        const decision = decided.kind === 'aligned' ? { ...decided, chosenOptionID: decided.primaryOptionID } : decided;
        mutate(tripID, (x) => ({
          ...x, decision, stage: 'decision', selectedFlightID: decision.kind === 'aligned' ? decision.primaryOptionID : x.selectedFlightID,
        }));
      },
      /**
       * Prototype tool: ranks so the group's leading option is one traveler's last choice and another's first, which is the
       * situation where Artemis shows a trade-off instead of a match.
       */
      forceTradeoff(tripID) {
        const t = get().trip(tripID);
        const matches = get().flightMatches(tripID)?.matches;
        if (!t || !matches || matches.length < 3) return;
        const top = matches[0];
        const rest = matches.slice(1);
        const members = t.members.filter(memberIsInTrip);
        if (members.length < 2) return;
        members.forEach((m, i) => {
          const others = i === 0
            ? [...rest].sort((a, b) => a.option.farePerTraveler - b.option.farePerTraveler)
            : [...rest].sort((a, b) => flightDurationOf(a.option) - flightDurationOf(b.option));
          const order = i === 0 ? [...others.map((o) => o.option.id), top.option.id] : [top.option.id, ...others.map((o) => o.option.id)];
          mutate(tripID, (x) => mapMember(x, m.traveler.id, (y) => ({ ...y, ranking: order, hasRanked: true })));
        });
        mutate(tripID, (x) => ({ ...x, selectedFlightID: undefined }));
        get().finalizeDecision(tripID);
      },

      // ── Choosing and booking ──
      chooseFlight(tripID, optionID) {
        const hotel = get().hotelPick(tripID)?.hotel.id;
        mutate(tripID, (t) => ({
          ...t, selectedFlightID: optionID, selectedHotelID: t.selectedHotelID ?? hotel,
          decision: t.decision ? { ...t.decision, chosenOptionID: optionID } : t.decision, stage: 'booking',
        }));
      },
      chooseHotelIfNeeded(tripID) {
        const hotel = get().hotelPick(tripID)?.hotel.id;
        if (get().trip(tripID)?.selectedHotelID !== undefined || !hotel) return;
        mutate(tripID, (t) => ({ ...t, selectedHotelID: hotel }));
      },
      async bookFlight(tripID, opts = {}) {
        const t = get().trip(tripID);
        const option = t && selectedFlight(t);
        if (!t || !option) return;
        const n = travelerCount(t);
        await runCheck(tripID, flightIntent(option, n, opts.impostor ?? false), `${option.airline} · ${routeCodes(option).join(' → ')}`,
          `${n} traveler${n === 1 ? '' : 's'} · ${dateRange(t).toLowerCase()}`);
      },
      async bookHotel(tripID) {
        const t = get().trip(tripID);
        const hotel: HotelOption | undefined = t && (selectedHotel(t) ?? get().hotelPick(tripID)?.hotel);
        if (!t || !hotel) return;
        mutate(tripID, (x) => ({ ...x, selectedHotelID: hotel.id }));
        const nights = hotelNights(get().trip(tripID) ?? t);
        await runCheck(tripID, hotelIntent(hotel, nights), hotel.name, `${nights} nights · ${hotel.neighborhood}`);
      },
      async runTrustDemo(demo) {
        const options = romeFlights(romeStart(clock()));
        const opt = (id: string): FlightOption => options.find((o) => o.id === id)!;
        let intent: BookingIntent;
        switch (demo) {
          case 'autoApproved': intent = flightIntent(opt('tap'), 2); break;
          case 'overPolicy': intent = flightIntent(opt('ita-premium'), 2); break;
          case 'impostor': intent = flightIntent(opt('tap'), 2, true); break;
          case 'capReached': intent = flightIntent({ ...opt('ita'), farePerTraveler: 590 }, 5); break;
        }
        await runCheck(undefined, intent, `${intent.provider} · GIG → FCO`, trustDemoTitle(demo));
      },
      /** The traveler said yes to an escalation. Only ever offered for APPROVAL_REQUIRED, never BLOCKED. */
      async approveActiveCheck() {
        const run = get().activeCheck;
        if (!run || run.phase !== 'awaitingApproval' || run.result?.decision !== 'approvalRequired') return;
        await finalizeBooking('approvedByYou');
      },
      declineActiveCheck() {
        const run = get().activeCheck;
        if (!run || run.phase !== 'awaitingApproval') return;
        set({ activeCheck: { ...run, phase: 'declined' } });
      },
      dismissCheck() { set({ activeCheck: undefined }); },

      // ── Journey (Trip Mode) ──
      itineraryEvents: (tripID) => { const t = get().trip(tripID); return t ? itinerary.events(t) : []; },
      nextEvent(tripID) {
        const t = get().trip(tripID);
        return t ? itinerary.next(get().journeyNow ?? clock(), itinerary.events(t)) : undefined;
      },
      simulator(tripID) {
        const t = get().trip(tripID);
        const f = t && selectedFlight(t);
        return f ? new JourneySimulator(f) : undefined;
      },
      journeyState(tripID) { return get().simulator(tripID)?.state(get().journeyNow ?? clock()); },
      setJourneyPhase(phase, tripID) {
        const sim = get().simulator(tripID);
        if (sim) set({ journeyNow: sim.time(phase) });
      },
      setJourneyTime(at) { set({ journeyNow: at }); },
      startJourney(tripID) {
        const sim = get().simulator(tripID);
        if (sim && get().journeyNow === undefined) set({ journeyNow: sim.time('notDeparted') });
      },
      endJourney() { set({ journeyNow: undefined }); },
      announceFlightSoon(tripID, hours) {
        deliver({ title: `Your flight leaves in ${hours} hours`, body: "Enter Trip Mode when you're ready.", tone: 'info', symbol: 'airplane.departure', tripID });
      },

      // ── Notifications ──
      deliver,
      dismissBanner() { set({ banner: undefined }); },
      clearNotifications() { set({ inbox: [], banner: undefined }); },
    };
  });
  return store;
}

const flightDurationOf = (o: FlightOption): number => (o.legs[o.legs.length - 1].arrive - o.legs[0].depart) / 1000;

