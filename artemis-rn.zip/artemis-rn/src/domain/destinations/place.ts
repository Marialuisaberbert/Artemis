import { Airport, Airports, airportDistance, airportNamed, allAirports } from './geo';

/** Where the traveler is right now. */
export interface Place {
  name: string;
  country: string;
  latitude: number;
  longitude: number;
  /** The nearest airport a trip from here would depart from. */
  airportCode: string;
  /** True when this is the built-in demo location rather than the device's real one. */
  isDemo: boolean;
}

export const placeAirport = (p: Place): Airport => airportNamed(p.airportCode) ?? Airports.gig;

/** The demo persona lives in Rio. */
export const rioPlace: Place = { name: 'Rio de Janeiro', country: 'Brazil', latitude: -22.91, longitude: -43.17, airportCode: 'GIG', isDemo: true };

/** A starting point chosen by hand: the city of one of Artemis's airports. */
export const chosenPlace = (a: Airport): Place => ({
  name: a.city, country: a.country, latitude: a.latitude, longitude: a.longitude, airportCode: a.code, isDemo: true,
});

/** The cities offered when the traveler chooses where they are starting from. */
export const startingPoints: Place[] = [Airports.gig, Airports.gru, Airports.lis, Airports.lhr, Airports.cdg, Airports.jfk, Airports.hnd].map(chosenPlace);

/** Maps raw coordinates onto the nearest airport Artemis knows about. */
export function nearestPlace(latitude: number, longitude: number): Place {
  const probe: Airport = { code: '???', city: '', name: '', country: '', latitude, longitude, timeZoneID: 'UTC' };
  let best = Airports.gig;
  let bestKm = Infinity;
  for (const a of allAirports) {
    const km = airportDistance(probe, a);
    if (km < bestKm) { bestKm = km; best = a; }
  }
  const name = bestKm < 200 ? best.city : `Near ${best.city}`;
  return { name, country: best.country, latitude, longitude, airportCode: best.code, isDemo: false };
}
