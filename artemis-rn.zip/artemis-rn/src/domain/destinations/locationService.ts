import { Place, rioPlace } from './place';

export type LocationStatus =
  | { kind: 'demo' }
  | { kind: 'requesting' }
  | { kind: 'live' }
  /** Permission was refused or location is unavailable. The app carries on with the demo location. */
  | { kind: 'unavailable'; reason: string };

/**
 * Where the traveler is. The prototype ships with a demo location (Rio de Janeiro) and can switch to the device's
 * real one; if that is refused or fails, it quietly falls back and never breaks the app.
 */
export interface LocationService {
  readonly place: Place;
  readonly status: LocationStatus;
  /** Called whenever `place` or `status` changes. */
  onChange?: () => void;
  useLiveLocation(): void;
  useDemoLocation(): void;
  /** Pick a starting point by hand (the demo location). */
  choose(place: Place): void;
}

export class DemoLocationService implements LocationService {
  place: Place;
  status: LocationStatus = { kind: 'demo' };
  onChange?: () => void;

  constructor(place: Place = rioPlace) { this.place = place; }

  useLiveLocation(): void { this.status = { kind: 'unavailable', reason: "Live location isn't available in this build." }; this.onChange?.(); }
  useDemoLocation(): void { this.status = { kind: 'demo' }; this.onChange?.(); }
  choose(place: Place): void { this.place = place; this.status = { kind: 'demo' }; this.onChange?.(); }
}
