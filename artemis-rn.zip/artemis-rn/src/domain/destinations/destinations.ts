import type { Money } from '../shared/money';
import { Airport, Airports } from './geo';

/** A real photograph of the place, and where in the frame it should stay centred when cropped to a portrait screen. */
export interface DestinationPhoto {
  file: string;
  /** 0…1 across the image. */
  focusX: number;
  focusY: number;
}

export interface Connection {
  airline: string;
  code: string;
  hub: Airport;
  nonstopAirline: string;
  nonstopCode: string;
}

export interface Destination {
  id: string;
  city: string;
  country: string;
  airport: Airport;
  latitude: number;
  longitude: number;
  tagline: string;
  blurb: string;
  highlights: string[];
  bestTime: string;
  /** Typical temperature in the best months. */
  climate: string;
  /** 1 (easy on the wallet) … 4. */
  costLevel: number;
  /** Typical round-trip fare from Rio, per traveler. Simulated. */
  typicalFare: Money;
  style: string[];
  suggestedDays: number;
  photo: DestinationPhoto;
  connection: Connection;
}

export const destinationName = (d: Destination): string => d.city.toUpperCase();
export const destinationSearchText = (d: Destination): string => `${d.city} ${d.country}`.toLowerCase();
export const costSymbols = (d: Destination): string => '$'.repeat(Math.max(1, Math.min(4, d.costLevel)));

const photo = (file: string, focusX = 0.5, focusY = 0.5): DestinationPhoto => ({ file, focusX, focusY });
const conn = (airline: string, code: string, hub: Airport, nonstopAirline: string, nonstopCode: string): Connection =>
  ({ airline, code, hub, nonstopAirline, nonstopCode });

const A = Airports;

const rome: Destination = {
  id: 'rome', city: 'Rome', country: 'Italy', airport: A.fco, latitude: 41.9, longitude: 12.5,
  tagline: 'Your next chapter.',
  blurb: 'Rome rewards slow walking. Start at dawn in Trastevere, spend the afternoon among marble and shade, and let dinner run until midnight.',
  highlights: ['Colosseum at blue hour', 'Trevi Fountain before breakfast', 'Pantheon', 'Trastevere dinners'],
  bestTime: 'Apr – Oct', climate: '24°C', costLevel: 3, typicalFare: 640, style: ['Culture', 'Food', 'Architecture'], suggestedDays: 6,
  photo: photo('rome', 0.42), connection: conn('TAP Air Portugal', 'TP', A.lis, 'ITA Airways', 'AZ'),
};
const paris: Destination = {
  id: 'paris', city: 'Paris', country: 'France', airport: A.cdg, latitude: 48.86, longitude: 2.35,
  tagline: 'Three neighborhoods worth waking up early for.',
  blurb: 'Skip the checklist. Pick the Marais, Saint-Germain and Montmartre, and give each a morning: a bakery, a bookshop, a bench.',
  highlights: ['Eiffel Tower at sunset', 'Walks along the Seine', 'Le Marais', 'Montmartre'],
  bestTime: 'Apr – Jun · Sep', climate: '19°C', costLevel: 4, typicalFare: 690, style: ['Art', 'Food', 'Walkable'], suggestedDays: 5,
  photo: photo('paris', 0.17), connection: conn('TAP Air Portugal', 'TP', A.lis, 'Air France', 'AF'),
};
const tokyo: Destination = {
  id: 'tokyo', city: 'Tokyo', country: 'Japan', airport: A.hnd, latitude: 35.68, longitude: 139.69,
  tagline: 'Your first 72 hours.',
  blurb: 'Neon, quiet shrines and the best convenience-store breakfast on Earth. Three days is enough to fall in love and plan the return.',
  highlights: ['Tokyo Tower after dark', 'Shibuya Crossing', 'Early-morning markets', 'Shrine gardens'],
  bestTime: 'Mar – May · Oct – Nov', climate: '21°C', costLevel: 3, typicalFare: 1380, style: ['Food', 'Nightlife', 'Design'], suggestedDays: 8,
  photo: photo('tokyo', 0.6), connection: conn('Qatar Airways', 'QR', A.doh, 'Qatar Airways', 'QR'),
};
const newYork: Destination = {
  id: 'new-york', city: 'New York', country: 'United States', airport: A.jfk, latitude: 40.71, longitude: -74.01,
  tagline: 'A city that rewards the unplanned afternoon.',
  blurb: 'Pick a neighborhood, pick a direction, and let the block decide. The best table is always the one you almost walked past.',
  highlights: ['Manhattan Bridge from Dumbo', 'The High Line', 'Late-night slices', 'Museum Mile'],
  bestTime: 'Apr – Jun · Sep – Nov', climate: '21°C', costLevel: 4, typicalFare: 720, style: ['Art', 'Food', 'Nightlife'], suggestedDays: 5,
  photo: photo('new-york'), connection: conn('American Airlines', 'AA', A.atl, 'LATAM Airlines', 'LA'),
};
const rio: Destination = {
  id: 'rio', city: 'Rio de Janeiro', country: 'Brazil', airport: A.gig, latitude: -22.91, longitude: -43.17,
  tagline: 'Where the mountains meet the sea.',
  blurb: 'Granite peaks over a city that never quite sits still. Sunrise at Corcovado, afternoons on the sand, and a table for samba at midnight.',
  highlights: ['Christ the Redeemer above the clouds', 'Sugarloaf at dusk', 'Ipanema', 'Santa Teresa'],
  bestTime: 'May – Oct', climate: '27°C', costLevel: 2, typicalFare: 0, style: ['Beach', 'Nature', 'Nightlife'], suggestedDays: 5,
  photo: photo('rio', 0.62), connection: conn('LATAM Airlines', 'LA', A.gru, 'LATAM Airlines', 'LA'),
};
const lisbon: Destination = {
  id: 'lisbon', city: 'Lisbon', country: 'Portugal', airport: A.lis, latitude: 38.72, longitude: -9.14,
  tagline: 'Tiled hills, yellow trams, and a very good custard tart.',
  blurb: 'Seven hills, one river, and light that makes everything look like a postcard someone forgot to send.',
  highlights: ['Tram 28', 'Alfama at golden hour', 'Pastéis de Belém', 'Miradouros'],
  bestTime: 'Mar – Jun · Sep – Oct', climate: '25°C', costLevel: 2, typicalFare: 560, style: ['Food', 'Walkable', 'Culture'], suggestedDays: 4,
  photo: photo('lisbon', 0.55), connection: conn('LATAM Airlines', 'LA', A.gru, 'TAP Air Portugal', 'TP'),
};
const london: Destination = {
  id: 'london', city: 'London', country: 'United Kingdom', airport: A.lhr, latitude: 51.51, longitude: -0.13,
  tagline: 'Old stone, new skyline, and a pub around every corner.',
  blurb: 'A city best met on foot along the river: bridges at golden hour, markets in the morning, and theater that starts at seven-thirty sharp.',
  highlights: ['Tower Bridge', 'The South Bank', 'Borough Market', 'West End theater'],
  bestTime: 'May – Sep', climate: '18°C', costLevel: 4, typicalFare: 760, style: ['Culture', 'Theater', 'Food'], suggestedDays: 5,
  photo: photo('london', 0.5), connection: conn('TAP Air Portugal', 'TP', A.lis, 'British Airways', 'BA'),
};
const capeTown: Destination = {
  id: 'cape-town', city: 'Cape Town', country: 'South Africa', airport: A.cpt, latitude: -33.92, longitude: 18.42,
  tagline: 'A mountain in the middle of the city.',
  blurb: "Lion's Head over the rooftops, penguins on the beach, and wine estates an hour away. Few cities put this much drama within reach.",
  highlights: ["Lion's Head at sunrise", 'Table Mountain cableway', 'Bo-Kaap', 'Cape Peninsula drive'],
  bestTime: 'Nov – Mar', climate: '26°C', costLevel: 2, typicalFare: 980, style: ['Nature', 'Food', 'Views'], suggestedDays: 7,
  photo: photo('cape-town'), connection: conn('Qatar Airways', 'QR', A.doh, 'LATAM Airlines', 'LA'),
};
const dubai: Destination = {
  id: 'dubai', city: 'Dubai', country: 'United Arab Emirates', airport: A.dxb, latitude: 25.2, longitude: 55.27,
  tagline: 'A skyline that keeps going up.',
  blurb: 'Glass towers, desert dunes at dawn, and dinners that start after sunset. Three nights is a good taste; a week is a proper visit.',
  highlights: ['Burj Khalifa at dusk', 'Desert sunrise', 'Old Dubai souks', 'Marina evenings'],
  bestTime: 'Nov – Mar', climate: '30°C', costLevel: 4, typicalFare: 1050, style: ['Design', 'Food', 'Shopping'], suggestedDays: 5,
  photo: photo('dubai'), connection: conn('Qatar Airways', 'QR', A.doh, 'Emirates', 'EK'),
};
const bali: Destination = {
  id: 'bali', city: 'Bali', country: 'Indonesia', airport: A.dps, latitude: -8.41, longitude: 115.19,
  tagline: 'Temples on the water, terraces in the hills.',
  blurb: 'Mornings among rice terraces, afternoons on volcanic beaches, and evenings at temples that seem to float. Slow travel at its best.',
  highlights: ['Pura Ulun Danu Bratan', 'Tegalalang rice terraces', 'Uluwatu sunset', 'Ubud cooking classes'],
  bestTime: 'Apr – Oct', climate: '30°C', costLevel: 2, typicalFare: 1450, style: ['Nature', 'Wellness', 'Culture'], suggestedDays: 9,
  photo: photo('bali', 0.35), connection: conn('Qatar Airways', 'QR', A.doh, 'Qatar Airways', 'QR'),
};

export const Destinations = {
  rome, paris, tokyo, newYork, rio, lisbon, london, capeTown, dubai, bali,
  all: [rome, paris, tokyo, newYork, rio, lisbon, london, capeTown, dubai, bali] as Destination[],
  named(id: string): Destination | undefined {
    return Destinations.all.find((d) => d.id === id);
  },
  search(query: string, excluding?: string): Destination[] {
    const q = query.trim().toLowerCase();
    const pool = Destinations.all.filter((d) => d.id !== excluding);
    return q ? pool.filter((d) => destinationSearchText(d).includes(q)) : pool;
  },
};
