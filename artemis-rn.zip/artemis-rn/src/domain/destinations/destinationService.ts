import { Money, usd } from '../shared/money';
import type { TravelStyleProfile } from '../matching/preferences';
import { airportDistance } from './geo';
import { Destination, Destinations } from './destinations';
import { Place, placeAirport } from './place';

export interface DestinationMatch {
  percent: number;
  reasons: string[];
}

/** The destination catalogue, and how well each place fits a traveler. */
export class DestinationService {
  constructor(private catalog: Destination[] = Destinations.all) {}

  destination(id: string): Destination | undefined { return this.catalog.find((d) => d.id === id); }

  /** Places to discover from where you are: everywhere except home, best fit first. */
  discover(place: Place, profile: TravelStyleProfile, budget: Money): Destination[] {
    return this.catalog
      .filter((d) => d.airport.code !== place.airportCode)
      .map((d) => ({ d, pct: this.match(d, profile, budget).percent }))
      .sort((a, b) => b.pct - a.pct)
      .map((x) => x.d);
  }

  /** A transparent fit score: shared interests, and whether the typical fare fits your flight budget. */
  match(d: Destination, profile: TravelStyleProfile, budget: Money): DestinationMatch {
    const shared = d.style.filter((s) => profile.styles.some((p) => p.toLowerCase() === s.toLowerCase()));
    let pts = 58 + shared.length * 14;
    const reasons = shared.map((s) => `You like ${s.toLowerCase()}`);
    const fare = d.typicalFare;
    if (fare > 0) {
      if (fare <= budget) { pts += 12; reasons.push(`Typical fare fits your ${usd(budget)} budget`); }
      else if (fare <= budget * 1.4) { pts += 4; reasons.push(`A stretch on fare, about ${usd(fare)}`); }
      else reasons.push(`Long and pricey: about ${usd(fare)}`);
    }
    if (d.costLevel <= 2) { pts += 4; reasons.push("Easy on the budget once you're there"); }
    return { percent: Math.min(98, Math.max(40, pts)), reasons };
  }

  /** Rough travel time from a place, in hours, from the great-circle distance. */
  travelHours(place: Place, d: Destination): number {
    return airportDistance(placeAirport(place), d.airport) / 850 + 0.5;
  }
}
