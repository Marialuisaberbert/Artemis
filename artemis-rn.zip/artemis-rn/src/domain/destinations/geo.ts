import type { Instant } from '../shared/time';

export interface Airport {
  code: string;
  city: string;
  name: string;
  country: string;
  latitude: number;
  longitude: number;
  timeZoneID: string;
}

const ap = (code: string, city: string, name: string, country: string, latitude: number, longitude: number, timeZoneID: string): Airport =>
  ({ code, city, name, country, latitude, longitude, timeZoneID });

export const Airports = {
  gig: ap('GIG', 'Rio de Janeiro', 'Galeão International', 'Brazil', -22.81, -43.25, 'America/Sao_Paulo'),
  gru: ap('GRU', 'São Paulo', 'Guarulhos International', 'Brazil', -23.44, -46.47, 'America/Sao_Paulo'),
  lis: ap('LIS', 'Lisbon', 'Humberto Delgado', 'Portugal', 38.77, -9.14, 'Europe/Lisbon'),
  fco: ap('FCO', 'Rome', 'Fiumicino', 'Italy', 41.8, 12.24, 'Europe/Rome'),
  mad: ap('MAD', 'Madrid', 'Barajas', 'Spain', 40.5, -3.57, 'Europe/Madrid'),
  cdg: ap('CDG', 'Paris', 'Charles de Gaulle', 'France', 49.01, 2.55, 'Europe/Paris'),
  bcn: ap('BCN', 'Barcelona', 'El Prat', 'Spain', 41.3, 2.08, 'Europe/Madrid'),
  hnd: ap('HND', 'Tokyo', 'Haneda', 'Japan', 35.55, 139.78, 'Asia/Tokyo'),
  jfk: ap('JFK', 'New York', 'John F. Kennedy', 'United States', 40.64, -73.78, 'America/New_York'),
  doh: ap('DOH', 'Doha', 'Hamad International', 'Qatar', 25.27, 51.61, 'Asia/Qatar'),
  lhr: ap('LHR', 'London', 'Heathrow', 'United Kingdom', 51.47, -0.45, 'Europe/London'),
  cpt: ap('CPT', 'Cape Town', 'Cape Town International', 'South Africa', -33.97, 18.6, 'Africa/Johannesburg'),
  dxb: ap('DXB', 'Dubai', 'Dubai International', 'United Arab Emirates', 25.25, 55.36, 'Asia/Dubai'),
  dps: ap('DPS', 'Bali', 'Ngurah Rai', 'Indonesia', -8.75, 115.17, 'Asia/Makassar'),
  atl: ap('ATL', 'Atlanta', 'Hartsfield–Jackson', 'United States', 33.64, -84.43, 'America/New_York'),
};

export const allAirports: Airport[] = [
  Airports.gig, Airports.gru, Airports.lis, Airports.fco, Airports.mad, Airports.cdg, Airports.bcn, Airports.hnd,
  Airports.jfk, Airports.doh, Airports.atl, Airports.lhr, Airports.cpt, Airports.dxb, Airports.dps,
];

export const airportNamed = (code: string): Airport | undefined => allAirports.find((a) => a.code === code);

/** "Rio" for Rio de Janeiro; the city name otherwise. */
export const shortCity = (a: Airport): string => (a.city === 'Rio de Janeiro' ? 'Rio' : a.city);

/** Great-circle distance in kilometres. */
export function airportDistance(a: Airport, b: Airport): number {
  const r = 6371;
  const p1 = (a.latitude * Math.PI) / 180;
  const p2 = (b.latitude * Math.PI) / 180;
  const dp = p2 - p1;
  const dl = ((b.longitude - a.longitude) * Math.PI) / 180;
  const h = Math.sin(dp / 2) ** 2 + Math.cos(p1) * Math.cos(p2) * Math.sin(dl / 2) ** 2;
  return 2 * r * Math.asin(Math.min(1, Math.sqrt(h)));
}

export type { Instant };
