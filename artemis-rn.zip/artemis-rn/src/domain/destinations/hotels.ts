import type { Money } from '../shared/money';
import type { HotelStyle, LocationPreference } from '../matching/preferences';

export interface HotelOption {
  id: string;
  name: string;
  neighborhood: string;
  style: HotelStyle;
  location: LocationPreference;
  nightlyRate: Money;
  rating: number;
  blurb: string;
  bookingProvider: string;
}

export const hotelTotal = (h: HotelOption, nights: number): Money => h.nightlyRate * nights;

const h = (id: string, name: string, neighborhood: string, style: HotelStyle, location: LocationPreference, nightlyRate: Money, rating: number, blurb: string): HotelOption =>
  ({ id, name, neighborhood, style, location, nightlyRate, rating, blurb, bookingProvider: name });

const byDestination: Record<string, HotelOption[]> = {
  rome: [
    h('hoxton', 'The Hoxton Rome', 'Centro Storico', 'modern', 'central', 189, 4.6, 'A warm, design-led base ten minutes from the Pantheon.'),
    h('casa-monti', 'Casa Monti', 'Monti', 'boutique', 'central', 228, 4.8, "Twelve rooms above a wine bar in Rome's oldest neighborhood."),
    h('trastevere-loft', 'Hotel Trastevere Loft', 'Trastevere', 'modern', 'quiet', 164, 4.3, 'Quiet courtyard rooms across the river.'),
    h('palazzo-aurelia', 'Palazzo Aurelia', 'Via Veneto', 'luxury', 'central', 310, 4.9, 'A 19th-century palazzo with a rooftop terrace.'),
  ],
  paris: [
    h('maison-marais', 'Maison Marais', 'Le Marais', 'boutique', 'central', 172, 4.6, 'Stone walls, brass taps and a tiny courtyard.'),
    h('hotel-lumen', 'Hôtel Lumen', 'Saint-Germain', 'modern', 'central', 205, 4.5, 'Bright rooms a short walk from the river.'),
    h('petit-vert', 'Le Petit Vert', 'Montmartre', 'classic', 'quiet', 132, 4.2, 'Old Paris on a hill, with a very good breakfast.'),
  ],
  tokyo: [
    h('shibuya-stay', 'Shibuya Sky Stay', 'Shibuya', 'modern', 'central', 180, 4.5, 'Compact, calm rooms above the crossing.'),
    h('koya-house', 'Kōya House', 'Yanaka', 'boutique', 'quiet', 210, 4.7, 'A restored townhouse on a temple street.'),
    h('ginza-kobo', 'Hotel Ginza Kōbō', 'Ginza', 'classic', 'central', 240, 4.6, 'Quiet luxury a block from the department stores.'),
  ],
  barcelona: [
    h('casa-gracia', 'Casa Gràcia', 'Gràcia', 'boutique', 'central', 158, 4.6, "Balconies over one of the city's best squares."),
    h('born-moderno', 'Hotel Born Moderno', 'El Born', 'modern', 'central', 196, 4.5, 'Clean lines in a medieval quarter.'),
    h('mar-i-cel', 'Mar i Cel', 'Barceloneta', 'luxury', 'transit', 260, 4.8, 'Sea-facing suites steps from the beach.'),
  ],
  lisbon: [
    h('alfama-azulejo', 'Alfama Azulejo Hotel', 'Alfama', 'boutique', 'central', 140, 4.6, 'Hand-painted tiles in every room.'),
    h('principe-real', 'Príncipe Real House', 'Príncipe Real', 'modern', 'central', 188, 4.7, "Garden terrace above the city's best shops."),
    h('belem-quinta', 'Belém Quinta', 'Belém', 'classic', 'quiet', 120, 4.3, 'A quiet villa near the river.'),
  ],
  rio: [
    h('santa-teresa', 'Casa Santa Teresa', 'Santa Teresa', 'boutique', 'central', 165, 4.7, 'A hillside house of tiled terraces above the city.'),
    h('ipanema-modern', 'Ipanema Modern', 'Ipanema', 'modern', 'central', 195, 4.5, 'A block from the beach, with a rooftop pool.'),
    h('botafogo-loft', 'Botafogo Loft', 'Botafogo', 'modern', 'quiet', 140, 4.2, 'Quiet rooms with a view of Sugarloaf.'),
  ],
  london: [
    h('borough-house', 'Borough House', 'Southwark', 'boutique', 'central', 214, 4.6, 'Steps from the market and the river.'),
    h('shoreditch-modern', 'Shoreditch Modern', 'Shoreditch', 'modern', 'central', 190, 4.4, 'Warehouse bones, quiet rooms.'),
    h('kew-lodge', 'Kew Lodge', 'Richmond', 'classic', 'quiet', 150, 4.3, 'Garden views and an easy train into town.'),
  ],
  'cape-town': [
    h('bokaap-house', 'Bo-Kaap House', 'Bo-Kaap', 'boutique', 'central', 132, 4.6, 'Painted walls and a view of the mountain.'),
    h('waterfront-modern', 'Waterfront Modern', 'V&A Waterfront', 'modern', 'central', 178, 4.5, 'Harbor light in every room.'),
    h('camps-bay-villa', 'Camps Bay Villa', 'Camps Bay', 'luxury', 'quiet', 290, 4.8, 'Sea-facing suites below the Twelve Apostles.'),
  ],
  dubai: [
    h('downtown-modern', 'Downtown Modern', 'Downtown', 'modern', 'central', 195, 4.5, 'Towers outside, calm within.'),
    h('creek-boutique', 'Creek Boutique', 'Al Fahidi', 'boutique', 'central', 170, 4.6, 'A restored courtyard house by the old creek.'),
    h('marina-tower', 'Marina Tower Suites', 'Dubai Marina', 'luxury', 'transit', 260, 4.6, 'High-floor suites over the marina.'),
  ],
  bali: [
    h('ubud-house', 'Ubud Garden House', 'Ubud', 'boutique', 'central', 120, 4.8, 'Open-air rooms above the rice fields.'),
    h('canggu-modern', 'Canggu Modern', 'Canggu', 'modern', 'central', 150, 4.4, 'A short walk to the surf.'),
    h('uluwatu-villa', 'Uluwatu Cliff Villa', 'Uluwatu', 'luxury', 'quiet', 280, 4.9, 'Clifftop pool, ocean to the horizon.'),
  ],
  'new-york': [
    h('bowery-room', 'The Bowery Room', 'Lower East Side', 'boutique', 'central', 230, 4.5, 'Small rooms, big windows, loud in the best way.'),
    h('chelsea-modern', 'Chelsea Modern', 'Chelsea', 'modern', 'central', 210, 4.4, 'Steps from the High Line.'),
    h('brooklyn-yard', 'Brooklyn Yard Hotel', 'Williamsburg', 'modern', 'transit', 170, 4.3, 'A short ride from Manhattan, with a courtyard.'),
  ],
};

export const HotelCatalog = {
  byDestination,
  hotels: (destinationID: string): HotelOption[] => byDestination[destinationID] ?? [],
  allProviders: (): string[] => Object.values(byDestination).flatMap((hs) => hs.map((x) => x.bookingProvider)),
};
