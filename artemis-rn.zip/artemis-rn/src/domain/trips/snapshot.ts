import type { TravelPreferences, TravelStyleProfile } from '../matching/preferences';
import type { Traveler } from '../matching/traveler';
import type { FinancialState } from '../trust/models';
import type { TrustPolicy } from '../trust/policy';
import type { Trip } from './trip';

/**
 * Everything worth keeping between launches. Live state (a trust check in flight, the journey clock) is
 * deliberately not saved.
 */
export interface TripStoreSnapshot {
  version: number;
  hasOnboarded: boolean;
  you: Traveler;
  policy: TrustPolicy;
  financial: FinancialState;
  trips: Trip[];
  referenceCounter: number;
  profile: TravelStyleProfile;
  defaultPreferences: TravelPreferences;
  useLiveLocation: boolean;
  ticketCounter: number;
  /** y-m-d of the last day the morning greeting was shown. */
  lastGreetingDay?: string;
  soundEnabled: boolean;
}

/** Storage is injected: AsyncStorage on device, memory in tests. */
export interface TripPersistence {
  load(): Promise<TripStoreSnapshot | undefined> | TripStoreSnapshot | undefined;
  save(snapshot: TripStoreSnapshot): void | Promise<void>;
  clear(): void | Promise<void>;
}

export class InMemoryTripPersistence implements TripPersistence {
  stored?: TripStoreSnapshot;
  load(): TripStoreSnapshot | undefined { return this.stored ? JSON.parse(JSON.stringify(this.stored)) : undefined; }
  save(snapshot: TripStoreSnapshot): void { this.stored = JSON.parse(JSON.stringify(snapshot)); }
  clear(): void { this.stored = undefined; }
}
