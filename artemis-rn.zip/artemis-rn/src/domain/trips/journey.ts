import { Instant, Seconds, addSeconds, secondsBetween } from '../shared/time';
import { FlightLeg, FlightOption, legDuration } from './flights';
import type { TripPhase } from './trip';

/** Where a traveler is on the way to their destination, for a given moment. */
export interface JourneyState {
  phase: TripPhase;
  now: Instant;
  /** Time until the first departure (negative once airborne). */
  untilDeparture: Seconds;
  /** Time until boarding opens (negative once it has). */
  untilBoarding: Seconds;
  /** Time left until the final landing (zero when landed). */
  remaining: Seconds;
  /** 0 … legs.length. An integer means "on the ground at that station". */
  position: number;
  /** Which leg the plane is on (or is about to take). */
  legIndex: number;
  /** True while waiting between two flights. */
  isConnecting: boolean;
  /** Overall progress 0…1, by time. */
  timeProgress: number;
}

/** A simulated clock for the journey. The prototype lets you jump between the four phases. */
export class JourneySimulator {
  readonly legs: FlightLeg[];
  /** Boarding opens this long before departure. */
  boardingLead: Seconds = 44 * 60;

  constructor(flightOrLegs: FlightOption | FlightLeg[]) {
    this.legs = Array.isArray(flightOrLegs) ? flightOrLegs : flightOrLegs.legs;
  }

  get departure(): Instant { return this.legs[0].depart; }
  get arrival(): Instant { return this.legs[this.legs.length - 1].arrive; }

  /** A moment that lands in the middle of each phase, so the screens read well. */
  time(phase: TripPhase): Instant {
    switch (phase) {
      case 'notDeparted': return addSeconds(this.departure, -(4 * 3600 + 32 * 60));
      case 'boarding': return addSeconds(this.departure, -20 * 60);
      case 'inFlight': return addSeconds(this.departure, 8 * 3600 + 53 * 60);
      case 'landed': return addSeconds(this.arrival, 20 * 60);
    }
  }

  state(now: Instant): JourneyState {
    const untilDeparture = secondsBetween(now, this.departure);
    const untilBoarding = untilDeparture - this.boardingLead;
    let phase: TripPhase;
    if (now < addSeconds(this.departure, -this.boardingLead)) phase = 'notDeparted';
    else if (now < this.departure) phase = 'boarding';
    else if (now <= this.arrival) phase = 'inFlight';
    else phase = 'landed';

    let position = 0;
    let legIndex = 0;
    let connecting = false;
    if (now >= this.arrival) {
      position = this.legs.length;
      legIndex = this.legs.length - 1;
    } else if (now > this.departure) {
      for (let i = 0; i < this.legs.length; i++) {
        const leg = this.legs[i];
        if (now <= leg.arrive) {
          const f = secondsBetween(leg.depart, now) / Math.max(1, legDuration(leg));
          position = i + Math.min(1, Math.max(0, f));
          legIndex = i;
          break;
        }
        if (i + 1 < this.legs.length && now < this.legs[i + 1].depart) {
          position = i + 1;
          legIndex = i + 1;
          connecting = true;
          break;
        }
      }
    }
    const total = Math.max(1, secondsBetween(this.departure, this.arrival));
    return {
      phase, now, untilDeparture, untilBoarding, remaining: Math.max(0, secondsBetween(now, this.arrival)),
      position, legIndex, isConnecting: connecting, timeProgress: Math.min(1, Math.max(0, secondsBetween(this.departure, now) / total)),
    };
  }
}
