import { Zoned, addSeconds, hoursMinutes, secondsBetween, startOfDay, timeZone } from '../shared/time';
import { legArriveLocal } from './flights';
import { ItineraryEvent, Trip, hotelBooking, selectedFlight, selectedHotel, tripDestination } from './trip';
import { flightArrival } from './flights';

const DAY = 86_400_000;

/** Nights at the hotel: from the day the flight lands to the end of the trip. */
export function hotelNights(t: Trip): number {
  const tz = timeZone(tripDestination(t).airport.timeZoneID);
  const flight = selectedFlight(t);
  const arrivalDay = startOfDay(flight ? flightArrival(flight) : t.startDate + DAY, tz);
  const endDay = startOfDay(t.endDate, tz);
  return Math.max(1, Math.round((endDay - arrivalDay) / DAY));
}

export function hotelCheckIn(t: Trip): number {
  const tz = timeZone(tripDestination(t).airport.timeZoneID);
  const flight = selectedFlight(t);
  const day = flight ? flightArrival(flight) : t.startDate + DAY;
  return Zoned.at(day, 15, 0, tz);
}

export const hotelCheckOut = (t: Trip): number => Zoned.at(t.endDate, 11, 0, timeZone(tripDestination(t).airport.timeZoneID));

/** Turns what has been chosen or booked into a timeline of dated events. */
export class ItineraryBuilder {
  events(trip: Trip): ItineraryEvent[] {
    const out: ItineraryEvent[] = [];
    const flight = selectedFlight(trip);
    if (flight) {
      flight.legs.forEach((leg, i) => {
        out.push({
          id: `dep-${leg.id}`, date: leg.depart, timeZoneID: leg.from.timeZoneID, kind: 'depart',
          title: `Depart ${leg.from.city}`, detail: `${leg.flightNumber} · ${leg.from.code} → ${leg.to.code}`, symbol: 'airplane.departure',
        });
        out.push({
          id: `arr-${leg.id}`, date: leg.arrive, timeZoneID: leg.to.timeZoneID, kind: 'arrive',
          title: `Arrive ${leg.to.city}`, detail: `${leg.flightNumber} · ${legArriveLocal(leg)} local`, symbol: 'airplane.arrival',
        });
        if (i + 1 < flight.legs.length) {
          const next = flight.legs[i + 1];
          const wait = secondsBetween(leg.arrive, next.depart);
          out.push({
            id: `lay-${leg.id}`, date: addSeconds(leg.arrive, wait / 2), timeZoneID: leg.to.timeZoneID, kind: 'layover',
            title: `Connection in ${leg.to.city}`, detail: `${hoursMinutes(wait)} between flights`, symbol: 'cup.and.saucer',
          });
        }
      });
    }
    const hotel = selectedHotel(trip);
    if (hotel) {
      const tz = tripDestination(trip).airport.timeZoneID;
      const booked = hotelBooking(trip) !== undefined;
      // Check-in opens at 3 PM, but nobody is at the desk before they've landed.
      const earliest = flight ? addSeconds(flightArrival(flight), 90 * 60) : hotelCheckIn(trip);
      const arrival = Math.max(hotelCheckIn(trip), earliest);
      out.push({
        id: 'checkin', date: arrival, timeZoneID: tz, kind: 'checkIn', title: `Check in · ${hotel.name}`,
        detail: booked ? 'Check-in opens at 3:00 PM' : 'Not booked yet · check-in opens at 3:00 PM', symbol: 'bed.double',
      });
      out.push({ id: 'checkout', date: hotelCheckOut(trip), timeZoneID: tz, kind: 'checkOut', title: 'Check out', detail: hotel.name, symbol: 'door.left.hand.open' });
    }
    return out.sort((a, b) => a.date - b.date);
  }

  /** The next thing that isn't behind the traveler yet. */
  next(after: number, events: ItineraryEvent[]): ItineraryEvent | undefined {
    return events.find((e) => e.date > after && e.kind !== 'layover');
  }
}
