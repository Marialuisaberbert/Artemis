import { Money } from '../shared/money';
import { Instant, Zoned, dateFrom, parts, startOfDay, timeZone, addDays } from '../shared/time';
import { Airport, Airports } from '../destinations/geo';
import { Destination, Destinations } from '../destinations/destinations';
import type { Traveler } from '../matching/traveler';

/** What Artemis understood from a sentence. */
export interface TripDraft {
  destination?: Destination;
  start?: Instant;
  end?: Instant;
  days?: number;
  budgetPerPerson?: Money;
  travelers: Traveler[];
  interests: string[];
  original: string;
}

export const isPlannable = (d: TripDraft): boolean => d.destination !== undefined;

const MONTHS: [string, number][] = [
  ['jan', 1], ['feb', 2], ['mar', 3], ['apr', 4], ['may', 5], ['jun', 6], ['jul', 7], ['aug', 8], ['sep', 9], ['oct', 10], ['nov', 11], ['dec', 12],
];

const INTEREST_WORDS: [string, string[]][] = [
  ['Food', ['food', 'eat', 'restaurant', 'dinner', 'espresso', 'wine', 'cuisine']],
  ['Museums', ['museum', 'gallery', 'galleries']],
  ['Culture', ['culture', 'history', 'historic', 'art ']],
  ['Architecture', ['architecture', 'design']],
  ['Nightlife', ['nightlife', 'bars', 'clubs', 'party']],
  ['Beach', ['beach', 'sea', 'sun']],
  ['Shopping', ['shopping', 'shops']],
  ['Nature', ['hike', 'hiking', 'nature', 'mountain']],
];

/**
 * Natural-language planning, on device. A rule-based parser stands in for a language model in this prototype: it
 * reads the destination, dates, budget, companions and interests out of a sentence.
 */
export class TripPlanner {
  static readonly examples = [
    "Plan a 6-day trip to Rome with Sofia in September. I want good food and museums but don't want to spend more than $2,000 each.",
    'A long weekend in Lisbon with Lucas, mostly food and nightlife',
    'Tokyo for 8 days in October, design and food, $3,500 each',
  ];

  constructor(public origin: Airport = Airports.gig) {}

  parse(text: string, friends: Traveler[], now: Instant = Date.now()): TripDraft {
    const lower = ` ${text.toLowerCase()} `;
    const draft: TripDraft = { travelers: [], interests: [], original: text };

    draft.destination = Destinations.all.find((d) => lower.includes(d.city.toLowerCase()) || lower.includes(d.country.toLowerCase()));

    // Companions
    draft.travelers = friends.filter((f) => lower.includes(f.firstName.toLowerCase()));

    // Length
    const n = this.firstNumber(lower);
    if (n !== undefined) draft.days = n;
    else if (lower.includes('long weekend')) draft.days = 4;
    else if (lower.includes('weekend')) draft.days = 3;
    else if (lower.includes('two weeks') || lower.includes('2 weeks')) draft.days = 14;
    else if (lower.includes('a week') || lower.includes('one week')) draft.days = 7;
    if (draft.days === undefined) draft.days = draft.destination?.suggestedDays;

    // Budget: "$2,000 each" is per person; otherwise it is shared between everyone.
    const money = lower.match(/\$\s?[\d,]+/);
    if (money) {
      const digits = money[0].replace(/[^0-9]/g, '');
      if (digits) {
        const value = Number(digits);
        const perPerson = lower.includes('each') || lower.includes('per person') || lower.includes('per traveler') || lower.includes('a person');
        const count = Math.max(1, draft.travelers.length + 1);
        draft.budgetPerPerson = perPerson ? value : value / count;
      }
    }

    // Interests
    for (const [name, words] of INTEREST_WORDS) if (words.some((w) => lower.includes(w))) draft.interests.push(name);

    // Dates
    const start = this.startDate(lower, now);
    draft.start = start;
    if (start !== undefined && draft.days !== undefined) draft.end = Zoned.at(start, 0, 0, timeZone(this.origin.timeZoneID), draft.days);
    return draft;
  }

  private firstNumber(text: string): number | undefined {
    const m = text.match(/(\d{1,2})[\s-]?(?:day|night)/);
    return m ? Number(m[1]) : undefined;
  }

  /** "September 24" is exact. "in September" becomes the first Thursday on or after the 20th. */
  private startDate(text: string, now: Instant): Instant | undefined {
    const tz = timeZone(this.origin.timeZoneID);
    const year = parts(now, tz).year;
    for (const [abbr, month] of MONTHS) {
      const at = text.indexOf(abbr);
      if (at === -1) continue;
      // Reject false positives such as "mar" in "market" by requiring a word boundary before it.
      if (at > 0 && /\p{L}/u.test(text[at - 1])) continue;
      const tail = text.slice(at + abbr.length).replace(/^\p{L}*/u, '').replace(/^[ .]*/, '');
      const digits = tail.match(/^\d+/)?.[0] ?? '';
      const day = digits ? Number(digits) : 20;
      let date = dateFrom(year, month, day, tz);
      if (!digits) {
        // First Thursday (weekday 5) on or after the 20th.
        let guard = 0;
        while (parts(date, tz).weekday !== 5 && guard++ < 8) date = addDays(date, 1, tz);
      }
      if (date < now) date = dateFrom(year + 1, month, day, tz);
      return startOfDay(date, tz);
    }
    return undefined;
  }
}
