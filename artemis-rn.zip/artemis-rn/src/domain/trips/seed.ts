import { Instant, Zoned, dateFrom, parts, startOfDay, timeZone } from '../shared/time';
import { Airports } from '../destinations/geo';
import { friendDefault, mariaDemo, mariaProfile, sofiaDemo } from '../matching/preferences';
import { Travelers } from '../matching/traveler';
import { demoAccount, demoPolicy } from '../trust/demoData';
import type { TripStoreSnapshot } from '../trips/snapshot';
import { Booking, Trip, newMember, newTrip } from './trip';

const rioTZ = () => timeZone(Airports.gig.timeZoneID);

export function seedSnapshot(now: Instant = Date.now(), hasOnboarded = false): TripStoreSnapshot {
  return {
    version: 1, hasOnboarded, you: Travelers.maria, policy: demoPolicy(), financial: demoAccount(),
    trips: [seedRome(now), seedParis(now)], referenceCounter: 724_918, profile: mariaProfile(), defaultPreferences: mariaDemo(),
    useLiveLocation: false, ticketCounter: 1, soundEnabled: false,
  };
}

/** The next September 24th, at midnight in Rio (where Maria departs from). */
export function romeStart(now: Instant): Instant {
  const tz = rioTZ();
  const year = parts(now, tz).year;
  let date = dateFrom(year, 9, 24, tz);
  if (date < startOfDay(now, tz)) date = dateFrom(year + 1, 9, 24, tz);
  return startOfDay(date, tz);
}

export function seedRome(now: Instant): Trip {
  const start = romeStart(now);
  const end = Zoned.at(start, 0, 0, rioTZ(), 8);
  return newTrip({
    id: 'trip-rome', destinationID: 'rome', originCode: 'GIG', startDate: start, endDate: end,
    members: [newMember(Travelers.maria, 'you', mariaDemo()), newMember(Travelers.sofia, 'notInvited', sofiaDemo())],
    stage: 'draft', createdAt: now,
  });
}

export function seedParis(now: Instant): Trip {
  const tz = rioTZ();
  let year = parts(now, tz).year;
  if (parts(now, tz).month < 6) year -= 1;
  const start = startOfDay(dateFrom(year, 5, 12, tz), tz);
  const end = Zoned.at(start, 0, 0, tz, 5);
  const day = 86_400_000;
  const bookings: Booking[] = [
    {
      id: 'bk-past-1', kind: 'flight', provider: 'Air France', title: 'Air France · GIG → CDG', subtitle: 'Round trip · 3 travelers',
      total: 2070, perTraveler: 690, travelerCount: 3, status: 'confirmed', reference: 'ART-611204', bookedAt: start - 40 * day,
    },
    {
      id: 'bk-past-2', kind: 'hotel', provider: 'Maison Marais', title: 'Maison Marais', subtitle: '5 nights · Le Marais',
      total: 860, perTraveler: 860, travelerCount: 1, status: 'confirmed', reference: 'ART-611205', bookedAt: start - 40 * day,
    },
  ];
  return newTrip({
    id: 'trip-paris', destinationID: 'paris', originCode: 'GIG', startDate: start, endDate: end,
    members: [
      newMember(Travelers.maria, 'you', mariaDemo(), true),
      newMember(Travelers.sofia, 'joined', sofiaDemo(), true),
      newMember(Travelers.lucas, 'joined', friendDefault(), true),
    ],
    stage: 'booked', bookings, createdAt: start - 60 * day, isPast: true,
  });
}
