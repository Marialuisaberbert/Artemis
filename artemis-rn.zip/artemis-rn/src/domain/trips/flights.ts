import type { Money } from '../shared/money';
import { Instant, Seconds, Zoned, hoursMinutes, secondsBetween, timeZone } from '../shared/time';
import { Airport, airportNamed, Airports } from '../destinations/geo';

export interface FlightLeg {
  id: string;
  airlineName: string;
  flightNumber: string;
  from: Airport;
  to: Airport;
  depart: Instant;
  arrive: Instant;
}

export const legDuration = (l: FlightLeg): Seconds => secondsBetween(l.depart, l.arrive);
export const legDepartLocal = (l: FlightLeg): string => Zoned.time(l.depart, timeZone(l.from.timeZoneID));
export const legArriveLocal = (l: FlightLeg): string => Zoned.time(l.arrive, timeZone(l.to.timeZoneID));

export interface FlightOption {
  id: string;
  /** "TAP Air Portugal", "LATAM + ITA" */
  airline: string;
  /** "TAP", "ITA", "LATAM" — the short form used in rankings. */
  shortName: string;
  /** The provider Artemis' agent books through, and whose identity is verified. */
  bookingProvider: string;
  legs: FlightLeg[];
  /** Per traveler. */
  farePerTraveler: Money;
  cabin: string;
}

export const flightOrigin = (f: FlightOption): Airport => f.legs[0].from;
export const flightDestination = (f: FlightOption): Airport => f.legs[f.legs.length - 1].to;
export const flightStops = (f: FlightOption): number => f.legs.length - 1;
export const flightDeparture = (f: FlightOption): Instant => f.legs[0].depart;
export const flightArrival = (f: FlightOption): Instant => f.legs[f.legs.length - 1].arrive;
export const flightDuration = (f: FlightOption): Seconds => secondsBetween(flightDeparture(f), flightArrival(f));
export const departureMinuteOfDay = (f: FlightOption): number => Zoned.minuteOfDay(flightDeparture(f), timeZone(flightOrigin(f).timeZoneID));
export const departureLocal = (f: FlightOption): string => Zoned.time(flightDeparture(f), timeZone(flightOrigin(f).timeZoneID));
export const arrivalLocal = (f: FlightOption): string => Zoned.time(flightArrival(f), timeZone(flightDestination(f).timeZoneID));
export const flightNumber = (f: FlightOption): string => f.legs[0].flightNumber;
export const routeCodes = (f: FlightOption): string[] => [flightOrigin(f).code, ...f.legs.map((l) => l.to.code)];
export const stopsLabel = (f: FlightOption): string => {
  const n = flightStops(f);
  return n === 0 ? 'Nonstop' : `${n} stop${n === 1 ? '' : 's'}`;
};

/** 0 when it lands the same calendar day it left (each measured in its own airport's time). */
export const arrivalDayOffset = (f: FlightOption): number =>
  Zoned.daysBetween(flightDeparture(f), timeZone(flightOrigin(f).timeZoneID), flightArrival(f), timeZone(flightDestination(f).timeZoneID));

/** Airports where the traveler changes planes, with the time spent there. */
export const layovers = (f: FlightOption): { airport: Airport; duration: Seconds }[] =>
  f.legs.slice(0, -1).map((leg, i) => ({ airport: leg.to, duration: secondsBetween(leg.arrive, f.legs[i + 1].depart) }));

export const legDurationLabel = (l: FlightLeg): string => hoursMinutes(legDuration(l));
export const airportOf = (code: string): Airport => airportNamed(code) ?? Airports.gig;
