import type { Money } from '../shared/money';
import { Instant, Zoned, startOfDay, timeZone } from '../shared/time';
import { Airport, Airports, airportNamed } from '../destinations/geo';
import { Destination, Destinations } from '../destinations/destinations';
import type { EvaluationResult } from '../trust/models';
import type { TravelPreferences } from '../matching/preferences';
import type { Traveler } from '../matching/traveler';
import type { FlightOption } from './flights';
import type { HotelOption } from '../destinations/hotels';

// MARK: - The journey a trip takes while it is being planned

/** One continuous journey: invite → preferences → overlap → options → rank → decide → book. */
export type TripStage = 'draft' | 'inviting' | 'preferences' | 'overlap' | 'options' | 'ranking' | 'decision' | 'booking' | 'booked';
export const allStages: TripStage[] = ['draft', 'inviting', 'preferences', 'overlap', 'options', 'ranking', 'decision', 'booking', 'booked'];
export const stageOrder = (s: TripStage): number => allStages.indexOf(s);
export const stageAtMost = (s: TripStage, other: TripStage): boolean => stageOrder(s) <= stageOrder(other);
/** The steps drawn in the planning trail. */
export const stageTrail: TripStage[] = ['inviting', 'preferences', 'overlap', 'options', 'ranking', 'decision', 'booking'];
/** Traveling alone has nobody to overlap with or rank against, so those two steps drop out. */
export const soloTrail: TripStage[] = ['preferences', 'options', 'booking'];
export const stageTitle = (s: TripStage): string =>
  ({ draft: 'Start', inviting: 'Invite', preferences: 'Prefs', overlap: 'Overlap', options: 'Options', ranking: 'Rank', decision: 'Decide', booking: 'Book', booked: 'Booked' })[s];

export type InviteState = 'you' | 'notInvited' | 'invited' | 'joined';

export interface TripMember {
  traveler: Traveler;
  invite: InviteState;
  /** What this traveler is editing. Private to them until `hasSubmittedPreferences`. */
  preferences: TravelPreferences;
  hasSubmittedPreferences: boolean;
  /** Option ids, best first. */
  ranking: string[];
  hasRanked: boolean;
}

export const memberIsInTrip = (m: TripMember): boolean => m.invite === 'you' || m.invite === 'joined';

export const newMember = (traveler: Traveler, invite: InviteState, preferences: TravelPreferences, submitted = false): TripMember => ({
  traveler, invite, preferences, hasSubmittedPreferences: submitted, ranking: [], hasRanked: false,
});

/** What the group's rankings add up to. */
export interface GroupDecision {
  kind: 'aligned' | 'tradeoff';
  primaryOptionID: string;
  /** For a trade-off: the other side of it. */
  alternativeOptionID?: string;
  headline: string;
  explanation: string[];
  /** What the group finally chose. */
  chosenOptionID?: string;
}

// MARK: - Bookings and itinerary

export type BookingKind = 'flight' | 'hotel';
export type BookingStatus = 'confirmed' | 'approvedByYou';

export interface Booking {
  id: string;
  kind: BookingKind;
  provider: string;
  title: string;
  subtitle: string;
  /** For everyone on the booking. */
  total: Money;
  perTraveler: Money;
  travelerCount: number;
  status: BookingStatus;
  reference: string;
  verification?: EvaluationResult;
  bookedAt: Instant;
}

export const bookingStatusLabel = (b: Booking): string => (b.status === 'approvedByYou' ? 'APPROVED BY YOU' : 'AUTO-APPROVED');

export type ItineraryKind = 'depart' | 'arrive' | 'layover' | 'checkIn' | 'checkOut';

export interface ItineraryEvent {
  id: string;
  date: Instant;
  timeZoneID: string;
  kind: ItineraryKind;
  title: string;
  detail: string;
  /** A glyph name the UI maps to an icon. */
  symbol: string;
}

export const eventTimeLabel = (e: ItineraryEvent): string => Zoned.time(e.date, timeZone(e.timeZoneID));
export const eventDayLabel = (e: ItineraryEvent): string => Zoned.dayUpper(e.date, timeZone(e.timeZoneID));

/** The four states the prototype lets you step through on the way to Rome. */
export type TripPhase = 'notDeparted' | 'boarding' | 'inFlight' | 'landed';
export const tripPhases: TripPhase[] = ['notDeparted', 'boarding', 'inFlight', 'landed'];
export const phaseLabel = (p: TripPhase): string => ({ notDeparted: 'NOT DEPARTED', boarding: 'BOARDING', inFlight: 'IN FLIGHT', landed: 'LANDED' })[p];
export const phaseShort = (p: TripPhase): string => ({ notDeparted: 'Before', boarding: 'Boarding', inFlight: 'In flight', landed: 'Landed' })[p];

// MARK: - Trip

export interface Trip {
  id: string;
  destinationID: string;
  originCode: string;
  startDate: Instant;
  endDate: Instant;
  members: TripMember[];
  stage: TripStage;
  flightOptions: FlightOption[];
  hotelOptions: HotelOption[];
  selectedFlightID?: string;
  selectedHotelID?: string;
  decision?: GroupDecision;
  bookings: Booking[];
  createdAt: Instant;
  isPast: boolean;
  /** Free text kept from the natural-language planner. */
  note?: string;
  /** When the traveler cut their trip ticket. The ticket is a keepsake, not a boarding pass. */
  ticketCutAt?: Instant;
  /** "TRIP 001": the order in which this traveler's trips were booked. */
  ticketNumber?: number;
}

export const newTrip = (t: Pick<Trip, 'id' | 'destinationID' | 'originCode' | 'startDate' | 'endDate' | 'members' | 'stage'> & Partial<Trip>): Trip => ({
  flightOptions: [], hotelOptions: [], bookings: [], createdAt: Date.now(), isPast: false, ...t,
});

export const tripDestination = (t: Trip): Destination => Destinations.named(t.destinationID) ?? Destinations.rome;
export const tripOrigin = (t: Trip): Airport => airportNamed(t.originCode) ?? Airports.gig;

export const tripTravelers = (t: Trip): Traveler[] => t.members.filter(memberIsInTrip).map((m) => m.traveler);
export const invitedMembers = (t: Trip): TripMember[] => t.members.filter((m) => m.invite !== 'you');
export const tripYou = (t: Trip): TripMember | undefined => t.members.find((m) => m.invite === 'you');
export const travelerCount = (t: Trip): number => Math.max(1, t.members.filter(memberIsInTrip).length);

/** Planning alone: one traveler, past the invite step. */
export const isSoloPlanning = (t: Trip): boolean => stageOrder(t.stage) > stageOrder('inviting') && t.members.filter(memberIsInTrip).length === 1;
export const everyoneJoined = (t: Trip): boolean => t.members.every(memberIsInTrip) && t.members.length > 1;
export const everyoneSubmittedPreferences = (t: Trip): boolean => t.members.filter(memberIsInTrip).every((m) => m.hasSubmittedPreferences);
export const everyoneRanked = (t: Trip): boolean => t.members.filter(memberIsInTrip).every((m) => m.hasRanked);

export function tripNights(t: Trip): number {
  const tz = timeZone(tripDestination(t).airport.timeZoneID);
  const a = startOfDay(t.startDate, tz);
  const b = startOfDay(t.endDate, tz);
  return Math.max(1, Math.round((b - a) / 86_400_000));
}
export const tripDays = tripNights;

export const selectedFlight = (t: Trip): FlightOption | undefined => t.flightOptions.find((f) => f.id === t.selectedFlightID);
export const selectedHotel = (t: Trip): HotelOption | undefined => t.hotelOptions.find((h) => h.id === t.selectedHotelID);
export const flightBooking = (t: Trip): Booking | undefined => t.bookings.find((b) => b.kind === 'flight');
export const hotelBooking = (t: Trip): Booking | undefined => t.bookings.find((b) => b.kind === 'hotel');
export const isBooked = (t: Trip): boolean => flightBooking(t) !== undefined;

/** "SEP 24 — SEP 30" */
export function dateRange(t: Trip): string {
  const tz = timeZone(tripOrigin(t).timeZoneID);
  return `${Zoned.dayUpper(t.startDate, tz)} — ${Zoned.dayUpper(t.endDate, tz)}`;
}

/** "Sep 24–30" */
export function shortDateRange(t: Trip): string {
  const tz = timeZone(tripOrigin(t).timeZoneID);
  const sMonth = Zoned.day(t.startDate, tz).split(' ')[0];
  const eMonth = Zoned.day(t.endDate, tz).split(' ')[0];
  const eDay = Zoned.day(t.endDate, tz).split(' ')[1];
  return sMonth === eMonth ? `${Zoned.day(t.startDate, tz)}–${eDay}` : `${Zoned.day(t.startDate, tz)}–${Zoned.day(t.endDate, tz)}`;
}

export function tripTitle(t: Trip): string {
  const others = t.members.filter((m) => m.invite !== 'you').map((m) => m.traveler.firstName);
  const city = tripDestination(t).city.toUpperCase();
  return others.length === 0 ? city : `${city} WITH ${others.join(' & ').toUpperCase()}`;
}

export const travelerSummary = (t: Trip): string => `${travelerCount(t)} traveler${travelerCount(t) === 1 ? '' : 's'}`;

export function tripStatusLabel(t: Trip): string {
  if (t.isPast) return 'COMPLETED';
  switch (t.stage) {
    case 'draft': return 'NOT PLANNED YET';
    case 'inviting': return 'INVITING';
    case 'preferences': return 'SETTING PREFERENCES';
    case 'overlap': return 'FINDING THE OVERLAP';
    case 'options':
    case 'ranking': return 'CHOOSING TOGETHER';
    case 'decision': return 'READY TO BOOK';
    case 'booking': return 'BOOKING';
    case 'booked': return hotelBooking(t) === undefined ? 'FLIGHT BOOKED' : 'BOOKED';
  }
}

/** "TRIP 001" */
export const ticketLabel = (n: number): string => `TRIP ${String(n).padStart(3, '0')}`;
