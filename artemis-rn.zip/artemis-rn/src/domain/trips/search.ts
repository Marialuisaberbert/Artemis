import { Money } from '../shared/money';
import { Instant, Seconds, Zoned, addSeconds, timeZone } from '../shared/time';
import { Airport, Airports, airportDistance } from '../destinations/geo';
import { Destination } from '../destinations/destinations';
import { HotelCatalog, HotelOption } from '../destinations/hotels';
import { SimulatedLatency, latencyNone, waitLatency } from '../trust/services';
import { FlightLeg, FlightOption } from './flights';
import { Trip, tripDestination, tripOrigin } from './trip';

// Flight and hotel search are interfaces so a real provider can replace the mock without touching the matching
// engine or any screen. Everything here is SIMULATED: fares, times and hotels are authored demo data, not live inventory.

export interface TravelSearchService {
  flights(trip: Trip): Promise<FlightOption[]>;
  hotels(trip: Trip): Promise<HotelOption[]>;
}

const h = (hours: number, minutes: number): Seconds => hours * 3600 + minutes * 60;

/** Rome from Rio — authored so the demo reads the same every time. */
export function romeFlights(start: Instant): FlightOption[] {
  const brt = timeZone(Airports.gig.timeZoneID);
  const leg = (id: string, airlineName: string, flightNumber: string, from: Airport, to: Airport, depart: Instant, dur: Seconds): FlightLeg =>
    ({ id, airlineName, flightNumber, from, to, depart, arrive: addSeconds(depart, dur) });

  // TAP: Rio 10:45 PM → Lisbon 12:20 PM (+1) · 2h 15m in Lisbon · → Rome 6:20 PM
  const tap1Depart = Zoned.at(start, 22, 45, brt);
  const tap1 = leg('tp74', 'TAP Air Portugal', 'TP 74', Airports.gig, Airports.lis, tap1Depart, h(9, 35));
  const tap2Depart = addSeconds(tap1.arrive, h(2, 15));
  const tap2 = leg('tp836', 'TAP Air Portugal', 'TP 836', Airports.lis, Airports.fco, tap2Depart, h(2, 45));

  // ITA: nonstop, Rio 2:30 PM → Rome 7:05 AM (+1)
  const itaDepart = Zoned.at(start, 14, 30, brt);
  const ita = leg('az681', 'ITA Airways', 'AZ 681', Airports.gig, Airports.fco, itaDepart, h(11, 35));

  // LATAM + ITA: Rio 11:10 AM → São Paulo · 5h 05m · → Rome 10:05 AM (+1)
  const latDepart = Zoned.at(start, 11, 10, brt);
  const lat1 = leg('la8084', 'LATAM Airlines', 'LA 8084', Airports.gig, Airports.gru, latDepart, h(1, 10));
  const lat2Depart = addSeconds(lat1.arrive, h(5, 5));
  const lat2 = leg('az675', 'ITA Airways', 'AZ 675', Airports.gru, Airports.fco, lat2Depart, h(11, 40));

  // The same nonstop, in a premium cabin — outside the group's shared budget.
  const premium = leg('az681p', 'ITA Airways', 'AZ 681', Airports.gig, Airports.fco, itaDepart, h(11, 35));

  return [
    { id: 'tap', airline: 'TAP Air Portugal', shortName: 'TAP', bookingProvider: 'TAP Air Portugal', legs: [tap1, tap2], farePerTraveler: 547, cabin: 'Economy' },
    { id: 'ita', airline: 'ITA Airways', shortName: 'ITA', bookingProvider: 'ITA Airways', legs: [ita], farePerTraveler: 589, cabin: 'Economy' },
    { id: 'latam', airline: 'LATAM + ITA', shortName: 'LATAM', bookingProvider: 'LATAM Airlines', legs: [lat1, lat2], farePerTraveler: 512, cabin: 'Economy' },
    { id: 'ita-premium', airline: 'ITA Airways', shortName: 'ITA Premium', bookingProvider: 'ITA Airways', legs: [premium], farePerTraveler: 850, cabin: 'Premium Economy' },
  ];
}

/** Every other destination — derived from real distances. */
export function generatedFlights(origin: Airport, destination: Destination, start: Instant): FlightOption[] {
  const tz = timeZone(origin.timeZoneID);
  const c = destination.connection;
  const dist = airportDistance(origin, destination.airport);
  const nonstopHours = dist / 850 + 0.5;
  const fare = destination.typicalFare;
  const money = (f: number): Money => Math.round(fare * f);
  const t = (hours: number): Seconds => hours * 3600;
  const leg = (id: string, airline: string, code: string, n: number, from: Airport, to: Airport, depart: Instant, hours: number): FlightLeg =>
    ({ id, airlineName: airline, flightNumber: `${code} ${n}`, from, to, depart, arrive: addSeconds(depart, t(hours)) });

  // A: connect through the airline's hub, overnight departure.
  const aDepart = Zoned.at(start, 22, 45, tz);
  const a1 = leg('a1', c.airline, c.code, 74, origin, c.hub, aDepart, airportDistance(origin, c.hub) / 850 + 0.5);
  const a2Depart = addSeconds(a1.arrive, t(2.5));
  const a2 = leg('a2', c.airline, c.code, 836, c.hub, destination.airport, a2Depart, airportDistance(c.hub, destination.airport) / 850 + 0.5);

  // B: nonstop when the route allows it, otherwise a quicker connection.
  const bDepart = Zoned.at(start, 14, 30, tz);
  let bLegs: FlightLeg[];
  if (nonstopHours <= 16) {
    bLegs = [leg('b1', c.nonstopAirline, c.nonstopCode, 681, origin, destination.airport, bDepart, nonstopHours)];
  } else {
    const b1 = leg('b1', c.nonstopAirline, c.nonstopCode, 681, origin, c.hub, bDepart, airportDistance(origin, c.hub) / 850 + 0.5);
    const b2Depart = addSeconds(b1.arrive, t(1.8));
    bLegs = [b1, leg('b2', c.nonstopAirline, c.nonstopCode, 682, c.hub, destination.airport, b2Depart, airportDistance(c.hub, destination.airport) / 850 + 0.5)];
  }

  // C: two airlines through São Paulo — cheapest, slowest.
  const cDepart = Zoned.at(start, 11, 10, tz);
  const c1 = leg('c1', 'LATAM Airlines', 'LA', 8084, origin, Airports.gru, cDepart, 1.2);
  const c2Depart = addSeconds(c1.arrive, t(4.6));
  const c2 = leg('c2', c.nonstopAirline, c.nonstopCode, 675, Airports.gru, destination.airport, c2Depart, airportDistance(Airports.gru, destination.airport) / 850 + 0.6);

  return [
    { id: 'a', airline: c.airline, shortName: c.code === 'TP' ? 'TAP' : c.airline, bookingProvider: c.airline, legs: [a1, a2], farePerTraveler: money(0.86), cabin: 'Economy' },
    { id: 'b', airline: c.nonstopAirline, shortName: c.nonstopAirline, bookingProvider: c.nonstopAirline, legs: bLegs, farePerTraveler: money(0.98), cabin: 'Economy' },
    { id: 'c', airline: `LATAM + ${c.nonstopCode}`, shortName: 'LATAM', bookingProvider: 'LATAM Airlines', legs: [c1, c2], farePerTraveler: money(0.79), cabin: 'Economy' },
    { id: 'premium', airline: c.nonstopAirline, shortName: `${c.nonstopAirline} Premium`, bookingProvider: c.nonstopAirline, legs: bLegs, farePerTraveler: money(1.5), cabin: 'Premium Economy' },
  ];
}

export class MockTravelSearchService implements TravelSearchService {
  constructor(private latency: SimulatedLatency = latencyNone) {}

  async flights(trip: Trip): Promise<FlightOption[]> {
    await waitLatency(this.latency);
    if (trip.destinationID === 'rome' && trip.originCode === 'GIG') return romeFlights(trip.startDate);
    return generatedFlights(tripOrigin(trip), tripDestination(trip), trip.startDate);
  }

  async hotels(trip: Trip): Promise<HotelOption[]> {
    await waitLatency(this.latency);
    return HotelCatalog.hotels(trip.destinationID);
  }
}
