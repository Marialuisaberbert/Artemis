import { Instant, Zoned, deviceTimeZone, parts, TimeZoneInfo, timeZone, DAY_MS } from '../shared/time';
import { Trip, isBooked, selectedFlight, tripDestination, tripOrigin } from '../trips/trip';
import { flightDeparture } from '../trips/flights';

/** What today looks like for the traveler. Decides what the morning greeting says. */
export type DailyContext =
  /** Nothing planned. */
  | { kind: 'noTrip' }
  /** A trip is coming. */
  | { kind: 'upcoming'; tripID: string; city: string; daysAway: number }
  /** Departure is today. */
  | { kind: 'departingToday'; tripID: string; city: string }
  /** Away right now. */
  | { kind: 'traveling'; tripID: string; city: string; plan: string; time: string };

/**
 * Works out the day's context and whether the greeting should show. Pure, so it can be tested.
 *
 * Rules:
 *   • The greeting shows on the first open of each calendar day, and never twice in one day.
 *   • It is contextual: no trip → "Where are we going?", a trip ahead → "Rome in 12 days", departure day →
 *     "Rome. Today.", mid-trip → "You're in Rome." with the plan for today.
 */
export class DailyContextService {
  context(trips: Trip[], now: Instant): DailyContext {
    const live = trips.filter((t) => !t.isPast);
    // Away right now
    const away = live.find((t) => isBooked(t) && t.startDate <= now && now <= t.endDate);
    if (away) {
      const sight = tripDestination(away).highlights[0] ?? tripDestination(away).city;
      return { kind: 'traveling', tripID: away.id, city: tripDestination(away).city, plan: sight, time: '2:00 PM' };
    }
    // The next trip that hasn't started
    const upcoming = live.filter((t) => t.startDate > now - DAY_MS).sort((a, b) => a.startDate - b.startDate)[0];
    if (!upcoming) return { kind: 'noTrip' };
    const flight = selectedFlight(upcoming);
    const tz = timeZone(tripOrigin(upcoming).timeZoneID);
    const days = DailyContextService.daysBetween(now, flight ? flightDeparture(flight) : upcoming.startDate, tz);
    const city = tripDestination(upcoming).city;
    return days <= 0 ? { kind: 'departingToday', tripID: upcoming.id, city } : { kind: 'upcoming', tripID: upcoming.id, city, daysAway: days };
  }

  /** The first open of a calendar day gets the greeting. */
  shouldShowGreeting(lastShownDay: string | undefined, now: Instant, tz: TimeZoneInfo = deviceTimeZone): boolean {
    return lastShownDay !== DailyContextService.dayKey(now, tz);
  }

  greetingWord(now: Instant, tz: TimeZoneInfo = deviceTimeZone): string {
    const h = parts(now, tz).hour;
    return h < 5 ? 'GOOD EVENING' : h < 12 ? 'GOOD MORNING' : h < 18 ? 'GOOD AFTERNOON' : 'GOOD EVENING';
  }

  static dayKey(at: Instant, tz: TimeZoneInfo): string {
    const p = parts(at, tz);
    return `${p.year}-${p.month}-${p.day}`;
  }

  static daysBetween(from: Instant, to: Instant, tz: TimeZoneInfo): number {
    return Zoned.daysBetween(from, tz, to, tz);
  }
}

/**
 * What the morning greeting says: an eyebrow and a headline, in capitals.
 *   no trip   → "GOOD MORNING, MARIA" / "WHERE ARE WE GOING?"
 *   upcoming  → "ROME IN 12 DAYS" ("ROME TOMORROW" for one day)
 *   today     → "ROME. TODAY."
 *   traveling → "YOU'RE IN ROME." / "TODAY: COLOSSEUM AT BLUE HOUR 2:00 PM"
 */
export function greetingText(ctx: DailyContext, word: string, firstName: string): { eyebrow: string; headline: string } {
  const greeting = `${word}, ${firstName.toUpperCase()}`;
  switch (ctx.kind) {
    case 'noTrip':
      return { eyebrow: greeting, headline: 'WHERE ARE WE GOING?' };
    case 'upcoming':
      return { eyebrow: greeting, headline: ctx.daysAway === 1 ? `${ctx.city.toUpperCase()} TOMORROW` : `${ctx.city.toUpperCase()} IN ${ctx.daysAway} DAYS` };
    case 'departingToday':
      return { eyebrow: greeting, headline: `${ctx.city.toUpperCase()}. TODAY.` };
    case 'traveling':
      return { eyebrow: `YOU'RE IN ${ctx.city.toUpperCase()}.`, headline: `TODAY: ${ctx.plan.toUpperCase()} ${ctx.time}` };
  }
}
