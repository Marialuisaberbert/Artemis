import {
  AgentRequest, Counterfactual, EvaluationResult, FinancialState, Layer, VerificationResult, notReached,
} from './models';
import type { TrustPolicy } from './policy';
import {
  FinancialService, IdentityService, MockFinancialService, MockIdentityService, MockPolicyService, PolicyService, SimulatedLatency, latencyNone,
} from './services';

/** A layer that does not say where its answer came from is a local stand-in. */
const tagged = (r: VerificationResult, fallback: 'simulated' | 'device' = 'simulated'): VerificationResult => (r.source ? r : { ...r, source: fallback });

/** Progress events, in order, as the engine works through a request. */
export type StageEvent =
  | { type: 'received' }
  | { type: 'started'; layer: Layer }
  | { type: 'completed'; layer: Layer; result: VerificationResult }
  | { type: 'decided'; result: EvaluationResult };

/** Called for each event. May suspend (to pace a UI) or throw (to abort). */
export type StageHandler = (event: StageEvent) => void | Promise<void>;

/**
 * The decision engine — the single source of truth for what happens to a request.
 *
 *     identity fails  → BLOCKED             (policy and financial are never called)
 *     policy fails    → APPROVAL REQUIRED   (financial is never called)
 *     financial fails → APPROVAL REQUIRED
 *     otherwise       → AUTO-APPROVED
 *
 * No screen contains decision logic; they render what this returns.
 */
export class DecisionEngine {
  constructor(
    public identityService: IdentityService,
    public policyService: PolicyService,
    public financialService: FinancialService,
  ) {}

  /** Engine wired to the prototype's mock services. */
  static mock(latency: SimulatedLatency = latencyNone): DecisionEngine {
    return new DecisionEngine(new MockIdentityService(latency), new MockPolicyService(latency), new MockFinancialService(latency));
  }

  /**
   * @param financialState The account state to evaluate against. When omitted, it is fetched from the financial
   *   service — but only if the request gets that far.
   */
  async evaluateTransaction(
    request: AgentRequest,
    policy: TrustPolicy,
    opts: { financialState?: FinancialState; includeCounterfactual?: boolean; onStage?: StageHandler } = {},
  ): Promise<EvaluationResult> {
    const { financialState, includeCounterfactual = true, onStage } = opts;
    await onStage?.({ type: 'received' });

    // 1 ─ IDENTITY
    await onStage?.({ type: 'started', layer: 'identity' });
    const identity = tagged(await this.identityService.verifyAgent(request.agent));
    await onStage?.({ type: 'completed', layer: 'identity', result: identity });

    if (identity.status !== 'passed') {
      const result: EvaluationResult = {
        requestID: request.id, decision: 'blocked', failedAt: 'identity', identity,
        policy: notReached('policy'), financial: notReached('financial'), reason: identity.description, humanApprovalRequired: false,
      };
      if (includeCounterfactual) result.counterfactual = await this.counterfactual(request, policy, financialState);
      await onStage?.({ type: 'decided', result });
      return result;
    }

    // 2 ─ POLICY
    await onStage?.({ type: 'started', layer: 'policy' });
    const policyResult = tagged(await this.policyService.evaluateTransaction(request, policy), 'device');
    await onStage?.({ type: 'completed', layer: 'policy', result: policyResult });

    if (policyResult.status !== 'passed') {
      const result: EvaluationResult = {
        requestID: request.id, decision: 'approvalRequired', failedAt: 'policy', identity, policy: policyResult,
        financial: notReached('financial'), reason: policyResult.description, humanApprovalRequired: true,
      };
      await onStage?.({ type: 'decided', result });
      return result;
    }

    // 3 ─ FINANCIAL
    await onStage?.({ type: 'started', layer: 'financial' });
    const state = financialState ?? (await this.financialService.currentState(request));
    const financial = tagged(await this.financialService.checkTransaction(request, policy, state));
    await onStage?.({ type: 'completed', layer: 'financial', result: financial });

    const cleared = financial.status === 'passed';
    const result: EvaluationResult = {
      requestID: request.id, decision: cleared ? 'autoApproved' : 'approvalRequired', failedAt: cleared ? undefined : 'financial',
      identity, policy: policyResult, financial,
      reason: cleared ? 'Within your trust policy and financial limits.' : financial.description, humanApprovalRequired: !cleared,
    };
    await onStage?.({ type: 'decided', result });
    return result;
  }

  /**
   * What policy and financial would have said if identity had passed — for the "the amount was fine, the identity
   * was fake" moment. A production deployment would not query a user's accounts on behalf of an unverified agent,
   * so this is opt-out via `includeCounterfactual`.
   */
  private async counterfactual(request: AgentRequest, policy: TrustPolicy, financialState?: FinancialState): Promise<Counterfactual> {
    const p = await this.policyService.evaluateTransaction(request, policy);
    const state = financialState ?? (await this.financialService.currentState(request));
    const f = await this.financialService.checkTransaction(request, policy, state);
    return { policyPassed: p.status === 'passed', financialPassed: f.status === 'passed', policyDetail: p.description, financialDetail: f.description };
  }
}
