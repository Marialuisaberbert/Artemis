import type { Money } from '../shared/money';
import type { Instant } from '../shared/time';
import { HotelOption, hotelTotal } from '../destinations/hotels';
import type { FlightOption } from '../trips/flights';
import { routeCodes } from '../trips/flights';
import { agentFor, impostorFor, verifiedDomain } from './demoData';
import { DecisionEngine, StageHandler } from './decisionEngine';
import type { AgentClaim, AgentRequest, EvaluationResult, FinancialState, TransactionKind } from './models';
import type { TrustPolicy } from './policy';
import { SimulatedLatency, latencyDemo } from './services';

/** What Artemis' booking agent asks the trust layer to authorize. */
export interface BookingIntent {
  id: string;
  kind: TransactionKind;
  provider: string;
  agent: AgentClaim;
  /** Per traveler for flights; the whole stay for a hotel room. */
  unitAmount: Money;
  travelers: number;
  nights?: number;
  detail: string;
}

export const intentTotal = (i: BookingIntent): Money => i.unitAmount * i.travelers;
export const isImpersonation = (i: BookingIntent): boolean => i.agent.domain.toLowerCase() !== verifiedDomain(i.provider);

export function flightIntent(option: FlightOption, travelers: number, impostor = false): BookingIntent {
  return {
    id: `book-${option.id}-${impostor ? 'x' : 'ok'}`, kind: 'flight', provider: option.bookingProvider,
    agent: impostor ? impostorFor(option.bookingProvider) : agentFor(option.bookingProvider),
    unitAmount: option.farePerTraveler, travelers, detail: `${routeCodes(option).join(' → ')} · ${option.airline}`,
  };
}

export function hotelIntent(hotel: HotelOption, nights: number): BookingIntent {
  return {
    id: `book-hotel-${hotel.id}`, kind: 'hotel', provider: hotel.bookingProvider, agent: agentFor(hotel.bookingProvider),
    unitAmount: hotelTotal(hotel, nights), travelers: 1, nights, detail: `${hotel.name} · ${nights} nights`,
  };
}

export function intentRequest(i: BookingIntent, date: Instant = Date.now()): AgentRequest {
  return {
    id: i.id, date, agent: i.agent, provider: i.provider, kind: i.kind, amount: i.unitAmount, currency: 'USD',
    nights: i.nights, travelers: i.travelers, detail: i.detail,
  };
}

/**
 * The trust layer, as the travel app sees it. It is deliberately separate from trip matching:
 * planning decides WHAT the group wants; this decides whether an agent may act on it.
 *
 *     Identity → Policy → Financial  →  AUTO_APPROVED · APPROVAL_REQUIRED · BLOCKED
 */
export class ArtemisTrustEngine {
  constructor(public engine: DecisionEngine) {}

  static simulated(latency: SimulatedLatency = latencyDemo): ArtemisTrustEngine {
    return new ArtemisTrustEngine(DecisionEngine.mock(latency));
  }

  /** Leave `financial` out to have the financial service fetch it — only if the booking gets that far. */
  evaluateBooking(intent: BookingIntent, policy: TrustPolicy, financial?: FinancialState, onStage?: StageHandler): Promise<EvaluationResult> {
    // No counterfactual: an unverified agent never gets the policy or financial services called on its behalf.
    return this.engine.evaluateTransaction(intentRequest(intent), policy, { financialState: financial, includeCounterfactual: false, onStage });
  }
}
