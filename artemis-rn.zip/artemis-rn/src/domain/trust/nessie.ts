import { Money, cents } from '../shared/money';
import type { FinancialState } from './models';

/**
 * The traveler's real (sandbox) bank account, on Capital One's Nessie API.
 *
 * Nessie is a hackathon sandbox: it stores accounts and purchases but never moves a balance on its own. So the account
 * is opened with the balance plus a seed purchase, and what is available is always `balance − purchases`. Every booking
 * Artemis approves is posted as a real purchase, and the next check reads it back.
 */

export interface KeyValueStorage {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
}

/** What the store needs from a bank. Anything that can answer these is a ledger. */
export interface FinancialLedger {
  state(): Promise<FinancialState>;
  record(amount: Money, description: string): Promise<void>;
  /** Forget the account, so the next call opens a fresh one. */
  reset(): Promise<void>;
}

export class NessieError extends Error {
  constructor(message: string, readonly status?: number) {
    super(message);
    this.name = 'NessieError';
  }
}

export interface NessieOptions {
  apiKey: string;
  storage: KeyValueStorage;
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
  clock?: () => number;
  /** What the traveler can spend when the account opens. */
  openingAvailable?: Money;
  /** Travel already spent this month when the account opens. */
  seedSpend?: Money;
}

interface Ids {
  customerId: string;
  accountId: string;
  merchantId: string;
}

interface NessieAccount {
  balance: number;
  account_number?: string;
}

interface NessiePurchase {
  amount: number;
  purchase_date?: string;
}

const STORAGE_KEY = 'artemis.nessie.v1';
const ADDRESS = { street_number: '1', street_name: 'Artemis Way', city: 'Blacksburg', state: 'VA', zip: '24060' };

export class NessieLedger implements FinancialLedger {
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly timeoutMs: number;
  private readonly clock: () => number;
  private readonly openingAvailable: Money;
  private readonly seedSpend: Money;
  private ids?: Ids;
  private opening?: Promise<Ids>;

  constructor(private readonly options: NessieOptions) {
    this.baseUrl = options.baseUrl ?? 'https://api.nessieisreal.com';
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.timeoutMs = options.timeoutMs ?? 6000;
    this.clock = options.clock ?? Date.now;
    this.openingAvailable = options.openingAvailable ?? 4820;
    this.seedSpend = options.seedSpend ?? 340;
  }

  // MARK: - FinancialLedger

  async state(): Promise<FinancialState> {
    try {
      return await this.read(await this.ensure());
    } catch (error) {
      // The account may have been deleted on Nessie's side: open a new one once.
      if (error instanceof NessieError && error.status === 404) {
        await this.forget();
        return this.read(await this.ensure());
      }
      throw error;
    }
  }

  async record(amount: Money, description: string): Promise<void> {
    const ids = await this.ensure();
    await this.purchase(ids, amount, description);
  }

  async reset(): Promise<void> {
    await this.forget();
  }

  // MARK: - Account

  private async read(ids: Ids): Promise<FinancialState> {
    const [account, purchases] = await Promise.all([
      this.request<NessieAccount>('GET', `/accounts/${ids.accountId}`),
      this.request<NessiePurchase[]>('GET', `/accounts/${ids.accountId}/purchases`),
    ]);
    const month = new Date(this.clock()).toISOString().slice(0, 7);
    let spent = 0;
    let monthSpend = 0;
    for (const p of purchases) {
      spent += p.amount;
      if (p.purchase_date?.startsWith(month)) monthSpend += p.amount;
    }
    const last4 = (account.account_number ?? '').slice(-4);
    return {
      accountName: last4 ? `Checking ••${last4}` : 'Checking',
      availableBalance: cents(account.balance - spent),
      monthToDateTravelSpend: cents(monthSpend),
      source: 'nessie',
    };
  }

  private async ensure(): Promise<Ids> {
    if (this.ids) return this.ids;
    if (!this.opening) this.opening = this.load().finally(() => { this.opening = undefined; });
    return this.opening;
  }

  private async load(): Promise<Ids> {
    const saved = await this.options.storage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const ids = JSON.parse(saved) as Ids;
        if (ids.accountId && ids.merchantId) { this.ids = ids; return ids; }
      } catch { /* fall through and open a new account */ }
    }
    return this.open();
  }

  /** A customer, a checking account, a merchant for travel, and this month's earlier spend. */
  private async open(): Promise<Ids> {
    const customer = await this.create('/customers', { first_name: 'Maria', last_name: 'Luiza', address: ADDRESS });
    const account = await this.create(`/customers/${customer._id}/accounts`, {
      type: 'Checking', nickname: 'Artemis Checking', rewards: 0, balance: Math.round(this.openingAvailable + this.seedSpend),
    });
    const merchant = await this.create('/merchants', {
      name: 'Artemis Travel', category: 'travel', address: ADDRESS, geocode: { lat: 37.23, lng: -80.41 },
    });
    const ids: Ids = { customerId: customer._id, accountId: account._id, merchantId: merchant._id };
    await this.purchase(ids, this.seedSpend, 'Earlier travel this month');
    this.ids = ids;
    await this.options.storage.setItem(STORAGE_KEY, JSON.stringify(ids));
    return ids;
  }

  private async forget(): Promise<void> {
    this.ids = undefined;
    await this.options.storage.removeItem(STORAGE_KEY);
  }

  private purchase(ids: Ids, amount: Money, description: string): Promise<unknown> {
    return this.request('POST', `/accounts/${ids.accountId}/purchases`, {
      merchant_id: ids.merchantId,
      medium: 'balance',
      purchase_date: new Date(this.clock()).toISOString().slice(0, 10),
      amount: cents(amount),
      // Nessie will not list an account's purchases if any one of them is missing a status.
      status: 'completed',
      description,
    });
  }

  private async create(path: string, body: unknown): Promise<{ _id: string }> {
    const response = await this.request<{ objectCreated?: { _id?: string } }>('POST', path, body);
    const id = response.objectCreated?._id;
    if (!id) throw new NessieError(`Nessie did not return an id for ${path}`);
    return { _id: id };
  }

  // MARK: - HTTP

  private async request<T>(method: 'GET' | 'POST', path: string, body?: unknown): Promise<T> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const url = `${this.baseUrl}${path}?key=${encodeURIComponent(this.options.apiKey)}`;
      const response = await this.fetchImpl(url, {
        method,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: controller.signal,
      });
      if (!response.ok) throw new NessieError(`Nessie answered ${response.status}`, response.status);
      return (await response.json()) as T;
    } catch (error) {
      if (error instanceof NessieError) throw error;
      throw new NessieError(controller.signal.aborted ? 'Nessie timed out' : 'Nessie could not be reached');
    } finally {
      clearTimeout(timer);
    }
  }
}
