import { HotelCatalog } from '../destinations/hotels';
import type { AgentClaim, FinancialState } from './models';
import type { TrustPolicy } from './policy';

export interface RegisteredAgent {
  domain: string;
  record: string;
}

/** Simulated data. Nothing here is a real account, agent registry or bank. */
export const airlines = [
  'TAP Air Portugal', 'ITA Airways', 'LATAM Airlines', 'Air France', 'Qatar Airways', 'Iberia', 'American Airlines', 'British Airways', 'Emirates',
];

/** "TAP Air Portugal" → "tapairportugal" */
export const compact = (provider: string): string => provider.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

/** The domain a legitimate agent for this provider calls from. */
export const verifiedDomain = (provider: string): string => `agent.${compact(provider)}.com`;

/** Providers Artemis' booking agent is allowed to work with. In the prototype the "registry" is this list. */
export function registeredAgents(): Record<string, RegisteredAgent> {
  const out: Record<string, RegisteredAgent> = {};
  for (const name of [...airlines, ...HotelCatalog.allProviders()]) {
    const domain = verifiedDomain(name);
    out[name.toLowerCase()] = { domain, record: `ans://${domain}` };
  }
  return out;
}

/** A legitimate agent for the provider — what Artemis' booking agent normally is. */
export const agentFor = (provider: string): AgentClaim => ({
  name: `${provider} · Artemis agent`, claimedIdentity: provider, domain: verifiedDomain(provider),
});

/** An agent claiming to be the provider from a lookalike domain. */
export const impostorFor = (provider: string): AgentClaim => ({
  name: `${provider.replace(/ /g, '')}-Agent`, claimedIdentity: provider, domain: `${compact(provider)}-agent.io`,
});

/** Maria's simulated account. */
export const demoAccount = (): FinancialState => ({ accountName: 'Checking ••4821', availableBalance: 4820.55, monthToDateTravelSpend: 340 });

/** The default trust policy for the demo persona. */
export const demoPolicy = (): TrustPolicy => ({
  flightLimit: 600, hotelNightlyLimit: 200, monthlyTravelLimit: 3200, verifiedProvidersOnly: true, escalateNonTravel: true,
});
