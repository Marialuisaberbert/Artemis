import { Money, usd } from '../shared/money';

export type RuleOutcome = 'autoApprove' | 'askYou' | 'block';
export const outcomeLabel = (o: RuleOutcome): string => ({ autoApprove: 'AUTO-APPROVE', askYou: 'ASK YOU', block: 'BLOCK' })[o];

export interface PolicyRule {
  condition: string;
  outcome: RuleOutcome;
}

/** The user's AI Trust Policy: the boundaries their agent operates inside. */
export interface TrustPolicy {
  flightLimit: Money;
  hotelNightlyLimit: Money;
  monthlyTravelLimit: Money;
  /** Always true in this release: an unverified agent is never trusted with money. */
  verifiedProvidersOnly: boolean;
  /** Purchases that aren't flights or hotels always come back to the user. */
  escalateNonTravel: boolean;
}

export const standardPolicy = (): TrustPolicy => ({
  flightLimit: 600, hotelNightlyLimit: 200, monthlyTravelLimit: 2000, verifiedProvidersOnly: true, escalateNonTravel: true,
});

/** The policy as plain-English rules, in the order they are evaluated. */
export function policyRules(p: TrustPolicy): PolicyRule[] {
  const list: PolicyRule[] = [
    { condition: `Flights under ${usd(p.flightLimit)} from verified providers`, outcome: 'autoApprove' },
    { condition: `Hotels under ${usd(p.hotelNightlyLimit)}/night from verified providers`, outcome: 'autoApprove' },
    { condition: 'Anything outside your limits', outcome: 'askYou' },
  ];
  if (p.escalateNonTravel) list.push({ condition: 'Purchases outside travel', outcome: 'askYou' });
  list.push({ condition: 'Unverified agents', outcome: 'block' });
  return list;
}

/** What happens at the edges of the policy, in the order a person thinks about them. */
export function boundaryRules(p: TrustPolicy): PolicyRule[] {
  const list: PolicyRule[] = [{ condition: 'Anything above your limits', outcome: 'askYou' }];
  if (p.escalateNonTravel) list.push({ condition: 'Purchases outside travel', outcome: 'askYou' });
  list.push({ condition: 'Unverified agents', outcome: 'block' });
  list.push({ condition: 'Transactions within your limits', outcome: 'autoApprove' });
  return list;
}

/** The answers a user gives while building a policy. */
export interface PolicyAnswers {
  flightLimit: Money;
  hotelNightlyLimit: Money;
  escalateNonTravel: boolean;
}

export const answersFrom = (p: TrustPolicy = standardPolicy()): PolicyAnswers => ({
  flightLimit: p.flightLimit, hotelNightlyLimit: p.hotelNightlyLimit, escalateNonTravel: p.escalateNonTravel,
});
