import { registeredAgents } from './demoData';
import { AgentClaim, VerificationResult, meta } from './models';
import type { IdentityService } from './services';

/**
 * Identity, checked against GoDaddy's Agent Name Service (ANS) registry.
 *
 * The registry maps a host name to a registered, certificate-backed agent. `LiveIdentityService` asks it whether the
 * agent that wants to book is registered and ACTIVE. An agent calling from a host that has no record — a lookalike
 * domain, say — gets a real "not found" and is blocked.
 *
 * Providers such as TAP Air Portugal are not registered in ANS, so a legitimate booking is verified through a
 * registered stand-in travel agent, and the result says so plainly.
 */

export interface AnsAgentRecord {
  ansName: string;
  agentId: string;
  displayName: string;
  host: string;
  status: string;
  registered?: string;
  protocol?: string;
}

export interface AnsOptions {
  key: string;
  secret: string;
  /** The test (OTE) registry by default. */
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
}

interface AnsListResponse {
  agents?: {
    ansName: string; agentId: string; agentDisplayName?: string; agentHost: string; status: string;
    registrationTimestamp?: string; endpoints?: { protocol?: string }[];
  }[];
}

export class AnsRegistryClient {
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly timeoutMs: number;

  constructor(private readonly options: AnsOptions) {
    this.baseUrl = options.baseUrl ?? 'https://api.ote-godaddy.com';
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.timeoutMs = options.timeoutMs ?? 6000;
  }

  /** The ACTIVE agent registered for exactly this host, or undefined when the registry has none. Throws if it cannot be reached. */
  async lookupHost(host: string): Promise<AnsAgentRecord | undefined> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    try {
      const response = await this.fetchImpl(`${this.baseUrl}/v1/agents?agentHost=${encodeURIComponent(host)}`, {
        headers: { Authorization: `sso-key ${this.options.key}:${this.options.secret}`, Accept: 'application/json' },
        signal: controller.signal,
      });
      if (!response.ok) throw new Error(`ANS answered ${response.status}`);
      const body = (await response.json()) as AnsListResponse;
      const match = body.agents?.find((a) => a.agentHost.toLowerCase() === host.toLowerCase() && a.status === 'ACTIVE');
      if (!match) return undefined;
      return {
        ansName: match.ansName, agentId: match.agentId, displayName: match.agentDisplayName ?? match.agentHost, host: match.agentHost,
        status: match.status, registered: match.registrationTimestamp?.slice(0, 10), protocol: match.endpoints?.[0]?.protocol,
      };
    } finally {
      clearTimeout(timer);
    }
  }
}

/** A registered travel agent in the ANS test registry, used to stand in for a provider's own agent. */
export const ANS_STAND_IN_HOST = 'travel-ote.agentnameregistry.ai';

export class LiveIdentityService implements IdentityService {
  constructor(
    private readonly registry: Pick<AnsRegistryClient, 'lookupHost'>,
    /** Answers when the registry cannot be reached, so a flaky network never stops a booking. */
    private readonly fallback: IdentityService,
    private readonly standInHost: string = ANS_STAND_IN_HOST,
  ) {}

  async verifyAgent(claim: AgentClaim): Promise<VerificationResult> {
    const known = registeredAgents()[claim.claimedIdentity.toLowerCase()];
    const legitimate = known !== undefined && claim.domain.toLowerCase() === known.domain.toLowerCase();
    const host = legitimate ? this.standInHost : claim.domain;
    const base = [meta('Claimed identity', claim.claimedIdentity), meta('Requesting agent', claim.name)];

    let record: AnsAgentRecord | undefined;
    try {
      record = await this.registry.lookupHost(host);
    } catch {
      return { ...(await this.fallback.verifyAgent(claim)), source: 'simulated' };
    }

    if (!record) {
      return {
        layer: 'identity', status: 'failed', title: 'Verification failed', source: 'live',
        description: `The ANS registry has no agent registered for ${host}, so the requesting agent could not be verified.`,
        metadata: [...base, meta('Domain', claim.domain, 'flagged'), meta('ANS registry', 'No record found', 'flagged')],
      };
    }
    return {
      layer: 'identity', status: 'passed', title: 'Verified', source: 'live',
      description: legitimate
        ? `Verified in the GoDaddy ANS registry: ${record.displayName} (${record.host}) is registered and active. It stands in for ${claim.claimedIdentity}'s own agent, which is not in ANS.`
        : `${record.displayName} is registered and active in the GoDaddy ANS registry.`,
      metadata: [
        ...base,
        meta('ANS host', record.host, 'verified'),
        meta('ANS record', record.ansName),
        meta('Status', record.status, 'verified'),
        ...(record.protocol ? [meta('Protocol', record.protocol)] : []),
        ...(record.registered ? [meta('Registered', record.registered)] : []),
      ],
    };
  }
}
