import { Money, usd } from '../shared/money';
import type { Instant } from '../shared/time';

// MARK: - The three layers

/** Identity → Policy → Financial. The order is the order of evaluation. */
export type Layer = 'identity' | 'policy' | 'financial';
export const layers: Layer[] = ['identity', 'policy', 'financial'];

export const layerTitle = (l: Layer): string => l.toUpperCase();
export const layerNumber = (l: Layer): string => ({ identity: '01', policy: '02', financial: '03' })[l];
export const layerQuestion = (l: Layer): string =>
  ({ identity: 'Is this agent who it claims to be?', policy: 'Is this transaction within your rules?', financial: 'Can the transaction proceed?' })[l];
/** The technology this layer is designed to integrate with. */
export const layerIntegration = (l: Layer): string => ({ identity: 'GoDaddy ANS', policy: 'Artemis policy rules', financial: 'Capital One Nessie' })[l];
export const nextLayer = (l: Layer): Layer | undefined => ({ identity: 'policy', policy: 'financial', financial: undefined } as const)[l];

/** `notReached`: the pipeline stopped before this layer, so it was never evaluated. */
export type LayerStatus = 'passed' | 'failed' | 'notReached';

export type Decision = 'autoApproved' | 'blocked' | 'approvalRequired';
export const decisionLabel = (d: Decision): string => ({ autoApproved: 'AUTO-APPROVED', blocked: 'BLOCKED', approvalRequired: 'APPROVAL REQUIRED' })[d];

export type Resolution = 'approved' | 'rejected';

// MARK: - Verification results

export type Emphasis = 'normal' | 'flagged' | 'verified';

export interface MetadataItem {
  label: string;
  value: string;
  emphasis: Emphasis;
}
export const meta = (label: string, value: string, emphasis: Emphasis = 'normal'): MetadataItem => ({ label, value, emphasis });

/** "$200 × 4 nights = $800 maximum" — the arithmetic behind a policy verdict. */
export interface PolicyCalculation {
  kind: 'flight' | 'hotel';
  /** Per booking (flight) or per night (hotel). */
  limit: Money;
  nights?: number;
  allowed: Money;
  requested: Money;
}
export const calcOver = (c: PolicyCalculation): Money => Math.max(0, c.requested - c.allowed);
export const calcIsOver = (c: PolicyCalculation): boolean => c.requested > c.allowed;
export const calcFormula = (c: PolicyCalculation): string =>
  c.kind === 'hotel' ? `${usd(c.limit)} × ${c.nights ?? 1} nights = ${usd(c.allowed)} maximum` : `${usd(c.allowed)} maximum per booking`;

/** Month-to-date travel spending against the cap. */
export interface CapStatus {
  cap: Money;
  spent: Money;
  requested: Money;
  balance: Money;
}
export const capProjected = (c: CapStatus): Money => c.spent + c.requested;
export const capIsOver = (c: CapStatus): boolean => capProjected(c) > c.cap;
export const capReached = (c: CapStatus): boolean => c.spent >= c.cap;

export interface VerificationResult {
  layer: Layer;
  status: LayerStatus;
  title: string;
  description: string;
  metadata: MetadataItem[];
  calculation?: PolicyCalculation;
  cap?: CapStatus;
  /** Whether this layer was answered by a real service or by the prototype's local stand-in. */
  source?: ServiceSource;
}

/** live: a real service answered. simulated: a local stand-in for a service. device: rules Artemis evaluates itself, on this phone. */
export type ServiceSource = 'live' | 'simulated' | 'device';

export const notReached = (layer: Layer): VerificationResult => ({
  layer, status: 'notReached', title: 'Not evaluated',
  description: 'Not evaluated, because the transaction stopped at an earlier layer.', metadata: [],
});

/** What the later layers would have said if identity had passed. */
export interface Counterfactual {
  policyPassed: boolean;
  financialPassed: boolean;
  policyDetail: string;
  financialDetail: string;
}

/** The decision engine's answer. The single source of truth for the UI. */
export interface EvaluationResult {
  requestID: string;
  decision: Decision;
  /** The first layer that failed, or undefined if all passed. */
  failedAt?: Layer;
  identity: VerificationResult;
  policy: VerificationResult;
  financial: VerificationResult;
  reason: string;
  humanApprovalRequired: boolean;
  counterfactual?: Counterfactual;
}

export const resultFor = (r: EvaluationResult, layer: Layer): VerificationResult => r[layer];

// MARK: - Requests and transactions

export type TransactionKind = 'flight' | 'hotel' | 'other';
export const transactionLabel = (k: TransactionKind): string => ({ flight: 'Flight', hotel: 'Hotel', other: 'Purchase' })[k];

/** Who the agent says it is, and where it is actually calling from. */
export interface AgentClaim {
  name: string;
  claimedIdentity: string;
  domain: string;
}

/** What an AI agent asks Artemis to authorize. It carries no verdict. */
export interface AgentRequest {
  id: string;
  date: Instant;
  agent: AgentClaim;
  /** The provider the agent claims to be booking with. */
  provider: string;
  kind: TransactionKind;
  amount: Money;
  currency: string;
  nights?: number;
  /** How many people the booking is for. Policy compares the per-traveler `amount`; the financial check compares the total. */
  travelers: number;
  detail: string;
}

/** What actually leaves the account. */
export const requestTotal = (r: AgentRequest): Money => r.amount * r.travelers;

export interface FinancialState {
  accountName: string;
  availableBalance: Money;
  monthToDateTravelSpend: Money;
  /** Set when the figures came from a real account (Capital One Nessie) rather than the built-in demo account. */
  source?: 'nessie';
}
