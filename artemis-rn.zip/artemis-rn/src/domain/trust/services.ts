import { Money, usd } from '../shared/money';
import { registeredAgents } from './demoData';
import {
  AgentClaim, AgentRequest, CapStatus, FinancialState, VerificationResult, calcFormula, calcIsOver, calcOver, capIsOver, capProjected,
  capReached, meta, requestTotal, transactionLabel, PolicyCalculation,
} from './models';
import { PolicyAnswers, TrustPolicy, standardPolicy } from './policy';
import { demoAccount } from './demoData';

// MARK: - The three layers, as interfaces
//
// Each layer is an interface so the prototype's mocks can be replaced by real integrations without touching
// the decision engine or any screen:
//
//   IdentityService   — designed to integrate with GoDaddy Agent Name Service (ANS)
//   PolicyService     — evaluates your trust policy on the device
//   FinancialService  — designed to integrate with Capital One Nessie
//
// The local versions below always work offline. Live versions of two layers (ans.ts for identity, nessie.ts for the
// account) can replace them when their keys are configured; each result says whether it was live, simulated or
// evaluated on the device (the policy rules).

export interface IdentityService {
  verifyAgent(claim: AgentClaim): Promise<VerificationResult>;
}

export interface PolicyService {
  evaluateTransaction(request: AgentRequest, policy: TrustPolicy): Promise<VerificationResult>;
  generatePolicy(answers: PolicyAnswers): Promise<TrustPolicy>;
}

export interface FinancialService {
  currentState(request: AgentRequest): Promise<FinancialState>;
  checkTransaction(request: AgentRequest, policy: TrustPolicy, state: FinancialState): Promise<VerificationResult>;
}

/** Artificial delay so the demo's stages are watchable. Zero when testing. */
export interface SimulatedLatency {
  minSeconds: number;
  maxSeconds: number;
}
export const latencyNone: SimulatedLatency = { minSeconds: 0, maxSeconds: 0 };
/** ~500–900ms per stage, as the demo calls for. */
export const latencyDemo: SimulatedLatency = { minSeconds: 0.5, maxSeconds: 0.85 };
/** A short pause so "finding your overlap" reads as work, without stalling tests. */
export const latencyDemoShort: SimulatedLatency = { minSeconds: 0.4, maxSeconds: 0.6 };

export async function waitLatency(l: SimulatedLatency): Promise<void> {
  if (l.maxSeconds <= 0) return;
  const s = l.minSeconds + Math.random() * (l.maxSeconds - l.minSeconds);
  await new Promise<void>((resolve) => setTimeout(resolve, s * 1000));
}

// MARK: - Mock identity (ANS)

export class MockIdentityService implements IdentityService {
  constructor(private latency: SimulatedLatency = latencyNone) {}

  async verifyAgent(claim: AgentClaim): Promise<VerificationResult> {
    await waitLatency(this.latency);
    const record = registeredAgents()[claim.claimedIdentity.toLowerCase()];
    const base = [meta('Claimed identity', claim.claimedIdentity), meta('Requesting agent', claim.name)];

    if (!record) {
      return {
        layer: 'identity', status: 'failed', title: 'Verification failed', description: 'The requesting agent could not be verified.',
        metadata: [...base, meta('Domain', claim.domain, 'flagged')],
      };
    }
    if (claim.domain.toLowerCase() !== record.domain.toLowerCase()) {
      return {
        layer: 'identity', status: 'failed', title: 'Verification failed', description: 'The requesting agent could not be verified.',
        metadata: [...base, meta('Domain', claim.domain, 'flagged'), meta('Verified domain', record.domain, 'verified')],
      };
    }
    return {
      layer: 'identity', status: 'passed', title: 'Verified',
      description: `${claim.name} is a registered agent for ${claim.claimedIdentity}.`,
      metadata: [...base, meta('Domain', claim.domain, 'verified'), meta('Registry record', record.record)],
    };
  }
}

// MARK: - Policy (evaluated on the device)

export class MockPolicyService implements PolicyService {
  constructor(private latency: SimulatedLatency = latencyNone) {}

  async evaluateTransaction(request: AgentRequest, policy: TrustPolicy): Promise<VerificationResult> {
    await waitLatency(this.latency);

    if (request.kind === 'flight') {
      const calc: PolicyCalculation = { kind: 'flight', limit: policy.flightLimit, allowed: policy.flightLimit, requested: request.amount };
      const over = calcIsOver(calc);
      const perTraveler = request.travelers > 1 ? ' per traveler' : '';
      return {
        layer: 'policy', status: over ? 'failed' : 'passed', title: over ? 'Exceeds flight limit' : 'Within limit',
        description: over
          ? `This flight is ${usd(calcOver(calc))}${perTraveler} over your ${usd(policy.flightLimit)} flight limit.`
          : `${usd(request.amount)}${perTraveler} is within your ${usd(policy.flightLimit)} flight limit.`,
        metadata: [meta('Flight limit', `${usd(policy.flightLimit)} per traveler`), meta('Requested', `${usd(request.amount)} per traveler`)],
        calculation: calc,
      };
    }

    if (request.kind === 'hotel') {
      const nights = request.nights ?? 1;
      const allowed = policy.hotelNightlyLimit * nights;
      const calc: PolicyCalculation = { kind: 'hotel', limit: policy.hotelNightlyLimit, nights, allowed, requested: request.amount };
      const over = calcIsOver(calc);
      const md = [meta('Calculation', calcFormula(calc)), meta('Requested', usd(request.amount))];
      if (over) md.push(meta('Over limit', usd(calcOver(calc)), 'flagged'));
      return {
        layer: 'policy', status: over ? 'failed' : 'passed', title: over ? 'Exceeds hotel limit' : 'Within limit',
        description: over
          ? `This transaction exceeds your hotel limit by ${usd(calcOver(calc))}.`
          : `${usd(request.amount)} is within your ${usd(allowed)} maximum for a ${nights}-night stay.`,
        metadata: md, calculation: calc,
      };
    }

    return {
      layer: 'policy', status: 'failed', title: 'Outside travel',
      description: 'This purchase is outside travel, which always requires your approval.',
      metadata: [meta('Category', transactionLabel(request.kind), 'flagged')],
    };
  }

  async generatePolicy(answers: PolicyAnswers): Promise<TrustPolicy> {
    await waitLatency(this.latency);
    return { ...standardPolicy(), flightLimit: answers.flightLimit, hotelNightlyLimit: answers.hotelNightlyLimit, escalateNonTravel: answers.escalateNonTravel };
  }
}

// MARK: - Mock financial (Nessie)

export class MockFinancialService implements FinancialService {
  constructor(private latency: SimulatedLatency = latencyNone) {}

  async currentState(_request: AgentRequest): Promise<FinancialState> {
    return demoAccount();
  }

  async checkTransaction(request: AgentRequest, policy: TrustPolicy, state: FinancialState): Promise<VerificationResult> {
    const result = await this.evaluate(request, policy, state);
    const live = state.source === 'nessie';
    return {
      ...result,
      source: live ? 'live' : 'simulated',
      metadata: live ? [meta('Account', `${state.accountName} · Capital One Nessie`, 'verified'), ...result.metadata] : result.metadata,
    };
  }

  private async evaluate(request: AgentRequest, policy: TrustPolicy, state: FinancialState): Promise<VerificationResult> {
    await waitLatency(this.latency);
    const total: Money = requestTotal(request);
    const cap: CapStatus = { cap: policy.monthlyTravelLimit, spent: state.monthToDateTravelSpend, requested: total, balance: state.availableBalance };
    const fundsOK = state.availableBalance >= total;
    const capOK = !capIsOver(cap);

    const md = [
      meta('Available balance', usd(state.availableBalance)),
      meta('Monthly travel', `${usd(cap.spent)} of ${usd(cap.cap)}`, capOK ? 'normal' : 'flagged'),
      meta('With this booking', usd(capProjected(cap)), capOK ? 'normal' : 'flagged'),
    ];

    if (!fundsOK) {
      return {
        layer: 'financial', status: 'failed', title: 'Insufficient funds',
        description: `Available balance of ${usd(state.availableBalance)} is below the ${usd(total)} requested.`, metadata: md, cap,
      };
    }
    if (!capOK) {
      return {
        layer: 'financial', status: 'failed', title: 'Monthly cap reached',
        description: capReached(cap)
          ? 'Monthly travel spending cap reached.'
          : `This would bring monthly travel spending to ${usd(capProjected(cap))}, over your ${usd(cap.cap)} cap.`,
        metadata: md, cap,
      };
    }
    return {
      layer: 'financial', status: 'passed', title: 'Clear',
      description: `Funds are available and this stays within your ${usd(cap.cap)} monthly travel cap.`, metadata: md, cap,
    };
  }
}

// MARK: - Financial, from a real account

/** The same rules as the mock, applied to the balance and spend read from a real account. */
export class LedgerFinancialService extends MockFinancialService {
  constructor(
    private readonly ledger: { state(): Promise<FinancialState> },
    /** What to use when the bank cannot be reached. */
    private readonly cached: () => FinancialState,
    latency: SimulatedLatency = latencyNone,
  ) {
    super(latency);
  }

  override async currentState(_request: AgentRequest): Promise<FinancialState> {
    try {
      return await this.ledger.state();
    } catch {
      const { source: _live, ...state } = this.cached();
      return state;
    }
  }
}
