export interface Traveler {
  id: string;
  firstName: string;
  lastName: string;
  isYou: boolean;
  /** Which brand tint the avatar uses. An index so the model has no UI dependency. */
  tint: number;
}

const t = (id: string, firstName: string, lastName: string, tint: number, isYou = false): Traveler => ({ id, firstName, lastName, isYou, tint });

const maria = t('maria', 'Maria', 'Luiza', 0, true);
const sofia = t('sofia', 'Sofia', 'Costa', 1);
const lucas = t('lucas', 'Lucas', 'Pereira', 2);
const ana = t('ana', 'Ana', 'Ribeiro', 3);

export const Travelers = { maria, sofia, lucas, ana, demoFriends: [sofia, lucas, ana] as Traveler[] };

export const fullName = (v: Traveler): string => `${v.firstName} ${v.lastName}`;
export const initials = (v: Traveler): string => `${v.firstName.charAt(0)}${v.lastName.charAt(0)}`.toUpperCase();
/** "You" for the current user, otherwise the first name. Used in sentences. */
export const voice = (v: Traveler): string => (v.isYou ? 'You' : v.firstName);
/** Possessive form used in sentences: "Your" / "Sofia's". */
export const possessive = (v: Traveler): string => (v.isYou ? 'Your' : `${v.firstName}'s`);
