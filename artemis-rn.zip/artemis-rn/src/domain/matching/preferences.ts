import type { Money } from '../shared/money';

// MARK: - How much a preference matters

/** Artemis never averages preferences. Each is a MUST HAVE, a PREFERRED, or a NICE TO HAVE. */
export type Strength = 'nice' | 'preferred' | 'must';

const STRENGTH_RANK: Record<Strength, number> = { nice: 0, preferred: 1, must: 2 };
export const strengthRank = (s: Strength): number => STRENGTH_RANK[s];
export const strongerThan = (a: Strength, b: Strength): boolean => STRENGTH_RANK[a] > STRENGTH_RANK[b];
export const maxStrength = (list: Strength[]): Strength | undefined =>
  list.reduce<Strength | undefined>((best, s) => (best === undefined || strongerThan(s, best) ? s : best), undefined);

export const strengthLabel = (s: Strength): string => ({ must: 'MUST HAVE', preferred: 'PREFERRED', nice: 'NICE TO HAVE' })[s];
export const strengthShort = (s: Strength): string => ({ must: 'Must', preferred: 'Prefer', nice: 'Nice' })[s];
export const nextStrength = (s: Strength): Strength => ({ must: 'preferred', preferred: 'nice', nice: 'must' } as const)[s];

export type PreferenceField = 'flightBudget' | 'hotelBudget' | 'departureWindow' | 'maxStops' | 'hotelStyle' | 'location';

export interface FieldStrengths {
  flightBudget: Strength;
  hotelBudget: Strength;
  departureWindow: Strength;
  maxStops: Strength;
  hotelStyle: Strength;
  location: Strength;
}

export const defaultStrengths = (): FieldStrengths => ({
  flightBudget: 'must', hotelBudget: 'must', departureWindow: 'preferred', maxStops: 'preferred', hotelStyle: 'nice', location: 'preferred',
});

// MARK: - Values

export type HotelStyle = 'boutique' | 'modern' | 'classic' | 'luxury';
export const hotelStyles: HotelStyle[] = ['boutique', 'modern', 'classic', 'luxury'];
export const hotelStyleLabel = (s: HotelStyle): string => s.charAt(0).toUpperCase() + s.slice(1);

export type LocationPreference = 'central' | 'quiet' | 'transit';
export const locationPreferences: LocationPreference[] = ['central', 'quiet', 'transit'];
export const locationLabel = (l: LocationPreference): string => ({ central: 'Central', quiet: 'Quiet', transit: 'Near transit' })[l];

/** When someone is happy to depart, as whole hours of the day (0…24). */
export interface DepartureWindow {
  startHour: number;
  endHour: number;
}

export const anyTime: DepartureWindow = { startHour: 0, endHour: 24 };
export const sameWindow = (a: DepartureWindow, b: DepartureWindow): boolean => a.startHour === b.startHour && a.endHour === b.endHour;
export const windowContains = (w: DepartureWindow, minuteOfDay: number): boolean => minuteOfDay >= w.startHour * 60 && minuteOfDay <= w.endHour * 60;

export function windowIntersection(a: DepartureWindow, b: DepartureWindow): DepartureWindow | undefined {
  const s = Math.max(a.startHour, b.startHour);
  const e = Math.min(a.endHour, b.endHour);
  return s < e ? { startHour: s, endHour: e } : undefined;
}

export function hourLabel(h: number): string {
  const hh = ((h % 24) + 24) % 24;
  if (hh === 0) return '12 AM';
  if (hh === 12) return '12 PM';
  return hh < 12 ? `${hh} AM` : `${hh - 12} PM`;
}

/** "Any time", "After 10 AM", "10 AM–6 PM" */
export function windowLabel(w: DepartureWindow): string {
  if (w.startHour <= 0 && w.endHour >= 24) return 'Any time';
  if (w.endHour >= 24) return `After ${hourLabel(w.startHour)}`;
  if (w.startHour <= 0) return `Before ${hourLabel(w.endHour)}`;
  return `${hourLabel(w.startHour)}–${hourLabel(w.endHour)}`;
}

/** How much each dimension matters to one traveler, 1 (barely) … 5 (most). */
export interface PriorityWeights {
  price: number;
  flightTime: number;
  hotel: number;
}

/** The dimension this traveler cares about most, in words. */
export function topPriority(p: PriorityWeights): string {
  const pairs: [string, number][] = [['price', p.price], ['flight time', p.flightTime], ['the hotel', p.hotel]];
  // Swift's max(by:) keeps the first of equal maxima.
  return pairs.reduce((best, cur) => (cur[1] > best[1] ? cur : best))[0];
}

export interface TravelPreferences {
  /** Per traveler, one way. */
  flightBudget: Money;
  /** Per night. */
  hotelBudget: Money;
  departureWindow: DepartureWindow;
  maxStops: number;
  hotelStyle: HotelStyle;
  location: LocationPreference;
  priorities: PriorityWeights;
  strengths: FieldStrengths;
  preferredAirlines: string[];
}

/** A traveler who says "0 stops" is asking for nonstop. */
export const wantsNonstop = (p: TravelPreferences): boolean => p.maxStops === 0;

export const defaultPreferences = (): TravelPreferences => ({
  flightBudget: 600, hotelBudget: 200, departureWindow: { ...anyTime }, maxStops: 1, hotelStyle: 'boutique', location: 'central',
  priorities: { price: 3, flightTime: 3, hotel: 3 }, strengths: defaultStrengths(), preferredAirlines: [],
});

/** Maria's standing preferences: price first, happy with one stop, later departures. */
export const mariaDemo = (): TravelPreferences => ({
  flightBudget: 600, hotelBudget: 200, departureWindow: { startHour: 10, endHour: 24 }, maxStops: 1, hotelStyle: 'boutique', location: 'central',
  priorities: { price: 5, flightTime: 4, hotel: 3 },
  strengths: { flightBudget: 'must', hotelBudget: 'must', departureWindow: 'preferred', maxStops: 'must', hotelStyle: 'nice', location: 'preferred' },
  preferredAirlines: ['TAP Air Portugal'],
});

/** Sofia's: nonstop, central, a little more to spend. */
export const sofiaDemo = (): TravelPreferences => ({
  flightBudget: 800, hotelBudget: 250, departureWindow: { ...anyTime }, maxStops: 0, hotelStyle: 'modern', location: 'central',
  priorities: { price: 3, flightTime: 5, hotel: 4 },
  strengths: { flightBudget: 'must', hotelBudget: 'must', departureWindow: 'preferred', maxStops: 'preferred', hotelStyle: 'nice', location: 'must' },
  preferredAirlines: ['ITA Airways'],
});

export const friendDefault = (): TravelPreferences => ({
  flightBudget: 700, hotelBudget: 220, departureWindow: { ...anyTime }, maxStops: 1, hotelStyle: 'modern', location: 'central',
  priorities: { price: 3, flightTime: 4, hotel: 3 }, strengths: defaultStrengths(), preferredAirlines: [],
});

/** A traveler's standing profile: the defaults Artemis starts every trip from. */
export interface TravelStyleProfile {
  styles: string[];
  flightPreference: string;
  hotelPreference: string;
  budgetLevel: string;
  favoriteAirports: string[];
  preferredAirlines: string[];
}

export const mariaProfile = (): TravelStyleProfile => ({
  styles: ['Culture', 'Food', 'Architecture'], flightPreference: 'Shorter flights', hotelPreference: 'Boutique · Central',
  budgetLevel: 'Moderate', favoriteAirports: ['GIG', 'LIS', 'FCO'], preferredAirlines: ['TAP Air Portugal', 'ITA Airways'],
});

export const sofiaProfile = (): TravelStyleProfile => ({
  styles: ['Nightlife', 'Food', 'Shopping'], flightPreference: 'Nonstop', hotelPreference: 'Modern · Central',
  budgetLevel: 'Flexible', favoriteAirports: ['GIG', 'MAD'], preferredAirlines: ['ITA Airways'],
});
