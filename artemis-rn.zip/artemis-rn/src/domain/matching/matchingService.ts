import { Money, usd } from '../shared/money';
import { Seconds, hoursMinutes } from '../shared/time';
import { HotelOption } from '../destinations/hotels';
import {
  FlightOption, departureLocal, departureMinuteOfDay, flightDuration, flightStops, layovers, stopsLabel,
} from '../trips/flights';
import type { GroupDecision } from '../trips/trip';
import {
  DepartureWindow, HotelStyle, LocationPreference, PreferenceField, Strength, TravelPreferences, hotelStyleLabel, locationLabel, maxStrength,
  sameWindow, strengthRank, strongerThan, topPriority, wantsNonstop, windowContains, windowIntersection, windowLabel,
} from './preferences';
import { Traveler, possessive, voice } from './traveler';

// MARK: - Inputs and outputs

/** One traveler's submitted preferences. */
export interface TravelerPreferences {
  traveler: Traveler;
  preferences: TravelPreferences;
}

/** A single line of the overlap: what the group agrees on, and how firmly. */
export interface SharedConstraint {
  field: PreferenceField;
  strength: Strength;
  title: string;
  value: string;
  /** Where it came from, in plain words. */
  detail: string;
}

export interface PreferenceConflict {
  id: string;
  title: string;
  detail: string;
}

/** Everything the group's preferences add up to. */
export interface SharedProfile {
  flightBudget: Money;
  flightBudgetStrength: Strength;
  hotelBudget: Money;
  hotelBudgetStrength: Strength;
  /** undefined when the travelers' windows never overlap. */
  window?: DepartureWindow;
  windowStrength: Strength;
  /** Nonstop is fine for everyone; this is what people would choose if they could. */
  stopsPreferred: number;
  /** The most stops anyone can accept. */
  stopsAcceptable: number;
  location?: LocationPreference;
  locationStrength: Strength;
  hotelStyles: HotelStyle[];
  constraints: SharedConstraint[];
  conflicts: PreferenceConflict[];
  /** False when travelers chose different departure windows / hotel styles — the difference is "flexible". */
  windowsIdentical: boolean;
  stylesIdentical: boolean;
  /** How many travelers' preferences this profile combines. 1 = a solo trip. */
  travelerCount: number;
}

export interface MatchReason {
  kind: 'met' | 'partial' | 'unmet';
  text: string;
}

export interface GroupMatch {
  percent: number;
  reasons: MatchReason[];
  /** Each traveler's own satisfaction, 0–100. */
  perTraveler: Record<string, number>;
  /** Set when the option breaks a MUST HAVE. */
  violation?: string;
}
export const isWithinConstraints = (m: GroupMatch): boolean => m.violation === undefined;

export interface ScoredFlight {
  option: FlightOption;
  match: GroupMatch;
}

export interface ScoredHotel {
  hotel: HotelOption;
  percent: number;
  reasons: MatchReason[];
}

export interface GroupOrderEntry {
  optionID: string;
  points: number;
  /** True when this option is ahead of the one below it only because of its group match score. */
  brokenByMatch: boolean;
}

// MARK: - Service

const clamp = (x: number): number => Math.min(1, Math.max(0, x));
/** Swift's `min(by:)` returns the first of equal minima. */
const firstMin = <T>(list: T[], key: (t: T) => number): T | undefined =>
  list.reduce<T | undefined>((best, cur) => (best === undefined || key(cur) < key(best) ? cur : best), undefined);
const yourOr = (t: Traveler): string => (possessive(t).toLowerCase() === 'your' ? 'your' : possessive(t));

/**
 * The group preference engine. It never averages: it finds what is shared, what is preferred, and
 * what is a real conflict — then explains every score.
 */
export class TripMatchingService {
  // MARK: Combine

  combinePreferences(inputs: TravelerPreferences[]): SharedProfile {
    if (inputs.length === 0) throw new Error('Need at least one traveler');
    const strongest = (f: PreferenceField): Strength => maxStrength(inputs.map((i) => i.preferences.strengths[f])) ?? 'preferred';
    const lowest = (pick: (p: TravelPreferences) => Money): { value: Money; owner?: Traveler } => {
      const minValue = Math.min(...inputs.map((i) => pick(i.preferences)));
      const owners = inputs.filter((i) => pick(i.preferences) === minValue);
      return { value: minValue, owner: owners.length === inputs.length ? undefined : owners[0]?.traveler };
    };

    const solo = inputs.length === 1;
    const constraints: SharedConstraint[] = [];
    const conflicts: PreferenceConflict[] = [];

    // Flight budget — the lowest limit binds.
    const fb = lowest((p) => p.flightBudget);
    constraints.push({
      field: 'flightBudget', strength: strongest('flightBudget'), title: 'Flight budget', value: `≤ ${usd(fb.value)}`,
      detail: fb.owner ? `${possessive(fb.owner)} limit is lower, so it becomes the shared cap.` : solo ? 'Your limit.' : 'You all set the same limit.',
    });

    // Stops — the lower ask is the preference; the higher tolerance is what's acceptable.
    const stopsPreferred = Math.min(...inputs.map((i) => i.preferences.maxStops));
    const mustCaps = inputs.filter((i) => i.preferences.strengths.maxStops === 'must').map((i) => i.preferences.maxStops);
    let stopsAcceptable = mustCaps.length > 0 ? Math.min(...mustCaps) : Math.max(...inputs.map((i) => i.preferences.maxStops));
    stopsAcceptable = Math.max(stopsAcceptable, stopsPreferred);
    let stopsValue: string;
    let stopsDetail: string;
    if (stopsPreferred === stopsAcceptable) {
      stopsValue = stopsPreferred === 0 ? 'Nonstop only' : `Up to ${stopsPreferred} stop${stopsPreferred === 1 ? '' : 's'}`;
      stopsDetail = solo ? 'Your call.' : 'Everyone agrees.';
    } else {
      const fans = inputs.filter((i) => wantsNonstop(i.preferences)).map((i) => i.traveler);
      const fanNames = fans.map(voice).join(' & ');
      stopsValue = `${stopsPreferred} preferred · up to ${stopsAcceptable} acceptable`;
      stopsDetail = fans.length === 0
        ? `Nonstop is the better fit, but ${stopsAcceptable} stop${stopsAcceptable === 1 ? ' is' : 's are'} acceptable.`
        : `${fanNames} prefer${fans.length === 1 && !fans[0].isYou ? 's' : ''} nonstop; the rest of you can do ${stopsAcceptable} stop${stopsAcceptable === 1 ? '' : 's'}.`;
    }
    constraints.push({ field: 'maxStops', strength: strongest('maxStops'), title: 'Stops', value: stopsValue, detail: stopsDetail });

    // Departure window — the intersection, if there is one.
    let window: DepartureWindow | undefined = inputs[0].preferences.departureWindow;
    for (const i of inputs.slice(1)) window = window && windowIntersection(window, i.preferences.departureWindow);
    if (window) {
      const w = window;
      const same = inputs.map((i) => i.preferences.departureWindow).every((x) => sameWindow(x, w));
      constraints.push({
        field: 'departureWindow', strength: strongest('departureWindow'), title: 'Departure', value: windowLabel(w),
        detail: solo ? 'Your window.' : same ? 'You all chose the same window.' : 'Where your departure windows overlap.',
      });
    } else {
      conflicts.push({
        id: 'window', title: "Departure times don't overlap",
        detail: inputs.map((i) => `${possessive(i.traveler)} window: ${windowLabel(i.preferences.departureWindow)}`).join(' · '),
      });
    }

    // Hotel budget
    const hb = lowest((p) => p.hotelBudget);
    constraints.push({
      field: 'hotelBudget', strength: strongest('hotelBudget'), title: 'Hotel budget', value: `≤ ${usd(hb.value)}/night`,
      detail: hb.owner ? `${possessive(hb.owner)} limit is lower, so it becomes the shared cap.` : solo ? 'Your limit.' : 'You all set the same limit.',
    });

    // Location
    const locations = new Set(inputs.map((i) => i.preferences.location));
    let location: LocationPreference | undefined;
    if (locations.size === 1) {
      location = [...locations][0];
      constraints.push({ field: 'location', strength: strongest('location'), title: 'Location', value: locationLabel(location), detail: solo ? 'Your area.' : 'You all want the same area.' });
    } else {
      // The firmer ask wins; if they are equally firm, it is a real conflict.
      const ranked = [...inputs].sort((a, b) => strengthRank(b.preferences.strengths.location) - strengthRank(a.preferences.strengths.location));
      if (strongerThan(ranked[0].preferences.strengths.location, ranked[1].preferences.strengths.location)) {
        location = ranked[0].preferences.location;
        constraints.push({
          field: 'location', strength: ranked[0].preferences.strengths.location, title: 'Location', value: locationLabel(location),
          detail: `${possessive(ranked[0].traveler)} firmer ask.`,
        });
      } else {
        conflicts.push({
          id: 'location', title: 'Different areas',
          detail: inputs.map((i) => `${voice(i.traveler)}: ${locationLabel(i.preferences.location)}`).join(' · '),
        });
      }
    }

    // Style — never a hard rule.
    const styles: HotelStyle[] = [];
    for (const i of inputs) if (!styles.includes(i.preferences.hotelStyle)) styles.push(i.preferences.hotelStyle);
    constraints.push({
      field: 'hotelStyle', strength: 'nice', title: 'Hotel style', value: styles.map(hotelStyleLabel).join(' or '),
      detail: styles.length > 1 ? 'Different tastes, so either works.' : solo ? 'Your taste.' : 'You agree.',
    });

    const windows = inputs.map((i) => i.preferences.departureWindow);
    return {
      flightBudget: fb.value, flightBudgetStrength: strongest('flightBudget'),
      hotelBudget: hb.value, hotelBudgetStrength: strongest('hotelBudget'),
      window, windowStrength: strongest('departureWindow'),
      stopsPreferred, stopsAcceptable,
      location, locationStrength: strongest('location'),
      hotelStyles: styles, constraints, conflicts,
      windowsIdentical: windows.every((w) => sameWindow(w, windows[0])),
      stylesIdentical: styles.length === 1,
      travelerCount: inputs.length,
    };
  }

  // MARK: Flights

  /**
   * Scores every option. Options inside the shared constraints come first (best match first);
   * options that break a MUST HAVE come back separately, so the UI can show them honestly.
   */
  recommendFlights(
    options: FlightOption[], profile: SharedProfile, inputs: TravelerPreferences[], hotel?: HotelOption,
  ): { matches: ScoredFlight[]; outside: ScoredFlight[] } {
    const durations = options.map(flightDuration);
    const shortest = durations.length ? Math.min(...durations) : 0;
    const longest = durations.length ? Math.max(...durations) : 0;
    const cheapest = options.length ? Math.min(...options.map((o) => o.farePerTraveler)) : 0;

    const scored = options.map<ScoredFlight>((option) => ({
      option, match: this.evaluate(option, profile, inputs, hotel, shortest, longest, cheapest, options),
    }));
    const byPercent = (a: ScoredFlight, b: ScoredFlight) => b.match.percent - a.match.percent;
    return {
      matches: scored.filter((s) => isWithinConstraints(s.match)).sort(byPercent),
      outside: scored.filter((s) => !isWithinConstraints(s.match)).sort(byPercent),
    };
  }

  evaluate(
    option: FlightOption, profile: SharedProfile, inputs: TravelerPreferences[], hotel: HotelOption | undefined,
    shortest: Seconds, longest: Seconds, cheapest: Money, peers: FlightOption[],
  ): GroupMatch {
    const duration = flightDuration(option);
    const stops = flightStops(option);
    const minute = departureMinuteOfDay(option);

    // 1 ─ Does it break a MUST HAVE?
    let violation: string | undefined;
    if (option.farePerTraveler > profile.flightBudget && profile.flightBudgetStrength === 'must') {
      const over = option.farePerTraveler - profile.flightBudget;
      const owner = firstMin(inputs, (i) => i.preferences.flightBudget)?.traveler;
      violation = `${usd(over)} over ${owner ? yourOr(owner) : 'the'} ${usd(profile.flightBudget)} limit`;
    } else if (stops > profile.stopsAcceptable) {
      violation = `${stops} stops is more than anyone will accept`;
    } else if (profile.window && profile.windowStrength === 'must' && !windowContains(profile.window, minute)) {
      violation = "Departs outside everyone's window";
    }

    // 2 ─ How happy is each traveler?
    const perTraveler: Record<string, number> = {};
    const scores: number[] = [];
    for (const input of inputs) {
      const s = this.satisfaction(option, input.preferences, profile, shortest, longest, cheapest);
      scores.push(s);
      perTraveler[input.traveler.id] = Math.round(s * 100);
    }
    // A group is only as happy as its least happy member, so weight the minimum heavily.
    const mean = scores.reduce((a, b) => a + b, 0) / Math.max(1, scores.length);
    const group = 0.5 * mean + 0.5 * (scores.length ? Math.min(...scores) : 0);
    let percent = Math.round(FLOOR + SCALE * group);
    if (violation !== undefined) percent -= 22;
    percent = Math.min(99, Math.max(1, percent));

    // 3 ─ Say why.
    const reasons: MatchReason[] = [];
    const multi = inputs.length > 1;
    const priceOwner = firstMin(inputs, (i) => i.preferences.flightBudget)?.traveler;

    if (option.farePerTraveler <= profile.flightBudget) {
      const under = profile.flightBudget - option.farePerTraveler;
      reasons.push({ kind: 'met', text: multi ? 'Within both budgets' : 'Within your budget' });
      if (priceOwner && under > 0 && multi) {
        reasons.push({ kind: 'met', text: `${usd(under)} under ${yourOr(priceOwner)} ${usd(profile.flightBudget)} limit` });
      }
    } else {
      reasons.push({ kind: 'unmet', text: violation ?? 'Over the shared budget' });
    }

    if (profile.window) {
      if (windowContains(profile.window, minute)) {
        reasons.push({ kind: 'met', text: multi ? 'Fits both departure windows' : 'Fits your departure window' });
      } else {
        reasons.push({ kind: 'partial', text: `Departs ${departureLocal(option)} — outside ${windowLabel(profile.window).toLowerCase()}` });
      }
    }

    const nonstopFans = inputs.filter((i) => wantsNonstop(i.preferences)).map((i) => i.traveler);
    if (stops === 0) {
      if (nonstopFans.length > 0) {
        reasons.push({ kind: 'met', text: nonstopFans.length > 1 ? 'Nonstop, as you both prefer' : `Nonstop — ${yourOr(nonstopFans[0])} preference` });
      } else {
        reasons.push({ kind: 'met', text: 'Nonstop' });
      }
    } else if (nonstopFans.length > 0 && (multi || nonstopFans[0].isYou)) {
      const fan = nonstopFans[0];
      const others = inputs.filter((i) => !wantsNonstop(i.preferences)).map((i) => i.traveler);
      let tail: string;
      if (others.length === 0) tail = '';
      else if (others.length === 1 && others[0].isYou) tail = ", you're fine with it";
      else tail = `, ${others.map((o) => o.firstName).join(' & ')} ${others.length === 1 ? 'is' : 'are'} fine with it`;
      reasons.push({ kind: 'partial', text: `${stopsLabel(option)} — ${fan.isYou ? 'you prefer' : `${fan.firstName} prefers`} nonstop${tail}` });
    } else {
      reasons.push({ kind: 'met', text: `${stopsLabel(option)} — within what ${multi ? 'everyone' : 'you'} accept${multi ? 's' : ''}` });
    }

    if (duration === shortest && peers.length > 1) {
      reasons.push({ kind: 'met', text: `Shortest journey · ${hoursMinutes(duration)}` });
    } else if (duration === longest && peers.length > 2 && longest - shortest > 3 * 3600) {
      reasons.push({ kind: 'partial', text: `Longest journey · ${hoursMinutes(duration)}` });
    }
    if (option.farePerTraveler === cheapest && peers.length > 1) {
      reasons.push({ kind: 'met', text: 'Lowest fare of your options' });
    }
    if (hotel && hotel.location === 'central') {
      reasons.push({ kind: 'met', text: multi ? 'Central hotel fits both budgets' : 'Central hotel fits your budget' });
    }

    return { percent, reasons, perTraveler, violation };
  }

  private satisfaction(
    option: FlightOption, prefs: TravelPreferences, profile: SharedProfile, shortest: Seconds, longest: Seconds, cheapest: Money,
  ): number {
    // Price: how far above the cheapest option it sits, as a share of the room left under the shared budget.
    const room = Math.max(1, profile.flightBudget - cheapest);
    const extra = option.farePerTraveler - cheapest;
    const priceC = clamp(1 - (1.1 * extra) / room);

    // Time: is it inside my window, and how long is the journey compared with the best on offer?
    const m = departureMinuteOfDay(option);
    const w = prefs.departureWindow;
    const hoursOutside = m < w.startHour * 60 ? (w.startHour * 60 - m) / 60 : m > w.endHour * 60 ? (m - w.endHour * 60) / 60 : 0;
    const windowC = clamp(1 - 0.2 * hoursOutside);
    const spread = Math.max(1, longest - shortest);
    const durationC = clamp(1 - (1.0 * (flightDuration(option) - shortest)) / spread);
    const timeC = 0.4 * windowC + 0.6 * durationC;

    // Comfort: fewer stops, especially for someone who asked for nonstop.
    // A long wait between planes counts against it: 12% for every hour beyond three.
    const stops = flightStops(option);
    const longestLayover = Math.max(0, ...layovers(option).map((l) => l.duration));
    const layoverPenalty = 0.12 * Math.max(0, longestLayover / 3600 - 3);
    const stopsC = stops === 0 ? 1 : Math.max(0, (wantsNonstop(prefs) ? 0.55 : 0.88) - 0.2 * Math.max(0, stops - 1) - layoverPenalty);

    const wPrice = prefs.priorities.price;
    const wTime = prefs.priorities.flightTime;
    const wStops = wantsNonstop(prefs) ? 4.0 : 2.0;
    return (wPrice * priceC + wTime * timeC + wStops * stopsC) / (wPrice + wTime + wStops);
  }

  // MARK: Hotel

  recommendHotel(hotels: HotelOption[], profile: SharedProfile, _nights: number): ScoredHotel | undefined {
    const candidates = hotels.filter((h) => {
      if (h.nightlyRate > profile.hotelBudget && profile.hotelBudgetStrength === 'must') return false;
      if (profile.location && profile.locationStrength === 'must' && h.location !== profile.location) return false;
      return true;
    });
    const scored = candidates.map<ScoredHotel>((h) => {
      let pts = 70;
      const reasons: MatchReason[] = [];
      if (h.nightlyRate <= profile.hotelBudget) {
        pts += 8;
        reasons.push({ kind: 'met', text: `${usd(h.nightlyRate)}/night, under ${profile.travelerCount > 1 ? 'the' : 'your'} ${usd(profile.hotelBudget)}${profile.travelerCount > 1 ? ' shared' : ''} limit` });
      }
      if (profile.location) {
        if (h.location === profile.location) { pts += 8; reasons.push({ kind: 'met', text: `${locationLabel(profile.location)} location` }); }
        else reasons.push({ kind: 'partial', text: `${locationLabel(h.location)}, not ${locationLabel(profile.location).toLowerCase()}` });
      }
      if (profile.hotelStyles.includes(h.style)) {
        pts += profile.hotelStyles.length > 1 ? 6 : 8;
        reasons.push({ kind: 'met', text: `${hotelStyleLabel(h.style)} style` });
      }
      pts += (h.rating - 4) * 5;
      return { hotel: h, percent: Math.min(99, Math.round(pts)), reasons };
    });
    return scored.reduce<ScoredHotel | undefined>((best, cur) => (best === undefined || cur.percent > best.percent ? cur : best), undefined);
  }

  // MARK: Ranking

  /** Borda count over everyone's rankings. Ties go to the better group match, and are labelled as such. */
  groupOrder(rankings: Record<string, string[]>, scored: ScoredFlight[]): GroupOrderEntry[] {
    const ids = scored.map((s) => s.option.id);
    const points: Record<string, number> = Object.fromEntries(ids.map((id) => [id, 0]));
    for (const order of Object.values(rankings)) {
      order.forEach((id, i) => { if (id in points) points[id] += ids.length - i; });
    }
    const percent: Record<string, number> = Object.fromEntries(scored.map((s) => [s.option.id, s.match.percent]));
    const sorted = [...ids].sort((a, b) => {
      if (points[a] !== points[b]) return points[b] - points[a];
      if (percent[a] !== percent[b]) return percent[b] - percent[a];
      return a < b ? -1 : a > b ? 1 : 0;
    });
    return sorted.map((id, i) => {
      const next = i + 1 < sorted.length ? sorted[i + 1] : undefined;
      return { optionID: id, points: points[id], brokenByMatch: next !== undefined ? points[next] === points[id] : false };
    });
  }

  /** Either a clear match, or a trade-off the travelers have to weigh themselves. */
  decide(
    order: GroupOrderEntry[], rankings: Record<string, string[]>, scored: ScoredFlight[], travelers: Traveler[], inputs: TravelerPreferences[],
  ): GroupDecision | undefined {
    const top = order[0];
    const topOption = top && scored.find((s) => s.option.id === top.optionID);
    if (!top || !topOption) return undefined;
    const names = new Map(travelers.map((t) => [t.id, t]));
    const sortedRankings = Object.entries(rankings).sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));

    // Aligned: everyone put the leading option in their top two, and it is a strong match.
    const everyoneTopTwo = Object.values(rankings).every((r) => {
      const idx = r.indexOf(top.optionID);
      return (idx === -1 ? 99 : idx) <= 1;
    });
    if (everyoneTopTwo && topOption.match.percent >= 80) {
      const solo = Object.keys(rankings).length === 1;
      const lines = solo
        ? ["It's at the top of your list.", `${topOption.match.percent}% match — every MUST HAVE is met.`]
        : ['Everyone ranked it in their top two.', `${topOption.match.percent}% group match — every MUST HAVE is met.`];
      if (!solo && top.brokenByMatch) lines.splice(1, 0, 'You were level on points, so the stronger group match came first.');
      return { kind: 'aligned', primaryOptionID: top.optionID, headline: 'ARTEMIS FOUND A MATCH', explanation: lines };
    }

    // Trade-off: the two options people actually want most.
    const firsts: string[] = [];
    for (const [, ranking] of sortedRankings) if (ranking[0] !== undefined && !firsts.includes(ranking[0])) firsts.push(ranking[0]);
    const pos = (id: string) => { const i = order.findIndex((o) => o.optionID === id); return i === -1 ? 99 : i; };
    const ranked = [...firsts].sort((a, b) => pos(a) - pos(b));
    const a = ranked.length >= 2 ? scored.find((s) => s.option.id === ranked[0]) : undefined;
    const b = ranked.length >= 2 ? scored.find((s) => s.option.id === ranked[1]) : undefined;
    if (!a || !b) {
      return { kind: 'aligned', primaryOptionID: top.optionID, headline: 'ARTEMIS FOUND A MATCH', explanation: [`${topOption.match.percent}% group match.`] };
    }
    const lines: string[] = [];
    for (const [id, ranking] of sortedRankings) {
      const who = names.get(id);
      const first = ranking[0];
      const opt = first !== undefined ? scored.find((s) => s.option.id === first) : undefined;
      if (!who || !opt) continue;
      const prefs = inputs.find((i) => i.traveler.id === id)?.preferences;
      lines.push(`${voice(who)} ranked ${opt.option.shortName} first — ${prefs ? `${topPriority(prefs.priorities)} comes first` : 'your call'}.`);
    }
    const cheaper = a.option.farePerTraveler <= b.option.farePerTraveler ? a : b;
    const faster = cheaper.option.id === a.option.id ? b : a;
    const saved = faster.option.farePerTraveler - cheaper.option.farePerTraveler;
    lines.push(
      `${cheaper.option.shortName} saves ${usd(saved)} each; ${faster.option.shortName} is ${hoursMinutes(flightDuration(cheaper.option) - flightDuration(faster.option))} shorter${flightStops(faster.option) < flightStops(cheaper.option) ? ' and has fewer stops' : ''}.`,
    );
    lines.push("Artemis won't choose for you — this one is yours to weigh.");
    return { kind: 'tradeoff', primaryOptionID: faster.option.id, alternativeOptionID: cheaper.option.id, headline: 'ARTEMIS FOUND A TRADE-OFF', explanation: lines };
  }
}

/**
 * Shortlisted options already satisfy every MUST HAVE, so the percentage measures how well they meet the softer
 * preferences, on a scale where "no trade-offs at all" tops out near 100.
 */
const FLOOR = 38.1;
const SCALE = 86.3;

// MARK: - How the overlap reads

export type Agreement = 'shared' | 'flexible' | 'conflict';
const AGREEMENT_ORDER: Record<Agreement, number> = { shared: 0, flexible: 1, conflict: 2 };
export const agreementLabel = (a: Agreement): string => ({ shared: 'SHARED', flexible: 'FLEXIBLE', conflict: 'CONFLICT' })[a];
export const agreementCaption = (a: Agreement): string =>
  ({ shared: 'You all want this', flexible: 'One of you cares more', conflict: 'You want different things' })[a];

export interface OverlapRow {
  id: string;
  agreement: Agreement;
  strength: Strength;
  title: string;
  value: string;
  detail: string;
}

/**
 * The overlap as a list a person can read: SHARED, FLEXIBLE, then any CONFLICT — each row still carrying how firmly
 * it is held (MUST HAVE / PREFERRED / NICE TO HAVE). "Stops" is split into what is acceptable (shared) and what is
 * merely preferred (flexible).
 */
export function overlapRows(p: SharedProfile): OverlapRow[] {
  const out: OverlapRow[] = [];
  for (const c of p.constraints) {
    if (c.field === 'maxStops' && p.stopsPreferred !== p.stopsAcceptable) {
      out.push({
        id: 'stops-ok', agreement: 'shared', strength: c.strength, title: 'Stops',
        value: `Up to ${p.stopsAcceptable} stop${p.stopsAcceptable === 1 ? '' : 's'} is fine`,
        detail: c.strength === 'must' ? 'The most anyone will accept.' : 'The most anyone can tolerate.',
      });
      out.push({
        id: 'stops-pref', agreement: 'flexible', strength: 'preferred', title: 'Stops',
        value: p.stopsPreferred === 0 ? 'Nonstop preferred' : `${p.stopsPreferred} stop${p.stopsPreferred === 1 ? '' : 's'} preferred`,
        detail: c.detail,
      });
    } else if ((c.field === 'departureWindow' && !p.windowsIdentical) || (c.field === 'hotelStyle' && !p.stylesIdentical)) {
      out.push({ id: c.field, agreement: 'flexible', strength: c.strength, title: c.title, value: c.value, detail: c.detail });
    } else {
      out.push({ id: c.field, agreement: 'shared', strength: c.strength, title: c.title, value: c.value, detail: c.detail });
    }
  }
  for (const conflict of p.conflicts) {
    out.push({
      id: `conflict-${conflict.id}`, agreement: 'conflict', strength: 'must', title: conflict.title, value: conflict.detail,
      detail: "Artemis won't average this. You'll decide together.",
    });
  }
  // Agreement ascending, then strength descending. Array.prototype.sort is stable.
  return out.sort((a, b) => AGREEMENT_ORDER[a.agreement] - AGREEMENT_ORDER[b.agreement] || strengthRank(b.strength) - strengthRank(a.strength));
}
