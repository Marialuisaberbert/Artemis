/**
 * What the ticket does under the traveler's finger. Pure, so the feel can be tested without a screen.
 *
 * The cut runs along the perforation. It is deliberately not linear: it takes a little effort in the middle,
 * the two halves begin to part near the end, and it snaps at the finish.
 */
export type CutEvent =
  | { type: 'tick'; at: number } // every 10%
  | { type: 'resistance' } // the paper catches, halfway
  | { type: 'separating' } // the halves begin to part
  | { type: 'snap' }; // through

export const isEvent = (e: CutEvent, type: CutEvent['type']): boolean => e.type === type;

export interface TicketCutState {
  /** 0…1 of the width the finger has covered (before the paper pushes back). */
  raw: number;
  lastTick: number;
  sawResistance: boolean;
  sawSeparating: boolean;
  isCut: boolean;
}

export const initialCutState = (): TicketCutState => ({ raw: 0, lastTick: 0, sawResistance: false, sawSeparating: false, isCut: false });

/** The paper resists between 45% and 65%: half the drag is less than half the cut. */
export function easeCut(r: number): number {
  const x = Math.min(1, Math.max(0, r));
  if (x < 0.45) return x;
  if (x < 0.65) return 0.45 + (x - 0.45) * 0.4;
  return 0.53 + (x - 0.65) * (0.47 / 0.35);
}

export class TicketCutModel {
  private s: TicketCutState = initialCutState();

  /** What the ticket shows, after resistance. */
  get progress(): number { return easeCut(this.s.raw); }
  get raw(): number { return this.s.raw; }
  get isCut(): boolean { return this.s.isCut; }
  /** How far apart the halves have drifted, 0…1. Zero until the end approaches. */
  get separation(): number { return this.s.isCut ? 1 : Math.max(0, (this.progress - 0.9) / 0.1); }
  /** Bend of the paper, 0…1, strongest as the cut nears the middle. */
  get bend(): number { return Math.sin(Math.min(1, this.progress) * Math.PI); }

  static ease = easeCut;

  /** Feed the fraction of the line covered. Returns what just happened. */
  update(covered: number): CutEvent[] {
    if (this.s.isCut) return [];
    this.s.raw = Math.max(this.s.raw, Math.min(1, Math.max(0, covered)));
    const out: CutEvent[] = [];
    const p = this.progress;
    const tick = Math.trunc(p * 10);
    if (tick > this.s.lastTick) {
      for (let t = this.s.lastTick + 1; t <= tick; t++) if (t < 10) out.push({ type: 'tick', at: t });
      this.s.lastTick = tick;
    }
    if (p >= 0.45 && !this.s.sawResistance) { this.s.sawResistance = true; out.push({ type: 'resistance' }); }
    if (p >= 0.9 && !this.s.sawSeparating) { this.s.sawSeparating = true; out.push({ type: 'separating' }); }
    if (p >= 0.985) { this.s.isCut = true; out.push({ type: 'snap' }); }
    return out;
  }

  /** The finger lifted before the end: the paper settles back. */
  release(): void {
    if (this.s.isCut) return;
    this.s = initialCutState();
  }

  /** The accessible alternative: cut without dragging. */
  cutNow(): CutEvent[] { return this.update(1); }
}
