/** Dollars. Prototype amounts are whole or two-decimal, so plain numbers, rounded to cents after arithmetic. */
export type Money = number;

export const cents = (m: Money): Money => Math.round(m * 100) / 100;

/** "$340", "$4,820.55" — whole amounts drop the cents. */
export function usd(amount: Money): string {
  const value = cents(amount);
  const whole = Number.isInteger(value);
  const fixed = Math.abs(value).toFixed(whole ? 0 : 2);
  const [int, frac] = fixed.split('.');
  const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return `${value < 0 ? '-' : ''}$${grouped}${frac ? `.${frac}` : ''}`;
}
