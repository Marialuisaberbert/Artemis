/**
 * Time, the way the Swift app treats it: every flight time is an absolute instant (epoch milliseconds),
 * shown in the local time of the airport it belongs to. Zones are resolved from a small rule table
 * (fixed offsets plus the EU and US daylight-saving rules) so the domain never depends on `Intl`.
 */

export type Instant = number; // epoch milliseconds
export type Seconds = number;

const MIN = 60_000;
const DAY = 86_400_000;

// MARK: - Zones

export interface TimeZoneInfo {
  id: string;
  /** Offset from UTC, in minutes, at the given instant. */
  offsetMinutes(at: Instant): number;
}

/** Last Sunday of the month at 01:00 UTC. */
function lastSundayUTC(year: number, month0: number, hourUTC: number): number {
  const last = new Date(Date.UTC(year, month0 + 1, 0, hourUTC));
  return last.getTime() - last.getUTCDay() * DAY;
}

/** The nth (1-based) Sunday of a month, at a UTC time. */
function nthSundayUTC(year: number, month0: number, n: number, hourUTC: number): number {
  const first = new Date(Date.UTC(year, month0, 1, hourUTC));
  const firstSunday = 1 + ((7 - first.getUTCDay()) % 7);
  return Date.UTC(year, month0, firstSunday + (n - 1) * 7, hourUTC);
}

function euDST(at: Instant): boolean {
  const y = new Date(at).getUTCFullYear();
  return at >= lastSundayUTC(y, 2, 1) && at < lastSundayUTC(y, 9, 1);
}

function usDST(at: Instant, stdOffsetMin: number): boolean {
  const y = new Date(at).getUTCFullYear();
  // 2:00 AM local standard time on the second Sunday of March → 2:00 AM local daylight time on the first Sunday of November.
  const start = nthSundayUTC(y, 2, 2, 2) - stdOffsetMin * MIN;
  const end = nthSundayUTC(y, 10, 1, 2) - (stdOffsetMin + 60) * MIN;
  return at >= start && at < end;
}

function fixed(id: string, minutes: number): TimeZoneInfo {
  return { id, offsetMinutes: () => minutes };
}
function eu(id: string, stdMinutes: number): TimeZoneInfo {
  return { id, offsetMinutes: (at) => stdMinutes + (euDST(at) ? 60 : 0) };
}
function us(id: string, stdMinutes: number): TimeZoneInfo {
  return { id, offsetMinutes: (at) => stdMinutes + (usDST(at, stdMinutes) ? 60 : 0) };
}

export const UTC = fixed('UTC', 0);

/** The device's own zone (what Swift calls `TimeZone.current`). */
export const deviceTimeZone: TimeZoneInfo = {
  id: 'device',
  offsetMinutes: (at) => -new Date(at).getTimezoneOffset(),
};

const ZONES: Record<string, TimeZoneInfo> = {
  UTC,
  GMT: UTC,
  'America/Sao_Paulo': fixed('America/Sao_Paulo', -180),
  'Europe/Lisbon': eu('Europe/Lisbon', 0),
  'Europe/London': eu('Europe/London', 0),
  'Europe/Rome': eu('Europe/Rome', 60),
  'Europe/Paris': eu('Europe/Paris', 60),
  'Europe/Madrid': eu('Europe/Madrid', 60),
  'Asia/Tokyo': fixed('Asia/Tokyo', 540),
  'Asia/Qatar': fixed('Asia/Qatar', 180),
  'Asia/Dubai': fixed('Asia/Dubai', 240),
  'Asia/Makassar': fixed('Asia/Makassar', 480),
  'Africa/Johannesburg': fixed('Africa/Johannesburg', 120),
  'America/New_York': us('America/New_York', -300),
};

export function timeZone(id: string): TimeZoneInfo {
  return ZONES[id] ?? UTC;
}

// MARK: - Calendar parts

export interface LocalParts {
  year: number;
  /** 1–12 */
  month: number;
  day: number;
  hour: number;
  minute: number;
  /** 1 = Sunday … 7 = Saturday, as in Swift's `Calendar`. */
  weekday: number;
}

export function parts(at: Instant, tz: TimeZoneInfo): LocalParts {
  const d = new Date(at + tz.offsetMinutes(at) * MIN);
  return {
    year: d.getUTCFullYear(),
    month: d.getUTCMonth() + 1,
    day: d.getUTCDate(),
    hour: d.getUTCHours(),
    minute: d.getUTCMinutes(),
    weekday: d.getUTCDay() + 1,
  };
}

/** The instant at which a wall clock in `tz` reads the given local time. Day overflow is normalised. */
export function localToInstant(year: number, month: number, day: number, hour: number, minute: number, tz: TimeZoneInfo): Instant {
  const wall = Date.UTC(year, month - 1, day, hour, minute);
  const first = wall - tz.offsetMinutes(wall) * MIN;
  const second = wall - tz.offsetMinutes(first) * MIN;
  return second;
}

export function startOfDay(at: Instant, tz: TimeZoneInfo): Instant {
  const p = parts(at, tz);
  return localToInstant(p.year, p.month, p.day, 0, 0, tz);
}

/** Calendar-day arithmetic that keeps the local time of day (so a DST change doesn't shift it). */
export function addDays(at: Instant, days: number, tz: TimeZoneInfo): Instant {
  const p = parts(at, tz);
  return localToInstant(p.year, p.month, p.day + days, p.hour, p.minute, tz);
}

/** Midnight local on a calendar date, like `cal.date(from: DateComponents(year:month:day:))`. */
export function dateFrom(year: number, month: number, day: number, tz: TimeZoneInfo): Instant {
  return localToInstant(year, month, day, 0, 0, tz);
}

export const Zoned = {
  /** The instant at `hour:minute` local time on the calendar day of `base` (in `tz`), plus `days`. */
  at(base: Instant, hour: number, minute: number, tz: TimeZoneInfo, plusDays = 0): Instant {
    const p = parts(base, tz);
    return localToInstant(p.year, p.month, p.day + plusDays, hour, minute, tz);
  },

  minuteOfDay(at: Instant, tz: TimeZoneInfo): number {
    const p = parts(at, tz);
    return p.hour * 60 + p.minute;
  },

  /** "10:45 PM" */
  time(at: Instant, tz: TimeZoneInfo): string {
    const p = parts(at, tz);
    const h12 = p.hour % 12 === 0 ? 12 : p.hour % 12;
    return `${h12}:${String(p.minute).padStart(2, '0')} ${p.hour < 12 ? 'AM' : 'PM'}`;
  },

  /** "Sep 24" */
  day(at: Instant, tz: TimeZoneInfo): string {
    const p = parts(at, tz);
    return `${MONTHS[p.month - 1]} ${p.day}`;
  },

  /** "SEP 24" */
  dayUpper(at: Instant, tz: TimeZoneInfo): string {
    return Zoned.day(at, tz).toUpperCase();
  },

  weekday(at: Instant, tz: TimeZoneInfo): string {
    return WEEKDAYS[parts(at, tz).weekday - 1];
  },

  /** Whole calendar days from `from` (in its zone) to `to` (in its zone). */
  daysBetween(from: Instant, fromTz: TimeZoneInfo, to: Instant, toTz: TimeZoneInfo): number {
    const a = parts(from, fromTz);
    const b = parts(to, toTz);
    return Math.round((Date.UTC(b.year, b.month - 1, b.day) - Date.UTC(a.year, a.month - 1, a.day)) / DAY);
  },
};

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// MARK: - Durations

/** "14h 35m" */
export function hoursMinutes(seconds: Seconds): string {
  const total = Math.round(seconds / 60);
  const h = Math.trunc(total / 60);
  const m = total % 60;
  if (h === 0) return `${m}m`;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}

/** "4H 32M" for countdowns. */
export function countdown(seconds: Seconds): string {
  return hoursMinutes(seconds).toUpperCase();
}

export const addSeconds = (at: Instant, s: Seconds): Instant => at + s * 1000;
export const secondsBetween = (from: Instant, to: Instant): Seconds => (to - from) / 1000;
export const HOUR_S = 3600;
export const DAY_MS = DAY;
