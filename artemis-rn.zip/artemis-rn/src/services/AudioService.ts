import { AudioPlayer, createAudioPlayer, setAudioModeAsync } from 'expo-audio';

/** The moments Artemis can make a sound for. */
export type AudioCue = 'takeoff' | 'cabinAmbience' | 'paperMove' | 'tear' | 'landing';

/**
 * Sound is optional and OFF by default. The app works perfectly without it.
 *
 * No sound files ship. To add sound, put files in `assets/sounds/` and register them in `SOUND_FILES` below (Metro needs
 * static `require`s, so they cannot be discovered at runtime). A cue with no file is silently skipped. Playback mixes with
 * the traveler's music and respects the silent switch, so it never interrupts anything.
 */
const SOUND_FILES: Partial<Record<AudioCue, number>> = {
  // takeoff: require('../../assets/sounds/takeoff.m4a'),
  // paperMove: require('../../assets/sounds/paperMove.m4a'),
  // tear: require('../../assets/sounds/tear.m4a'),
};

class ArtemisAudio {
  enabled = false;
  private players: Partial<Record<AudioCue, AudioPlayer>> = {};
  private modeSet = false;

  setEnabled(on: boolean): void {
    this.enabled = on;
    if (!on) for (const cue of Object.keys(this.players) as AudioCue[]) this.stop(cue);
  }

  play(cue: AudioCue): void {
    if (!this.enabled) return;
    const source = SOUND_FILES[cue];
    if (source === undefined) return; // no file for this cue: skipped silently
    try {
      if (!this.modeSet) {
        this.modeSet = true;
        void setAudioModeAsync({ playsInSilentMode: false, interruptionMode: 'mixWithOthers' }).catch(() => {});
      }
      const player = (this.players[cue] ??= createAudioPlayer(source));
      void player.seekTo(0).catch(() => {});
      player.play();
    } catch {
      /* sound is a flourish, never a dependency */
    }
  }

  stop(cue: AudioCue): void {
    try { this.players[cue]?.pause(); } catch { /* ignore */ }
  }
}

export const Audio = new ArtemisAudio();
