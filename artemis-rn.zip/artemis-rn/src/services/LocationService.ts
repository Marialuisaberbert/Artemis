import * as Location from 'expo-location';
import { LocationService, LocationStatus } from '../domain/destinations/locationService';
import { Place, nearestPlace, rioPlace } from '../domain/destinations/place';

/**
 * Device location through expo-location, with the demo place (Rio) as the fallback for every failure. It never
 * breaks the app: if permission is refused or the fix fails, the traveler simply starts from Rio.
 */
export class ExpoLocationService implements LocationService {
  place: Place = rioPlace;
  status: LocationStatus = { kind: 'demo' };
  onChange?: () => void;

  useLiveLocation(): void {
    this.status = { kind: 'requesting' };
    this.onChange?.();
    void this.locate();
  }

  useDemoLocation(): void {
    this.place = rioPlace;
    this.status = { kind: 'demo' };
    this.onChange?.();
  }

  choose(place: Place): void {
    this.place = place;
    this.status = { kind: 'demo' };
    this.onChange?.();
  }

  private fallback(reason: string): void {
    this.place = rioPlace;
    this.status = { kind: 'unavailable', reason };
    this.onChange?.();
  }

  private async locate(): Promise<void> {
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (perm.status !== 'granted') return this.fallback('Location access is off. Using Rio de Janeiro.');
      const pos =
        (await Location.getLastKnownPositionAsync()) ?? (await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Low }));
      this.place = nearestPlace(pos.coords.latitude, pos.coords.longitude);
      this.status = { kind: 'live' };
      this.onChange?.();
    } catch {
      this.fallback("Couldn't find you. Using Rio de Janeiro.");
    }
  }
}
