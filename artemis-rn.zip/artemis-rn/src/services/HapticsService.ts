import * as Haptics from 'expo-haptics';

/**
 * The moments of the Artemis journey, each with one deliberate tactile answer. Used sparingly.
 * Every call is fire-and-forget and never throws: haptics are a flourish, not a dependency.
 */
export type HapticMoment =
  | 'takeoff' // the plane leaves the ground: light
  | 'bookingConfirmed' // medium
  | 'ticketAppears' // light
  | 'cutThreshold' // the paper catches, and the halves begin to part: medium
  | 'tear' // through: strong, sharp (rigid, then heavy 60 ms later)
  | 'completed' // success
  | 'tick'; // progress along the cut: barely there

const safe = (p: Promise<unknown>): void => { p.catch(() => {}); };

export const HapticsService = {
  play(moment: HapticMoment): void {
    switch (moment) {
      case 'takeoff': safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)); break;
      case 'bookingConfirmed': safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)); break;
      case 'ticketAppears': safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)); break;
      case 'cutThreshold': safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium)); break;
      case 'tear':
        safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Rigid));
        setTimeout(() => safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy)), 60);
        break;
      case 'completed': safe(Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)); break;
      case 'tick': safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Soft)); break;
    }
  },
  /** A light tap on a button. */
  tap(): void { safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light)); },
  /** A selection change (chips, sliders, ranking). */
  select(): void { safe(Haptics.selectionAsync()); },
  soft(): void { safe(Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Soft)); },
  success(): void { safe(Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success)); },
  warning(): void { safe(Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning)); },
  error(): void { safe(Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error)); },
};
