import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, StyleSheet, View, useWindowDimensions } from 'react-native';
import { useImage } from '@shopify/react-native-skia';
import Animated, { FadeIn, FadeInDown, FadeOut, useAnimatedStyle, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import { Icon } from '../../design/Icon';
import { PhotoBackdrop } from '../../design/PhotoView';
import { photoSource } from '../../design/photos';
import { Caps, T } from '../../design/text';
import { colors, fonts as fontFamilies } from '../../design/theme';
import { Trip, dateRange, tripDestination } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { useTicketFonts } from './fonts';
import { TicketMetrics } from './geometry';
import { TicketInteraction } from './TicketInteraction';
import { TicketStub } from './TicketStub';
import { stageAtLeast, useTicketReveal } from './useTicketReveal';

interface Props {
  trip: Trip;
  /** "BOOKING CONFIRMED" opens the sequence. Onboarding passes undefined. */
  confirmation?: string;
  /** Called at the moment the paper tears. */
  onCut: () => void;
  /** What to offer once the ticket is cut and saved. */
  actions: React.ReactNode;
}

/**
 * Booking confirmed → dark → the ticket arrives → "Your trip is ready" → "Cut your ticket" → the cut →
 * "The trip is yours" → "Welcome aboard".
 *
 * Used after a real booking, and by onboarding with a sample ticket. `onCut` is called at the moment the paper tears,
 * so the ticket is saved even if the traveler leaves right away.
 */
export function TicketReveal({ trip, confirmation, onCut, actions }: Props) {
  const reduceMotion = useReducedMotion();
  const reveal = useTicketReveal({ reduceMotion, onCut });
  const { stage } = reveal;
  const { width, height } = useWindowDimensions();
  const [showBack, setShowBack] = useState(false);
  const dest = tripDestination(trip);
  const image = useImage(photoSource(dest.photo.file) as number);
  const fonts = useTicketFonts();

  useEffect(() => {
    if (confirmation) HapticsService.play('bookingConfirmed');
    reveal.play();
    return reveal.stop;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // The place, revealed behind the paper.
  const backdrop = useSharedValue(0);
  useEffect(() => { backdrop.value = withTiming(stageAtLeast(stage, 'arriving') ? 0.9 : 0, { duration: reduceMotion ? 400 : 2200 }); }, [stage, backdrop, reduceMotion]);
  const backdropStyle = useAnimatedStyle(() => ({ opacity: backdrop.value }));

  const caption = useMemo((): { text: string; small?: string } | undefined => {
    switch (stage) {
      case 'dark': return confirmation ? { text: confirmation, small: `${dest.city.toUpperCase()} · ${dateRange(trip)}` } : undefined;
      case 'arriving': return confirmation ? { text: confirmation } : undefined;
      case 'ready': return { text: 'YOUR TRIP IS READY' };
      case 'cutting': return { text: 'CUT YOUR TICKET' };
      case 'cut': return undefined;
      case 'yours': return { text: 'THE TRIP IS YOURS' };
      case 'aboard': return { text: 'WELCOME ABOARD' };
    }
  }, [stage, confirmation, dest.city, trip]);

  const scale = Math.min(1.05, Math.max(0.6, (height - 330) / TicketMetrics.height));
  const big = stage === 'aboard' || stage === 'yours';

  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      <Animated.View style={[StyleSheet.absoluteFill, backdropStyle]} pointerEvents="none">
        <PhotoBackdrop destination={dest} blur={34} dim={0.62} drift />
      </Animated.View>

      <View style={{ flex: 1, width, alignItems: 'center' }}>
        {/* Caption */}
        <View style={{ height: 118, marginTop: 36, justifyContent: 'flex-end', alignItems: 'center', paddingHorizontal: 20 }} accessible accessibilityLiveRegion="polite">
          {caption && (
            <Animated.View key={caption.text} entering={FadeInDown.duration(700)} exiting={FadeOut.duration(300)} style={{ alignItems: 'center', gap: 10 }}>
              {(stage === 'dark' || stage === 'arriving') && confirmation && (
                <View style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: colors.cream, alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name="check" size={17} color="#000" strokeWidth={2.6} />
                </View>
              )}
              <T numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}
                style={{ fontFamily: fontFamilies.serif, color: '#fff', textAlign: 'center', fontSize: big ? 30 : 24, letterSpacing: big ? 4 : 5 }}>
                {caption.text}
              </T>
              {caption.small && <Caps size={10.5} tracking={2.6} opacity={0.6}>{caption.small}</Caps>}
            </Animated.View>
          )}
        </View>

        <View style={{ flex: 1 }} />

        {/* The ticket */}
        <View style={{ width: TicketMetrics.width * scale, height: TicketMetrics.height * scale, alignItems: 'center', justifyContent: 'center' }}>
          <View style={{ transform: [{ scale }] }}>
            {stageAtLeast(stage, 'aboard') ? (
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Turn the ticket over"
                onPress={() => { HapticsService.soft(); setShowBack((b) => !b); }}
              >
                <Animated.View entering={FadeIn.duration(350)}>
                  <TicketStub trip={trip} image={image} fonts={fonts} showsBack={showBack} />
                </Animated.View>
              </Pressable>
            ) : (
              <View pointerEvents={stageAtLeast(stage, 'cut') ? 'none' : 'auto'} style={{ width: TicketMetrics.width, height: TicketMetrics.height + 3 }}>
                <TicketInteraction trip={trip} reveal={reveal} image={image} fonts={fonts} />
              </View>
            )}
          </View>
        </View>

        <View style={{ flex: 1 }} />

        {/* Footer */}
        <View style={{ minHeight: 132, paddingBottom: 12, width: '100%', paddingHorizontal: 24, alignItems: 'center' }}>
          {(stage === 'ready' || stage === 'cutting') && (
            <Animated.View entering={FadeIn.duration(600)} exiting={FadeOut.duration(200)} style={{ alignItems: 'center', gap: 6 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <Icon name="scissors" size={14} color="#fff" strokeWidth={2} />
                <Caps size={12} tracking={3.6} opacity={1}>SWIPE TO CUT</Caps>
              </View>
              <Pressable accessibilityRole="button" accessibilityLabel="Cut ticket" onPress={reveal.cutNow} hitSlop={8} style={{ minHeight: 44, paddingHorizontal: 14, justifyContent: 'center' }}>
                <T style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12, fontWeight: '600' }}>or tap to cut</T>
              </Pressable>
            </Animated.View>
          )}
          {stage === 'aboard' && (
            <Animated.View entering={FadeInDown.duration(600)} style={{ alignItems: 'center', gap: 10, width: '100%' }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Icon name="check" size={13} color="rgba(255,255,255,0.75)" strokeWidth={2.4} />
                <T style={{ color: 'rgba(255,255,255,0.75)', fontSize: 13, fontWeight: '600', letterSpacing: 1.2 }}>Saved to My Trips</T>
              </View>
              {actions}
            </Animated.View>
          )}
        </View>
      </View>
    </View>
  );
}
