import React, { useEffect, useMemo } from 'react';
import { BlurMask, Canvas, Circle, DashPathEffect, Group, Path, Rect, Skia } from '@shopify/react-native-skia';
import Animated, { Easing, SharedValue, useDerivedValue, useFrameCallback, useSharedValue, withTiming } from 'react-native-reanimated';
import { colors } from '../../design/theme';
import { jag, SHEET_H, SHEET_W, TEETH, TicketMetrics } from './geometry';

const { cutY } = TicketMetrics;
/** The overlay is bigger than the sheet: paper scraps fly a long way. */
const PX = 200;
const PY_TOP = 320;
const PY_BOTTOM = 620;
const OW = SHEET_W + PX * 2;
const OH = SHEET_H + PY_TOP + PY_BOTTOM;

const JAG_Y: number[] = Array.from({ length: TEETH + 1 }, (_, i) => cutY + jag(i));

interface Props {
  guide: boolean;
  slit: boolean;
  opened: SharedValue<number>;
  touching: SharedValue<number>;
  fingerX: SharedValue<number>;
  tornAt?: number;
}

/**
 * Everything that floats above the paper while it is being cut: the "swipe to cut" guide (a dotted line that breathes and a
 * finger that shows the way), the slit opening behind the finger, and the paper scraps thrown off by the tear.
 */
export function TicketOverlay({ guide, slit, opened, touching, fingerX, tornAt }: Props) {
  const time = useSharedValue(0);
  useFrameCallback((f) => { time.value = (f.timeSinceFirstFrame ?? 0) / 1000; });

  const pulse = useDerivedValue(() => 0.5 + 0.5 * Math.sin(time.value * 3.2));
  const phase = useDerivedValue(() => (time.value % 2.8) / 2.8);
  const fingerPos = useDerivedValue(() => {
    const p = phase.value;
    // hold at the start, glide across with a soft ease, fade out
    const move = Math.min(1, Math.max(0, (p - 0.12) / 0.66));
    const eased = move * move * (3 - 2 * move);
    const a = p < 0.08 ? p / 0.08 : p > 0.86 ? Math.max(0, (1 - p) / 0.14) : 1;
    return { x: -6 + (SHEET_W + 12) * eased, a };
  });
  const idleOpacity = useDerivedValue(() => (guide && touching.value < 0.5 ? fingerPos.value.a : 0));
  const idleX = useDerivedValue(() => fingerPos.value.x);
  const touchOpacity = useDerivedValue(() => (guide ? touching.value : 0));
  const touchX = useDerivedValue(() => fingerX.value);

  const outsideOpacity = useDerivedValue(() => (guide ? 0.55 + 0.45 * pulse.value : 0));
  const glowOpacity = useDerivedValue(() => (guide ? 0.5 * (0.6 + 0.4 * pulse.value) : 0));
  const inkOpacity = useDerivedValue(() => (guide ? 0.35 + 0.35 * pulse.value : 0));

  const leftLine = useMemo(() => Skia.PathBuilder.Make().moveTo(-34, cutY).lineTo(-10, cutY).build(), []);
  const rightLine = useMemo(() => Skia.PathBuilder.Make().moveTo(SHEET_W + 10, cutY).lineTo(SHEET_W + 34, cutY).build(), []);
  const inkLine = useMemo(() => Skia.PathBuilder.Make().moveTo(14, cutY).lineTo(SHEET_W - 14, cutY).build(), []);

  // The slit opening behind the finger, following the torn edge.
  const slitPath = useDerivedValue(() => {
    const b = Skia.PathBuilder.Make();
    const n = Math.max(1, Math.floor(TEETH * Math.min(1, Math.max(0, opened.value))));
    for (let i = 0; i <= n; i++) {
      const x = (SHEET_W * i) / TEETH;
      if (i === 0) b.moveTo(x, JAG_Y[i]); else b.lineTo(x, JAG_Y[i]);
    }
    return b.build();
  });
  const slitOpacity = useDerivedValue(() => (slit && opened.value > 0.02 ? 1 : 0));

  return (
    <Animated.View pointerEvents="none" style={{ position: 'absolute', left: -PX, top: -PY_TOP, width: OW, height: OH }}>
      <Canvas style={{ width: OW, height: OH }}>
        <Group transform={[{ translateX: PX }, { translateY: PY_TOP }]}>
          {/* The slit */}
          <Path path={slitPath} style="stroke" strokeWidth={3} color={colors.white} opacity={useDerivedValue(() => slitOpacity.value * 0.7)}>
            <BlurMask blur={5} style="normal" />
          </Path>
          <Path path={slitPath} style="stroke" strokeWidth={1.3} strokeCap="round" strokeJoin="round" color={colors.ink} opacity={useDerivedValue(() => slitOpacity.value * 0.9)} />

          {/* Outside the paper: white, glowing */}
          {[leftLine, rightLine].map((p, i) => (
            <React.Fragment key={i}>
              <Path path={p} style="stroke" strokeWidth={4} strokeCap="round" color={colors.white} opacity={glowOpacity}>
                <DashPathEffect intervals={[1, 6]} />
                <BlurMask blur={5} style="normal" />
              </Path>
              <Path path={p} style="stroke" strokeWidth={2.2} strokeCap="round" color={colors.white} opacity={outsideOpacity}>
                <DashPathEffect intervals={[1, 6]} />
              </Path>
            </React.Fragment>
          ))}
          {/* On the paper: ink, along the perforation */}
          <Path path={inkLine} style="stroke" strokeWidth={1.4} strokeCap="round" color={colors.ink} opacity={inkOpacity}>
            <DashPathEffect intervals={[1, 7]} />
          </Path>

          {/* The finger that shows the way */}
          <Circle cx={idleX} cy={cutY} r={26} color="rgba(255,255,255,0.22)" opacity={idleOpacity}>
            <BlurMask blur={6} style="normal" />
          </Circle>
          <Circle cx={idleX} cy={cutY} r={14} color="rgba(255,255,255,0.92)" opacity={idleOpacity} />
          <Circle cx={idleX} cy={cutY} r={14} color={colors.white} opacity={useDerivedValue(() => idleOpacity.value * 0.6)}>
            <BlurMask blur={10} style="normal" />
          </Circle>
          {/* The real finger, while it is down */}
          <Circle cx={touchX} cy={cutY} r={23} color="rgba(255,255,255,0.16)" opacity={touchOpacity} />
          <Circle cx={touchX} cy={cutY} r={23} style="stroke" strokeWidth={1.5} color="rgba(255,255,255,0.85)" opacity={touchOpacity} />
          <Circle cx={touchX} cy={cutY} r={23} color={colors.white} opacity={useDerivedValue(() => touchOpacity.value * 0.35)}>
            <BlurMask blur={10} style="normal" />
          </Circle>

          {tornAt !== undefined && <PaperParticles key={tornAt} />}
        </Group>
      </Canvas>
    </Animated.View>
  );
}

// MARK: - Paper scraps

const PALETTE = [colors.paper, colors.paperLight, '#C9BDA3', 'rgba(28,25,21,0.85)', '#ffffff'];

interface Scrap {
  x0: number; angle: number; speed: number; spin: number; size: number; life: number; color: string;
}

/** A tiny seeded generator so the burst is the same every time. */
function scraps(count: number): Scrap[] {
  let seed = 0xc0ffee;
  const next = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  return Array.from({ length: count }, () => {
    const x0 = next() * SHEET_W;
    const angle = -Math.PI / 2 + (next() - 0.5) * 2.4;
    const speed = 70 + next() * 190;
    const spin = (next() - 0.5) * 12;
    const size = 2.5 + next() * 4.5;
    const life = 0.9 + next() * 0.9;
    const color = PALETTE[Math.floor(next() * PALETTE.length) % PALETTE.length];
    return { x0, angle, speed, spin, size, life, color };
  });
}

/** ~46 paper scraps burst from the tear line and fall with gravity. Brief and quiet. */
function PaperParticles() {
  const t = useSharedValue(0);
  useEffect(() => { t.value = withTiming(2, { duration: 2000, easing: Easing.linear }); }, [t]);
  const list = useMemo(() => scraps(46), []);
  return <>{list.map((s, i) => <ScrapRect key={i} s={s} t={t} />)}</>;
}

function ScrapRect({ s, t }: { s: Scrap; t: SharedValue<number> }) {
  const transform = useDerivedValue(() => [
    { translateX: s.x0 + Math.cos(s.angle) * s.speed * t.value },
    { translateY: cutY + Math.sin(s.angle) * s.speed * t.value + 260 * t.value * t.value },
    { rotate: s.spin * t.value },
  ]);
  const opacity = useDerivedValue(() => {
    const age = t.value / s.life;
    return age >= 1 ? 0 : age < 0.6 ? 1 : (1 - age) / 0.4;
  });
  return (
    <Group transform={transform} opacity={opacity}>
      <Rect x={-s.size / 2} y={-s.size * 0.3} width={s.size} height={s.size * 0.6} color={s.color} />
    </Group>
  );
}
