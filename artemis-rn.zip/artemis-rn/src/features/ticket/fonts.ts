import { useMemo } from 'react';
import { Skia, SkFont, matchFont, useTypeface } from '@shopify/react-native-skia';
import { Newsreader_500Medium } from '@expo-google-fonts/newsreader';

export interface TicketFonts {
  serif(size: number): SkFont;
  sans(size: number, weight?: '400' | '500' | '600' | '700'): SkFont;
  mono(size: number): SkFont;
}

/** The ticket is drawn in Skia, so it needs Skia fonts: Newsreader for the city, the system sans for labels, Menlo for the route. */
export function useTicketFonts(): TicketFonts | null {
  const face = useTypeface(Newsreader_500Medium);
  return useMemo(() => {
    if (!face) return null;
    const cache = new Map<string, SkFont>();
    const memo = (key: string, make: () => SkFont): SkFont => {
      let f = cache.get(key);
      if (!f) { f = make(); cache.set(key, f); }
      return f;
    };
    return {
      serif: (size) => memo(`serif-${size}`, () => Skia.Font(face, size)),
      sans: (size, weight = '600') => memo(`sans-${size}-${weight}`, () => matchFont({ fontFamily: 'Helvetica Neue', fontSize: size, fontWeight: weight })),
      mono: (size) => memo(`mono-${size}`, () => matchFont({ fontFamily: 'Menlo', fontSize: size, fontWeight: 'bold' })),
    };
  }, [face]);
}
