import { PathOp, Skia, SkPath } from '@shopify/react-native-skia';

// The Artemis Trip Ticket: a collectible piece of paper, not a boarding pass.
//
// It is printed on cream stock with a perforation, a torn edge and a tiny photograph of the place. It carries names,
// dates and a trip number. It has no barcode, no QR code, no gate, no seat and no security wording, and it cannot be
// scanned or used to travel.

export const TicketMetrics = {
  width: 296,
  height: 476,
  /** Where the perforation runs, from the top. */
  cutY: 316,
  /** Corner radius of the sheet. */
  radius: 10,
  /** Radius of the half-circle bitten out of each side at the perforation. */
  notch: 11,
  /** The thickness of the stock, peeking out under the sheet. */
  edgeOffset: 2.2,
} as const;

/** The frame every ticket layer is drawn into: the sheet plus the 3 px its thickness adds. */
export const SHEET_W = TicketMetrics.width;
export const SHEET_H = TicketMetrics.height + 3;
/** Room around the sheet inside each canvas, for shadows. */
export const PAD = 48;

/** Number of teeth along the tear. */
export const TEETH = 34;

/** A small deterministic offset (±2.5 pt) for tooth `i`. Identical on both halves so they fit. */
export const jag = (i: number): number => (((i * 37 + 11) % 13) - 6) * 0.42;

const jaggedPoints = (): { x: number; y: number }[] =>
  Array.from({ length: TEETH + 1 }, (_, i) => ({ x: (SHEET_W * i) / TEETH, y: TicketMetrics.cutY + jag(i) }));

/** The ticket outline: a rounded card with a half-circle bitten out of each side at the perforation. */
export function outlinePath(): SkPath {
  const { width, height, cutY, radius, notch } = TicketMetrics;
  const card = Skia.PathBuilder.Make().addRRect(Skia.RRectXY(Skia.XYWHRect(0, 0, width, height), radius, radius)).build();
  const holes = Skia.PathBuilder.Make().addCircle(0, cutY, notch).addCircle(width, cutY, notch).build();
  return Skia.Path.MakeFromOp(card, holes, PathOp.Difference) ?? card;
}

/** Everything above (isTop) or below the jagged tear. */
export function tearRegion(isTop: boolean): SkPath {
  const pts = jaggedPoints();
  const far = isTop ? -60 : SHEET_H + 60;
  const b = Skia.PathBuilder.Make();
  b.moveTo(-30, far);
  b.lineTo(SHEET_W + 30, far);
  b.lineTo(SHEET_W + 30, pts[pts.length - 1].y);
  for (let i = pts.length - 1; i >= 0; i--) b.lineTo(pts[i].x, pts[i].y);
  b.lineTo(-30, pts[0].y);
  b.close();
  return b.build();
}

/** The torn edge itself, from x = 0 to `fraction` of the width. Used for the slit that opens behind the finger. */
export function tearLine(fraction: number): SkPath {
  const n = Math.max(1, Math.floor(TEETH * Math.min(1, Math.max(0, fraction))));
  const pts = jaggedPoints();
  const b = Skia.PathBuilder.Make();
  for (let i = 0; i <= n; i++) {
    if (i === 0) b.moveTo(pts[i].x, pts[i].y); else b.lineTo(pts[i].x, pts[i].y);
  }
  return b.build();
}

export interface TicketPaths {
  outline: SkPath;
  topRegion: SkPath;
  bottomRegion: SkPath;
  /** Sheet ∩ half, i.e. the visible shape of each half. */
  top: SkPath;
  bottom: SkPath;
  /** The outline pushed down by the thickness of the stock. */
  edge: SkPath;
}

let cached: TicketPaths | undefined;
export function ticketPaths(): TicketPaths {
  if (cached) return cached;
  const outline = outlinePath();
  const topRegion = tearRegion(true);
  const bottomRegion = tearRegion(false);
  const top = Skia.Path.MakeFromOp(outline, topRegion, PathOp.Intersect) ?? outline;
  const bottom = Skia.Path.MakeFromOp(outline, bottomRegion, PathOp.Intersect) ?? outline;
  const edge = Skia.PathBuilder.MakeFromPath(outline).transform(Skia.Matrix().translate(0, TicketMetrics.edgeOffset)).build();
  cached = { outline, topRegion, bottomRegion, top, bottom, edge };
  return cached;
}
