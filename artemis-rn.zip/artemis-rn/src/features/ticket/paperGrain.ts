import { Skia, SkPath, SkPoint } from '@shopify/react-native-skia';
import { SHEET_H, SHEET_W } from './geometry';

/** A tiny seeded generator: the grain is the same every time, so the ticket never shimmers between renders. */
function rng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface Grain {
  /** Speckle in three strengths, fainter to darker. */
  speckle: { points: SkPoint[]; width: number; alpha: number }[];
  /** Fine paper fibres, as one path. */
  fibres: SkPath;
}

let cached: Grain | undefined;

/** Paper fibre and speckle. Built once. */
export function paperGrain(density = 2600): Grain {
  if (cached) return cached;
  const next = rng(0x9e3779b9);
  const buckets: SkPoint[][] = [[], [], []];
  for (let i = 0; i < density; i++) {
    const x = next() * SHEET_W;
    const y = next() * SHEET_H;
    const r = 0.35 + next() * 0.7;
    const a = 0.03 + next() * 0.06;
    void r;
    buckets[Math.min(2, Math.floor(((a - 0.03) / 0.06) * 3))].push({ x, y });
  }
  const fibres = Skia.PathBuilder.Make();
  for (let i = 0; i < 140; i++) {
    const x = next() * SHEET_W;
    const y = next() * SHEET_H;
    const a = next() * Math.PI;
    const l = 2 + next() * 7;
    fibres.moveTo(x, y);
    fibres.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l);
  }
  cached = {
    speckle: buckets.map((points, i) => ({ points, width: 0.7, alpha: 0.04 + i * 0.02 })),
    fibres: fibres.build(),
  };
  return cached;
}
