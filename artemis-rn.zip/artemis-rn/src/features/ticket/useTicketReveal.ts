import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Easing, useSharedValue, withSpring, withTiming } from 'react-native-reanimated';
import { TicketCutModel, CutEvent } from '../../domain/ticket/cutModel';
import { Audio } from '../../services/AudioService';
import { HapticsService } from '../../services/HapticsService';
import { TicketMetrics } from './geometry';

/**
 * The story of one ticket, from a dark screen to "Welcome aboard".
 *
 *   dark → arriving (slides in, unfolds) → ready ("Your trip is ready") → cutting ("Swipe to cut") → cut → yours → aboard
 *
 * The feel of the cut itself lives in `TicketCutModel` (pure and tested). This hook turns finger positions into that
 * model, and turns what happens in the model into haptics, sound and animation values.
 */
export type TicketStage = 'dark' | 'arriving' | 'ready' | 'cutting' | 'cut' | 'yours' | 'aboard';
const ORDER: TicketStage[] = ['dark', 'arriving', 'ready', 'cutting', 'cut', 'yours', 'aboard'];
export const stageIndex = (s: TicketStage): number => ORDER.indexOf(s);
export const stageAtLeast = (s: TicketStage, min: TicketStage): boolean => stageIndex(s) >= stageIndex(min);

interface Options {
  reduceMotion: boolean;
  /** Called at the moment the paper tears, so the ticket is saved even if the traveler leaves right away. */
  onCut: () => void;
}

const curve = (a: number, b: number, c: number, d: number) => Easing.bezier(a, b, c, d);

export function useTicketReveal({ reduceMotion, onCut }: Options) {
  const [stage, setStageState] = useState<TicketStage>('dark');
  const stageRef = useRef<TicketStage>('dark');
  const setStage = useCallback((s: TicketStage) => { stageRef.current = s; setStageState(s); }, []);
  const [tornAt, setTornAt] = useState<number | undefined>();

  /** Fold angle of the stub over the perforation: 178° (folded over the top half) → 0° (open). */
  const unfold = useSharedValue(178);
  /** 0 = below the screen, 1 = in place. */
  const arrive = useSharedValue(0);
  /** Fraction of the perforation opened behind the finger (after the paper's resistance). */
  const opened = useSharedValue(0);
  const bend = useSharedValue(0);
  /** 0 = whole, 1 = the halves have parted. */
  const parted = useSharedValue(0);
  /** 0 → 1 once "The trip is yours": the top half floats off and the stub settles. */
  const done = useSharedValue(0);
  const fingerX = useSharedValue(0);
  const touching = useSharedValue(0);

  const cut = useRef(new TicketCutModel());
  const minX = useRef(Infinity);
  const maxX = useRef(0);
  const run = useRef(0);
  const onCutRef = useRef(onCut);
  onCutRef.current = onCut;

  const sleep = useCallback((s: number, id: number) => new Promise<boolean>((resolve) => {
    setTimeout(() => resolve(run.current === id), (reduceMotion ? s * 0.3 : s) * 1000);
  }), [reduceMotion]);

  const syncVisuals = useCallback(() => {
    opened.value = cut.current.progress;
    bend.value = stageAtLeast(stageRef.current, 'cut') ? 0 : cut.current.bend;
  }, [opened, bend]);

  const snap = useCallback(() => {
    const id = ++run.current;
    setStage('cut');
    setTornAt(Date.now());
    touching.value = 0;
    HapticsService.play('tear');
    Audio.play('tear');
    onCutRef.current();
    parted.value = reduceMotion ? withTiming(1, { duration: 300 }) : withSpring(1, { damping: 13, stiffness: 120, mass: 1 });
    bend.value = withTiming(0, { duration: 250 });
    void (async () => {
      if (!(await sleep(0.5, id))) return;
      HapticsService.play('completed');
      if (!(await sleep(0.9, id))) return;
      setStage('yours');
      done.value = withTiming(1, { duration: reduceMotion ? 250 : 600, easing: curve(0.4, 0, 0.2, 1) });
      if (!(await sleep(2.0, id))) return;
      setStage('aboard');
    })();
  }, [bend, done, parted, reduceMotion, setStage, sleep, touching]);

  const handle = useCallback((events: CutEvent[]) => {
    for (const e of events) {
      switch (e.type) {
        case 'tick': HapticsService.play('tick'); break;
        case 'resistance': HapticsService.play('cutThreshold'); break;
        case 'separating': Audio.play('paperMove'); break;
        case 'snap': snap(); break;
      }
    }
  }, [snap]);

  /** Plays the reveal. */
  const play = useCallback(() => {
    const id = ++run.current;
    void (async () => {
      if (!(await sleep(0.5, id))) return;
      setStage('arriving');
      HapticsService.play('ticketAppears');
      Audio.play('paperMove');
      arrive.value = withTiming(1, { duration: reduceMotion ? 300 : 1300, easing: curve(0.16, 1, 0.3, 1) });
      unfold.value = reduceMotion ? 0 : withTiming(0, { duration: 1000, easing: curve(0.45, 0, 0.2, 1) });
      if (!(await sleep(1.9, id))) return;
      setStage('ready');
      if (!(await sleep(1.7, id))) return;
      if (stageRef.current === 'ready') setStage('cutting');
    })();
  }, [arrive, reduceMotion, setStage, sleep, unfold]);

  const stop = useCallback(() => { run.current++; }, []);
  useEffect(() => stop, [stop]);

  /** Feed a finger position, in the ticket's own coordinate space. */
  const drag = useCallback((x: number, y: number, ticketWidth: number) => {
    const s = stageRef.current;
    if (s !== 'cutting' && s !== 'ready') return;
    if (s === 'ready') { run.current++; setStage('cutting'); }
    touching.value = 1;
    fingerX.value = Math.min(ticketWidth, Math.max(0, x));
    // The finger has to stay near the perforation for the paper to give.
    if (Math.abs(y - TicketMetrics.cutY) >= 64) return;
    minX.current = Math.min(minX.current, Math.max(0, x));
    maxX.current = Math.max(maxX.current, Math.min(ticketWidth, x));
    const events = cut.current.update((maxX.current - minX.current) / (ticketWidth * 0.94));
    syncVisuals();
    handle(events);
  }, [fingerX, handle, setStage, syncVisuals, touching]);

  /** The finger lifted. If the paper hasn't given way, it settles back. */
  const release = useCallback(() => {
    touching.value = 0;
    if (stageRef.current !== 'cutting') return;
    cut.current.release();
    minX.current = Infinity;
    maxX.current = 0;
    opened.value = withTiming(0, { duration: 400 });
    bend.value = withTiming(0, { duration: 400 });
  }, [bend, opened, touching]);

  /** The accessible way to cut: a button instead of a drag. */
  const cutNow = useCallback(() => {
    const s = stageRef.current;
    if (s !== 'cutting' && s !== 'ready') return;
    run.current++;
    setStage('cutting');
    const events = cut.current.cutNow();
    syncVisuals();
    handle(events);
  }, [handle, setStage, syncVisuals]);

  /** Jump straight to the end (skip). */
  const finish = useCallback(() => {
    run.current++;
    setStage('aboard');
    parted.value = 1;
    unfold.value = 0;
    arrive.value = 1;
    done.value = 1;
  }, [arrive, done, parted, setStage, unfold]);

  return useMemo(
    () => ({ stage, tornAt, unfold, arrive, opened, bend, parted, done, fingerX, touching, play, stop, drag, release, cutNow, finish }),
    [stage, tornAt, unfold, arrive, opened, bend, parted, done, fingerX, touching, play, stop, drag, release, cutNow, finish],
  );
}

export type TicketReveal = ReturnType<typeof useTicketReveal>;
