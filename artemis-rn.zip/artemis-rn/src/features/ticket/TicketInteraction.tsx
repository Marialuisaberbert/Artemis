import React, { useMemo } from 'react';
import { View } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { interpolate, useAnimatedStyle, useDerivedValue } from 'react-native-reanimated';
import { scheduleOnRN } from 'react-native-worklets';
import type { SkImage } from '@shopify/react-native-skia';
import { Icon } from '../../design/Icon';
import type { Trip } from '../../domain/trips/trip';
import { tripDestination } from '../../domain/trips/trip';
import type { TicketFonts } from './fonts';
import { SHEET_H, SHEET_W, TicketMetrics } from './geometry';
import { TicketOverlay } from './TicketOverlay';
import { SheetShadow, TicketSheet } from './TicketSheet';
import { stageAtLeast, TicketReveal } from './useTicketReveal';

const { cutY } = TicketMetrics;
const STUB_SHIFT = cutY / 2;
const PERSPECTIVE = 900;

interface Props {
  trip: Trip;
  reveal: TicketReveal;
  image: SkImage | null;
  fonts: TicketFonts | null;
}

/**
 * The ticket as an object: it slides in, unfolds, waits to be cut, bends under the finger, tears, and parts in two.
 * All state comes from `useTicketReveal`. This view only draws it and forwards the finger.
 */
export function TicketInteraction({ trip, reveal, image, fonts }: Props) {
  const { stage, unfold, arrive, opened, bend, parted, done, fingerX, touching, tornAt } = reveal;
  const canCut = stage === 'ready' || stage === 'cutting';

  // Shadows follow the paper: tighter when whole, deeper once the halves part.
  const topShadow: SheetShadow = {
    dy: useDerivedValue(() => interpolate(parted.value, [0, 1], [4 + bend.value * 4, 16])),
    blur: useDerivedValue(() => interpolate(parted.value, [0, 1], [3 + bend.value * 4, 11])),
    alpha: useDerivedValue(() => 0.28 + parted.value * 0.2),
  };
  const bottomShadow: SheetShadow = {
    dy: useDerivedValue(() => interpolate(parted.value, [0, 1], [4, 16])),
    blur: useDerivedValue(() => interpolate(parted.value, [0, 1], [3, 11])),
    alpha: useDerivedValue(() => 0.28 + parted.value * 0.2),
  };
  const foldDim = useDerivedValue(() => 0.06 * Math.min(1, unfold.value / 90));

  // The whole sheet slides up from below the screen as it arrives.
  const arriveStyle = useAnimatedStyle(() => ({
    opacity: Math.min(1, arrive.value * 12),
    transform: [{ translateY: (1 - arrive.value) * 520 }],
  }));

  // Top half: bends up under the finger, lifts and turns when it parts, floats away when the trip is yours.
  const topOuter = useAnimatedStyle(() => ({
    opacity: 1 - done.value,
    transform: [{ translateY: -parted.value * 58 - bend.value * 3 - done.value * 460 }],
  }));
  const topMid = useAnimatedStyle(() => ({ transform: [{ rotate: `${-6 * parted.value}deg` }] }));
  const topInner = useAnimatedStyle(() => ({ transform: [{ perspective: PERSPECTIVE }, { rotateX: `${-bend.value * 9}deg` }] }));

  // Bottom half (the stub): folded over the top half until the ticket unfolds; drifts down when it parts; settles centred.
  const bottomOuter = useAnimatedStyle(() => ({
    transform: [{ translateY: parted.value * 18 * (1 - done.value) + bend.value * 2 - done.value * STUB_SHIFT }],
  }));
  const bottomMid = useAnimatedStyle(() => ({ transform: [{ rotate: `${3 * parted.value * (1 - done.value)}deg` }] }));
  // Past 90° the underside of the sheet is showing, which is blank. Faces are switched by angle, since backfaceVisibility
  // does not reach the Skia canvases inside them.
  const frontFace = useAnimatedStyle(() => ({ opacity: unfold.value + bend.value * 6 < 90 ? 1 : 0 }));
  const blankFace = useAnimatedStyle(() => ({ opacity: unfold.value + bend.value * 6 >= 90 ? 1 : 0 }));
  const bottomFold = useAnimatedStyle(() => ({ transform: [{ perspective: PERSPECTIVE }, { rotateX: `${unfold.value + bend.value * 6}deg` }] }));

  const pan = useMemo(
    () =>
      Gesture.Pan()
        .enabled(canCut)
        .minDistance(0)
        .onBegin((e) => { scheduleOnRN(reveal.drag, e.x, e.y, SHEET_W); })
        .onChange((e) => { scheduleOnRN(reveal.drag, e.x, e.y, SHEET_W); })
        .onFinalize(() => { scheduleOnRN(reveal.release); }),
    [canCut, reveal.drag, reveal.release],
  );

  const guideOn = stage === 'ready' || stage === 'cutting';
  const fill = { position: 'absolute', left: 0, top: 0, width: SHEET_W, height: SHEET_H } as const;
  const originHinge = `50% ${cutY}px`;

  return (
    <GestureDetector gesture={pan}>
      <Animated.View
        style={[{ width: SHEET_W, height: SHEET_H }, arriveStyle]}
        accessible
        accessibilityLabel={`Your Artemis Trip Ticket to ${tripDestination(trip).city}`}
        accessibilityHint="Drag across the dotted line to cut it, or use the Cut ticket action"
        accessibilityActions={[{ name: 'cut', label: 'Cut ticket' }]}
        onAccessibilityAction={(e) => { if (e.nativeEvent.actionName === 'cut') reveal.cutNow(); }}
      >
        {/* Top half */}
        <Animated.View style={[fill, topOuter]}>
          <Animated.View style={[fill, topMid, { transformOrigin: `20% ${cutY}px` }]}>
            <Animated.View style={[fill, topInner, { transformOrigin: originHinge }]}>
              <TicketSheet trip={trip} face="front" clip="top" image={image} fonts={fonts} shadow={topShadow} />
            </Animated.View>
          </Animated.View>
        </Animated.View>

        {/* Bottom half */}
        <Animated.View style={[fill, bottomOuter, { zIndex: 1 }]}>
          <Animated.View style={[fill, bottomMid, { transformOrigin: `80% ${cutY}px` }]}>
            <Animated.View style={[fill, bottomFold, { transformOrigin: originHinge }]}>
              <Animated.View style={[fill, frontFace]}>
                <TicketSheet trip={trip} face="front" clip="bottom" image={image} fonts={fonts} shadow={bottomShadow} dim={foldDim} />
              </Animated.View>
              {/* Past 90° you see the back of the sheet, which is blank */}
              <Animated.View style={[fill, blankFace, { transform: [{ rotateX: '180deg' }], transformOrigin: originHinge }]}>
                <TicketSheet trip={trip} face="blank" clip="bottom" image={null} fonts={fonts} shadow={bottomShadow} dim={foldDim} />
              </Animated.View>
            </Animated.View>
          </Animated.View>
        </Animated.View>

        {/* Slit, guide, scraps */}
        <View pointerEvents="none" style={[fill, { zIndex: 3 }]}>
          <TicketOverlay guide={guideOn} slit={stage === 'cutting'} opened={opened} touching={touching} fingerX={fingerX} tornAt={stageAtLeast(stage, 'cut') ? tornAt : undefined} />
          {guideOn && (
            <View style={{ position: 'absolute', left: -39, top: cutY - 23 }}>
              <Icon name="scissors" size={18} color="rgba(255,255,255,0.9)" strokeWidth={1.9} />
            </View>
          )}
        </View>
      </Animated.View>
    </GestureDetector>
  );
}
