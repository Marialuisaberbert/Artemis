import React, { useState } from 'react';
import { Pressable, View } from 'react-native';
import { router } from 'expo-router';
import { useImage } from '@shopify/react-native-skia';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CTAButton, RoundIconButton } from '../../design/controls';
import { PhotoBackdrop } from '../../design/PhotoView';
import { photoSource } from '../../design/photos';
import { Caps, Display } from '../../design/text';
import { ticketLabel, tripDestination } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore } from '../../store/useTripStore';
import { useTrip } from '../../store/hooks';
import { useTicketFonts } from './fonts';
import { TicketReveal } from './TicketReveal';
import { TicketStub } from './TicketStub';

/** "VIEW TICKET" from a trip: the souvenir. If the ticket hasn't been cut yet, it opens the reveal so it can be. */
export function TicketScreen({ tripID }: { tripID: string }) {
  const trip = useTrip(tripID);
  const insets = useSafeAreaInsets();
  const [showBack, setShowBack] = useState(false);
  const fonts = useTicketFonts();
  const dest = trip ? tripDestination(trip) : undefined;
  const image = useImage(dest ? (photoSource(dest.photo.file) as number) : undefined);
  if (!trip || !dest) return <View style={{ flex: 1, backgroundColor: '#000' }} />;
  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      {trip.ticketCutAt === undefined ? (
        <TicketReveal trip={trip} onCut={() => getTripStore().cutTicket(tripID)} actions={<CTAButton title="DONE" onPress={() => router.back()} />} />
      ) : (
        <View style={{ flex: 1 }}>
          <PhotoBackdrop destination={dest} blur={34} dim={0.62} drift />
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 26, paddingTop: 20 }}>
            <Caps size={11} tracking={4} opacity={0.7}>{ticketLabel(trip.ticketNumber ?? 1)}</Caps>
            <Display size={32} tracking={5} shrink numberOfLines={1}>{dest.city.toUpperCase()}</Display>
            <Pressable accessibilityRole="button" accessibilityLabel={showBack ? 'Turn the ticket to its front' : 'Turn the ticket over'} onPress={() => { HapticsService.soft(); setShowBack((b) => !b); }}>
              <TicketStub trip={trip} image={image} fonts={fonts} scale={1.05} showsBack={showBack} />
            </Pressable>
            <Caps size={10.5} tracking={2.6} opacity={0.55}>{showBack ? 'TAP TO TURN OVER' : 'TAP TO SEE THE BACK'}</Caps>
          </View>
        </View>
      )}
      <View style={{ position: 'absolute', top: insets.top + 8, left: 20 }}>
        <RoundIconButton icon="close" label="Close" onPress={() => router.back()} />
      </View>
    </View>
  );
}
