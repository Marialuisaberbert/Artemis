import React, { useEffect } from 'react';
import { View } from 'react-native';
import Animated, { Easing, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import type { SkImage } from '@shopify/react-native-skia';
import type { Trip } from '../../domain/trips/trip';
import { tripDestination } from '../../domain/trips/trip';
import type { TicketFonts } from './fonts';
import { SHEET_H, SHEET_W, TicketMetrics } from './geometry';
import { SheetShadow, TicketSheet } from './TicketSheet';

const STUB_H = TicketMetrics.height - TicketMetrics.cutY + 14;
const STUB_OFFSET = TicketMetrics.cutY - 10;

interface Props {
  trip: Trip;
  image: SkImage | null;
  fonts: TicketFonts | null;
  scale?: number;
  showsBack?: boolean;
}

/** The half the traveler keeps: the stub, torn along its top edge. Turn it over to read the trip. */
export function TicketStub({ trip, image, fonts, scale = 1, showsBack = false }: Props) {
  const flip = useSharedValue(showsBack ? 180 : 0);
  useEffect(() => {
    flip.value = withTiming(showsBack ? 180 : 0, { duration: 700, easing: Easing.bezier(0.4, 0, 0.2, 1) });
  }, [showsBack, flip]);
  // At rest (0° or 180°) the transforms are dropped entirely: a 3D-rotated Skia canvas is resampled as a texture and looks soft.
  const atRest = (v: number) => {
    'worklet';
    return v < 0.5 || v > 179.5;
  };
  const turn = useAnimatedStyle(() => ({ transform: atRest(flip.value) ? [] : [{ perspective: 700 }, { rotateY: `${flip.value}deg` }] }));
  // Past 90° the back is showing. Faces are switched by angle rather than backfaceVisibility, which does not reach the Skia canvases.
  const frontStyle = useAnimatedStyle(() => ({ opacity: flip.value < 90 ? 1 : 0 }));
  const backStyle = useAnimatedStyle(() => ({
    opacity: flip.value >= 90 ? 1 : 0,
    transform: flip.value > 179.5 ? [] : [{ rotateY: '180deg' }],
  }));

  const shadow: SheetShadow = {
    dy: useSharedValue(8),
    blur: useSharedValue(5),
    alpha: useSharedValue(0.45),
  };
  const face = { position: 'absolute', left: 0, top: 0, width: SHEET_W, height: STUB_H + 3 } as const;

  return (
    <View
      accessible
      accessibilityRole="button"
      accessibilityLabel={`Artemis Trip Ticket stub, ${tripDestination(trip).city}`}
      accessibilityHint={showsBack ? 'Turns the ticket to its front' : 'Turns the ticket over to read the trip details'}
      style={{ width: SHEET_W * scale, height: (STUB_H + 3) * scale }}
    >
      <View style={{ width: SHEET_W, height: STUB_H + 3, transform: [{ scale }], transformOrigin: '0% 0%' }}>
        <Animated.View style={[{ width: SHEET_W, height: STUB_H + 3 }, turn]}>
          <Animated.View style={[face, frontStyle]}>
            <TicketSheet trip={trip} face="front" clip="bottom" image={image} fonts={fonts} shadow={shadow} offsetY={-STUB_OFFSET} />
          </Animated.View>
          <Animated.View style={[face, backStyle]}>
            <TicketSheet trip={trip} face="back" clip="bottom" image={image} fonts={fonts} shadow={shadow} offsetY={-STUB_OFFSET} />
          </Animated.View>
        </Animated.View>
      </View>
    </View>
  );
}

export const STUB_SIZE = { width: SHEET_W, height: STUB_H + 3, full: SHEET_H };
