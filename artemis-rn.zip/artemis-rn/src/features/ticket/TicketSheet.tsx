import React, { useMemo } from 'react';
import {
  Canvas, ColorMatrix, Glyphs, Group, Image as SkImageNode, LinearGradient, Path, Points, RadialGradient, Rect, RoundedRect,
  Shadow, Skia, SkFont, SkImage, Text as SkText, vec,
} from '@shopify/react-native-skia';
import type { SharedValue } from 'react-native-reanimated';
import { useDerivedValue } from 'react-native-reanimated';
import { logoPathData } from '../../design/logoPath';
import { colors } from '../../design/theme';
import { shortCity } from '../../domain/destinations/geo';
import { hotelBooking, dateRange, ticketLabel, tripDestination, tripNights, tripOrigin, tripTravelers, flightBooking, selectedFlight, selectedHotel, Trip, travelerCount, bookingStatusLabel } from '../../domain/trips/trip';
import { routeCodes } from '../../domain/trips/flights';
import { PAD, SHEET_H, SHEET_W, TicketMetrics, ticketPaths } from './geometry';
import { paperGrain } from './paperGrain';
import type { TicketFonts } from './fonts';

const INK = colors.ink;
const inkA = (a: number) => `rgba(28,25,21,${a})`;
const { cutY } = TicketMetrics;

export type SheetFace = 'front' | 'back' | 'blank';
export type SheetClip = 'top' | 'bottom' | 'none';

export interface SheetShadow {
  dy: SharedValue<number>;
  blur: SharedValue<number>;
  alpha: SharedValue<number>;
}

interface SheetProps {
  trip: Trip;
  face: SheetFace;
  clip: SheetClip;
  image: SkImage | null;
  fonts: TicketFonts | null;
  shadow?: SheetShadow;
  /** Shift the sheet up inside the canvas (the souvenir stub shows only the lower part). */
  offsetY?: number;
  /** 0…1 darkening of the sheet, for a half that is folded over. */
  dim?: SharedValue<number>;
}

/**
 * The ticket, drawn once and clipped twice: the same sheet is the top half, the bottom half, the whole ticket or
 * the souvenir stub, depending on `clip`. The canvas is larger than the sheet so shadows have room.
 */
export function TicketSheet({ trip, face, clip, image, fonts, shadow, offsetY = 0, dim }: SheetProps) {
  const paths = useMemo(() => ticketPaths(), []);
  const visible = clip === 'top' ? paths.top : clip === 'bottom' ? paths.bottom : paths.outline;
  const region = clip === 'top' ? paths.topRegion : clip === 'bottom' ? paths.bottomRegion : undefined;
  const grain = useMemo(() => paperGrain(), []);

  const shadowDy = useDerivedValue(() => shadow?.dy.value ?? 4);
  const shadowBlur = useDerivedValue(() => shadow?.blur.value ?? 3);
  const shadowColor = useDerivedValue(() => `rgba(0,0,0,${shadow?.alpha.value ?? 0.28})`);
  const dimOpacity = useDerivedValue(() => dim?.value ?? 0);

  return (
    <Canvas style={{ position: 'absolute', left: -PAD, top: -PAD + offsetY, width: SHEET_W + PAD * 2, height: SHEET_H + PAD * 2 }} pointerEvents="none">
      <Group transform={[{ translateX: PAD }, { translateY: PAD }]}>
        {/* The shadow the half casts */}
        {shadow && (
          <Path path={visible} color="black">
            <Shadow dx={0} dy={shadowDy} blur={shadowBlur} color={shadowColor} shadowOnly />
          </Path>
        )}
        {/* The thickness of the stock, peeking out under the sheet */}
        <Group clip={region ?? paths.outline}>
          <Path path={paths.edge} color="#C9BDA3" />
        </Group>
        {/* The paper, with the perforation punched all the way through */}
        <Group clip={visible} layer>
          <Rect x={0} y={0} width={SHEET_W} height={SHEET_H}>
            <LinearGradient start={vec(0, 0)} end={vec(SHEET_W, SHEET_H)} colors={[colors.paperLight, colors.paper, colors.paperShade]} />
          </Rect>
          {grain.speckle.map((g, i) => (
            <Points key={i} points={g.points} mode="points" style="stroke" strokeCap="round" strokeWidth={g.width} color={INK} opacity={g.alpha} />
          ))}
          <Path path={grain.fibres} style="stroke" strokeWidth={0.4} color="#C9BDA3" opacity={0.35} />
          <Rect x={0} y={0} width={SHEET_W} height={SHEET_H}>
            <RadialGradient c={vec(SHEET_W * 0.15, SHEET_H * 0.06)} r={320} colors={['rgba(255,255,255,0.35)', 'rgba(255,255,255,0)']} />
          </Rect>
          <Rect x={0} y={SHEET_H / 2} width={SHEET_W} height={SHEET_H / 2}>
            <LinearGradient start={vec(0, SHEET_H / 2)} end={vec(0, SHEET_H)} colors={['rgba(28,25,21,0)', 'rgba(28,25,21,0.06)']} />
          </Rect>
          {fonts && face === 'front' && <FrontContent trip={trip} image={image} fonts={fonts} />}
          {fonts && face === 'back' && <BackContent trip={trip} fonts={fonts} />}
          {dim && <Path path={visible} color="black" opacity={dimOpacity} />}
          <Perforation />
        </Group>
        <Path path={visible} style="stroke" strokeWidth={0.6} color={inkA(0.1)} />
      </Group>
    </Canvas>
  );
}

/** A row of small round holes, punched all the way through the sheet. */
function Perforation() {
  const path = useMemo(() => {
    const b = Skia.PathBuilder.Make();
    for (let x = 20; x < SHEET_W - 16; x += 8.2) b.addCircle(x, cutY, 1.7);
    return b.build();
  }, []);
  return <Path path={path} color="black" blendMode="dstOut" />;
}

// MARK: - Tracked text

interface TrackedProps {
  text: string;
  x: number;
  /** Baseline. */
  y: number;
  font: SkFont;
  tracking?: number;
  color?: string;
  opacity?: number;
  align?: 'left' | 'right';
}

/** Letter-spaced text: Skia has no tracking, so each glyph is placed by hand. */
export function trackedWidth(text: string, font: SkFont, tracking: number): number {
  const ids = font.getGlyphIDs(text);
  const widths = font.getGlyphWidths(ids);
  return widths.reduce((a, b) => a + b, 0) + tracking * Math.max(0, ids.length - 1);
}

export function Tracked({ text, x, y, font, tracking = 2.4, color = INK, opacity = 1, align = 'left' }: TrackedProps) {
  const glyphs = useMemo(() => {
    const ids = font.getGlyphIDs(text);
    const widths = font.getGlyphWidths(ids);
    const total = widths.reduce((a, b) => a + b, 0) + tracking * Math.max(0, ids.length - 1);
    let cx = align === 'right' ? x - total : x;
    return ids.map((id, i) => {
      const g = { id, pos: { x: cx, y } };
      cx += widths[i] + tracking;
      return g;
    });
  }, [text, font, tracking, x, y, align]);
  return <Glyphs font={font} glyphs={glyphs} x={0} y={0} color={color} opacity={opacity} />;
}

// MARK: - Front

function FrontContent({ trip, image, fonts }: { trip: Trip; image: SkImage | null; fonts: TicketFonts }) {
  const dest = tripDestination(trip);
  const city = dest.city.toUpperCase();
  const names = tripTravelers(trip).map((t) => t.firstName.toUpperCase()).join(' + ');
  const number = ticketLabel(trip.ticketNumber ?? 1);
  const origin = shortCity(tripOrigin(trip)).toUpperCase();

  const logo = useMemo(() => Skia.Path.MakeFromSVGString(logoPathData((15 * 104) / 114, 15))!, []);
  const numFont = fonts.sans(10.5);
  const numW = trackedWidth(number, numFont, 1.8);

  // City: 60 (46 when long), shrunk to fit if it would still overflow.
  const baseSize = city.length > 7 ? 46 : 60;
  const measure = fonts.serif(baseSize);
  const rawW = trackedWidth(city, measure, -1.6);
  const size = rawW > SHEET_W - 40 ? Math.max(baseSize * 0.5, (baseSize * (SHEET_W - 40)) / rawW) : baseSize;
  const cityFont = fonts.serif(size);
  const countryFont = fonts.sans(11.5);
  const countryText = dest.country.toUpperCase();
  const countryW = trackedWidth(countryText, countryFont, 4);

  const routeText = `${origin} → ${city}`;
  let routeSize = 21;
  const routeW = trackedWidth(routeText, fonts.mono(21), -0.3);
  if (routeW > SHEET_W - 40) routeSize = Math.max(21 * 0.55, (21 * (SHEET_W - 40)) / routeW);

  return (
    <>
      {/* Header */}
      <Group transform={[{ translateX: 20 }, { translateY: 23.25 }]}>
        <Path path={logo} color={INK} />
      </Group>
      <Tracked text="ARTEMIS" x={41.7} y={34.7} font={fonts.sans(11)} tracking={3.6} />
      <RoundedRect x={SHEET_W - 20 - numW - 16} y={20} width={numW + 16} height={21.5} r={3} style="stroke" strokeWidth={0.8} color={inkA(0.55)} />
      <Tracked text={number} x={SHEET_W - 20 - 8} y={34.2} font={numFont} tracking={1.8} align="right" />

      {/* A small printed photograph, like a plate tipped into an album */}
      <Photo image={image} focusX={dest.photo.focusX} focusY={dest.photo.focusY} x={20} y={56} w={SHEET_W - 40} h={132} />

      {/* The place */}
      <Tracked text={city} x={20} y={204 + size * 0.86} font={cityFont} tracking={-1.6} />
      <Tracked text={countryText} x={20} y={289} font={countryFont} tracking={4} />
      <Rect x={20 + countryW + 10} y={285.5} width={Math.max(0, SHEET_W - 20 - (20 + countryW + 10))} height={0.7} color={inkA(0.35)} />

      {/* The stub */}
      <Tracked text={routeText} x={20} y={cutY + 34 + routeSize * 0.8} font={fonts.mono(routeSize)} tracking={-0.3} />
      <Tracked text={dateRange(trip)} x={20} y={cutY + 34 + 25 + 9 + 11} font={fonts.sans(11.5)} tracking={2.6} opacity={0.85} />
      <Rect x={20} y={cutY + 34 + 25 + 9 + 14 + 9 + 2} width={SHEET_W - 40} height={0.7} color={inkA(0.2)} />
      <Tracked text={names} x={20} y={cutY + 34 + 25 + 9 + 14 + 9 + 2 + 21} font={fonts.sans(12.5)} tracking={2.2} />
      <Tracked text="ARTEMIS TRIP TICKET" x={SHEET_W - 20} y={cutY + 34 + 25 + 9 + 14 + 9 + 2 + 21} font={fonts.sans(7)} tracking={1.6} opacity={0.5} align="right" />
    </>
  );
}

/** The printed photograph: cover-cropped around the subject, a little desaturated and tinted to the paper. */
function Photo({ image, focusX, focusY, x, y, w, h }: { image: SkImage | null; focusX: number; focusY: number; x: number; y: number; w: number; h: number }) {
  const frame = useMemo(() => Skia.RRectXY(Skia.XYWHRect(x, y, w, h), 3, 3), [x, y, w, h]);
  const layout = useMemo(() => {
    if (!image) return undefined;
    const iw = Math.max(1, image.width());
    const ih = Math.max(1, image.height());
    const scale = Math.max(w / iw, h / ih);
    const dw = iw * scale;
    const dh = ih * scale;
    return { x: x + (w - dw) * focusX, y: y + (h - dh) * focusY, w: dw, h: dh };
  }, [image, focusX, focusY, x, y, w, h]);
  // saturation 0.78, contrast 1.04
  const matrix = useMemo(() => {
    const s = 0.78;
    const c = 1.04;
    const lr = 0.2126, lg = 0.7152, lb = 0.0722;
    const t = 0.5 * (1 - c);
    const m = [
      (lr * (1 - s) + s) * c, lg * (1 - s) * c, lb * (1 - s) * c, 0, t,
      lr * (1 - s) * c, (lg * (1 - s) + s) * c, lb * (1 - s) * c, 0, t,
      lr * (1 - s) * c, lg * (1 - s) * c, (lb * (1 - s) + s) * c, 0, t,
      0, 0, 0, 1, 0,
    ];
    return m;
  }, []);
  return (
    <>
      <Group clip={frame}>
        <Rect x={x} y={y} width={w} height={h} color="#d9cfba" />
        {image && layout && (
          <SkImageNode image={image} x={layout.x} y={layout.y} width={layout.w} height={layout.h} fit="fill">
            <ColorMatrix matrix={matrix} />
          </SkImageNode>
        )}
        <Rect x={x} y={y} width={w} height={h} color={colors.paper} opacity={0.1} blendMode="multiply" />
      </Group>
      <RoundedRect x={x} y={y} width={w} height={h} r={3} style="stroke" strokeWidth={0.7} color={inkA(0.35)} />
    </>
  );
}

// MARK: - Back

/** The back of the half the traveler keeps: the trip, in plain type. It lives in the stub's area of the sheet. */
function BackContent({ trip, fonts }: { trip: Trip; fonts: TicketFonts }) {
  const dest = tripDestination(trip);
  const number = ticketLabel(trip.ticketNumber ?? 1);
  const logo = useMemo(() => Skia.Path.MakeFromSVGString(logoPathData((12 * 104) / 114, 12))!, []);
  const flight = selectedFlight(trip);
  const hotel = selectedHotel(trip);
  const fb = flightBooking(trip);
  const travelers = tripTravelers(trip);

  const cells: { x: number; y: number; label: string; value: string; detail?: string }[] = [];
  const colW = (SHEET_W - 40 - 14) / 2;
  const x0 = 20;
  const x1 = 20 + colW + 14;
  const row1 = cutY + 24 + 11 + 12 + 11;
  const row2 = row1 + 46;
  cells.push({ x: x0, y: row1, label: 'TRAVELERS', value: travelers.map((t) => t.firstName).join(' & '), detail: `${travelerCount(trip)} travelers` });
  cells.push({ x: x1, y: row1, label: 'NIGHTS', value: `${tripNights(trip)} in ${dest.city}`, detail: titleCase(dateRange(trip)) });
  cells.push(flight
    ? { x: x0, y: row2, label: 'FLIGHTS', value: flight.airline, detail: routeCodes(flight).join(' · ') }
    : { x: x0, y: row2, label: 'FLIGHTS', value: 'To be booked' });
  if (hotel && hotelBooking(trip)) cells.push({ x: x1, y: row2, label: 'STAY', value: hotel.name, detail: hotel.neighborhood });
  else if (fb) cells.push({ x: x1, y: row2, label: 'BOOKED', value: titleCase(bookingStatusLabel(fb)), detail: fb.reference });
  else cells.push({ x: x1, y: row2, label: 'STAY', value: 'To be booked' });

  return (
    <>
      <Group transform={[{ translateX: 20 }, { translateY: cutY + 24 - 1 }]}>
        <Path path={logo} color={INK} />
      </Group>
      <Tracked text="TRIP DETAILS" x={20 + 11 + 8} y={cutY + 24 + 9} font={fonts.sans(9.5)} tracking={3} />
      <Tracked text={number} x={SHEET_W - 20} y={cutY + 24 + 9} font={fonts.sans(9.5)} tracking={1.6} align="right" />
      <Rect x={20} y={cutY + 24 + 12 + 9} width={SHEET_W - 40} height={0.7} color={inkA(0.22)} />
      {cells.map((c) => (
        <React.Fragment key={c.label}>
          <Tracked text={c.label} x={c.x} y={c.y} font={fonts.sans(7.5)} tracking={2.2} opacity={0.55} />
          <FitText text={c.value} x={c.x} y={c.y + 15} maxWidth={colW} font={fonts} size={13.5} />
          {c.detail && <FitText text={c.detail} x={c.x} y={c.y + 27} maxWidth={colW} font={fonts} size={9.5} sans opacity={0.6} />}
        </React.Fragment>
      ))}
      <Tracked text="ARTEMIS TRIP TICKET · A KEEPSAKE" x={20} y={row2 + 46} font={fonts.sans(6.5)} tracking={1.6} opacity={0.5} />
    </>
  );
}

const titleCase = (s: string): string => s.toLowerCase().replace(/(^|\s)\S/g, (m) => m.toUpperCase());

/** A single line that shrinks to fit, like `minimumScaleFactor`. */
function FitText({ text, x, y, maxWidth, font, size, sans = false, opacity = 1 }: { text: string; x: number; y: number; maxWidth: number; font: TicketFonts; size: number; sans?: boolean; opacity?: number }) {
  const make = (s: number) => (sans ? font.sans(s, '400') : font.serif(s));
  const w = make(size).measureText(text).width;
  const scaled = w > maxWidth ? Math.max(size * (sans ? 0.7 : 0.65), (size * maxWidth) / w) : size;
  return <SkText x={x} y={y} text={text} font={make(scaled)} color={INK} opacity={opacity} />;
}

