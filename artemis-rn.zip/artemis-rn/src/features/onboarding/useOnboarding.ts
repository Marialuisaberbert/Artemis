import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Easing, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import { flyCamera, useGlobeCamera } from '../../design/globe/Globe';
import { midpoint, shortestLon } from '../../design/globe/math';
import { Destinations } from '../../domain/destinations/destinations';
import { Place, rioPlace, startingPoints } from '../../domain/destinations/place';
import { demoPolicy } from '../../domain/trust/demoData';
import { seedRome } from '../../domain/trips/seed';
import type { Trip } from '../../domain/trips/trip';
import { Audio } from '../../services/AudioService';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore, tripStore } from '../../store/useTripStore';

/**
 * The cinematic first minute. No forms: a story, two questions (where from, where to), and a ticket to cut.
 *
 *   takeoff → route → welcome → location → destinations → personal → together → merge → place (book) → ticket
 */
export const STEPS = ['takeoff', 'route', 'welcome', 'location', 'destinations', 'personal', 'together', 'merge', 'place', 'ticket'] as const;
export type Step = (typeof STEPS)[number];
export const stepIndex = (s: Step): number => STEPS.indexOf(s);
/** Steps where the world is the backdrop. */
export const isWorld = (s: Step): boolean => stepIndex(s) <= stepIndex('destinations');

const pull = Easing.bezier(0.45, 0, 0.15, 1);

export function useOnboarding() {
  const reduce = useReducedMotion();
  const [step, setStep] = useState<Step>('takeoff');
  const [showRoute, setShowRoute] = useState(false);
  const [flight, setFlight] = useState(0);
  const [origin, setOrigin] = useState<Place>(() => getTripStore().currentPlace ?? rioPlace);
  const [destinationID, setDestinationID] = useState('rome');
  const [choosingCity, setChoosingCity] = useState(false);
  const [locationNote, setLocationNote] = useState<string | undefined>();
  const [originConfirmed, setOriginConfirmed] = useState(false);
  const [merged, setMerged] = useState(false);
  const [checks, setChecks] = useState(0);
  const [booking, setBooking] = useState(false);

  const cam = useGlobeCamera({ lat: -22.9, lon: -43.2, radius: 2.4, centerY: 1.55 });
  const globeOpacity = useSharedValue(0);
  const routePosition = useSharedValue(0);
  const reveal = useSharedValue(0);
  const run = useRef(0);
  const originRef = useRef(origin);
  originRef.current = origin;
  const destRef = useRef(destinationID);
  destRef.current = destinationID;

  const destination = useMemo(() => Destinations.named(destinationID) ?? Destinations.rome, [destinationID]);
  const originCoord = useMemo(() => ({ lat: origin.latitude, lon: origin.longitude }), [origin]);
  const destinationCoord = useMemo(() => ({ lat: destination.latitude, lon: destination.longitude }), [destination]);

  /** The sample trip the story ends on: yours and Sofia's, to wherever you chose. */
  const sampleTrip = useMemo<Trip>(() => {
    const t = seedRome(Date.now());
    return {
      ...t, destinationID, originCode: origin.airportCode, ticketNumber: 1,
      members: t.members.map((m, i) => (i === 1 ? { ...m, invite: 'joined' as const } : m)),
    };
  }, [destinationID, origin.airportCode]);

  const sleep = useCallback((s: number, id: number) => new Promise<boolean>((r) => setTimeout(() => r(run.current === id), (reduce ? s * 0.35 : s) * 1000)), [reduce]);

  const launchPlane = useCallback(() => {
    setFlight((f) => f + 1);
    HapticsService.play('takeoff');
    Audio.play('takeoff');
  }, []);

  const routeCamera = useCallback((duration: number) => {
    const mid = midpoint({ lat: originRef.current.latitude, lon: originRef.current.longitude }, { lat: Destinations.named(destRef.current)!.latitude, lon: Destinations.named(destRef.current)!.longitude });
    flyCamera(cam, { radius: 0.62, centerY: 0.4, lat: mid.lat * 0.8, lon: mid.lon, duration, curve: [0.45, 0, 0.15, 1] });
  }, [cam]);

  /** Dark. The world comes up under a low plane, the camera pulls back and the route draws itself. */
  const begin = useCallback(() => {
    const id = ++run.current;
    void (async () => {
      globeOpacity.value = withTiming(1, { duration: 1400, easing: Easing.out(Easing.ease) });
      if (!(await sleep(1.1, id))) return;
      launchPlane();
      if (!(await sleep(reduce ? 0.5 : 2.3, id))) return;
      setStep('route');
      routeCamera(reduce ? 800 : 3200);
      if (!(await sleep(0.7, id))) return;
      setShowRoute(true);
      await new Promise((r) => setTimeout(r, 60));
      routePosition.value = withTiming(1, { duration: reduce ? 800 : 2600, easing: Easing.inOut(Easing.ease) });
      if (!(await sleep(2.9, id))) return;
      setStep('welcome');
    })();
  }, [globeOpacity, launchPlane, reduce, routeCamera, routePosition, sleep]);

  const stop = useCallback(() => { run.current++; }, []);
  useEffect(() => stop, [stop]);

  const skipIntro = useCallback(() => {
    run.current++;
    setShowRoute(true);
    routePosition.value = 1;
    globeOpacity.value = 1;
    routeCamera(800);
    setStep('welcome');
  }, [globeOpacity, routeCamera, routePosition]);

  const flyTo = useCallback((c: { lat: number; lon: number }, radius: number, centerY: number) => {
    flyCamera(cam, { lat: c.lat, lon: c.lon, radius, centerY, duration: 1600 });
  }, [cam]);

  /** "LET'S FLY": the plane sweeps across and the world turns to where you are. */
  const letsFly = useCallback(() => {
    launchPlane();
    setStep('location');
    flyTo({ lat: originRef.current.latitude, lon: originRef.current.longitude }, 0.62, 0.4);
  }, [flyTo, launchPlane]);

  // MARK: Destinations

  const focusDestination = useCallback(() => {
    const o = originRef.current;
    const d = Destinations.named(destRef.current)!;
    const mid = midpoint({ lat: o.latitude, lon: o.longitude }, { lat: d.latitude, lon: d.longitude });
    flyCamera(cam, { lat: mid.lat * 0.8, lon: mid.lon, radius: 0.54, centerY: 0.56, duration: 1500 });
    const id = ++run.current;
    routePosition.value = 0;
    void (async () => {
      await new Promise((r) => setTimeout(r, 200));
      if (run.current !== id) return;
      routePosition.value = withTiming(1, { duration: 2400, easing: Easing.inOut(Easing.ease) });
    })();
  }, [cam, routePosition]);

  const toDestinations = useCallback(() => {
    setStep('destinations');
    setShowRoute(true);
    routePosition.value = 0;
    focusDestination();
  }, [focusDestination, routePosition]);

  const confirmOrigin = useCallback((p: Place) => {
    setOriginConfirmed(true);
    originRef.current = p;
    flyTo({ lat: p.latitude, lon: p.longitude }, 0.62, 0.4);
    const id = ++run.current;
    setTimeout(() => { if (run.current === id) toDestinations(); }, 1600);
  }, [flyTo, toDestinations]);

  const useMyLocation = useCallback(() => {
    const store = getTripStore();
    store.setUseLiveLocation(true);
    // The permission prompt takes as long as it takes; the store tells us how it ended.
    const unsub = tripStore.subscribe((s) => {
      const k = s.locationStatus.kind;
      if (k === 'requesting') return;
      unsub();
      const p = s.currentPlace;
      setOrigin(p);
      setLocationNote(s.locationStatus.kind === 'unavailable' ? `${s.locationStatus.reason.replace(/\.$/, '')}, so we'll start from ${p.name}.` : undefined);
      confirmOrigin(p);
    });
  }, [confirmOrigin]);

  const chooseCity = useCallback(() => setChoosingCity(true), []);

  const choose = useCallback((place: Place) => {
    getTripStore().chooseLocation(place);
    setOrigin(place);
    HapticsService.select();
    setChoosingCity(false);
    confirmOrigin(place);
  }, [confirmOrigin]);

  const select = useCallback((id: string) => {
    if (id === destRef.current) return;
    HapticsService.select();
    destRef.current = id;
    setDestinationID(id);
    focusDestination();
  }, [focusDestination]);

  // MARK: The rest of the story

  const advance = useCallback(() => {
    const next = STEPS[stepIndex(step) + 1];
    if (!next) return;
    run.current++;
    HapticsService.tap();
    setStep(next);
    reveal.value = 0;
    if (next === 'together') reveal.value = withTiming(1, { duration: 1200, easing: Easing.bezier(0.4, 0, 0.2, 1) });
    if (next === 'merge') {
      setMerged(false);
      const id = ++run.current;
      void (async () => {
        await new Promise((r) => setTimeout(r, 1600));
        if (run.current !== id) return;
        setMerged(true);
        await new Promise((r) => setTimeout(r, 1200));
        if (run.current !== id) return;
        HapticsService.play('tick');
      })();
    }
  }, [reveal, step]);

  /** BOOK: identity, policy, payment, each quietly checked, then the ticket. */
  const book = useCallback(() => {
    if (booking) return;
    setBooking(true);
    HapticsService.tap();
    const id = ++run.current;
    void (async () => {
      for (let i = 1; i <= 3; i++) {
        await new Promise((r) => setTimeout(r, 700));
        if (run.current !== id) return;
        setChecks(i);
        HapticsService.soft();
      }
      await new Promise((r) => setTimeout(r, 900));
      if (run.current !== id) return;
      setStep('ticket');
    })();
  }, [booking]);

  /** Onboarding is done. The defaults stand in for the questions we chose not to ask; Profile changes them. */
  const complete = useCallback(() => {
    HapticsService.play('completed');
    getTripStore().completeOnboarding(demoPolicy(), 600, 200);
  }, []);

  return {
    step, showRoute, flight, origin, destination, destinationID, choosingCity, locationNote, originConfirmed, merged, checks, booking,
    cam, globeOpacity, routePosition, reveal, originCoord, destinationCoord, sampleTrip, startingPoints,
    begin, stop, skipIntro, letsFly, useMyLocation, chooseCity, choose, select, toDestinations, advance, book, complete, reduce,
  };
}

export type Onboarding = ReturnType<typeof useOnboarding>;
export { shortestLon };
