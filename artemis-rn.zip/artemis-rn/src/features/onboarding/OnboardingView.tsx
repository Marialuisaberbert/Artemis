import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View, useWindowDimensions } from 'react-native';
import Animated, { Easing, FadeIn, FadeInDown, FadeOut, useAnimatedStyle, withTiming } from 'react-native-reanimated';
import { BlurView } from 'expo-blur';
import Svg, { Line } from 'react-native-svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ArtemisLogo } from '../../design/ArtemisLogo';
import { CTAButton, GlassPanel } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { NightBackdrop } from '../../design/NightBackdrop';
import { PhotoBackdrop } from '../../design/PhotoView';
import { PlaneFlyby } from '../../design/PlaneFlyby';
import { Globe } from '../../design/globe/Globe';
import { Body, Caps, Display, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { TravelerAvatar } from '../../design/widgets';
import { Destinations } from '../../domain/destinations/destinations';
import { Travelers } from '../../domain/matching/traveler';
import { dateRange } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { TicketReveal } from '../ticket/TicketReveal';
import { isWorld, Onboarding, stepIndex, useOnboarding } from './useOnboarding';

/** The first minute of Artemis, told as a journey: a plane, the world, two people, one trip, one ticket. */
export function OnboardingView() {
  const model = useOnboarding();
  const { step } = model;
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();

  useEffect(() => { model.begin(); return model.stop; }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const world = isWorld(step);
  const showMarkers = step === 'destinations';
  const markers = useMemo(
    () => (showMarkers ? Destinations.all.filter((d) => d.airport.code !== model.origin.airportCode).map((d) => ({ id: d.id, label: d.city, lat: d.latitude, lon: d.longitude })) : []),
    [showMarkers, model.origin.airportCode],
  );
  const routeStops = useMemo(() => [model.originCoord, model.destinationCoord], [model.originCoord, model.destinationCoord]);
  const worldStyle = useAnimatedStyle(() => ({ opacity: model.globeOpacity.value }));
  const takeoff = step === 'takeoff';

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      {world && (
        <Animated.View exiting={FadeOut.duration(600)} style={StyleSheet.absoluteFill}>
          <NightBackdrop glow={0.55} />
          <Animated.View style={[StyleSheet.absoluteFill, worldStyle]}>
            <Globe
              width={width} height={height} camera={model.cam} markers={markers} selectedId={showMarkers ? model.destinationID : undefined}
              you={stepIndex(step) >= stepIndex('welcome') ? model.originCoord : undefined}
              route={model.showRoute ? { stops: routeStops, position: model.routePosition } : undefined}
              interactive={showMarkers} onSelectMarker={model.select} driftDegPerSec={stepIndex(step) >= stepIndex('welcome') ? 0.35 : 0}
            />
          </Animated.View>
          {model.flight > 0 && !model.reduce && stepIndex(step) <= stepIndex('location') && (
            <PlaneFlyby
              key={model.flight} width={width} height={height} flightKey={model.flight} duration={takeoff ? 2.6 : 1.5}
              from={{ x: -0.2, y: takeoff ? 0.78 : 0.6 }} to={{ x: 1.25, y: takeoff ? 0.16 : 0.12 }} bow={takeoff ? -0.2 : -0.12}
              size={takeoff ? 74 : 60} recede={0.55} easing={takeoff ? 'accelerate' : 'smooth'}
            />
          )}
        </Animated.View>
      )}

      {step === 'welcome' && <Scene key="welcome"><WelcomeScene model={model} /></Scene>}
      {step === 'location' && <Scene key="location"><LocationScene model={model} /></Scene>}
      {step === 'destinations' && <Scene key="destinations"><DestinationsScene model={model} /></Scene>}
      {step === 'personal' && <Scene key="personal"><PersonalScene model={model} /></Scene>}
      {step === 'together' && <Scene key="together"><TogetherScene model={model} /></Scene>}
      {step === 'merge' && <Scene key="merge"><MergeScene model={model} /></Scene>}
      {step === 'place' && <Scene key="place"><PlaceScene model={model} /></Scene>}
      {step === 'ticket' && (
        <Scene key="ticket">
          <TicketReveal trip={model.sampleTrip} confirmation="BOOKING CONFIRMED" onCut={() => {}} actions={<CTAButton title="START EXPLORING" onPress={model.complete} />} />
        </Scene>
      )}

      {stepIndex(step) < stepIndex('welcome') && (
        <Animated.View exiting={FadeOut} style={{ position: 'absolute', right: 22, top: insets.top + 8 }}>
          <Pressable accessibilityRole="button" accessibilityLabel="Skip the intro" onPress={model.skipIntro} style={{ minWidth: 44, minHeight: 44, alignItems: 'center', justifyContent: 'center' }}>
            <Caps size={11} tracking={2.4} opacity={0.6}>SKIP</Caps>
          </Pressable>
        </Animated.View>
      )}
    </View>
  );
}

const Scene = ({ children }: { children: React.ReactNode }) => (
  <Animated.View entering={FadeIn.duration(800)} exiting={FadeOut.duration(400)} style={StyleSheet.absoluteFill}>{children}</Animated.View>
);

/** A scene's own timing: things appear one after another, and the way forward appears last. */
function Reveal({ delay, children, style }: { delay: number; children: React.ReactNode; style?: object }) {
  return <Animated.View entering={FadeInDown.delay(delay * 1000).duration(900)} style={style}>{children}</Animated.View>;
}

function useSceneInsets() {
  const insets = useSafeAreaInsets();
  return { paddingHorizontal: 26, paddingTop: insets.top + 12, paddingBottom: Math.max(insets.bottom, 12) + 12 };
}

// MARK: - Scenes

function WelcomeScene({ model }: { model: Onboarding }) {
  const pad = useSceneInsets();
  return (
    <View style={[{ flex: 1 }, pad]}>
      <Reveal delay={0.1}><ArtemisLogo size={26} /></Reveal>
      <View style={{ flex: 1 }} />
      <View style={{ gap: 14 }}>
        <Reveal delay={0.5}><Caps size={11.5} tracking={4} opacity={0.7}>WELCOME ABOARD</Caps></Reveal>
        <Reveal delay={0.9}><Display size={36} tracking={1.5}>{'YOUR JOURNEY\nSTARTS HERE'}</Display></Reveal>
      </View>
      <Reveal delay={1.7} style={{ marginTop: 34 }}><CTAButton title="LET'S FLY" icon="arrowRight" onPress={model.letsFly} /></Reveal>
    </View>
  );
}

function LocationScene({ model }: { model: Onboarding }) {
  const pad = useSceneInsets();
  // The tap that opened this scene must not also press a button that has just appeared under the finger.
  const [armed, setArmed] = useState(false);
  useEffect(() => { const t = setTimeout(() => setArmed(true), 700); return () => clearTimeout(t); }, []);
  return (
    <View style={[{ flex: 1 }, pad]} pointerEvents={armed ? 'auto' : 'none'}>
      <View style={{ flex: 1 }} />
      <View style={{ gap: 14, marginBottom: 24 }}>
        <Caps size={10.5} tracking={3.4} opacity={0.55}>STEP 1 OF 2</Caps>
        <Display size={36} tracking={1.5}>{'WHERE ARE YOU\nSTARTING FROM?'}</Display>
      </View>
      {model.originConfirmed ? (
        <Animated.View entering={FadeIn} style={{ gap: 6 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <Icon name="location" size={16} color="#fff" strokeWidth={2.2} />
            <Caps size={15} tracking={2.4} opacity={1}>{model.origin.name.toUpperCase()}</Caps>
          </View>
          {model.locationNote && <Body size={13} opacity={0.65}>{model.locationNote}</Body>}
        </Animated.View>
      ) : model.choosingCity ? (
        <Animated.View entering={FadeIn} style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
          {model.startingPoints.map((p) => (
            <Pressable key={p.airportCode} accessibilityRole="button" accessibilityLabel={p.name} onPress={() => model.choose(p)}
              style={{ minHeight: 46, minWidth: 130, flexGrow: 1, borderRadius: 999, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center', paddingHorizontal: 12 }}>
              <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
              <Caps size={11.5} tracking={1.6} opacity={1} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>{p.name.toUpperCase()}</Caps>
            </Pressable>
          ))}
        </Animated.View>
      ) : (
        <Animated.View entering={FadeIn} style={{ gap: 10 }}>
          <CTAButton title="USE MY LOCATION" icon="location" onPress={model.useMyLocation} />
          <CTAButton title="CHOOSE A CITY" kind="ghost" onPress={model.chooseCity} />
        </Animated.View>
      )}
    </View>
  );
}

function DestinationsScene({ model }: { model: Onboarding }) {
  const pad = useSceneInsets();
  const d = model.destination;
  return (
    <View style={[{ flex: 1 }, pad]} pointerEvents="box-none">
      <View style={{ gap: 10, marginTop: 58 }} pointerEvents="none">
        <Caps size={10.5} tracking={3.4} opacity={0.55}>STEP 2 OF 2</Caps>
        <Display size={30} tracking={1.5}>{'WHERE DO YOU\nWANT TO GO?'}</Display>
      </View>
      <View style={{ flex: 1 }} pointerEvents="none" />
      <Animated.View key={d.id} entering={FadeIn.duration(400)} style={{ gap: 4 }} pointerEvents="none">
        <Display size={40} tracking={2} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>{d.city.toUpperCase()}</Display>
        <Caps size={11} tracking={3.6} opacity={0.7}>{d.country.toUpperCase()}</Caps>
      </Animated.View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -26, marginTop: 14, flexGrow: 0 }} contentContainerStyle={{ paddingHorizontal: 26, gap: 8 }}>
        {Destinations.all.filter((x) => x.airport.code !== model.origin.airportCode).map((x) => {
          const on = x.id === model.destinationID;
          return (
            <Pressable key={x.id} accessibilityRole="button" accessibilityState={{ selected: on }} accessibilityLabel={x.city} onPress={() => model.select(x.id)}
              style={{ minHeight: 44, paddingHorizontal: 14, borderRadius: 999, justifyContent: 'center', backgroundColor: on ? '#fff' : 'rgba(255,255,255,0.12)', borderWidth: 1, borderColor: on ? 'transparent' : 'rgba(255,255,255,0.25)' }}>
              <Caps size={10.5} tracking={1.8} opacity={on ? 1 : 0.75} color={on ? '#000' : '#fff'}>{x.city.toUpperCase()}</Caps>
            </Pressable>
          );
        })}
      </ScrollView>
      <CTAButton title="CONTINUE" onPress={model.advance} style={{ marginTop: 16 }} />
    </View>
  );
}

/** A full-screen statement, over the place you chose. */
function StatementScene({ model, blur = 26, dim = 0.6, children }: { model: Onboarding; blur?: number; dim?: number; children: React.ReactNode }) {
  const [canContinue, setCanContinue] = useState(false);
  const insets = useSafeAreaInsets();
  useEffect(() => { const t = setTimeout(() => setCanContinue(true), model.reduce ? 700 : 2200); return () => clearTimeout(t); }, [model.reduce]);
  return (
    <View style={{ flex: 1 }}>
      <PhotoBackdrop destination={model.destination} blur={blur} dim={dim} bottomScrim={0.5} />
      <View style={{ flex: 1, paddingHorizontal: 26, paddingTop: insets.top + 60, paddingBottom: Math.max(insets.bottom, 12) + 12 }}>
        {children}
        <View style={{ minHeight: 58, justifyContent: 'flex-end' }}>
          {canContinue && <Animated.View entering={FadeIn.duration(800)}><CTAButton title="CONTINUE" kind="ghost" onPress={model.advance} /></Animated.View>}
        </View>
      </View>
    </View>
  );
}

function PersonalScene({ model }: { model: Onboarding }) {
  return (
    <StatementScene model={model}>
      <View style={{ flex: 1, justifyContent: 'flex-end', gap: 14, paddingBottom: 30 }}>
        <Reveal delay={0.3}><Display size={34} tracking={1.5}>{'TRAVEL SHOULD\nFEEL PERSONAL.'}</Display></Reveal>
        <Reveal delay={1.2}><Body size={16} opacity={0.75}>Not a list of results. A trip that is yours.</Body></Reveal>
      </View>
    </StatementScene>
  );
}

function TogetherScene({ model }: { model: Onboarding }) {
  const gap = 96;
  const lineW = gap * 2 - 80;
  const lineStyle = useAnimatedStyle(() => ({ width: lineW * model.reveal.value }));
  const planeStyle = useAnimatedStyle(() => ({ transform: [{ translateX: lineW * model.reveal.value - 11 }], opacity: model.reveal.value > 0.02 && model.reveal.value < 0.99 ? 1 : 0 }));
  const sofiaStyle = useAnimatedStyle(() => ({ opacity: model.reveal.value > 0.15 ? 1 : 0.15 }));
  const person = (t: typeof Travelers.maria) => (
    <View style={{ alignItems: 'center', gap: 10 }}>
      <View style={{ width: 76, height: 76, borderRadius: 38, overflow: 'hidden', borderWidth: 1.2, borderColor: 'rgba(255,255,255,0.55)', alignItems: 'center', justifyContent: 'center' }}>
        <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
        <T style={{ color: '#fff', fontSize: 24, fontWeight: '600', letterSpacing: 1 }} maxFontSizeMultiplier={1.1}>{t.firstName.charAt(0)}{t.lastName.charAt(0)}</T>
      </View>
      <Caps size={11} tracking={3} opacity={1}>{t.firstName.toUpperCase()}</Caps>
    </View>
  );
  return (
    <StatementScene model={model} blur={30} dim={0.66}>
      <Reveal delay={0.2}><Display size={34} tracking={1.5}>{'TRAVEL WITH\nSOMEONE.'}</Display></Reveal>
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <View style={{ height: 150, alignItems: 'center', justifyContent: 'center' }}>
          <View style={{ position: 'absolute', top: 36, height: 4, width: lineW, left: '50%', marginLeft: -lineW / 2 }}>
            <Animated.View style={[{ height: 4, overflow: 'hidden' }, lineStyle]}>
              <Svg width={lineW} height={4}><Line x1={0} y1={2} x2={lineW} y2={2} stroke="rgba(255,255,255,0.7)" strokeWidth={1.4} strokeLinecap="round" strokeDasharray="1 6" /></Svg>
            </Animated.View>
            <Animated.View style={[{ position: 'absolute', top: -9, left: 0 }, planeStyle]}><Icon name="plane" size={22} color="#fff" /></Animated.View>
          </View>
          <View style={{ position: 'absolute', left: '50%', marginLeft: -gap - 38 }}>{person(Travelers.maria)}</View>
          <Animated.View style={[{ position: 'absolute', left: '50%', marginLeft: gap - 38 }, sofiaStyle]}>{person(Travelers.sofia)}</Animated.View>
        </View>
      </View>
    </StatementScene>
  );
}

function MergeScene({ model }: { model: Onboarding }) {
  const m = model.merged;
  return (
    <StatementScene model={model} blur={30} dim={0.7}>
      <Reveal delay={0.2}><Display size={30} tracking={1.5}>{'TWO PEOPLE.\nTWO PREFERENCES.\nONE TRIP.'}</Display></Reveal>
      <Reveal delay={0.8} style={{ flex: 1 }}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <MergeCard name="MARIA" rows={['$600', '1 STOP MAX', 'LATER FLIGHT']} merged={m} from={-84} />
          <MergeCard name="SOFIA" rows={['$800', 'NONSTOP', 'CENTRAL HOTEL']} merged={m} from={84} />
          <MergedCard merged={m} />
        </View>
      </Reveal>
    </StatementScene>
  );
}

const MERGE = { duration: 1400, easing: Easing.bezier(0.5, 0, 0.15, 1) };

/** Two preference cards slide together and dissolve into one shared card. */
function MergeCard({ name, rows, merged, from }: { name: string; rows: string[]; merged: boolean; from: number }) {
  const style = useAnimatedStyle(() => ({
    position: 'absolute',
    opacity: withTiming(merged ? 0 : 1, MERGE),
    transform: [{ translateX: withTiming(merged ? 0 : from, MERGE) }, { scale: withTiming(merged ? 0.92 : 1, MERGE) }],
  }));
  return (
    <Animated.View style={style}>
      <GlassPanel radius={18} padding={16} style={{ width: 152 }}>
        <View style={{ gap: 9 }}>
          <Caps size={11} tracking={3} opacity={1}>{name}</Caps>
          <View style={{ height: 1, backgroundColor: 'rgba(255,255,255,0.2)' }} />
          {rows.map((r) => <Caps key={r} size={11.5} tracking={1.6} weight="500" opacity={0.85}>{r}</Caps>)}
        </View>
      </GlassPanel>
    </Animated.View>
  );
}

function MergedCard({ merged }: { merged: boolean }) {
  const style = useAnimatedStyle(() => ({ opacity: withTiming(merged ? 1 : 0, MERGE), transform: [{ scale: withTiming(merged ? 1 : 0.9, MERGE) }] }));
  const row = (a: string, b: string) => (
    <View key={a} style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
      <Caps size={12} tracking={1.6} weight="500" opacity={1}>{a}</Caps>
      <Caps size={9} tracking={2} opacity={0.6}>{b}</Caps>
    </View>
  );
  return (
    <Animated.View style={style}>
      <GlassPanel radius={20} padding={18} style={{ width: 240 }}>
        <View style={{ gap: 9 }}>
          <Caps size={11} tracking={3} opacity={1}>ROME · YOUR TRIP</Caps>
          <View style={{ height: 1, backgroundColor: 'rgba(255,255,255,0.3)' }} />
          {row('$600', 'SHARED')}
          {row('1 STOP', 'FLEXIBLE')}
          {row('CENTRAL HOTEL', 'SHARED')}
        </View>
      </GlassPanel>
    </Animated.View>
  );
}

function PlaceScene({ model }: { model: Onboarding }) {
  const insets = useSafeAreaInsets();
  const d = model.destination;
  return (
    <View style={{ flex: 1 }}>
      <PhotoBackdrop destination={d} blur={0} dim={0.05} bottomScrim={0.85} />
      <View style={{ flex: 1, paddingHorizontal: 26, paddingBottom: Math.max(insets.bottom, 12) + 12 }}>
        <View style={{ flex: 1 }} />
        <Reveal delay={0.3} style={{ gap: 6 }}>
          <Caps size={11.5} tracking={4} opacity={0.8}>{d.country.toUpperCase()}</Caps>
          <Display size={64} tracking={2} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5}>{d.city.toUpperCase()}</Display>
          <Caps size={11} tracking={2.6} opacity={0.85} style={{ marginTop: 4 }}>{`${dateRange(model.sampleTrip)} · MARIA + SOFIA`}</Caps>
        </Reveal>
        {/* What "book" quietly means: who's asking, whether it's allowed, whether the money is there. */}
        <View style={{ flexDirection: 'row', gap: 18, marginTop: 22, height: 26, alignItems: 'center' }}>
          {['IDENTITY', 'POLICY', 'PAYMENT'].map((name, i) => (
            <View key={name} style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
              <Caps size={9.5} tracking={2} opacity={model.checks > i ? 0.95 : 0.35}>{name}</Caps>
              <View style={{ opacity: model.checks > i ? 1 : 0 }}><Icon name="check" size={10} color="#fff" strokeWidth={3} /></View>
            </View>
          ))}
        </View>
        <Reveal delay={1.2} style={{ marginTop: 14 }}>
          <CTAButton title={model.booking ? 'BOOKING…' : 'BOOK'} disabled={model.booking} onPress={model.book} />
        </Reveal>
      </View>
    </View>
  );
}
