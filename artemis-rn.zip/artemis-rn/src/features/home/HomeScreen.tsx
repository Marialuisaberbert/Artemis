import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Pressable, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import Animated, { Easing, SharedValue, interpolate, useAnimatedScrollHandler, useAnimatedStyle, useSharedValue, withRepeat, withTiming, cancelAnimation } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { ArtemisLogo } from '../../design/ArtemisLogo';
import { Icon } from '../../design/Icon';
import { NightBackdrop } from '../../design/NightBackdrop';
import { Globe, flyCamera, useGlobeCamera } from '../../design/globe/Globe';
import { midpoint } from '../../design/globe/math';
import { Caps, Display } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { DestinationService } from '../../domain/destinations/destinationService';
import { Destination, Destinations } from '../../domain/destinations/destinations';
import { selectedFlight, Trip } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { useTripStore } from '../../store/useTripStore';
import { WorldCard } from './WorldCard';
import { StyleSheet } from 'react-native';

type Card = { kind: 'trip'; id: string; tripID: string } | { kind: 'place'; id: string; placeID: string };
const service = new DestinationService();
const CARD_GAP = 14;

/** The world. Artemis opens on a globe with you on it: where you are, where you are going, and where you could go. */
export function HomeScreen() {
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const place = useTripStore((s) => s.currentPlace);
  const trips = useTripStore((s) => s.trips);
  const profile = useTripStore((s) => s.profile);
  const budget = useTripStore((s) => s.defaultPreferences.flightBudget);
  const inbox = useTripStore((s) => s.inbox);

  const featured = useMemo(() => {
    const up = trips.filter((t) => !t.isPast).sort((a, b) => a.startDate - b.startDate);
    return up.find((t) => t.bookings.some((b) => b.kind === 'flight')) ?? up[0];
  }, [trips]);

  const cards = useMemo<Card[]>(() => {
    const out: Card[] = [];
    const used = new Set<string>();
    if (featured) { out.push({ kind: 'trip', id: `trip-${featured.id}`, tripID: featured.id }); used.add(featured.destinationID); }
    for (const d of service.discover(place, profile, budget)) if (!used.has(d.id)) out.push({ kind: 'place', id: `place-${d.id}`, placeID: d.id });
    return out;
  }, [featured, place, profile, budget]);

  const destinationOf = useCallback((c: Card): { d: Destination; trip?: Trip } | undefined => {
    if (c.kind === 'trip') { const t = trips.find((x) => x.id === c.tripID); return t ? { d: Destinations.named(t.destinationID) ?? Destinations.rome, trip: t } : undefined; }
    const d = Destinations.named(c.placeID);
    return d ? { d } : undefined;
  }, [trips]);

  const [index, setIndex] = useState(0);
  const selected = cards[Math.min(index, cards.length - 1)];
  const sel = selected ? destinationOf(selected) : undefined;

  const cam = useGlobeCamera({ lat: place.latitude, lon: place.longitude, radius: 0.6, centerY: 0.42 });
  const loop = useSharedValue(0);
  const you = useMemo(() => ({ lat: place.latitude, lon: place.longitude }), [place.latitude, place.longitude]);

  const route = useMemo(() => {
    if (!sel) return undefined;
    const stops = [you];
    const flight = sel.trip && selectedFlight(sel.trip);
    if (flight) for (const l of flight.legs) stops.push({ lat: l.to.latitude, lon: l.to.longitude });
    else stops.push({ lat: sel.d.latitude, lon: sel.d.longitude });
    return stops;
  }, [sel, you]);

  const markers = useMemo(
    () => Destinations.all.filter((d) => d.airport.code !== place.airportCode).map((d) => ({ id: d.id, label: d.city, lat: d.latitude, lon: d.longitude })),
    [place.airportCode],
  );

  // Glide the camera so both you and the selected place are on the visible face, then loop the plane.
  useEffect(() => {
    if (!sel || !route) return;
    const mid = midpoint(you, { lat: sel.d.latitude, lon: sel.d.longitude });
    flyCamera(cam, { lat: mid.lat * 0.8, lon: mid.lon, duration: 1600 });
    cancelAnimation(loop);
    loop.value = 0;
    loop.value = withRepeat(withTiming(Math.max(1, route.length - 1), { duration: 6500, easing: Easing.inOut(Easing.ease) }), -1, false);
    return () => cancelAnimation(loop);
  }, [sel?.d.id, route, you, cam, loop]); // eslint-disable-line react-hooks/exhaustive-deps

  // Carousel
  const cardW = width * 0.76;
  const step = cardW + CARD_GAP;
  const scrollX = useSharedValue(0);
  const onScroll = useAnimatedScrollHandler({ onScroll: (e) => { scrollX.value = e.contentOffset.x; } });
  const settle = useCallback((x: number) => {
    const i = Math.max(0, Math.min(cards.length - 1, Math.round(x / step)));
    setIndex((prev) => { if (prev !== i) HapticsService.select(); return i; });
  }, [cards.length, step]);
  const scroller = React.useRef<Animated.ScrollView>(null);

  const select = useCallback((id: string) => {
    const i = cards.findIndex((c) => destinationOf(c)?.d.id === id);
    if (i >= 0) { HapticsService.select(); scroller.current?.scrollTo({ x: i * step, animated: true }); setIndex(i); }
  }, [cards, destinationOf, step]);

  const open = (c: Card, i: number) => {
    if (i !== index) { scroller.current?.scrollTo({ x: i * step, animated: true }); setIndex(i); return; }
    HapticsService.tap();
    if (c.kind === 'trip') router.push({ pathname: '/trip', params: { id: c.tripID } });
    else router.push({ pathname: '/destination', params: { id: c.placeID } });
  };

  const unread = inbox.length > 0;
  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      <NightBackdrop glow={0.6} />
      <Globe
        width={width} height={height} camera={cam} markers={markers} selectedId={sel?.d.id} you={you}
        route={route ? { stops: route, position: loop } : undefined} interactive onSelectMarker={select}
      />
      <View pointerEvents="box-none" style={{ flex: 1, paddingTop: insets.top + 8 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 22 }} pointerEvents="box-none">
          <View style={{ gap: 6 }}>
            <ArtemisLogo size={24} />
            <Caps size={10.5} tracking={3} opacity={0.6} style={{ marginTop: 14 }}>{place.isDemo ? 'YOU ARE HERE' : 'YOU ARE HERE · LIVE'}</Caps>
            <Display size={30} tracking={1.5} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6} style={{ fontFamily: undefined, fontWeight: '600' }}>{place.name.toUpperCase()}</Display>
          </View>
          <Pressable accessibilityRole="button" accessibilityLabel={unread ? 'Notifications, unread' : 'Notifications'} onPress={() => router.push('/inbox')}
            style={{ width: 44, height: 44, borderRadius: 22, overflow: 'hidden', borderWidth: 1, borderColor: alpha('#ffffff', 0.2), alignItems: 'center', justifyContent: 'center', marginTop: 64 }}>
            <BlurView intensity={26} tint="dark" style={StyleSheet.absoluteFill} />
            <Icon name="bell" size={18} color="#fff" strokeWidth={2} />
            {unread && <View style={{ position: 'absolute', top: 10, right: 11, width: 8, height: 8, borderRadius: 4, backgroundColor: colors.habanero }} />}
          </Pressable>
        </View>
        <View style={{ flex: 1 }} pointerEvents="none" />
        <View style={{ marginBottom: 104 }}>
          <Animated.ScrollView
            ref={scroller} horizontal showsHorizontalScrollIndicator={false} snapToInterval={step} decelerationRate="fast" scrollEventThrottle={16}
            onScroll={onScroll} onMomentumScrollEnd={(e) => settle(e.nativeEvent.contentOffset.x)} contentContainerStyle={{ paddingHorizontal: (width - cardW) / 2, gap: CARD_GAP }}
            style={{ height: 232 }}
          >
            {cards.map((c, i) => {
              const info = destinationOf(c);
              if (!info) return null;
              return (
                <CardSlot key={c.id} i={i} step={step} scrollX={scrollX} width={cardW} onPress={() => open(c, i)}>
                  <WorldCard destination={info.d} trip={info.trip} from={place} />
                </CardSlot>
              );
            })}
          </Animated.ScrollView>
        </View>
      </View>
    </View>
  );
}

function CardSlot({ i, step, scrollX, width, onPress, children }: { i: number; step: number; scrollX: SharedValue<number>; width: number; onPress: () => void; children: React.ReactNode }) {
  const style = useAnimatedStyle(() => {
    const d = Math.min(1, Math.abs(scrollX.value - i * step) / step);
    return { opacity: interpolate(d, [0, 1], [1, 0.65]), transform: [{ scale: interpolate(d, [0, 1], [1, 0.9]) }, { translateY: interpolate(d, [0, 1], [0, 12]) }] };
  });
  return (
    <Pressable onPress={onPress} style={{ width, paddingVertical: 10 }}>
      <Animated.View style={style}>{children}</Animated.View>
    </Pressable>
  );
}

