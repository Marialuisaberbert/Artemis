import React from 'react';
import { StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { DestinationPhotoView } from '../../design/PhotoView';
import { Display, T } from '../../design/text';
import { GlassPill } from '../../design/widgets';
import { DestinationService } from '../../domain/destinations/destinationService';
import type { Destination } from '../../domain/destinations/destinations';
import { Place, placeAirport } from '../../domain/destinations/place';
import { shortCity } from '../../domain/destinations/geo';
import { usd } from '../../domain/shared/money';
import { Trip, dateRange, shortDateRange } from '../../domain/trips/trip';

const service = new DestinationService();

/** One destination as a floating photographic card. */
export function WorldCard({ destination, trip, from, height = 210 }: { destination: Destination; trip?: Trip; from: Place; height?: number }) {
  const meta = trip
    ? `${dateRange(trip)} · ${shortCity(placeAirport(from)).toUpperCase()} → ${destination.city.toUpperCase()}`
    : `${Math.round(service.travelHours(from, destination))} H AWAY · FROM ${usd(destination.typicalFare)}`;
  return (
    <View
      accessible accessibilityRole="button"
      accessibilityLabel={trip ? `Your next trip, ${destination.city}, ${shortDateRange(trip)}` : `${destination.city}, ${destination.country}`}
      style={{ height, borderRadius: 30, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)', backgroundColor: '#0d0d0d', shadowColor: '#000', shadowOpacity: 0.5, shadowRadius: 18, shadowOffset: { width: 0, height: 10 } }}
    >
      <DestinationPhotoView photo={destination.photo} title={destination.city} />
      <LinearGradient colors={['rgba(0,0,0,0.25)', 'rgba(0,0,0,0)', 'rgba(0,0,0,0.78)']} style={StyleSheet.absoluteFill} />
      <View style={{ flex: 1, padding: 16, justifyContent: 'space-between' }}>
        <GlassPill text={trip ? 'YOUR NEXT TRIP' : destination.country.toUpperCase()} />
        <View style={{ gap: 5 }}>
          <Display size={34} tracking={0} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>{destination.city}</Display>
          <T numberOfLines={1} style={{ color: 'rgba(255,255,255,0.82)', fontSize: 10.5, fontWeight: '600', letterSpacing: 1.4 }}>{meta}</T>
        </View>
      </View>
    </View>
  );
}

