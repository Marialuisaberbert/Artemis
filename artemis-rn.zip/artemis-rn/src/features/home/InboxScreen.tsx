import React from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { router } from 'expo-router';
import { Icon } from '../../design/Icon';
import { NightBackdrop } from '../../design/NightBackdrop';
import { Body, Eyebrow, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { notificationIcon } from '../shell/NotificationBanner';
import { useTripStore } from '../../store/useTripStore';

export function InboxScreen() {
  const inbox = useTripStore((s) => s.inbox);
  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <NightBackdrop glow={0.25} showStars={false} />
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingTop: 18 }}>
        <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Notifications</Eyebrow>
        <Pressable accessibilityRole="button" accessibilityLabel="Done" onPress={() => router.back()} style={{ minWidth: 44, minHeight: 44, alignItems: 'flex-end', justifyContent: 'center' }}>
          <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>Done</T>
        </Pressable>
      </View>
      {inbox.length === 0 ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8, paddingHorizontal: 40 }}>
          <Icon name="bell" size={30} color={alpha(colors.luster, 0.5)} strokeWidth={1.6} />
          <T style={{ color: colors.luster, fontSize: 19, fontWeight: '600' }}>Nothing yet</T>
          <Body size={15} opacity={0.6} style={{ textAlign: 'center' }}>Artemis will tell you when something needs you.</Body>
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 20, gap: 16 }}>
          {inbox.map((n) => (
            <View key={n.id} style={{ flexDirection: 'row', gap: 12 }}>
              <View style={{ width: 34, height: 34, borderRadius: 9, alignItems: 'center', justifyContent: 'center', backgroundColor: n.tone === 'attention' ? colors.habanero : alpha('#ffffff', 0.14) }}>
                <Icon name={notificationIcon(n)} size={14} color={n.tone === 'attention' ? colors.depths : '#fff'} strokeWidth={2.6} />
              </View>
              <View style={{ flex: 1, gap: 2 }}>
                <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>{n.title}</T>
                <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>{n.body}</T>
              </View>
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
}
