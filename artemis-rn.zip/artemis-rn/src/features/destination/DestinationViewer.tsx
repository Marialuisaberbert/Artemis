import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, View, useWindowDimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { SharedValue, interpolate, useAnimatedScrollHandler, useAnimatedStyle, useSharedValue } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ArtemisLogo } from '../../design/ArtemisLogo';
import { CTAButton, RoundIconButton } from '../../design/controls';
import { DestinationPhotoView } from '../../design/PhotoView';
import { Body, Caps, Display, Editorial, Mono, T } from '../../design/text';
import { GlassPill } from '../../design/widgets';
import { DestinationService } from '../../domain/destinations/destinationService';
import { costSymbols, Destination } from '../../domain/destinations/destinations';
import { usd } from '../../domain/shared/money';
import credits from '../../../assets/photos/credits.json';
import { HapticsService } from '../../services/HapticsService';
import { useTripStore } from '../../store/useTripStore';

const service = new DestinationService();
const creditFor = (d: Destination): string | undefined => {
  const c = (credits as Record<string, { artist: string; license: string }>)[d.photo.file];
  return c ? `Photo ${c.artist} · ${c.license}` : undefined;
};
const spaced = (s: string) => s.toUpperCase().split('').join(' ');

interface Props {
  destinations: Destination[];
  startID?: string;
  mode?: 'discover' | 'choose';
  bottomInset?: number;
  showsClose?: boolean;
  onClose?: () => void;
  onStart: (d: Destination) => void;
}

/**
 * Places, one photograph at a time. Swipe sideways to move between them; the photograph is the interface.
 * Used as Discover (embedded in a tab), as the viewer opened from the world, and as the destination picker when starting a trip.
 */
export function DestinationViewer({ destinations, startID, mode = 'discover', bottomInset = 0, showsClose = false, onClose, onStart }: Props) {
  const { width, height } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  const profile = useTripStore((s) => s.profile);
  const budget = useTripStore((s) => s.defaultPreferences.flightBudget);
  const place = useTripStore((s) => s.currentPlace);
  const startIndex = Math.max(0, destinations.findIndex((d) => d.id === startID));
  const [index, setIndex] = useState(startIndex);
  const scrollX = useSharedValue(startIndex * width);
  const scroller = React.useRef<Animated.ScrollView>(null);
  const onScroll = useAnimatedScrollHandler({ onScroll: (e) => { scrollX.value = e.contentOffset.x; } });
  const go = (i: number) => { HapticsService.select(); scroller.current?.scrollTo({ x: i * width, animated: true }); setIndex(i); };
  const next = destinations.slice(index + 1, index + 4);

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <Animated.ScrollView
        ref={scroller} horizontal pagingEnabled showsHorizontalScrollIndicator={false} scrollEventThrottle={16} onScroll={onScroll}
        contentOffset={{ x: startIndex * width, y: 0 }}
        onMomentumScrollEnd={(e) => { const i = Math.round(e.nativeEvent.contentOffset.x / width); setIndex((p) => { if (p !== i) HapticsService.select(); return i; }); }}
      >
        {destinations.map((d, i) => (
          <Page key={d.id} d={d} i={i} width={width} height={height} scrollX={scrollX} mode={mode} bottomInset={bottomInset + insets.bottom}
            match={service.match(d, profile, budget).percent} hours={service.travelHours(place, d)} onStart={() => { HapticsService.tap(); onStart(d); }} />
        ))}
      </Animated.ScrollView>

      {/* Chrome: as little as possible. */}
      <View pointerEvents="box-none" style={{ position: 'absolute', top: 0, left: 0, right: 0, paddingTop: insets.top + 8, paddingHorizontal: 22, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        {showsClose && onClose ? <RoundIconButton icon="close" label="Close" onPress={onClose} /> : <ArtemisLogo size={22} />}
        <Mono size={11} color="rgba(255,255,255,0.7)" style={{ letterSpacing: 2 }}>{`${String(index + 1).padStart(2, '0')} / ${String(destinations.length).padStart(2, '0')}`}</Mono>
      </View>

      {/* The next places, fanned like cards behind the current one. */}
      <View pointerEvents="box-none" style={{ position: 'absolute', right: 22, bottom: bottomInset + insets.bottom + 128, width: 130, height: 90 }}>
        {next.map((d, k) => ({ d, k })).reverse().map(({ d, k }) => (
          <Pressable key={d.id} accessibilityRole="button" accessibilityLabel={`Next: ${d.city}`} onPress={() => go(destinations.indexOf(d))}
            style={{ position: 'absolute', right: k * 22, bottom: k * 6, width: 58, height: 78, borderRadius: 16, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)', transform: [{ rotate: `${k * -4}deg` }], shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } }}>
            <DestinationPhotoView photo={d.photo} title={d.city} />
          </Pressable>
        ))}
      </View>
    </View>
  );
}

function Page({ d, i, width, height, scrollX, mode, bottomInset, match, hours, onStart }: {
  d: Destination; i: number; width: number; height: number; scrollX: SharedValue<number>; mode: 'discover' | 'choose'; bottomInset: number; match: number; hours: number; onStart: () => void;
}) {
  // The photograph moves slower than the page: parallax.
  const parallax = useAnimatedStyle(() => ({ transform: [{ scale: 1.14 }, { translateX: interpolate(scrollX.value, [(i - 1) * width, i * width, (i + 1) * width], [width * 0.28, 0, -width * 0.28]) }] }));
  const credit = creditFor(d);
  return (
    <View style={{ width, height, overflow: 'hidden' }}>
      <Animated.View style={[StyleSheet.absoluteFill, parallax]}>
        <DestinationPhotoView photo={d.photo} title={d.city} drift />
      </Animated.View>
      <LinearGradient colors={['rgba(0,0,0,0.45)', 'rgba(0,0,0,0)', 'rgba(0,0,0,0.35)', 'rgba(0,0,0,0.86)']} style={StyleSheet.absoluteFill} />
      <View style={{ flex: 1, justifyContent: 'flex-end', paddingHorizontal: 22, paddingBottom: bottomInset + 26 }}>
        <Caps size={11} tracking={3} opacity={0.75}>{spaced(d.country)}</Caps>
        <Display size={76} tracking={-2} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5} style={{ marginTop: 6 }}>{d.city}</Display>
        <Editorial size={21} style={{ fontFamily: 'Newsreader_400Regular_Italic', color: 'rgba(255,255,255,0.92)', marginTop: 4 }}>{d.tagline}</Editorial>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 18 }}>
          <GlassPill text={d.climate} />
          <GlassPill text={costSymbols(d)} />
          <GlassPill text={d.bestTime.toUpperCase()} icon="calendar" />
        </View>
        <Body size={13} opacity={0.72} numberOfLines={2} style={{ marginTop: 14, paddingRight: 100 }}>{d.highlights.slice(0, 3).join('  ·  ')}</Body>
        {d.typicalFare > 0 && (
          <T style={{ color: 'rgba(255,255,255,0.6)', fontSize: 11.5, fontWeight: '600', letterSpacing: 0.6, marginTop: 6 }}>
            {`${Math.round(hours)} h away · from ${usd(d.typicalFare)} · ${match}% match for you`}
          </T>
        )}
        <CTAButton title={mode === 'choose' ? `CHOOSE ${d.city.toUpperCase()}  →` : 'START A TRIP'} onPress={onStart} style={{ marginTop: 20, marginRight: 100 }} />
        {credit && <T style={{ color: 'rgba(255,255,255,0.4)', fontSize: 9, marginTop: 10 }}>{credit}</T>}
      </View>
    </View>
  );
}

export const useDestinations = (): Destination[] => {
  const place = useTripStore((s) => s.currentPlace);
  const profile = useTripStore((s) => s.profile);
  const budget = useTripStore((s) => s.defaultPreferences.flightBudget);
  return useMemo(() => service.discover(place, profile, budget), [place, profile, budget]);
};
