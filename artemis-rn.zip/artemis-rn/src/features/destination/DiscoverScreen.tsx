import React from 'react';
import { router } from 'expo-router';
import { DestinationViewer, useDestinations } from './DestinationViewer';

export function DiscoverScreen() {
  const destinations = useDestinations();
  return <DestinationViewer destinations={destinations} bottomInset={74} onStart={(d) => router.push({ pathname: '/create', params: { preset: d.id } })} />;
}
