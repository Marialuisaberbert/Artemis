import React, { useMemo } from 'react';
import { View } from 'react-native';
import { Icon, IconName } from '../../design/Icon';
import { Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { Zoned, timeZone } from '../../domain/shared/time';
import type { ItineraryEvent } from '../../domain/trips/trip';
import { eventTimeLabel } from '../../domain/trips/trip';

const SYMBOL: Record<string, IconName> = {
  'airplane.departure': 'plane', 'airplane.arrival': 'plane', 'cup.and.saucer': 'clock', 'bed.double': 'bed', 'door.left.hand.open': 'chevronRight',
};

/** A vertical timeline: one line, one dot per moment, days as quiet headers. */
export function ItineraryTimeline({ events, now }: { events: ItineraryEvent[]; now?: number }) {
  const days = useMemo(() => {
    const order: string[] = [];
    const map = new Map<string, ItineraryEvent[]>();
    for (const e of events) {
      const tz = timeZone(e.timeZoneID);
      const key = `${Zoned.weekday(e.date, tz).toUpperCase()} · ${Zoned.dayUpper(e.date, tz)}`;
      if (!map.has(key)) { order.push(key); map.set(key, []); }
      map.get(key)!.push(e);
    }
    return order.map((label) => ({ label, events: map.get(label)! }));
  }, [events]);
  const nextID = now === undefined ? undefined : events.find((e) => e.date > now && e.kind !== 'layover')?.id;
  return (
    <View style={{ gap: 22 }}>
      {days.map((day) => (
        <View key={day.label}>
          <T style={{ color: colors.habanero, fontSize: 11, fontWeight: '800', letterSpacing: 1.8, marginBottom: 12 }}>{day.label}</T>
          {day.events.map((e, i) => <Row key={e.id} event={e} isLast={i === day.events.length - 1} past={now !== undefined && e.date < now} isNext={e.id === nextID} />)}
        </View>
      ))}
    </View>
  );
}

function Row({ event, isLast, past, isNext }: { event: ItineraryEvent; isLast: boolean; past: boolean; isNext: boolean }) {
  const layover = event.kind === 'layover';
  return (
    <View accessible accessibilityLabel={`${eventTimeLabel(event)}, ${event.title}. ${event.detail}`} style={{ flexDirection: 'row', gap: 14, alignItems: 'flex-start' }}>
      <Mono size={12.5} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.8} color={alpha(colors.luster, past ? 0.4 : 0.85)} style={{ width: 74, textAlign: 'right', paddingTop: 10 }}>{eventTimeLabel(event)}</Mono>
      <View style={{ alignItems: 'center' }}>
        <View style={{ width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center', backgroundColor: isNext ? colors.habanero : layover ? 'transparent' : alpha(colors.luster, past ? 0.06 : 0.14), borderWidth: layover ? 1 : 0, borderStyle: 'dashed', borderColor: alpha(colors.luster, 0.3) }}>
          <Icon name={SYMBOL[event.symbol] ?? 'clock'} size={14} color={isNext ? colors.depths : alpha(colors.luster, past ? 0.5 : 1)} strokeWidth={2} />
        </View>
        {!isLast && <View style={{ width: 1.5, minHeight: 22, flex: 1, backgroundColor: alpha(colors.luster, 0.18) }} />}
      </View>
      <View style={{ flex: 1, gap: 2, paddingTop: 6, paddingBottom: 14 }}>
        <T style={{ color: alpha(colors.luster, past ? 0.5 : 1), fontSize: 15, fontWeight: '600' }}>{event.title}</T>
        <T style={{ color: alpha(colors.luster, past ? 0.35 : 0.65), fontSize: 13 }}>{event.detail}</T>
      </View>
    </View>
  );
}
