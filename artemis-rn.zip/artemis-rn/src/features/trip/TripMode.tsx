import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Pressable, View, useWindowDimensions } from 'react-native';
import { router } from 'expo-router';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { Easing, FadeIn, FadeOut, runOnJS, useAnimatedStyle, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { StyleSheet } from 'react-native';
import { GlassPanel, RoundIconButton } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { PhotoBackdrop } from '../../design/PhotoView';
import { Globe, flyCamera, useGlobeCamera } from '../../design/globe/Globe';
import { latLonOf, slerp, vecFromLatLon } from '../../design/globe/math';
import { Display, Eyebrow, Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { shortCity } from '../../domain/destinations/geo';
import { countdown, hoursMinutes, timeZone, Zoned } from '../../domain/shared/time';
import { arrivalDayOffset, arrivalLocal, departureLocal, flightDestination, flightDuration, flightOrigin, stopsLabel, legDepartLocal, FlightOption } from '../../domain/trips/flights';
import { hotelCheckIn } from '../../domain/trips/itinerary';
import type { JourneyState } from '../../domain/trips/journey';
import { hotelBooking, dateRange, phaseShort, selectedFlight, selectedHotel, tripDays, tripDestination, Trip, tripPhases, TripPhase } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore, useTripStore } from '../../store/useTripStore';
import { useItinerary, useTrip } from '../../store/hooks';
import { ItineraryTimeline } from './ItineraryTimeline';

/**
 * TRIP MODE. Once a trip is booked, the app simplifies to what matters for the journey: where you are, how long is left,
 * and the next thing that needs you. Everything else fades away.
 */
export function TripMode({ tripID }: { tripID: string }) {
  const trip = useTrip(tripID);
  const journeyNow = useTripStore((s) => s.journeyNow);
  const clockTick = useTicker(journeyNow === undefined);
  const insets = useSafeAreaInsets();
  const { height } = useWindowDimensions();
  const reduce = useReducedMotion();
  const [playing, setPlaying] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const store = getTripStore();
  const playRef = useRef(false);
  playRef.current = playing;

  useEffect(() => { store.startJourney(tripID); return () => store.endJourney(); }, [tripID]); // eslint-disable-line react-hooks/exhaustive-deps

  // A time-lapse: the whole journey in about half a minute.
  useEffect(() => {
    if (!playing) return;
    const sim = store.simulator(tripID);
    if (!sim) return;
    const id = setInterval(() => {
      const now = getTripStore().journeyState(tripID)?.now;
      if (now === undefined) return;
      const next = now + ((38 * 60) / 25) * 1000; // 38 simulated minutes per second, at 25 fps
      if (next >= sim.arrival + 20 * 60_000) { getTripStore().setJourneyTime(sim.time('landed')); setPlaying(false); HapticsService.success(); return; }
      const prev = getTripStore().journeyState(tripID)?.phase;
      getTripStore().setJourneyTime(next);
      if (getTripStore().journeyState(tripID)?.phase !== prev) HapticsService.soft();
    }, 40);
    return () => clearInterval(id);
  }, [playing, tripID]); // eslint-disable-line react-hooks/exhaustive-deps

  void clockTick;
  const flight = trip && selectedFlight(trip);
  const state = useMemo(() => store.journeyState(tripID), [journeyNow, trip, clockTick]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!trip || !flight || !state) return <View style={{ flex: 1, backgroundColor: colors.depths }} />;

  const simulate = () => {
    Alert.alert('Simulate journey state', 'Prototype', [
      ...tripPhases.map((p) => ({ text: `${state.phase === p ? '✓ ' : ''}${phaseShort(p)}`, onPress: () => { setPlaying(false); HapticsService.select(); store.setJourneyPhase(p, tripID); } })),
      { text: playing ? 'Pause journey' : 'Play journey', onPress: () => { if (playing) setPlaying(false); else { if (state.phase === 'landed') store.setJourneyPhase('notDeparted', tripID); setPlaying(true); } } },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  const openDrawer = () => { HapticsService.tap(); setDrawerOpen(true); };
  const swipeUp = Gesture.Pan()
    .activeOffsetY(-10)
    .onEnd((e) => { if (e.translationY < -40) runOnJS(openDrawer)(); });

  return (
    <View style={{ flex: 1, backgroundColor: colors.depths }}>
      <PhotoBackdrop destination={tripDestination(trip)} blur={state.phase === 'landed' ? 3 : 26} dim={state.phase === 'inFlight' ? 0.68 : 0.5} bottomScrim={0.6} />
      <View style={{ flex: 1, paddingTop: insets.top }}>
        {/* Top bar */}
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingTop: 8 }}>
          <RoundIconButton icon="close" label="Leave Trip Mode" onPress={() => { HapticsService.tap(); router.back(); }} />
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 999, backgroundColor: alpha(colors.luster, 0.1), borderWidth: 1, borderColor: alpha(colors.luster, 0.2) }}>
            <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: colors.habanero }} />
            <T style={{ color: colors.luster, fontSize: 11, fontWeight: '800', letterSpacing: 2 }}>TRIP MODE</T>
          </View>
          <RoundIconButton icon="refresh" label="Simulate journey state (prototype)" onPress={simulate} />
        </View>
        <View style={{ flex: 1, minHeight: 8 }} />
        {/* City */}
        <View style={{ alignItems: 'center', gap: 6, paddingHorizontal: 20 }} accessible>
          <Display size={62} tracking={-1.5} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5}>{tripDestination(trip).city}</Display>
          <T style={{ color: alpha(colors.luster, 0.65), fontSize: 12, fontWeight: '600', letterSpacing: 2 }}>{`${tripDays(trip)} DAYS · ${dateRange(trip)}`}</T>
        </View>
        <FlightGlobe flight={flight} state={state} />
        <View style={{ paddingHorizontal: 24 }}><StatusBlock state={state} flight={flight} trip={trip} /></View>
        <View style={{ flex: 1, minHeight: 12 }} />
        <View style={{ paddingHorizontal: 20 }}><NextCard trip={trip} state={state} /></View>
        <GestureDetector gesture={swipeUp}>
          <Pressable accessibilityRole="button" accessibilityLabel="Itinerary" accessibilityHint="Opens the full itinerary" onPress={openDrawer}
            style={{ minHeight: 64, alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 4, marginBottom: Math.max(insets.bottom, 6) }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: alpha(colors.luster, 0.4) }} />
            <T style={{ color: alpha(colors.luster, 0.5), fontSize: 10, fontWeight: '800', letterSpacing: 2 }}>SWIPE UP · ITINERARY</T>
          </Pressable>
        </GestureDetector>
      </View>
      <Drawer open={drawerOpen} onClose={() => setDrawerOpen(false)} height={height} tripID={tripID} now={state.now} reduce={reduce} />
    </View>
  );
}

/** Re-renders once a minute while the real clock is in use. */
function useTicker(real: boolean): number {
  const [n, setN] = useState(0);
  useEffect(() => { if (!real) return; const id = setInterval(() => setN((x) => x + 1), 30_000); return () => clearInterval(id); }, [real]);
  return n;
}

// MARK: - The plane, over the world

/** A globe that follows the plane. Tap it for the flight. */
function FlightGlobe({ flight, state }: { flight: FlightOption; state: JourneyState }) {
  const { width } = useWindowDimensions();
  const [showCard, setShowCard] = useState(false);
  const stops = useMemo(() => [flightOrigin(flight), ...flight.legs.map((l) => l.to)], [flight]);
  const geo = useMemo(() => {
    const i = Math.min(Math.max(0, Math.trunc(state.position)), stops.length - 2);
    const t = Math.min(1, Math.max(0, state.position - i));
    return latLonOf(slerp(vecFromLatLon(stops[i].latitude, stops[i].longitude), vecFromLatLon(stops[i + 1].latitude, stops[i + 1].longitude), t));
  }, [stops, state.position]);
  const cam = useGlobeCamera({ lat: geo.lat * 0.8, lon: geo.lon, radius: 0.56, centerY: 0.5 });
  const pos = useSharedValue(state.position);
  const first = useRef(true);
  useEffect(() => {
    // Time-lapse steps land often, so follow them closely; a jump between phases glides.
    const quick = !first.current && Math.abs(pos.value - state.position) < 0.06;
    first.current = false;
    pos.value = withTiming(state.position, { duration: quick ? 60 : 1800, easing: Easing.inOut(Easing.ease) });
    flyCamera(cam, { lat: geo.lat * 0.8, lon: geo.lon, duration: quick ? 60 : 1800 });
  }, [state.position]); // eslint-disable-line react-hooks/exhaustive-deps
  const markers = useMemo(() => stops.map((a) => ({ id: a.code, label: a.code, lat: a.latitude, lon: a.longitude })), [stops]);
  const route = useMemo(() => ({ stops: stops.map((a) => ({ lat: a.latitude, lon: a.longitude })), position: pos }), [stops, pos]);
  return (
    <Pressable style={{ height: 300 }} accessibilityRole="button" accessibilityLabel={`Globe following your flight from ${flightOrigin(flight).city} to ${flightDestination(flight).city}`} onPress={() => { HapticsService.select(); setShowCard((s) => !s); }}>
      <Globe width={width} height={300} camera={cam} markers={markers} route={route} />
      {showCard && (
        <Animated.View entering={FadeIn.duration(300)} exiting={FadeOut.duration(200)} style={{ position: 'absolute', bottom: 8, left: 20, right: 20, borderRadius: 18, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.25)', padding: 14, gap: 6 }}>
          <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
          <T style={{ color: '#fff', fontSize: 12, fontWeight: '600', letterSpacing: 1.6 }}>{`${flightOrigin(flight).city.toUpperCase()} → ${flightDestination(flight).city.toUpperCase()}`}</T>
          <Mono size={13} color="rgba(255,255,255,0.8)">{flight.legs.map((l) => l.flightNumber).join(' + ')}</Mono>
          <T style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13 }}>{`${departureLocal(flight)} → ${arrivalLocal(flight)}${arrivalDayOffset(flight) > 0 ? ` +${arrivalDayOffset(flight)}` : ''} · ${hoursMinutes(flightDuration(flight))} · ${stopsLabel(flight)}`}</T>
        </Animated.View>
      )}
    </Pressable>
  );
}

// MARK: - Status

function StatusBlock({ state, flight, trip }: { state: JourneyState; flight: FlightOption; trip: Trip }) {
  const first = flight.legs[0];
  const eyebrow = (s: string) => <T style={{ color: colors.habanero, fontSize: 12, fontWeight: '800', letterSpacing: 2.4 }}>{s}</T>;
  const big = (s: string, size = 62) => <Mono size={size} weight="600" color={colors.luster} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5} style={{ letterSpacing: -2 }}>{s}</Mono>;
  const sub = (s: string) => <T style={{ color: alpha(colors.luster, 0.75), fontSize: 13, fontWeight: '600', letterSpacing: 0.8, textAlign: 'center' }}>{s}</T>;
  const pill = (s: string) => (
    <View style={{ marginTop: 4, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 999, backgroundColor: alpha(colors.luster, 0.1), borderWidth: 1, borderColor: alpha(colors.luster, 0.2) }}>
      <T style={{ color: colors.luster, fontSize: 11, fontWeight: '800', letterSpacing: 1.6 }}>{s}</T>
    </View>
  );
  const from = shortCity(first.from).toUpperCase();
  const firstTo = shortCity(first.to).toUpperCase();
  let content: React.ReactNode;
  switch (state.phase) {
    case 'notDeparted':
      content = <>{eyebrow('FLIGHT IN')}{big(countdown(state.untilDeparture))}{sub(`${from} → ${firstTo} · ${first.flightNumber} · ${departureLocal(flight)}`)}{pill(`BOARDING IN ${countdown(Math.max(0, state.untilBoarding))}`)}</>;
      break;
    case 'boarding':
      // The Swift app adds a simulated gate and seat here. The trip ticket never carries them, and neither does this.
      content = <>{eyebrow('BOARDING')}{big('NOW', 60)}{sub(`Boarding closes in ${countdown(Math.max(0, state.untilDeparture))}`)}{pill(`${first.flightNumber} · ${from} → ${firstTo}`)}</>;
      break;
    case 'inFlight': {
      const leg = flight.legs[state.legIndex];
      content = state.isConnecting
        ? <>{eyebrow(`CONNECTING IN ${shortCity(leg.from).toUpperCase()}`)}{big(countdown(Math.max(0, (leg.depart - state.now) / 1000)))}{sub(`until ${leg.flightNumber} to ${shortCity(leg.to)} · ${legDepartLocal(leg)}`)}{pill(`${countdown(state.remaining)} REMAINING`)}</>
        : <>{eyebrow('✈ IN FLIGHT')}{big(countdown(state.remaining))}{sub(`REMAINING · ${from} → ${shortCity(flightDestination(flight)).toUpperCase()}`)}{pill(`${leg.flightNumber} · ${leg.from.code} → ${leg.to.code}`)}</>;
      break;
    }
    case 'landed':
      content = (
        <>
          {eyebrow('LANDED')}
          <Display size={38} tracking={-1} shrink numberOfLines={2} style={{ textAlign: 'center' }}>{`WELCOME TO ${tripDestination(trip).city.toUpperCase()}`}</Display>
          {sub(`Local time ${Zoned.time(state.now, timeZone(flightDestination(flight).timeZoneID))} · ${Zoned.weekday(state.now, timeZone(flightDestination(flight).timeZoneID))}`)}
        </>
      );
      break;
  }
  return <Animated.View key={state.phase} entering={FadeIn.duration(550)} style={{ alignItems: 'center', gap: 8 }} accessible>{content}</Animated.View>;
}

// MARK: - Next

function NextCard({ trip, state }: { trip: Trip; state: JourneyState }) {
  const tz = timeZone(tripDestination(trip).airport.timeZoneID);
  const checkIn = hotelCheckIn(trip);
  const diff = Zoned.daysBetween(state.now, tz, checkIn, tz);
  const when = checkIn <= state.now ? `Open now · from ${Zoned.time(checkIn, tz)}` : `${diff === 0 ? 'Today' : diff === 1 ? 'Tomorrow' : Zoned.day(checkIn, tz)} · ${Zoned.time(checkIn, tz)}`;
  return (
    <GlassPanel radius={24} padding={14}>
      <View accessible style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <View style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: colors.royal, alignItems: 'center', justifyContent: 'center' }}><Icon name="bed" size={20} color={colors.luster} strokeWidth={1.9} /></View>
        <View style={{ flex: 1, gap: 3 }}>
          <T style={{ color: alpha(colors.luster, 0.55), fontSize: 10, fontWeight: '800', letterSpacing: 1.8 }}>{hotelBooking(trip) ? 'NEXT' : 'STAY'}</T>
          <T numberOfLines={1} style={{ color: colors.luster, fontSize: 16, fontWeight: '800', letterSpacing: 0.4 }}>{(selectedHotel(trip)?.name ?? 'Your hotel').toUpperCase()}</T>
          <T style={{ color: alpha(colors.luster, 0.7), fontSize: 12, fontWeight: '600', letterSpacing: 0.8 }}>{`CHECK-IN · ${when}`}</T>
        </View>
      </View>
    </GlassPanel>
  );
}

// MARK: - Itinerary drawer

function Drawer({ open, onClose, height, tripID, now, reduce }: { open: boolean; onClose: () => void; height: number; tripID: string; now: number; reduce: boolean }) {
  const openH = height * 0.72;
  const y = useSharedValue(openH + 40);
  const events = useItinerary(tripID);
  const insets = useSafeAreaInsets();
  useEffect(() => { y.value = withTiming(open ? 0 : openH + 40, { duration: reduce ? 200 : 700, easing: Easing.bezier(0.22, 1, 0.36, 1) }); }, [open, openH, reduce, y]);
  const pan = Gesture.Pan()
    .onChange((e) => { y.value = Math.max(0, e.translationY); })
    .onEnd((e) => { if (e.translationY > 70) runOnJS(onClose)(); y.value = withTiming(e.translationY > 70 ? openH + 40 : 0, { duration: 500 }); });
  const style = useAnimatedStyle(() => ({ transform: [{ translateY: y.value }] }));
  return (
    <View pointerEvents={open ? 'auto' : 'none'} style={StyleSheet.absoluteFill} accessibilityElementsHidden={!open}>
      <GestureDetector gesture={pan}>
        <Animated.View style={[{ position: 'absolute', left: 0, right: 0, bottom: 0, height: openH, borderTopLeftRadius: 32, borderTopRightRadius: 32, overflow: 'hidden', borderWidth: 1, borderColor: alpha(colors.luster, 0.18) }, style]}>
          <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
          <View style={[StyleSheet.absoluteFill, { backgroundColor: alpha(colors.depths, 0.96) }]} />
          <View style={{ alignItems: 'center', paddingTop: 10 }}><View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: alpha(colors.luster, 0.4) }} /></View>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20 }}>
            <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Itinerary</Eyebrow>
            <Pressable accessibilityRole="button" accessibilityLabel="Close itinerary" onPress={onClose} style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="chevronDown" size={18} color={colors.luster} strokeWidth={2.4} />
            </Pressable>
          </View>
          <Animated.ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 40 }} showsVerticalScrollIndicator={false}>
            <ItineraryTimeline events={events} now={now} />
          </Animated.ScrollView>
        </Animated.View>
      </GestureDetector>
    </View>
  );
}

