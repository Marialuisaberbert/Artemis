import React, { useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { router } from 'expo-router';
import { BlurView } from 'expo-blur';
import { StyleSheet } from 'react-native';
import Animated, { FadeInDown, FadeOut, LinearTransition } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CTAButton, RoundIconButton } from '../../design/controls';
import { Icon, IconName } from '../../design/Icon';
import { PhotoBackdrop } from '../../design/PhotoView';
import { Caps, Display, Editorial, Mono, T } from '../../design/text';
import { GlassButton } from '../../design/widgets';
import { hotelTotal } from '../../domain/destinations/hotels';
import { shortCity } from '../../domain/destinations/geo';
import { EvaluationResult } from '../../domain/trust/models';
import { usd } from '../../domain/shared/money';
import { hoursMinutes, timeZone, Zoned } from '../../domain/shared/time';
import { layovers, legArriveLocal, legDepartLocal, legDuration } from '../../domain/trips/flights';
import { hotelCheckIn, hotelCheckOut, hotelNights } from '../../domain/trips/itinerary';
import { Booking, bookingStatusLabel, dateRange, flightBooking, hotelBooking, isBooked, selectedFlight, selectedHotel, tripDestination, tripOrigin } from '../../domain/trips/trip';
import { locationLabel, hotelStyleLabel } from '../../domain/matching/preferences';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore } from '../../store/useTripStore';
import { useHotelPick, useItinerary, useTrip } from '../../store/hooks';
import { HotelBookingSheet } from '../booking/ConfirmationStage';
import { WhySheet } from '../booking/WhySheet';
import { ItineraryTimeline } from './ItineraryTimeline';

type Section = 'flight' | 'hotel' | 'places' | 'itinerary';
const SECTIONS: { id: Section; icon: IconName }[] = [{ id: 'flight', icon: 'plane' }, { id: 'hotel', icon: 'bed' }, { id: 'places', icon: 'pin' }, { id: 'itinerary', icon: 'calendar' }];
const spaced = (s: string) => s.toUpperCase().split('').join(' ');

/** The trip as a living object: the destination fills the screen, and four quiet doors open onto everything else. */
export function TripDetail({ tripID }: { tripID: string }) {
  const trip = useTrip(tripID);
  const insets = useSafeAreaInsets();
  const pick = useHotelPick(tripID);
  const [section, setSection] = useState<Section | undefined>();
  const [why, setWhy] = useState<EvaluationResult | undefined>();
  const [showHotel, setShowHotel] = useState(false);
  const events = useItinerary(tripID);
  if (!trip) return <View style={{ flex: 1, backgroundColor: '#000' }} />;
  const d = tripDestination(trip);
  const store = getTripStore();
  const others = trip.members.filter((m) => !m.traveler.isYou).map((m) => m.traveler.firstName);
  const tz = timeZone(d.airport.timeZoneID);

  const bookingLine = (b: Booking) => (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingTop: 4 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, backgroundColor: '#fff' }}>
        <Icon name="check" size={10} color="#000" strokeWidth={3.2} />
        <T style={{ color: '#000', fontSize: 10, fontWeight: '600', letterSpacing: 1 }}>{bookingStatusLabel(b)}</T>
      </View>
      <Mono size={13} color="rgba(255,255,255,0.7)">{b.reference}</Mono>
      <View style={{ flex: 1 }} />
      {b.verification && (
        <Pressable accessibilityRole="button" accessibilityLabel="Why?" onPress={() => setWhy(b.verification)} style={{ minWidth: 44, minHeight: 32, alignItems: 'flex-end', justifyContent: 'center' }}>
          <T style={{ color: 'rgba(255,255,255,0.8)', fontSize: 13, fontWeight: '600' }}>Why?</T>
        </Pressable>
      )}
    </View>
  );
  const note = (title: string, body: string) => (
    <View style={{ gap: 4 }}>
      <T style={{ color: 'rgba(255,255,255,0.9)', fontSize: 15, fontWeight: '600' }}>{title}</T>
      <T style={{ color: 'rgba(255,255,255,0.6)', fontSize: 13 }}>{body}</T>
    </View>
  );

  const panel = (s: Section) => {
    switch (s) {
      case 'flight': {
        const f = selectedFlight(trip);
        if (!f) return note('No flight chosen yet', 'Artemis finds the flights that fit everyone once preferences are in.');
        const lay = layovers(f);
        return (
          <>
            {f.legs.map((leg, i) => (
              <View key={leg.id} style={{ gap: 8 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                  <T style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11, fontWeight: '600', letterSpacing: 1.6 }}>{leg.airlineName.toUpperCase()}</T>
                  <Mono size={13} color="rgba(255,255,255,0.7)">{leg.flightNumber}</Mono>
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 10 }}>
                  <Mono size={19} weight="600" numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>{`${leg.from.code}  ${legDepartLocal(leg)}`}</Mono>
                  <Icon name="arrowRight" size={13} color="rgba(255,255,255,0.5)" strokeWidth={2.2} />
                  <Mono size={19} weight="600" numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>{`${leg.to.code}  ${legArriveLocal(leg)}`}</Mono>
                </View>
                <T style={{ color: 'rgba(255,255,255,0.6)', fontSize: 13 }}>{`${leg.from.city} → ${leg.to.city} · ${hoursMinutes(legDuration(leg))}`}</T>
                {i < lay.length && (
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    <Icon name="clock" size={13} color="rgba(255,255,255,0.55)" strokeWidth={2} />
                    <T style={{ color: 'rgba(255,255,255,0.55)', fontSize: 13, fontWeight: '600' }}>{`${hoursMinutes(lay[i].duration)} in ${lay[i].airport.city}`}</T>
                  </View>
                )}
              </View>
            ))}
            {flightBooking(trip) && bookingLine(flightBooking(trip)!)}
          </>
        );
      }
      case 'hotel': {
        const h = selectedHotel(trip) ?? pick?.hotel;
        if (!h) return note('No hotel yet', 'Artemis picks a stay that fits your shared budget and area.');
        const nights = hotelNights(trip);
        return (
          <>
            <Display size={22} tracking={0}>{h.name}</Display>
            <T style={{ color: 'rgba(255,255,255,0.65)', fontSize: 13 }}>{`${h.neighborhood} · ${hotelStyleLabel(h.style)} · ${locationLabel(h.location)}`}</T>
            <T style={{ color: 'rgba(255,255,255,0.85)', fontSize: 15 }}>{`${Zoned.day(hotelCheckIn(trip), tz)} — ${Zoned.day(hotelCheckOut(trip), tz)} · ${nights} nights · ${usd(hotelTotal(h, nights))}`}</T>
            {hotelBooking(trip) ? bookingLine(hotelBooking(trip)!) : isBooked(trip) ? (
              <CTAButton compact haptic title="BOOK WITH ARTEMIS" onPress={() => { store.chooseHotelIfNeeded(tripID); setShowHotel(true); }} style={{ alignSelf: 'flex-start' }} />
            ) : null}
          </>
        );
      }
      case 'places':
        return (
          <View style={{ gap: 12 }}>
            <Editorial size={15} style={{ color: 'rgba(255,255,255,0.9)' }}>{d.blurb}</Editorial>
            {d.highlights.map((h, i) => (
              <View key={h} style={{ flexDirection: 'row', gap: 12 }}>
                <Mono size={13} weight="700" color="rgba(255,255,255,0.5)">{String(i + 1).padStart(2, '0')}</Mono>
                <T style={{ color: '#fff', fontSize: 15, fontWeight: '600' }}>{h}</T>
              </View>
            ))}
          </View>
        );
      case 'itinerary':
        return events.length === 0 ? note('Nothing scheduled yet', 'Your itinerary fills in as you choose and book.') : <ItineraryTimeline events={events} />;
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <PhotoBackdrop destination={d} blur={section ? 12 : 0} dim={section ? 0.35 : 0.05} bottomScrim={0.78} />
      <View style={{ flex: 1, justifyContent: 'flex-end', paddingBottom: Math.max(insets.bottom, 12) }}>
        <View style={{ paddingHorizontal: 22, gap: 6 }}>
          <Caps size={11} tracking={3} opacity={0.75}>{spaced(d.country)}</Caps>
          <Display size={76} tracking={-2} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5}>{d.city}</Display>
          {trip.members.length > 1 && <Editorial size={22} style={{ fontFamily: 'Newsreader_400Regular_Italic', color: 'rgba(255,255,255,0.9)' }}>{`with ${others.join(' & ')}`}</Editorial>}
          <T style={{ color: 'rgba(255,255,255,0.75)', fontSize: 11.5, fontWeight: '600', letterSpacing: 1.6, marginTop: 4 }}>{`${dateRange(trip)}  ·  ${shortCity(tripOrigin(trip)).toUpperCase()} → ${d.city.toUpperCase()}`}</T>
          {!trip.isPast && (
            <View style={{ marginTop: 14 }}>
              {isBooked(trip)
                ? <CTAButton haptic icon="plane" title="ENTER TRIP MODE" onPress={() => router.push({ pathname: '/tripmode', params: { id: tripID } })} />
                : <CTAButton haptic icon="sparkles" title={trip.stage === 'draft' ? 'PLAN THIS TRIP' : 'CONTINUE PLANNING'} onPress={() => { if (trip.stage === 'draft') store.beginPlanning(tripID); router.push({ pathname: '/plan', params: { id: tripID } }); }} />}
            </View>
          )}
        </View>
        <View style={{ flexDirection: 'row', gap: 8, paddingHorizontal: 22, paddingTop: 18 }}>
          {SECTIONS.map((s) => {
            const on = section === s.id;
            return (
              <Pressable key={s.id} accessibilityRole="button" accessibilityState={{ selected: on }} accessibilityLabel={s.id}
                onPress={() => { HapticsService.select(); setSection(on ? undefined : s.id); }}
                style={{ flex: 1, minHeight: 58, borderRadius: 18, overflow: 'hidden', alignItems: 'center', justifyContent: 'center', gap: 5, backgroundColor: on ? '#fff' : 'rgba(0,0,0,0.28)', borderWidth: 1, borderColor: on ? 'transparent' : 'rgba(255,255,255,0.22)' }}>
                {!on && <BlurView intensity={24} tint="dark" style={StyleSheet.absoluteFill} />}
                <Icon name={s.icon} size={18} color={on ? '#000' : '#fff'} strokeWidth={1.9} />
                <T style={{ color: on ? '#000' : '#fff', fontSize: 8.5, fontWeight: '600', letterSpacing: 1.4 }}>{s.id.toUpperCase()}</T>
              </Pressable>
            );
          })}
        </View>
        {section && (
          <Animated.View key={section} entering={FadeInDown.duration(400)} exiting={FadeOut.duration(200)} layout={LinearTransition}
            style={{ marginHorizontal: 16, marginTop: 12, maxHeight: 330, borderRadius: 28, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.18)' }}>
            <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
            <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.4)' }]} />
            <ScrollView contentContainerStyle={{ padding: 18, gap: 14 }} showsVerticalScrollIndicator={false}>{panel(section)}</ScrollView>
          </Animated.View>
        )}
      </View>
      <View style={{ position: 'absolute', top: insets.top + 8, left: 20, right: 20, flexDirection: 'row', justifyContent: 'space-between' }}>
        <RoundIconButton icon="chevronLeft" label="Back" onPress={() => router.back()} />
        {trip.ticketCutAt !== undefined
          ? <GlassButton title="VIEW TICKET" icon="ticket" onPress={() => router.push({ pathname: '/ticket', params: { id: tripID } })} />
          : isBooked(trip) ? <GlassButton title="CUT YOUR TICKET" icon="scissors" onPress={() => router.push({ pathname: '/ticket', params: { id: tripID } })} /> : null}
      </View>
      <WhySheet result={why} onClose={() => setWhy(undefined)} />
      <HotelBookingSheet tripID={tripID} visible={showHotel} onClose={() => { setShowHotel(false); store.dismissCheck(); }} />
    </View>
  );
}

