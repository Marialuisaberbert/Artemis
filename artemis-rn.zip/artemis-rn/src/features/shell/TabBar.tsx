import React from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { BlurView } from 'expo-blur';
import Animated, { useAnimatedStyle, withTiming } from 'react-native-reanimated';
import { Icon, IconName } from '../../design/Icon';
import { T } from '../../design/text';
import { alpha } from '../../design/theme';
import { HapticsService } from '../../services/HapticsService';
import { AppTab, appTabs, tabTitle } from '../../store/router';

const ICONS: Record<AppTab, IconName> = { home: 'globe', explore: 'compass', trips: 'plane', profile: 'person' };

/** Four sections, and a quiet floating pill. The trip is the centre of the app, not the tab bar. */
export function TabBar({ selection, onSelect }: { selection: AppTab; onSelect: (t: AppTab) => void }) {
  return (
    <View style={{ borderRadius: 999, overflow: 'hidden', borderWidth: 1, borderColor: alpha('#ffffff', 0.18), shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 16, shadowOffset: { width: 0, height: 6 } }}>
      <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
      <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.45)' }]} />
      <View style={{ flexDirection: 'row', padding: 5 }}>
        {appTabs.map((tab) => <Item key={tab} tab={tab} on={selection === tab} onSelect={onSelect} />)}
      </View>
    </View>
  );
}

function Item({ tab, on, onSelect }: { tab: AppTab; on: boolean; onSelect: (t: AppTab) => void }) {
  const bg = useAnimatedStyle(() => ({ opacity: withTiming(on ? 1 : 0, { duration: 350 }) }));
  return (
    <Pressable
      accessibilityRole="button" accessibilityLabel={tabTitle(tab).charAt(0) + tabTitle(tab).slice(1).toLowerCase()} accessibilityState={{ selected: on }}
      onPress={() => { if (!on) { HapticsService.select(); onSelect(tab); } }}
      style={{ flex: 1, minHeight: 54, alignItems: 'center', justifyContent: 'center', gap: 3, borderRadius: 999 }}
    >
      <Animated.View style={[StyleSheet.absoluteFill, { borderRadius: 999, backgroundColor: alpha('#ffffff', 0.16) }, bg]} />
      <Icon name={ICONS[tab]} size={18} color={on ? '#fff' : alpha('#ffffff', 0.55)} strokeWidth={on ? 2 : 1.7} />
      <T style={{ color: on ? '#fff' : alpha('#ffffff', 0.55), fontSize: 8.5, fontWeight: '600', letterSpacing: 1.4 }} maxFontSizeMultiplier={1.15}>{tabTitle(tab)}</T>
    </Pressable>
  );
}
