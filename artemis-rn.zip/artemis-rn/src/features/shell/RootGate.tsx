import React, { useEffect, useRef, useState } from 'react';
import { AppState, StyleSheet, View } from 'react-native';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import { colors } from '../../design/theme';
import { Audio } from '../../services/AudioService';
import { useRouterState } from '../../store/router';
import { getTripStore, useTripStore } from '../../store/useTripStore';
import { MorningGreeting } from '../greeting/MorningGreeting';
import { OnboardingView } from '../onboarding/OnboardingView';
import { MainTabs } from './MainTabs';

/**
 * Decides what to show: first-launch onboarding, or the app (with today's morning greeting in front of it, once).
 * Everything cinematic (planning, Trip Mode, the ticket) is presented over the tabs, so the trip feels like one journey.
 */
export function RootGate() {
  const ready = useTripStore((s) => s.ready);
  const hasOnboarded = useTripStore((s) => s.hasOnboarded);
  const soundEnabled = useTripStore((s) => s.soundEnabled);
  const replay = useRouterState((s) => s.replayGreeting);
  /** Whether today's greeting is still on screen. Decided once, when the app opens. */
  const [greeting, setGreeting] = useState<boolean | undefined>(undefined);
  const lastReplay = useRef(replay);

  useEffect(() => { Audio.setEnabled(soundEnabled); }, [soundEnabled]);

  useEffect(() => {
    if (ready && greeting === undefined) setGreeting(getTripStore().shouldShowMorningGreeting());
  }, [ready, greeting]);

  useEffect(() => {
    if (replay !== lastReplay.current) { lastReplay.current = replay; if (getTripStore().hasOnboarded) setGreeting(true); }
  }, [replay]);

  // Back after midnight: the first open of a new day gets its greeting too.
  useEffect(() => {
    const sub = AppState.addEventListener('change', (s) => {
      if (s === 'active' && greeting === false && getTripStore().shouldShowMorningGreeting()) setGreeting(true);
    });
    return () => sub.remove();
  }, [greeting]);

  // Onboarding ends on its own "welcome aboard", so today's greeting is already spoken for.
  useEffect(() => {
    if (hasOnboarded && greeting === undefined && ready) return;
  }, [hasOnboarded, greeting, ready]);
  const prevOnboarded = useRef(hasOnboarded);
  useEffect(() => {
    if (!prevOnboarded.current && hasOnboarded) { getTripStore().markGreetingShown(); setGreeting(false); }
    prevOnboarded.current = hasOnboarded;
  }, [hasOnboarded]);

  if (!ready) return <View style={{ flex: 1, backgroundColor: colors.field }} />;

  const s = getTripStore();
  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      {hasOnboarded ? (
        <Animated.View key="main" entering={FadeIn.duration(500)} style={StyleSheet.absoluteFill}>
          <MainTabs />
          {greeting === true && (
            <Animated.View entering={FadeIn.duration(300)} exiting={FadeOut.duration(800)} style={[StyleSheet.absoluteFill, { zIndex: 30 }]}>
              <MorningGreeting
                context={s.dailyContext()} word={s.greetingWord()} firstName={s.you.firstName} place={s.currentPlace}
                onFinish={() => { getTripStore().markGreetingShown(); setGreeting(false); }}
              />
            </Animated.View>
          )}
        </Animated.View>
      ) : (
        <Animated.View key="onboarding" entering={FadeIn.duration(500)} exiting={FadeOut.duration(500)} style={StyleSheet.absoluteFill}>
          <OnboardingView />
        </Animated.View>
      )}
    </View>
  );
}
