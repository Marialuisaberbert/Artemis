import React from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../design/theme';
import { useRouterState } from '../../store/router';
import { DiscoverScreen } from '../destination/DiscoverScreen';
import { HomeScreen } from '../home/HomeScreen';
import { ProfileScreen } from '../profile/ProfileScreen';
import { TripsScreen } from '../trips/TripsScreen';
import { TabBar } from './TabBar';

/** Four sections and a floating bar. Sections crossfade; the bar steps aside whenever a screen is pushed over the tabs. */
export function MainTabs() {
  const tab = useRouterState((s) => s.tab);
  const setTab = useRouterState((s) => s.setTab);
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      <Animated.View key={tab} entering={FadeIn.duration(350)} exiting={FadeOut.duration(200)} style={StyleSheet.absoluteFill}>
        {tab === 'home' && <HomeScreen />}
        {tab === 'explore' && <DiscoverScreen />}
        {tab === 'trips' && <TripsScreen />}
        {tab === 'profile' && <ProfileScreen />}
      </Animated.View>
      <View pointerEvents="box-none" style={{ position: 'absolute', left: 22, right: 22, bottom: Math.max(insets.bottom, 12) - 4 }}>
        <TabBar selection={tab} onSelect={setTab} />
      </View>
    </View>
  );
}
