import React, { useEffect } from 'react';
import { Pressable, StyleSheet, View } from 'react-native';
import { BlurView } from 'expo-blur';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { runOnJS, SlideInUp, SlideOutUp, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon, IconName } from '../../design/Icon';
import { T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore, useTripStore } from '../../store/useTripStore';
import type { ArtemisNotification } from '../../store/tripStore';

/** An iOS-style banner that slides down, and up again. */
export function NotificationBannerHost() {
  const banner = useTripStore((s) => s.banner);
  const insets = useSafeAreaInsets();
  return (
    <View pointerEvents="box-none" style={[StyleSheet.absoluteFill, { zIndex: 100, paddingTop: insets.top + 6, paddingHorizontal: 10 }]}>
      {banner && <Card key={banner.id} n={banner} />}
    </View>
  );
}

export const notificationIcon = (n: { symbol: string }): IconName =>
  ({ checkmark: 'check', exclamationmark: 'exclamation', xmark: 'close', sparkles: 'sparkles', 'list.number': 'list', 'airplane.departure': 'plane' } as Record<string, IconName>)[n.symbol] ?? 'person';

function Card({ n }: { n: ArtemisNotification }) {
  const drag = useSharedValue(0);
  useEffect(() => {
    if (n.tone === 'good') HapticsService.success(); else if (n.tone === 'attention') HapticsService.warning(); else HapticsService.soft();
  }, [n.tone]);
  const dismiss = () => getTripStore().dismissBanner();
  const pan = Gesture.Pan()
    .onChange((e) => { drag.value = Math.min(0, e.translationY); })
    .onEnd((e) => { if (e.translationY < -20) runOnJS(dismiss)(); drag.value = withTiming(0); });
  const style = useAnimatedStyle(() => ({ transform: [{ translateY: drag.value }] }));
  const attention = n.tone === 'attention';
  return (
    <GestureDetector gesture={pan}>
      <Animated.View entering={SlideInUp.duration(450)} exiting={SlideOutUp.duration(300)} style={style}>
        <Pressable onPress={dismiss} accessibilityRole="alert" accessibilityLabel={`${n.title}. ${n.body}`}
          style={{ borderRadius: 22, overflow: 'hidden', borderWidth: 1, borderColor: alpha(colors.luster, 0.18), shadowColor: colors.depths, shadowOpacity: 0.4, shadowRadius: 18, shadowOffset: { width: 0, height: 8 } }}>
          <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFill} />
          <View style={[StyleSheet.absoluteFill, { backgroundColor: alpha(colors.depths, 0.94) }]} />
          <View style={{ flexDirection: 'row', gap: 12, padding: 14 }}>
            <View style={{ width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: attention ? colors.habanero : alpha('#ffffff', 0.16) }}>
              <Icon name={notificationIcon(n)} size={15} color={attention ? colors.depths : '#fff'} strokeWidth={2.6} />
            </View>
            <View style={{ flex: 1, gap: 2 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <T style={{ color: alpha(colors.luster, 0.6), fontSize: 10, fontWeight: '800', letterSpacing: 1.6 }}>ARTEMIS</T>
                <T style={{ color: alpha(colors.luster, 0.5), fontSize: 11 }}>now</T>
              </View>
              <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>{n.title}</T>
              <T numberOfLines={2} style={{ color: alpha(colors.luster, 0.75), fontSize: 13 }}>{n.body}</T>
            </View>
          </View>
        </Pressable>
      </Animated.View>
    </GestureDetector>
  );
}
