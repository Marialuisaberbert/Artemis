import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon } from '../../design/Icon';
import { NightBackdrop } from '../../design/NightBackdrop';
import { DestinationPhotoView } from '../../design/PhotoView';
import { Body, Display, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { GlassPill, SegmentedPill } from '../../design/widgets';
import { Trip, dateRange, isBooked, selectedFlight, shortDateRange, travelerCount, tripDestination, tripStatusLabel } from '../../domain/trips/trip';
import { flightDeparture } from '../../domain/trips/flights';
import { countdown } from '../../domain/shared/time';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore, useTripStore } from '../../store/useTripStore';

/** A short, human countdown. */
export function tripTiming(trip: Trip, now = Date.now()): string {
  const flight = selectedFlight(trip);
  const target = flight ? flightDeparture(flight) : trip.startDate;
  const seconds = (target - now) / 1000;
  if (trip.isPast) return 'COMPLETED';
  if (seconds < 0) return 'UNDERWAY';
  const days = Math.trunc(seconds / 86_400);
  if (days >= 2) return `IN ${days} DAYS`;
  if (days === 1) return 'TOMORROW';
  return `IN ${countdown(seconds)}`;
}

/** A trip as a photograph: the destination fills the card, the city is set large, everything else is quiet. */
export function TripPhotoCard({ trip, height = 250 }: { trip: Trip; height?: number }) {
  const d = tripDestination(trip);
  return (
    <View
      accessible accessibilityRole="button"
      accessibilityLabel={`${d.city}, ${shortDateRange(trip)}, ${trip.members.length} travelers. ${tripStatusLabel(trip).toLowerCase()}.`}
      style={{ height, borderRadius: 28, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.14)', backgroundColor: '#0d0d0d' }}
    >
      <DestinationPhotoView photo={d.photo} title={d.city} />
      <LinearGradient colors={['rgba(0,0,0,0.3)', 'rgba(0,0,0,0)', 'rgba(0,0,0,0.72)']} style={StyleSheet.absoluteFill} />
      <View style={{ flex: 1, padding: 18, justifyContent: 'space-between' }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <GlassPill text={tripTiming(trip)} />
          {trip.ticketCutAt !== undefined && <GlassPill text="TICKET SAVED" icon="ticket" />}
        </View>
        <View style={{ gap: 4 }}>
          <Display size={40} tracking={0} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>{d.city}</Display>
          <T style={{ color: 'rgba(255,255,255,0.8)', fontSize: 11, fontWeight: '600', letterSpacing: 1.6 }}>
            {`${dateRange(trip)} · ${trip.members.length} TRAVELER${trip.members.length === 1 ? '' : 'S'}`}
          </T>
        </View>
      </View>
    </View>
  );
}

export function TripsScreen() {
  const insets = useSafeAreaInsets();
  const trips = useTripStore((s) => s.trips);
  const [showPast, setShowPast] = useState(false);
  const list = useMemo(
    () => (showPast ? trips.filter((t) => t.isPast).sort((a, b) => b.startDate - a.startDate) : trips.filter((t) => !t.isPast).sort((a, b) => a.startDate - b.startDate)),
    [trips, showPast],
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      <NightBackdrop glow={0.3} showStars={false} />
      <ScrollView contentContainerStyle={{ paddingTop: insets.top + 8, paddingBottom: 130, paddingHorizontal: 20, gap: 12 }} showsVerticalScrollIndicator={false}>
        <View style={{ gap: 18, paddingBottom: 6 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Display size={40} tracking={-1}>Trips</Display>
            <Pressable accessibilityRole="button" accessibilityLabel="Create a trip" onPress={() => { HapticsService.tap(); router.push('/create'); }}
              style={{ width: 46, height: 46, borderRadius: 23, borderWidth: 1, borderColor: alpha(colors.luster, 0.3), alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="plus" size={20} color={colors.luster} strokeWidth={2.4} />
            </Pressable>
          </View>
          <SegmentedPill items={[{ value: 'up', label: 'UPCOMING' }, { value: 'past', label: 'PAST' }]} selection={showPast ? 'past' : 'up'} onChange={(v) => setShowPast(v === 'past')} />
        </View>
        {list.length === 0 && (
          <View style={{ alignItems: 'center', gap: 8, paddingVertical: 60 }}>
            <T style={{ color: colors.luster, fontSize: 17, fontWeight: '600' }}>{showPast ? 'No past trips yet' : 'No trips yet'}</T>
            <Body size={15} opacity={0.65} style={{ textAlign: 'center' }}>{showPast ? "Trips you've taken will appear here." : 'Create one and Artemis will help the group agree.'}</Body>
          </View>
        )}
        {list.map((trip) => (
          <View key={trip.id} style={{ gap: 8 }}>
            <Pressable onPress={() => router.push({ pathname: '/trip', params: { id: trip.id } })}>
              <TripPhotoCard trip={trip} />
            </Pressable>
            <View style={{ flexDirection: 'row', gap: 10 }}>
              {!trip.isPast && (
                <Chip label={isBooked(trip) ? 'Trip Mode' : 'Plan'} icon={isBooked(trip) ? 'plane' : 'sparkles'} accent
                  onPress={() => {
                    HapticsService.tap();
                    if (isBooked(trip)) router.push({ pathname: '/tripmode', params: { id: trip.id } });
                    else { getTripStore().beginPlanning(trip.id); router.push({ pathname: '/plan', params: { id: trip.id } }); }
                  }} />
              )}
              <Chip label="Delete" icon="close" onPress={() => { HapticsService.warning(); getTripStore().deleteTrip(trip.id); }} />
              <View style={{ flex: 1 }} />
              <T style={{ color: alpha(colors.luster, 0.5), fontSize: 11, alignSelf: 'center' }}>{travelerCount(trip)} traveler{travelerCount(trip) === 1 ? '' : 's'}</T>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}

function Chip({ label, icon, onPress, accent = false }: { label: string; icon: 'plane' | 'sparkles' | 'close'; onPress: () => void; accent?: boolean }) {
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress}
      style={{ minHeight: 44, paddingHorizontal: 14, borderRadius: 999, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: accent ? colors.habanero : alpha(colors.luster, 0.08), borderWidth: 1, borderColor: accent ? 'transparent' : alpha(colors.luster, 0.2) }}>
      <Icon name={icon} size={14} color={accent ? colors.depths : colors.luster} strokeWidth={2.2} />
      <T style={{ color: accent ? colors.depths : colors.luster, fontSize: 13, fontWeight: '700' }}>{label}</T>
    </Pressable>
  );
}
