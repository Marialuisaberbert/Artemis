import React, { useMemo, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { router } from 'expo-router';
import Animated, { FadeInDown, FadeOut } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Calendar, YMD, addDaysYMD, formatYMD, ymdFromDate, ymdKey } from '../../design/Calendar';
import { CTAButton, GlassPanel, RoundIconButton } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { PhotoBackdrop } from '../../design/PhotoView';
import { Caps, Display, Editorial, T } from '../../design/text';
import { TravelerAvatar } from '../../design/widgets';
import { Destination, Destinations } from '../../domain/destinations/destinations';
import { placeAirport } from '../../domain/destinations/place';
import { dateFrom, timeZone } from '../../domain/shared/time';
import { fullName } from '../../domain/matching/traveler';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore, useTripStore } from '../../store/useTripStore';
import { DestinationViewer, useDestinations } from '../destination/DestinationViewer';

const spaced = (s: string) => s.toUpperCase().split('').join(' ');

/**
 * Start a trip. The destination is on screen from the first tap to the last: choose a place by swiping through
 * photographs, then dates, then who is coming, over the same photograph as it comes into focus.
 */
export function CreateTripFlow({ presetID }: { presetID?: string }) {
  const insets = useSafeAreaInsets();
  const destinations = useDestinations();
  const you = useTripStore((s) => s.you);
  const friends = useTripStore((s) => s.friends());
  const place = useTripStore((s) => s.currentPlace);
  const preset = presetID ? Destinations.named(presetID) : undefined;
  const [step, setStep] = useState(preset ? 1 : 0);
  const [destination, setDestination] = useState<Destination | undefined>(preset);
  const today = useMemo(() => ymdFromDate(new Date()), []);
  const [start, setStart] = useState<YMD>(() => addDaysYMD(today, 21));
  const [end, setEnd] = useState<YMD>(() => addDaysYMD(today, 21 + (preset?.suggestedDays ?? 6)));
  const [editing, setEditing] = useState<'start' | 'end'>('start');
  const [chosen, setChosen] = useState<string[]>([]);

  const choose = (d: Destination) => {
    setDestination(d);
    const s = addDaysYMD(today, 21);
    setStart(s); setEnd(addDaysYMD(s, d.suggestedDays));
    setStep(1);
  };

  const back = () => { if (step === 1 && !presetID) setStep(0); else if (step === 1) router.back(); else setStep((s) => s - 1); };

  const create = () => {
    if (!destination) return;
    HapticsService.success();
    const tz = timeZone(placeAirport(place).timeZoneID);
    const s = dateFrom(start.y, start.m, start.d, tz);
    const eYMD = ymdKey(end) <= ymdKey(start) ? addDaysYMD(start, 1) : end;
    const e = dateFrom(eYMD.y, eYMD.m, eYMD.d, tz);
    const store = getTripStore();
    const id = store.createTrip({ destination, start: s, end: e, friendIDs: chosen });
    store.beginPlanning(id);
    router.replace({ pathname: '/plan', params: { id } });
  };

  if (step === 0 || !destination) {
    return <DestinationViewer destinations={destinations} mode="choose" showsClose onClose={() => router.back()} onStart={choose} />;
  }

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <PhotoBackdrop destination={destination} blur={step === 1 ? 14 : 4} dim={0.4} bottomScrim={0.7} />
      <View style={{ flex: 1, paddingTop: insets.top + 8 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20 }}>
          <RoundIconButton icon="chevronLeft" label="Back" onPress={back} />
          <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }} accessible accessibilityLabel={`Step ${step + 1} of 3`}>
            {[0, 1, 2].map((i) => <View key={i} style={{ height: 3, borderRadius: 2, width: i === step ? 24 : 7, backgroundColor: i <= step ? '#fff' : 'rgba(255,255,255,0.3)' }} />)}
          </View>
          <RoundIconButton icon="close" label="Close" onPress={() => router.back()} />
        </View>
        <View style={{ paddingHorizontal: 22, paddingTop: 18, gap: 4 }}>
          <Caps size={10.5} tracking={3} opacity={0.7}>{spaced(destination.country)}</Caps>
          <Display size={step === 1 ? 68 : 52} tracking={-1.5} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.5}>{destination.city}</Display>
        </View>
        {step === 1 ? (
          <Animated.View key="when" entering={FadeInDown.duration(500)} exiting={FadeOut} style={{ flex: 1 }}>
            <ScrollView contentContainerStyle={{ paddingBottom: 12, gap: 16 }} showsVerticalScrollIndicator={false}>
              <Editorial size={19} style={{ fontFamily: 'Newsreader_400Regular_Italic', color: 'rgba(255,255,255,0.9)', paddingHorizontal: 22, paddingTop: 10 }}>Choose your dates</Editorial>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 22 }}>
                <DateChip title="Departure" v={start} on={editing === 'start'} onPress={() => setEditing('start')} />
                <Icon name="arrowRight" size={16} color="rgba(255,255,255,0.5)" strokeWidth={2.4} />
                <DateChip title="Return" v={end} on={editing === 'end'} onPress={() => setEditing('end')} />
              </View>
              <View style={{ paddingHorizontal: 22 }}>
                <GlassPanel radius={26} padding={8}>
                  <Calendar
                    value={editing === 'start' ? start : end} min={editing === 'start' ? today : start} rangeFrom={start} rangeTo={end}
                    onChange={(v) => {
                      if (editing === 'start') { setStart(v); if (ymdKey(end) <= ymdKey(v)) setEnd(addDaysYMD(v, 1)); } else setEnd(v);
                    }}
                  />
                </GlassPanel>
              </View>
            </ScrollView>
            <View style={{ paddingHorizontal: 22, paddingBottom: Math.max(insets.bottom, 12) }}>
              <CTAButton title="CONTINUE  →" haptic onPress={() => setStep(2)} />
            </View>
          </Animated.View>
        ) : (
          <Animated.View key="who" entering={FadeInDown.duration(500)} exiting={FadeOut} style={{ flex: 1 }}>
            <ScrollView contentContainerStyle={{ paddingBottom: 12, gap: 14, paddingHorizontal: 22 }} showsVerticalScrollIndicator={false}>
              <Editorial size={19} style={{ fontFamily: 'Newsreader_400Regular_Italic', color: 'rgba(255,255,255,0.9)', paddingTop: 10 }}>Who's coming?</Editorial>
              <GlassPanel radius={22} padding={12}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                  <TravelerAvatar traveler={you} size={46} badge="done" />
                  <View style={{ flex: 1 }}>
                    <T style={{ color: '#fff', fontSize: 17, fontWeight: '600' }}>You</T>
                    <T style={{ color: 'rgba(255,255,255,0.65)', fontSize: 13 }}>Organizer</T>
                  </View>
                </View>
              </GlassPanel>
              {friends.map((f) => {
                const on = chosen.includes(f.id);
                return (
                  <Pressable key={f.id} accessibilityRole="button" accessibilityState={{ selected: on }} accessibilityLabel={fullName(f)}
                    onPress={() => { HapticsService.select(); setChosen((c) => (on ? c.filter((x) => x !== f.id) : [...c, f.id])); }}>
                    <GlassPanel radius={22} padding={12} style={on ? { borderColor: 'rgba(255,255,255,0.7)' } : undefined}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                        <TravelerAvatar traveler={f} size={46} />
                        <T style={{ flex: 1, color: '#fff', fontSize: 17, fontWeight: '600' }}>{fullName(f)}</T>
                        <Icon name={on ? 'check' : 'plus'} size={20} color={on ? '#fff' : 'rgba(255,255,255,0.6)'} strokeWidth={2.4} />
                      </View>
                    </GlassPanel>
                  </Pressable>
                );
              })}
            </ScrollView>
            <View style={{ paddingHorizontal: 22, paddingBottom: Math.max(insets.bottom, 12) }}>
              <CTAButton title={chosen.length === 0 ? 'CREATE TRIP' : 'CREATE TRIP & INVITE  →'} onPress={create} />
            </View>
          </Animated.View>
        )}
      </View>
    </View>
  );
}

function DateChip({ title, v, on, onPress }: { title: string; v: YMD; on: boolean; onPress: () => void }) {
  return (
    <Pressable accessibilityRole="button" accessibilityState={{ selected: on }} accessibilityLabel={`${title}, ${formatYMD(v)}`} onPress={() => { HapticsService.select(); onPress(); }}
      style={{ flex: 1, padding: 14, borderRadius: 18, gap: 3, backgroundColor: on ? '#fff' : 'rgba(0,0,0,0.35)', borderWidth: 1, borderColor: on ? 'transparent' : 'rgba(255,255,255,0.25)' }}>
      <T style={{ color: on ? 'rgba(0,0,0,0.55)' : 'rgba(255,255,255,0.6)', fontSize: 10, fontWeight: '600', letterSpacing: 1.6 }}>{title.toUpperCase()}</T>
      <T style={{ color: on ? '#000' : '#fff', fontSize: 17, fontWeight: '600' }}>{formatYMD(v)}</T>
    </Pressable>
  );
}

