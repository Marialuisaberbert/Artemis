import React, { useState } from 'react';
import { Pressable, ScrollView, TextInput, View } from 'react-native';
import { router } from 'expo-router';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CTAButton, GlassPanel } from '../../design/controls';
import { NightBackdrop } from '../../design/NightBackdrop';
import { DestinationPhotoView } from '../../design/PhotoView';
import { Body, Display, Eyebrow, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { Airports } from '../../domain/destinations/geo';
import { Zoned, timeZone } from '../../domain/shared/time';
import { TripDraft, TripPlanner } from '../../domain/trips/planner';
import { usd } from '../../domain/shared/money';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore, useTripStore } from '../../store/useTripStore';

const planner = new TripPlanner();

/** A lightweight travel command: one sentence in, a visual trip out. Parsing runs on device. */
export function PlannerSheet() {
  const insets = useSafeAreaInsets();
  const friends = useTripStore((s) => s.friends());
  const [text, setText] = useState('');
  const [draft, setDraft] = useState<TripDraft | undefined>();
  const [thinking, setThinking] = useState(false);

  const understand = () => {
    HapticsService.tap();
    setThinking(true);
    setTimeout(() => { setDraft(planner.parse(text, friends)); setThinking(false); HapticsService.success(); }, 700);
  };
  const create = (d: TripDraft) => {
    const id = getTripStore().createTripFromDraft(d);
    if (!id) return;
    HapticsService.success();
    getTripStore().beginPlanning(id);
    router.replace({ pathname: '/plan', params: { id } });
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <NightBackdrop glow={0.3} showStars={false} />
      <ScrollView keyboardDismissMode="interactive" keyboardShouldPersistTaps="handled" contentContainerStyle={{ padding: 20, paddingTop: 20, paddingBottom: insets.bottom + 40, gap: 20 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Plan with a sentence</Eyebrow>
          <Pressable accessibilityRole="button" accessibilityLabel="Done" onPress={() => router.back()} style={{ minWidth: 44, minHeight: 44, alignItems: 'flex-end', justifyContent: 'center' }}>
            <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>Done</T>
          </Pressable>
        </View>
        <Display size={40} tracking={-1} color={colors.luster}>{'Tell Artemis\nwhere.'}</Display>
        <View style={{ padding: 12, borderRadius: 22, backgroundColor: alpha(colors.luster, 0.08), borderWidth: 1, borderColor: alpha(colors.luster, 0.25) }}>
          <TextInput
            value={text} onChangeText={(t) => { setText(t); setDraft(undefined); }} multiline accessibilityLabel="Describe your trip"
            placeholder="Plan a 6-day trip to Rome with Sofia in September. Good food and museums, under $2,000 each."
            placeholderTextColor={alpha(colors.luster, 0.4)} selectionColor={colors.habanero} keyboardAppearance="dark"
            style={{ minHeight: 110, color: colors.luster, fontSize: 16, textAlignVertical: 'top' }}
          />
        </View>
        {!draft && (
          <View style={{ gap: 8 }}>
            <Eyebrow color={alpha(colors.luster, 0.6)} opacity={1}>Try</Eyebrow>
            {TripPlanner.examples.map((ex) => (
              <Pressable key={ex} accessibilityRole="button" onPress={() => { HapticsService.select(); setText(ex); }}>
                <GlassPanel radius={16} padding={12}><T style={{ color: alpha(colors.luster, 0.8), fontSize: 13 }}>{`“${ex}”`}</T></GlassPanel>
              </Pressable>
            ))}
          </View>
        )}
        {draft && <DraftCard draft={draft} />}
        {draft?.destination ? (
          <CTAButton title="CREATE TRIP  →" onPress={() => create(draft)} />
        ) : (
          <CTAButton title={thinking ? 'READING…' : 'UNDERSTAND'} icon="sparkles" disabled={!text.trim() || thinking} onPress={understand} />
        )}
        <Body size={12} opacity={0.45}>Prototype: the sentence is read on your device by a simple rule-based parser, not a language model.</Body>
      </ScrollView>
    </View>
  );
}

function DraftCard({ draft }: { draft: TripDraft }) {
  const tz = timeZone(Airports.gig.timeZoneID);
  const dates = draft.start === undefined ? "You'll pick them next" : draft.end !== undefined ? `${Zoned.day(draft.start, tz)} – ${Zoned.day(draft.end, tz)}` : Zoned.day(draft.start, tz);
  const row = (label: string, value: string, ok: boolean) => (
    <View key={label} style={{ flexDirection: 'row', alignItems: 'baseline' }}>
      <T style={{ width: 96, color: alpha(colors.luster, 0.55), fontSize: 10.5, fontWeight: '800', letterSpacing: 1.4 }}>{label.toUpperCase()}</T>
      <T style={{ flex: 1, color: ok ? colors.luster : alpha(colors.luster, 0.5), fontSize: 15, fontWeight: '600' }}>{value}</T>
    </View>
  );
  const d = draft.destination;
  return (
    <Animated.View entering={FadeInDown.duration(500)}>
      <GlassPanel radius={26} padding={18}>
        <View style={{ gap: 14 }}>
          <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Artemis understood</Eyebrow>
          {d && <View style={{ height: 110, borderRadius: 18, overflow: 'hidden' }}><DestinationPhotoView photo={d.photo} title={d.city} /></View>}
          {row('Destination', d ? `${d.city}, ${d.country}` : 'Not found — try a city like Rome or Tokyo', !!d)}
          {d && row('Dates', dates, draft.start !== undefined)}
          {d && row('Length', draft.days !== undefined ? `${draft.days} days` : '—', draft.days !== undefined)}
          {d && row('Travelers', ['You', ...draft.travelers.map((t) => t.firstName)].join(' & '), true)}
          {d && row('Budget', draft.budgetPerPerson !== undefined ? `${usd(draft.budgetPerPerson)} each` : 'Not mentioned', draft.budgetPerPerson !== undefined)}
          {d && row('Preferences', draft.interests.length ? draft.interests.join(' · ') : 'Not mentioned', draft.interests.length > 0)}
        </View>
      </GlassPanel>
    </Animated.View>
  );
}
