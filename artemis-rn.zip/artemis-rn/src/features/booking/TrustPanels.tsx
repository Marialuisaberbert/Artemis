import React from 'react';
import { Pressable, View } from 'react-native';
import Animated, { ZoomIn } from 'react-native-reanimated';
import { GlassPanel } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { Eyebrow, Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { Spinner } from '../../design/widgets';
import { verifiedDomain } from '../../domain/trust/demoData';
import { calcOver, EvaluationResult, Layer, layers, layerQuestion, layerTitle, resultFor, VerificationResult } from '../../domain/trust/models';
import { usd } from '../../domain/shared/money';
import type { TrustCheckRun } from '../../store/tripStore';
import { useTripStore } from '../../store/useTripStore';

type RowState = 'idle' | 'checking' | 'passed' | 'failed' | 'skipped';

function rowState(layer: Layer, run?: TrustCheckRun): RowState {
  if (!run) return 'idle';
  const r = run.completed[layer];
  if (r) return r.status === 'passed' ? 'passed' : 'failed';
  if (run.active === layer) return 'checking';
  if (run.result && resultFor(run.result, layer).status === 'notReached') return 'skipped';
  return 'idle';
}

const HEADLINES: Record<Layer, Record<RowState, string>> = {
  identity: { idle: 'Verified provider', checking: 'Verifying provider…', passed: 'Verified provider', failed: "Couldn't verify the provider", skipped: 'Not checked' },
  policy: { idle: 'Within your policy', checking: 'Checking your policy…', passed: 'Within your policy', failed: 'Outside your policy', skipped: 'Not checked' },
  financial: { idle: 'Payment approved', checking: 'Checking payment…', passed: 'Clear', failed: 'Payment needs you', skipped: 'Not checked' },
};

/** IDENTITY → POLICY → FINANCIAL, resolving one after another. Friendly words up front, the machinery one tap away. */
export function TrustCheckPanel({ run, onWhy }: { run?: TrustCheckRun; onWhy?: () => void }) {
  return (
    <GlassPanel radius={28} padding={18}>
      <View style={{ gap: 14 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Artemis trust check</Eyebrow>
          {run?.result && (
            <Pressable accessibilityRole="button" accessibilityLabel="Why?" onPress={onWhy} style={{ minHeight: 32, flexDirection: 'row', alignItems: 'center', gap: 5 }}>
              <Icon name="info" size={14} color={colors.aster} strokeWidth={2} />
              <T style={{ color: colors.aster, fontSize: 13, fontWeight: '600' }}>Why?</T>
            </Pressable>
          )}
        </View>
        {layers.map((l) => <TrustRow key={l} layer={l} run={run} />)}
      </View>
    </GlassPanel>
  );
}

function TrustRow({ layer, run }: { layer: Layer; run?: TrustCheckRun }) {
  const state = rowState(layer, run);
  const result: VerificationResult | undefined = run?.completed[layer];
  const headline = HEADLINES[layer][state];
  const detail = state === 'idle' ? layerQuestion(layer) : state === 'checking' ? 'Working…' : state === 'skipped' ? 'Stopped at an earlier layer.' : result?.description ?? '';
  const fill = state === 'passed' ? alpha(colors.royal, 0.5) : state === 'failed' ? (layer === 'identity' ? alpha(colors.luster, 0.12) : alpha(colors.habanero, 0.14)) : alpha(colors.luster, 0.04);
  const stroke = state === 'passed' ? alpha(colors.aster, 0.6) : state === 'failed' ? (layer === 'identity' ? alpha(colors.luster, 0.7) : colors.habanero) : alpha(colors.luster, 0.14);
  return (
    <View
      accessible accessibilityLabel={`${layerTitle(layer)}: ${headline}. ${detail}`}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 14, padding: 12, borderRadius: 18, backgroundColor: fill, borderWidth: 1, borderColor: stroke, borderStyle: state === 'skipped' ? 'dashed' : 'solid' }}
    >
      <View style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
        {state === 'passed' && <Animated.View entering={ZoomIn.duration(250)} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.luster, alignItems: 'center', justifyContent: 'center' }}><Icon name="check" size={17} color={colors.depths} strokeWidth={3.2} /></Animated.View>}
        {state === 'failed' && <Animated.View entering={ZoomIn.duration(250)} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: layer === 'identity' ? colors.luster : colors.habanero, alignItems: 'center', justifyContent: 'center' }}><Icon name={layer === 'identity' ? 'close' : 'exclamation'} size={17} color={colors.depths} strokeWidth={3.2} /></Animated.View>}
        {state === 'checking' && <Spinner size={38} />}
        {state === 'skipped' && <View style={{ width: 40, height: 40, borderRadius: 20, borderWidth: 1.5, borderStyle: 'dashed', borderColor: alpha(colors.luster, 0.25), alignItems: 'center', justifyContent: 'center' }}><View style={{ width: 12, height: 2, backgroundColor: alpha(colors.luster, 0.4) }} /></View>}
        {state === 'idle' && <View style={{ width: 38, height: 38, borderRadius: 19, borderWidth: 1.5, borderColor: alpha(colors.luster, 0.3) }} />}
      </View>
      <View style={{ flex: 1, gap: 2 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <T style={{ color: alpha(colors.luster, 0.55), fontSize: 10.5, fontWeight: '800', letterSpacing: 1.6 }}>{layerTitle(layer)}</T>
          {result?.source && <SourceChip source={result.source} />}
        </View>
        <T style={{ color: state === 'idle' || state === 'skipped' ? alpha(colors.luster, 0.55) : colors.luster, fontSize: 18, fontWeight: '600' }}>{headline}</T>
        <T numberOfLines={state === 'failed' ? 4 : 2} style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>{detail}</T>
      </View>
    </View>
  );
}

/** LIVE when a real service answered, SIMULATED when a local stand-in did, ON DEVICE for rules Artemis evaluates itself. */
export function SourceChip({ source }: { source: 'live' | 'simulated' | 'device' }) {
  const live = source === 'live';
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 7, paddingVertical: 2, borderRadius: 999, backgroundColor: live ? alpha(colors.aster, 0.18) : alpha(colors.luster, 0.08), borderWidth: 1, borderColor: live ? alpha(colors.aster, 0.6) : alpha(colors.luster, 0.18) }}>
      <View style={{ width: 5, height: 5, borderRadius: 2.5, backgroundColor: live ? colors.aster : alpha(colors.luster, 0.4) }} />
      <T style={{ color: live ? colors.aster : alpha(colors.luster, 0.55), fontSize: 8.5, fontWeight: '800', letterSpacing: 1.2 }}>{live ? 'LIVE' : source === 'device' ? 'ON DEVICE' : 'SIMULATED'}</T>
    </View>
  );
}

// MARK: - Outcome panels

const Figure = ({ label, value, hot = false }: { label: string; value: string; hot?: boolean }) => (
  <View style={{ flex: 1, padding: 10, borderRadius: 12, gap: 3, backgroundColor: hot ? colors.habanero : alpha(colors.depths, 0.5) }}>
    <T style={{ color: hot ? alpha(colors.depths, 0.7) : alpha(colors.luster, 0.55), fontSize: 9, fontWeight: '800', letterSpacing: 1.1 }}>{label.toUpperCase()}</T>
    <Mono size={14} weight="700" color={hot ? colors.depths : colors.luster} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>{value}</Mono>
  </View>
);

export function ApprovalRequiredPanel({ result, onBack }: { result: EvaluationResult; onBack: () => void }) {
  const calc = result.policy.calculation;
  const cap = result.financial.cap;
  return (
    <GlassPanel radius={26} padding={18} style={{ borderColor: alpha(colors.habanero, 0.85), backgroundColor: alpha(colors.habanero, 0.1) }}>
      <View style={{ gap: 14 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.habanero, alignItems: 'center', justifyContent: 'center' }}><Icon name="exclamation" size={17} color={colors.depths} strokeWidth={3.2} /></View>
          <View style={{ flex: 1, gap: 2 }}>
            <T style={{ color: colors.habanero, fontSize: 11, fontWeight: '800', letterSpacing: 1.6 }}>APPROVAL REQUIRED</T>
            <T style={{ color: colors.luster, fontSize: 22, fontWeight: '800' }}>Artemis needs your approval</T>
          </View>
        </View>
        <T style={{ color: alpha(colors.luster, 0.9), fontSize: 16 }}>{result.reason}</T>
        {calc && result.failedAt === 'policy' && (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Figure label="Requested" value={usd(calc.requested) + (calc.kind === 'flight' ? '/traveler' : '')} />
            <Figure label="Your limit" value={usd(calc.allowed)} />
            <Figure label="Over by" value={usd(calcOver(calc))} hot />
          </View>
        )}
        {cap && result.failedAt === 'financial' && (
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Figure label="Spent" value={usd(cap.spent)} />
            <Figure label="This booking" value={usd(cap.requested)} />
            <Figure label="Monthly cap" value={usd(cap.cap)} hot />
          </View>
        )}
        <Pressable accessibilityRole="button" onPress={onBack} style={{ minHeight: 36, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Icon name="refresh" size={15} color={colors.aster} strokeWidth={2} />
          <T style={{ color: colors.aster, fontSize: 15, fontWeight: '600' }}>Choose another flight</T>
        </Pressable>
      </View>
    </GlassPanel>
  );
}

/** No override: an unverified provider is never offered "approve anyway". */
export function BlockedPanel({ run, onBack }: { run: TrustCheckRun; onBack: () => void }) {
  const flightLimit = useTripStore((s) => s.policy.flightLimit);
  const domain = (label: string, value: string, flagged: boolean) => (
    <View key={label} style={{ padding: 12, borderRadius: 12, gap: 3, backgroundColor: flagged ? alpha(colors.habanero, 0.1) : alpha(colors.royal, 0.4) }}>
      <T style={{ color: flagged ? colors.habanero : colors.aster, fontSize: 9.5, fontWeight: '800', letterSpacing: 1.2 }}>{label.toUpperCase()}</T>
      <Mono size={17} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6} color={colors.luster} style={flagged ? { textDecorationLine: 'underline', textDecorationColor: colors.habanero } : undefined}>{value}</Mono>
    </View>
  );
  return (
    <GlassPanel radius={26} padding={18} style={{ borderColor: alpha(colors.luster, 0.7), backgroundColor: alpha(colors.luster, 0.08) }}>
      <View style={{ gap: 14 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.luster, alignItems: 'center', justifyContent: 'center' }}><Icon name="close" size={17} color={colors.depths} strokeWidth={3.2} /></View>
          <View style={{ flex: 1, gap: 2 }}>
            <T style={{ color: alpha(colors.luster, 0.85), fontSize: 11, fontWeight: '800', letterSpacing: 1.6 }}>BLOCKED BEFORE PAYMENT</T>
            <T style={{ color: colors.luster, fontSize: 22, fontWeight: '800' }}>Provider couldn't be verified</T>
          </View>
        </View>
        <T style={{ color: alpha(colors.luster, 0.9), fontSize: 16 }}>{`The agent asking to book ${run.intent.provider} isn't who it claims to be, so Artemis stopped. Nothing was booked and no money moved.`}</T>
        <View style={{ gap: 8 }}>
          {domain('Requesting agent', run.intent.agent.domain, true)}
          {domain(`Verified for ${run.intent.provider}`, verifiedDomain(run.intent.provider), false)}
        </View>
        {run.intent.kind === 'flight' && run.intent.unitAmount <= flightLimit && (
          <T style={{ color: alpha(colors.luster, 0.7), fontSize: 13, fontWeight: '600' }}>{`The fare (${usd(run.intent.unitAmount)}) was inside your ${usd(flightLimit)} limit. Only the identity was wrong.`}</T>
        )}
        <Pressable accessibilityRole="button" onPress={onBack} style={{ minHeight: 36, flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <Icon name="refresh" size={15} color={colors.aster} strokeWidth={2} />
          <T style={{ color: colors.aster, fontSize: 15, fontWeight: '600' }}>Back to your options</T>
        </Pressable>
      </View>
    </GlassPanel>
  );
}
