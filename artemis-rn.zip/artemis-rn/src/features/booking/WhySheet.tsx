import React from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import { GlassPanel } from '../../design/controls';
import { NightBackdrop } from '../../design/NightBackdrop';
import { SheetModal } from '../../design/SheetModal';
import { Body, Eyebrow, Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { decisionLabel, EvaluationResult, layerIntegration, layerNumber, layerQuestion, layers, layerTitle } from '../../domain/trust/models';

/** An honest footer: which of the three services really answered, and which are stand-ins. */
function liveNote(result: EvaluationResult): string {
  const live = layers.filter((l) => result[l].source === 'live');
  const simulated = layers.filter((l) => result[l].source === 'simulated').map(layerIntegration);
  if (live.length === 0) {
    return 'Prototype infrastructure. Your policy is evaluated on this device. Identity and financial checks run on simulated services, and no real money moves.';
  }
  const money = live.includes('financial') ? ' The Capital One account is a sandbox account, so no real money moves.' : '';
  return `Answered live by ${live.map(layerIntegration).join(' and ')}. Your policy is evaluated on this device.${simulated.length ? ` ${simulated.join(' and ')} ran as a simulated service.` : ''}${money}`;
}

/** The machinery behind the words: which layer said what, and which service it is designed to talk to. */
export function WhySheet({ result, onClose }: { result?: EvaluationResult; onClose: () => void }) {
  return (
    <SheetModal visible={!!result} onClose={onClose}>
      <NightBackdrop glow={0.25} showStars={false} />
      {result && (
        <ScrollView contentContainerStyle={{ padding: 20, gap: 18 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Why this decision</Eyebrow>
            <Pressable accessibilityRole="button" accessibilityLabel="Done" onPress={onClose} style={{ minWidth: 44, minHeight: 44, alignItems: 'flex-end', justifyContent: 'center' }}>
              <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>Done</T>
            </Pressable>
          </View>
          <T style={{ color: colors.luster, fontSize: 34, fontWeight: '800', letterSpacing: -1 }}>{decisionLabel(result.decision)}</T>
          <Body size={16} opacity={0.85}>{result.reason}</Body>
          {layers.map((layer) => {
            const r = result[layer];
            return (
              <GlassPanel key={layer} radius={22} padding={16}>
                <View style={{ gap: 10 }}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <T style={{ color: colors.habanero, fontSize: 11, fontWeight: '800', letterSpacing: 1.6 }}>{`${layerNumber(layer)} · ${layerTitle(layer)}`}</T>
                    <T style={{ color: r.status === 'failed' ? colors.habanero : alpha(colors.luster, 0.7), fontSize: 10, fontWeight: '800', letterSpacing: 1.2 }}>
                      {r.status === 'passed' ? 'PASSED' : r.status === 'failed' ? 'FAILED' : 'NOT REACHED'}
                    </T>
                  </View>
                  <Body size={15} opacity={0.7}>{layerQuestion(layer)}</Body>
                  <T style={{ color: colors.luster, fontSize: 17, fontWeight: '600' }}>{r.description}</T>
                  {r.metadata.map((m) => (
                    <View key={m.label} style={{ flexDirection: 'row', justifyContent: 'space-between', gap: 12 }}>
                      <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>{m.label}</T>
                      <Mono size={13} style={{ flexShrink: 1, textAlign: 'right' }} color={m.emphasis === 'flagged' ? colors.habanero : m.emphasis === 'verified' ? colors.aster : colors.luster}>{m.value}</Mono>
                    </View>
                  ))}
                  <T style={{ color: alpha(colors.luster, 0.45), fontSize: 11, fontWeight: '600', letterSpacing: 0.4 }}>
                    {r.source === 'live' ? `Answered live by ${layerIntegration(layer)}` : r.source === 'device' ? 'Evaluated on this device against your trust policy' : `Designed for ${layerIntegration(layer)} · simulated in this prototype`}
                  </T>
                </View>
              </GlassPanel>
            );
          })}
          <Body size={13} opacity={0.55}>
            {liveNote(result)}
          </Body>
        </ScrollView>
      )}
    </SheetModal>
  );
}
