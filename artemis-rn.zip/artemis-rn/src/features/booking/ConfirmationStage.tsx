import React, { useState } from 'react';
import { View } from 'react-native';
import { router } from 'expo-router';
import { CTAButton } from '../../design/controls';
import { NightBackdrop } from '../../design/NightBackdrop';
import { PhotoBackdrop } from '../../design/PhotoView';
import { SheetModal } from '../../design/SheetModal';
import { Pressable } from 'react-native';
import { T } from '../../design/text';
import { hotelBooking, isBooked, selectedHotel, tripDestination } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore } from '../../store/useTripStore';
import { useTrip } from '../../store/hooks';
import { TicketReveal } from '../ticket/TicketReveal';
import { TrustBookingView } from './TrustBookingView';

/** After a booking is approved: the cinematic ticket reveal, full screen over the planning flow. */
export function ConfirmationStage({ tripID, onClose }: { tripID: string; onClose: () => void }) {
  const trip = useTrip(tripID);
  const [showHotel, setShowHotel] = useState(false);
  if (!trip || !isBooked(trip)) return null;
  const closeThen = (fn: () => void, delay = 450) => { onClose(); setTimeout(fn, delay); };
  return (
    <View style={{ flex: 1 }}>
      <TicketReveal
        trip={trip} confirmation="BOOKING CONFIRMED" onCut={() => getTripStore().cutTicket(tripID)}
        actions={
          <View style={{ gap: 10, width: '100%' }}>
            <CTAButton haptic icon="plane" title="ENTER TRIP MODE" onPress={() => closeThen(() => router.push({ pathname: '/tripmode', params: { id: tripID } }), 500)} />
            <View style={{ flexDirection: 'row', gap: 10 }}>
              <CTAButton haptic kind="ghost" title="VIEW TRIP" style={{ flex: 1 }} onPress={() => closeThen(() => router.push({ pathname: '/trip', params: { id: tripID } }), 400)} />
              {hotelBooking(trip) === undefined && selectedHotel(trip) !== undefined && (
                <CTAButton haptic kind="ghost" title="BOOK HOTEL" style={{ flex: 1 }} onPress={() => setShowHotel(true)} />
              )}
            </View>
          </View>
        }
      />
      <HotelBookingSheet tripID={tripID} visible={showHotel} onClose={() => { setShowHotel(false); getTripStore().dismissCheck(); }} />
    </View>
  );
}

export function HotelBookingSheet({ tripID, visible, onClose }: { tripID: string; visible: boolean; onClose: () => void }) {
  const trip = useTrip(tripID);
  return (
    <SheetModal visible={visible} onClose={onClose}>
      {trip ? <PhotoBackdrop destination={tripDestination(trip)} blur={20} dim={0.55} drift={false} /> : <NightBackdrop />}
      <View style={{ flex: 1 }}>
        <View style={{ alignItems: 'flex-end', paddingHorizontal: 20, paddingTop: 8 }}>
          <Pressable accessibilityRole="button" accessibilityLabel="Done" onPress={() => { HapticsService.tap(); onClose(); }} style={{ minWidth: 44, minHeight: 44, justifyContent: 'center', alignItems: 'flex-end' }}>
            <T style={{ color: '#fff', fontSize: 15, fontWeight: '600' }}>Done</T>
          </Pressable>
        </View>
        <TrustBookingView tripID={tripID} kind="hotel" />
      </View>
    </SheetModal>
  );
}

