import React, { useEffect, useRef, useState } from 'react';
import { Alert, Pressable, ScrollView, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import { CTAButton, GlassPanel, Hairline } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { RouteLine } from '../../design/RouteLine';
import { Eyebrow, Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { StatusBanner, TravelerAvatar } from '../../design/widgets';
import { hotelTotal } from '../../domain/destinations/hotels';
import { usd } from '../../domain/shared/money';
import { hoursMinutes, Zoned, timeZone } from '../../domain/shared/time';
import {
  arrivalDayOffset, arrivalLocal, departureLocal, flightDeparture, flightDestination, flightDuration, flightOrigin, flightStops, routeCodes, stopsLabel,
} from '../../domain/trips/flights';
import { shortCity } from '../../domain/destinations/geo';
import { hotelCheckIn, hotelCheckOut, hotelNights } from '../../domain/trips/itinerary';
import { BookingKind, selectedFlight, selectedHotel, tripDestination, tripTravelers, travelerCount } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore, useTripStore } from '../../store/useTripStore';
import { useTrip } from '../../store/hooks';
import { StageFooter } from '../planning/ui';
import { ApprovalRequiredPanel, BlockedPanel, TrustCheckPanel } from './TrustPanels';
import { WhySheet } from './WhySheet';
import type { EvaluationResult } from '../../domain/trust/models';

/**
 * Booking, the Artemis way: one tap, and the agent works. Before it touches any money, the trust layer verifies
 * identity, policy and finances. Routine bookings simply go through.
 */
export function TrustBookingView({ tripID, kind }: { tripID: string; kind: BookingKind }) {
  const trip = useTrip(tripID);
  const active = useTripStore((s) => s.activeCheck);
  const [why, setWhy] = useState<EvaluationResult | undefined>();
  const scroller = useRef<ScrollView>(null);
  const run = active && active.tripID === tripID && (active.intent.kind === 'hotel') === (kind === 'hotel') ? active : undefined;
  const decision = run?.result?.decision;
  useEffect(() => { if (decision) setTimeout(() => scroller.current?.scrollToEnd({ animated: true }), 150); }, [decision]);
  if (!trip) return null;
  const store = getTripStore();
  const f = selectedFlight(trip);
  const h = selectedHotel(trip);
  const headline = kind === 'flight' ? (f ? `${shortCity(flightOrigin(f))} → ${shortCity(flightDestination(f))}` : 'Flight') : h?.name ?? 'Hotel';
  const n = travelerCount(trip);
  const nights = hotelNights(trip);
  const dtz = timeZone(tripDestination(trip).airport.timeZoneID);
  const line = (label: string, value: string) => (
    <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
      <T style={{ color: alpha(colors.luster, 0.75), fontSize: 15 }}>{label}</T>
      <Mono size={15} color={colors.luster}>{value}</Mono>
    </View>
  );

  const summary = () => {
    if (kind === 'flight' && f) {
      const total = f.farePerTraveler * n;
      const off = arrivalDayOffset(f);
      return (
        <Animated.View exiting={FadeOut.duration(200)}>
          <GlassPanel radius={28} padding={20}>
            <View style={{ gap: 14 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <View style={{ gap: 3, flex: 1 }}>
                  <T style={{ color: colors.luster, fontSize: 17, fontWeight: '800' }}>{f.airline.toUpperCase()}</T>
                  <Mono size={13} color={alpha(colors.luster, 0.6)}>{f.legs.map((l) => l.flightNumber).join(' + ')}</Mono>
                </View>
                <T style={{ color: alpha(colors.luster, 0.7), fontSize: 12, fontWeight: '800', letterSpacing: 1.4 }}>{Zoned.dayUpper(flightDeparture(f), timeZone(flightOrigin(f).timeZoneID))}</T>
              </View>
              <RouteLine codes={routeCodes(f)} position={flightStops(f) === 0 ? 0.5 : 0.62} width={300} height={44} />
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                <Mono size={17} weight="600" color={colors.luster}>{departureLocal(f)}</Mono>
                <T style={{ color: alpha(colors.luster, 0.65), fontSize: 12, fontWeight: '600', textAlign: 'center', flexShrink: 1 }} numberOfLines={2}>{`${hoursMinutes(flightDuration(f))}\n${stopsLabel(f)}`}</T>
                <Mono size={17} weight="600" color={colors.luster}>{arrivalLocal(f) + (off > 0 ? ` +${off}` : '')}</Mono>
              </View>
              <Hairline color={alpha(colors.luster, 0.14)} />
              {line(`${usd(f.farePerTraveler)} × ${n} ${n === 1 ? 'traveler' : 'travelers'}`, usd(total))}
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <T style={{ color: alpha(colors.luster, 0.7), fontSize: 12, fontWeight: '800', letterSpacing: 1.6 }}>TOTAL</T>
                <Mono size={34} weight="600" color={colors.luster} style={{ letterSpacing: -1 }}>{usd(total)}</Mono>
              </View>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                {tripTravelers(trip).map((t, i) => <View key={t.id} style={{ marginLeft: i ? -8 : 0 }}><TravelerAvatar traveler={t} size={28} /></View>)}
                <T style={{ color: alpha(colors.luster, 0.75), fontSize: 13, fontWeight: '600', marginLeft: 12 }}>{tripTravelers(trip).map((t) => t.firstName).join(' & ')}</T>
              </View>
            </View>
          </GlassPanel>
        </Animated.View>
      );
    }
    if (kind === 'hotel' && h) {
      const total = hotelTotal(h, nights);
      return (
        <Animated.View exiting={FadeOut.duration(200)}>
          <GlassPanel radius={28} padding={20}>
            <View style={{ gap: 12 }}>
              <T style={{ color: alpha(colors.luster, 0.6), fontSize: 11, fontWeight: '800', letterSpacing: 1.6 }}>{h.neighborhood.toUpperCase()}</T>
              <T style={{ color: alpha(colors.luster, 0.8), fontSize: 15 }}>{h.blurb}</T>
              <Hairline color={alpha(colors.luster, 0.14)} />
              {line(`${usd(h.nightlyRate)} × ${nights} nights`, usd(total))}
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                <T style={{ color: alpha(colors.luster, 0.7), fontSize: 12, fontWeight: '800', letterSpacing: 1.6 }}>TOTAL</T>
                <Mono size={34} weight="600" color={colors.luster} style={{ letterSpacing: -1 }}>{usd(total)}</Mono>
              </View>
              <T style={{ color: alpha(colors.luster, 0.65), fontSize: 13, fontWeight: '600' }}>{`${Zoned.day(hotelCheckIn(trip), dtz)} – ${Zoned.day(hotelCheckOut(trip), dtz)}`}</T>
            </View>
          </GlassPanel>
        </Animated.View>
      );
    }
    return null;
  };

  const compact = run && (
    <Animated.View entering={FadeIn}>
      <GlassPanel radius={22} padding={12}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: colors.royal, alignItems: 'center', justifyContent: 'center' }}>
            <Icon name={kind === 'flight' ? 'plane' : 'bed'} size={15} color={colors.luster} strokeWidth={2.2} />
          </View>
          <View style={{ flex: 1 }}>
            <T numberOfLines={1} style={{ color: colors.luster, fontSize: 15, fontWeight: '700' }}>{run.title}</T>
            <T numberOfLines={1} style={{ color: alpha(colors.luster, 0.65), fontSize: 12 }}>{run.subtitle}</T>
          </View>
          <Mono size={20} weight="600" color={colors.luster}>{usd(run.intent.unitAmount * run.intent.travelers)}</Mono>
        </View>
      </GlassPanel>
    </Animated.View>
  );

  const outcome = () => {
    if (!run?.result) return null;
    const result = run.result;
    if (run.phase === 'running' && result.decision === 'autoApproved') return <StatusBanner icon="check" title="AUTO-APPROVED" message="Ready to book. No human confirmation needed." />;
    if (run.phase === 'awaitingApproval') return <ApprovalRequiredPanel result={result} onBack={() => { store.dismissCheck(); store.goTo('options', tripID); }} />;
    if (run.phase === 'blocked') return <BlockedPanel run={run} onBack={() => { store.dismissCheck(); store.goTo('options', tripID); }} />;
    if (run.phase === 'declined') return <StatusBanner icon="close" title="NOT BOOKED" message="You declined. Nothing was booked and no money moved." tone="neutral" />;
    if (run.phase === 'booked') return <StatusBanner icon="check" title={run.booking?.status === 'approvedByYou' ? 'APPROVED BY YOU' : 'AUTO-APPROVED'} message={`Booked. Reference ${run.booking?.reference ?? ''}.`} />;
    return null;
  };

  const action = () => {
    switch (run?.phase) {
      case undefined:
        return (
          <>
            <CTAButton haptic icon="sparkles" title="BOOK WITH ARTEMIS" onPress={() => { void (kind === 'flight' ? store.bookFlight(tripID) : store.bookHotel(tripID)); }} />
            {kind === 'flight' && (
              <Pressable accessibilityRole="button" accessibilityLabel="Prototype tools" style={{ minHeight: 32, alignItems: 'center', justifyContent: 'center' }}
                onPress={() => Alert.alert('Prototype tools', undefined, [
                  { text: 'Simulate an unverified provider', onPress: () => { void store.bookFlight(tripID, { impostor: true }); } },
                  { text: 'Cancel', style: 'cancel' },
                ])}>
                <T style={{ color: alpha(colors.luster, 0.45), fontSize: 12, fontWeight: '600' }}>Prototype tools</T>
              </Pressable>
            )}
          </>
        );
      case 'running': return <CTAButton kind="ghost" disabled title="ARTEMIS IS CHECKING…" />;
      case 'awaitingApproval':
        return (
          <>
            <CTAButton title="APPROVE & BOOK" onPress={() => { HapticsService.success(); void store.approveActiveCheck(); }} />
            <CTAButton kind="ghost" haptic title="DECLINE" onPress={() => store.declineActiveCheck()} />
          </>
        );
      case 'declined':
      case 'blocked':
        return <CTAButton kind="ghost" title={run.phase === 'blocked' ? 'CLOSE' : 'TRY AGAIN'} onPress={() => store.dismissCheck()} />;
      default: return null;
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <ScrollView ref={scroller} contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 22, paddingBottom: 24 }} showsVerticalScrollIndicator={false}>
        <View style={{ gap: 8 }}>
          <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>{kind === 'flight' ? 'Book this flight' : 'Book your stay'}</Eyebrow>
          <T numberOfLines={2} adjustsFontSizeToFit minimumFontScale={0.6} style={{ color: colors.luster, fontFamily: 'Newsreader_500Medium', fontSize: 34, letterSpacing: -1 }}>{headline}</T>
        </View>
        {run ? compact : summary()}
        <TrustCheckPanel run={run} onWhy={() => run?.result && setWhy(run.result)} />
        {outcome()}
        <View style={{ flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 6 }}>
          <Icon name="shield" size={12} color={alpha(colors.luster, 0.5)} strokeWidth={2} />
          <T style={{ color: alpha(colors.luster, 0.5), fontSize: 12, fontWeight: '600', letterSpacing: 0.5 }}>DEMO BOOKING · nothing is charged</T>
        </View>
      </ScrollView>
      <View>
        <LinearGradient colors={['rgba(11,11,14,0)', 'rgba(11,11,14,0.92)']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 0.3 }} style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0 }} pointerEvents="none" />
        <StageFooter>{action()}</StageFooter>
      </View>
      <WhySheet result={why} onClose={() => setWhy(undefined)} />
    </View>
  );
}
