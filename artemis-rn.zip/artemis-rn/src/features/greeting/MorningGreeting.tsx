import React, { useEffect, useMemo, useRef } from 'react';
import { Pressable, StyleSheet, View, useWindowDimensions } from 'react-native';
import Animated, { Easing, useAnimatedStyle, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import { ArtemisLogo } from '../../design/ArtemisLogo';
import { NightBackdrop } from '../../design/NightBackdrop';
import { PlaneFlyby } from '../../design/PlaneFlyby';
import { Globe, useGlobeCamera } from '../../design/globe/Globe';
import { Caps, Display } from '../../design/text';
import { greetingText, DailyContext } from '../../domain/daily/dailyContext';
import type { Place } from '../../domain/destinations/place';
import { Audio } from '../../services/AudioService';
import { HapticsService } from '../../services/HapticsService';

/** The camera framing Home opens with. The greeting ends exactly here, so the two feel like one shot. */
export const HOME_RADIUS = 0.6;
export const HOME_CENTER_Y = 0.42;

interface Props {
  context: DailyContext;
  word: string;
  firstName: string;
  place: Place;
  onFinish: () => void;
}

/**
 * "Good morning, Maria." The world, seen from just above it, and what today holds.
 *
 *   text (fades in, holds) → text fades → the plane appears and crosses → the camera pulls back → Home
 */
export function MorningGreeting({ context, word, firstName, place, onFinish }: Props) {
  const { width, height } = useWindowDimensions();
  const reduce = useReducedMotion();
  const { eyebrow, headline } = useMemo(() => greetingText(context, word, firstName), [context, word, firstName]);
  const cam = useGlobeCamera({ lat: place.latitude - 8, lon: place.longitude, radius: 1.9, centerY: 1.28 });
  const globeOpacity = useSharedValue(0);
  const textOpacity = useSharedValue(0);
  const you = useMemo(() => ({ lat: place.latitude, lon: place.longitude }), [place]);
  const [flight, setFlight] = React.useState(0);
  const run = useRef(0);
  const finished = useRef(false);

  const finish = () => {
    if (finished.current) return;
    finished.current = true;
    onFinish();
  };

  useEffect(() => {
    const id = ++run.current;
    const pause = (s: number) => new Promise<boolean>((r) => setTimeout(() => r(run.current === id), (reduce ? s * 0.4 : s) * 1000));
    const pull = { duration: reduce ? 600 : 2100, easing: Easing.bezier(0.45, 0, 0.15, 1) };
    void (async () => {
      globeOpacity.value = withTiming(1, { duration: 1100, easing: Easing.out(Easing.ease) });
      if (!(await pause(0.3))) return;
      textOpacity.value = withTiming(1, { duration: 900, easing: Easing.out(Easing.ease) });
      if (!(await pause(2.7))) return;
      // The words leave, the plane arrives.
      textOpacity.value = withTiming(0, { duration: 600, easing: Easing.in(Easing.ease) });
      if (!(await pause(0.5))) return;
      if (!reduce) {
        setFlight(1);
        HapticsService.play('takeoff');
        Audio.play('takeoff');
        if (!(await pause(1.3))) return;
      }
      // Pull back into the world.
      cam.radius.value = withTiming(HOME_RADIUS, pull);
      cam.centerY.value = withTiming(HOME_CENTER_Y, pull);
      cam.lat.value = withTiming(place.latitude, pull);
      if (!(await pause(2.0))) return;
      finish();
    })();
    return () => { run.current++; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** Tapping anywhere ends the greeting straight away. */
  const skip = () => {
    run.current++;
    const quick = { duration: 500, easing: Easing.bezier(0.45, 0, 0.15, 1) };
    textOpacity.value = withTiming(0, quick);
    globeOpacity.value = withTiming(1, quick);
    cam.radius.value = withTiming(HOME_RADIUS, quick);
    cam.centerY.value = withTiming(HOME_CENTER_Y, quick);
    cam.lat.value = withTiming(place.latitude, quick);
    setTimeout(finish, 450);
  };

  const globeStyle = useAnimatedStyle(() => ({ opacity: globeOpacity.value }));
  const textStyle = useAnimatedStyle(() => ({ opacity: textOpacity.value, transform: [{ translateY: (1 - textOpacity.value) * 8 }] }));

  return (
    <Pressable
      onPress={skip} accessibilityRole="button" accessibilityLabel={`${eyebrow}. ${headline}`} accessibilityHint="Tap to continue"
      style={[StyleSheet.absoluteFill, { backgroundColor: '#000' }]}
    >
      <NightBackdrop glow={0.5} />
      <Animated.View style={[StyleSheet.absoluteFill, globeStyle]} pointerEvents="none">
        <Globe width={width} height={height} camera={cam} you={you} driftDegPerSec={1.5} />
      </Animated.View>
      {flight > 0 && !reduce && (
        <PlaneFlyby width={width} height={height} flightKey={flight} duration={1.6} from={{ x: -0.2, y: 0.62 }} to={{ x: 1.2, y: 0.2 }} bow={-0.14} size={64} recede={0.7} />
      )}
      <Animated.View style={[{ paddingHorizontal: 28, paddingTop: 70, gap: 14 }, textStyle]} pointerEvents="none">
        <ArtemisLogo size={22} />
        <View style={{ height: 26 }} />
        <Caps size={11.5} tracking={3.4} opacity={0.7}>{eyebrow}</Caps>
        <Display size={44} tracking={1.5} numberOfLines={3} adjustsFontSizeToFit minimumFontScale={0.6}>{headline}</Display>
      </Animated.View>
    </Pressable>
  );
}
