import React from 'react';
import { Pressable, ScrollView, Switch, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Icon, IconName } from '../../design/Icon';
import { NightBackdrop } from '../../design/NightBackdrop';
import { Body, Eyebrow, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { TravelerAvatar } from '../../design/widgets';
import { fullName } from '../../domain/matching/traveler';
import { usd } from '../../domain/shared/money';
import { getTripStore, useTripStore } from '../../store/useTripStore';

export type ProfileRoute = 'preferences' | 'policy' | 'style' | 'payment' | 'friends' | 'tools' | 'location' | 'credits';

export function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const you = useTripStore((s) => s.you);
  const place = useTripStore((s) => s.currentPlace);
  const profile = useTripStore((s) => s.profile);
  const prefs = useTripStore((s) => s.defaultPreferences);
  const policy = useTripStore((s) => s.policy);
  const financial = useTripStore((s) => s.financial);
  const sound = useTripStore((s) => s.soundEnabled);
  const friends = useTripStore((s) => s.friends());

  const group = (title: string, children: React.ReactNode) => (
    <View style={{ gap: 10 }}>
      <Eyebrow opacity={0.55}>{title}</Eyebrow>
      <View style={{ borderRadius: 22, overflow: 'hidden', backgroundColor: alpha(colors.luster, 0.07), borderWidth: 1, borderColor: alpha(colors.luster, 0.16) }}>{children}</View>
    </View>
  );
  const row = (route: ProfileRoute, icon: IconName, title: string, detail: string, last = false) => (
    <Pressable key={route} accessibilityRole="button" accessibilityLabel={`${title}. ${detail}`} onPress={() => router.push({ pathname: '/profile', params: { section: route } })}
      style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 16, paddingVertical: 12, minHeight: 56, borderBottomWidth: last ? 0 : 1, borderBottomColor: alpha(colors.luster, 0.1) }}>
      <View style={{ width: 34, height: 34, alignItems: 'center', justifyContent: 'center' }}><Icon name={icon} size={20} color={colors.aster} strokeWidth={1.8} /></View>
      <View style={{ flex: 1, gap: 2 }}>
        <T style={{ color: colors.luster, fontSize: 16, fontWeight: '600' }}>{title}</T>
        <T numberOfLines={1} style={{ color: alpha(colors.luster, 0.68), fontSize: 13 }}>{detail}</T>
      </View>
      <Icon name="chevronRight" size={14} color={alpha(colors.luster, 0.5)} strokeWidth={2.6} />
    </Pressable>
  );

  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      <NightBackdrop glow={0.3} showStars={false} />
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingTop: insets.top + 8, paddingBottom: 130, gap: 26 }} showsVerticalScrollIndicator={false}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 16 }}>
          <TravelerAvatar traveler={you} size={72} />
          <View style={{ flex: 1, gap: 4 }}>
            <T style={{ color: colors.luster, fontSize: 26, fontWeight: '700', letterSpacing: -0.6 }}>{fullName(you)}</T>
            <T style={{ color: alpha(colors.luster, 0.7), fontSize: 13 }}>{`Rio de Janeiro · ${profile.styles.join(' · ')}`}</T>
          </View>
        </View>
        {group('Where you are', row('location', 'location', place.name, place.isDemo ? 'Demo location · tap to use your own' : 'Live location', true))}
        {group('Travel', <>
          {row('preferences', 'list', 'Travel preferences', `${usd(prefs.flightBudget)} flights · ${usd(prefs.hotelBudget)}/night`)}
          {row('style', 'star', 'Style & favorites', profile.favoriteAirports.join(' · '))}
          {row('friends', 'contacts', 'Friends', `${friends.length} travelers`, true)}
        </>)}
        {group('Booking', <>
          {row('policy', 'shield', 'Trust policy', `Flights ≤ ${usd(policy.flightLimit)} · Hotels ≤ ${usd(policy.hotelNightlyLimit)}/night`)}
          {row('payment', 'wallet', 'Payment & booking', `${financial.accountName} · ${financial.source === 'nessie' ? 'Nessie sandbox' : 'simulated'}`, true)}
        </>)}
        {group('Experience', (
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 16, paddingVertical: 12 }}>
            <View style={{ width: 34, height: 34, alignItems: 'center', justifyContent: 'center' }}><Icon name="sound" size={20} color={colors.aster} strokeWidth={1.8} /></View>
            <View style={{ flex: 1, gap: 2 }}>
              <T style={{ color: colors.luster, fontSize: 16, fontWeight: '600' }}>Sound</T>
              <T style={{ color: alpha(colors.luster, 0.68), fontSize: 13 }}>Takeoff, paper and tear. Off unless you turn it on.</T>
            </View>
            <Switch accessibilityLabel="Sound" value={sound} onValueChange={(v) => getTripStore().setSoundEnabled(v)} trackColor={{ true: colors.aster, false: alpha(colors.luster, 0.2) }} />
          </View>
        ))}
        {group('Prototype', <>
          {row('tools', 'sparkles', 'Prototype tools', 'Trust demos · reset')}
          {row('credits', 'ticket', 'Photo credits', 'Destination photography · Wikimedia Commons', true)}
        </>)}
        <Body size={12} opacity={0.5}>Artemis prototype · simulated flights and hotels · sandbox accounts only · no real bookings or charges</Body>
      </ScrollView>
    </View>
  );
}
