import React, { useEffect, useState } from 'react';
import { Alert, Pressable, Switch, View } from 'react-native';
import { router } from 'expo-router';
import { CTAButton, GlassPanel, Hairline, SelectableChip } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { NightBackdrop } from '../../design/NightBackdrop';
import { SheetModal } from '../../design/SheetModal';
import { Body, Display, Eyebrow, Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { BudgetSlider, StatusBanner, TravelerAvatar } from '../../design/widgets';
import { Destinations } from '../../domain/destinations/destinations';
import { sofiaProfile, TravelStyleProfile } from '../../domain/matching/preferences';
import { fullName, Travelers } from '../../domain/matching/traveler';
import { usd } from '../../domain/shared/money';
import { Layer, layerIntegration, layerNumber, layerQuestion, layers, layerTitle } from '../../domain/trust/models';
import credits from '../../../assets/photos/credits.json';
import { HapticsService } from '../../services/HapticsService';
import { useRouterState } from '../../store/router';
import { getTripStore, liveServices, useTripStore } from '../../store/useTripStore';
import { trustDemos, trustDemoDetail, trustDemoOutcome, trustDemoTitle, TrustDemo } from '../../store/tripStore';
import { stageAtMost, stageOrder } from '../../domain/trips/trip';
import { PreferencesEditor } from '../planning/PreferencesStage';
import { ApprovalRequiredPanel, BlockedPanel, SourceChip, TrustCheckPanel } from '../booking/TrustPanels';
import { WhySheet } from '../booking/WhySheet';
import { DarkScreen } from './DarkScreen';
import type { EvaluationResult } from '../../domain/trust/models';

export function PreferencesScreen() {
  const prefs = useTripStore((s) => s.defaultPreferences);
  return (
    <DarkScreen title="Travel preferences" subtitle="Your defaults. Every new trip starts from these, and you can change them per trip.">
      <PreferencesEditor prefs={prefs} onChange={(p) => getTripStore().setDefaultPreferences(p)} />
    </DarkScreen>
  );
}

export function TrustPolicyScreen() {
  const policy = useTripStore((s) => s.policy);
  const set = (patch: Partial<typeof policy>) => getTripStore().setPolicy({ ...policy, ...patch });
  return (
    <DarkScreen title="Trust policy" subtitle="Under these limits, Artemis books for you. Above them, it asks first.">
      <GlassPanel radius={28} padding={20}>
        <View style={{ gap: 20 }}>
          <BudgetSlider title="Flight, per traveler" value={policy.flightLimit} min={200} max={1500} step={25} onChange={(v) => set({ flightLimit: v })} />
          <Hairline color={alpha(colors.luster, 0.12)} />
          <BudgetSlider title="Hotel, per night" unit="/ night" value={policy.hotelNightlyLimit} min={80} max={500} step={10} onChange={(v) => set({ hotelNightlyLimit: v })} />
          <Hairline color={alpha(colors.luster, 0.12)} />
          <BudgetSlider title="Monthly travel" unit="/ month" value={policy.monthlyTravelLimit} min={500} max={6000} step={100} onChange={(v) => set({ monthlyTravelLimit: v })} />
        </View>
      </GlassPanel>
      <GlassPanel radius={22} padding={16}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ flex: 1, gap: 2 }}>
            <T style={{ color: colors.luster, fontSize: 16, fontWeight: '600' }}>Ask me about non-travel purchases</T>
            <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>Anything outside flights and hotels always comes to you.</T>
          </View>
          <Switch accessibilityLabel="Ask me about non-travel purchases" value={policy.escalateNonTravel} onValueChange={(v) => set({ escalateNonTravel: v })} trackColor={{ true: colors.habanero, false: alpha(colors.luster, 0.2) }} />
        </View>
      </GlassPanel>
      <GlassPanel radius={22} padding={16}>
        <View style={{ gap: 10 }}>
          <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Always on</Eyebrow>
          {layers.map((l) => (
            <View key={l} style={{ flexDirection: 'row', gap: 12 }}>
              <Mono size={13} weight="800" color={colors.habanero} style={{ width: 24 }}>{layerNumber(l)}</Mono>
              <View style={{ flex: 1, gap: 2 }}>
                <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>{layerTitle(l).charAt(0) + layerTitle(l).slice(1).toLowerCase()}</T>
                <T style={{ color: alpha(colors.luster, 0.65), fontSize: 13 }}>{layerQuestion(l)}</T>
                <T style={{ color: alpha(colors.luster, 0.4), fontSize: 11 }}>{layerStatus(l)}</T>
              </View>
            </View>
          ))}
          <T style={{ color: alpha(colors.luster, 0.75), fontSize: 13, fontWeight: '600', marginTop: 4 }}>An unverified provider is always blocked. There is no override.</T>
        </View>
      </GlassPanel>
    </DarkScreen>
  );
}

const ALL_STYLES = ['Culture', 'Food', 'Architecture', 'Nightlife', 'Shopping', 'Beach', 'Nature', 'Design'];
const AIRLINES = ['TAP Air Portugal', 'ITA Airways', 'LATAM Airlines', 'Air France', 'Iberia'];

function Chips({ items, selection, onChange, single = false }: { items: string[]; selection: string[]; onChange: (s: string[]) => void; single?: boolean }) {
  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {items.map((it) => (
        <SelectableChip key={it} title={it} selected={selection.includes(it)} onPress={() => onChange(single ? [it] : selection.includes(it) ? selection.filter((x) => x !== it) : [...selection, it])} />
      ))}
    </View>
  );
}

export function StyleScreen() {
  const profile = useTripStore((s) => s.profile);
  const set = (patch: Partial<TravelStyleProfile>) => getTripStore().setProfile({ ...profile, ...patch });
  const panel = (title: string, children: React.ReactNode) => (
    <GlassPanel radius={24} padding={18}><View style={{ gap: 12 }}><Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>{title}</Eyebrow>{children}</View></GlassPanel>
  );
  return (
    <DarkScreen title="Style & favorites" subtitle="Artemis uses these to shorten every future plan.">
      {panel('Travel style', <Chips items={ALL_STYLES} selection={profile.styles} onChange={(styles) => set({ styles })} />)}
      {panel('Flights', <Chips single items={['Shorter flights', 'Nonstop', 'Cheapest', 'Later departures']} selection={[profile.flightPreference]} onChange={([f]) => set({ flightPreference: f })} />)}
      {panel('Preferred airlines', <Chips items={AIRLINES} selection={profile.preferredAirlines} onChange={(preferredAirlines) => set({ preferredAirlines })} />)}
      {panel('Favorite airports', <Chips items={['GIG', 'GRU', 'LIS', 'FCO', 'MAD', 'CDG']} selection={profile.favoriteAirports} onChange={(favoriteAirports) => set({ favoriteAirports })} />)}
      {panel('Hotels', <Chips single items={['Boutique · Central', 'Modern · Central', 'Quiet · Classic', 'Luxury']} selection={[profile.hotelPreference]} onChange={([h]) => set({ hotelPreference: h })} />)}
    </DarkScreen>
  );
}

export function FriendsScreen() {
  const friends = useTripStore((s) => s.friends());
  return (
    <DarkScreen title="Friends" subtitle="Collaborators, not a feed. Friends appear here so you can invite them to trips.">
      {friends.map((f) => {
        const style = f.id === Travelers.sofia.id ? sofiaProfile() : undefined;
        return (
          <GlassPanel key={f.id} radius={24} padding={16}>
            <View style={{ gap: 12 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <TravelerAvatar traveler={f} size={52} />
                <View style={{ flex: 1, gap: 2 }}>
                  <T style={{ color: colors.luster, fontSize: 17, fontWeight: '600' }}>{fullName(f)}</T>
                  <T style={{ color: alpha(colors.luster, 0.55), fontSize: 10.5, fontWeight: '800', letterSpacing: 1.4 }}>{style ? style.budgetLevel.toUpperCase() : 'PREFERENCES PRIVATE'}</T>
                </View>
              </View>
              {style && (
                <>
                  <T style={{ color: alpha(colors.luster, 0.85), fontSize: 15 }}>{style.styles.join(' · ')}</T>
                  <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>{`${style.flightPreference} · ${style.hotelPreference}`}</T>
                </>
              )}
              <View style={{ flexDirection: 'row', gap: 6, alignItems: 'center' }}>
                <Icon name="shield" size={12} color={alpha(colors.luster, 0.5)} strokeWidth={2} />
                <T style={{ color: alpha(colors.luster, 0.5), fontSize: 12 }}>Trip preferences stay private until you both submit.</T>
              </View>
            </View>
          </GlassPanel>
        );
      })}
    </DarkScreen>
  );
}

export function PaymentScreen() {
  const f = useTripStore((s) => s.financial);
  const cap = useTripStore((s) => s.policy.monthlyTravelLimit);
  const used = Math.min(1, f.monthToDateTravelSpend / Math.max(1, cap));
  return (
    <DarkScreen title="Payment & booking" subtitle={f.source === 'nessie' ? "The account Artemis' agent books with: a Capital One Nessie sandbox account. No real money moves." : "The account Artemis' agent books with. Simulated: nothing here is a real account."}>
      <GlassPanel radius={28} padding={20}>
        <View style={{ gap: 14 }}>
          <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>{f.source === 'nessie' ? 'Linked account · Capital One Nessie sandbox' : 'Linked account · simulated'}</Eyebrow>
          <T style={{ color: colors.luster, fontSize: 17, fontWeight: '600' }}>{f.accountName}</T>
          <Mono size={40} weight="600" color={colors.luster} style={{ letterSpacing: -1 }}>{usd(f.availableBalance)}</Mono>
          <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>Available balance</T>
          <Hairline color={alpha(colors.luster, 0.14)} />
          <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
            <T style={{ color: alpha(colors.luster, 0.55), fontSize: 10.5, fontWeight: '800', letterSpacing: 1.4 }}>TRAVEL THIS MONTH</T>
            <Mono size={13} color={colors.luster}>{`${usd(f.monthToDateTravelSpend)} / ${usd(cap)}`}</Mono>
          </View>
          <View style={{ height: 8, borderRadius: 4, backgroundColor: alpha(colors.luster, 0.14) }}>
            <View style={{ width: `${used * 100}%`, height: 8, borderRadius: 4, backgroundColor: used > 0.9 ? colors.habanero : colors.aster }} />
          </View>
        </View>
      </GlassPanel>
      <GlassPanel radius={22} padding={16}>
        <View style={{ gap: 8 }}>
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <Icon name="shield" size={16} color={colors.luster} strokeWidth={2} />
            <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>Demo booking</T>
          </View>
          <T style={{ color: alpha(colors.luster, 0.65), fontSize: 13 }}>When you confirm, Artemis creates a mock reference like ART-724918. No card is charged and no airline or hotel is contacted.</T>
        </View>
      </GlassPanel>
    </DarkScreen>
  );
}

export function LocationScreen() {
  const place = useTripStore((s) => s.currentPlace);
  const live = useTripStore((s) => s.useLiveLocation);
  const status = useTripStore((s) => s.locationStatus);
  return (
    <DarkScreen title="Where you are" subtitle="Artemis anchors the world on where you are, and new trips start from the nearest airport.">
      <GlassPanel radius={26} padding={20}>
        <View style={{ gap: 8 }}>
          <T style={{ color: 'rgba(255,255,255,0.6)', fontSize: 10.5, fontWeight: '600', letterSpacing: 2 }}>{place.isDemo ? 'DEMO LOCATION' : 'LIVE LOCATION'}</T>
          <Display size={34} tracking={0}>{place.name}</Display>
          <T style={{ color: 'rgba(255,255,255,0.7)', fontSize: 15 }}>{`${place.country} · departs from ${place.airportCode}`}</T>
        </View>
      </GlassPanel>
      <GlassPanel radius={22} padding={16}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
          <View style={{ flex: 1, gap: 2 }}>
            <T style={{ color: '#fff', fontSize: 16, fontWeight: '600' }}>Use my real location</T>
            <T style={{ color: 'rgba(255,255,255,0.6)', fontSize: 13 }}>Asks for permission once. If it's refused, Artemis stays on Rio de Janeiro.</T>
          </View>
          <Switch accessibilityLabel="Use my real location" value={live} onValueChange={(v) => getTripStore().setUseLiveLocation(v)} trackColor={{ true: '#fff', false: alpha(colors.luster, 0.2) }} />
        </View>
      </GlassPanel>
      {status.kind === 'unavailable' && <Row icon="exclamation" text={status.reason} />}
      {status.kind === 'requesting' && <Row icon="location" text="Finding you…" />}
    </DarkScreen>
  );
}

const Row = ({ icon, text }: { icon: 'exclamation' | 'location'; text: string }) => (
  <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
    <Icon name={icon} size={15} color="rgba(255,255,255,0.75)" strokeWidth={2} />
    <T style={{ color: 'rgba(255,255,255,0.75)', fontSize: 13, flex: 1 }}>{text}</T>
  </View>
);

export function CreditsScreen() {
  const c = credits as Record<string, { artist: string; license: string; title: string }>;
  return (
    <DarkScreen title="Photo credits" subtitle="Destination photography is from Wikimedia Commons, used under the licenses shown. Thank you to the photographers.">
      {Destinations.all.map((d) => {
        const cr = c[d.photo.file];
        if (!cr) return null;
        return (
          <GlassPanel key={d.id} radius={18} padding={14}>
            <View style={{ gap: 4 }}>
              <T style={{ color: 'rgba(255,255,255,0.6)', fontSize: 10.5, fontWeight: '600', letterSpacing: 2 }}>{d.city.toUpperCase()}</T>
              <T style={{ color: '#fff', fontSize: 15, fontWeight: '600' }}>{cr.artist}</T>
              <T numberOfLines={2} style={{ color: 'rgba(255,255,255,0.6)', fontSize: 12 }}>{`${cr.license} · ${cr.title}`}</T>
            </View>
          </GlassPanel>
        );
      })}
    </DarkScreen>
  );
}

export function PrototypeToolsScreen() {
  const trips = useTripStore((s) => s.trips);
  const [demo, setDemo] = useState<TrustDemo | undefined>();
  const target = trips.find((t) => !t.isPast && stageOrder(t.stage) >= stageOrder('options') && stageAtMost(t.stage, 'decision'));
  const store = getTripStore();
  return (
    <DarkScreen title="Prototype tools" subtitle="For demos and testing. Nothing here exists in a real Artemis.">
      <LiveServices />
      <View style={{ gap: 10 }}>
        <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Trust layer</Eyebrow>
        {trustDemos.map((d) => (
          <Pressable key={d} accessibilityRole="button" accessibilityLabel={`${trustDemoTitle(d)}. ${trustDemoDetail(d)}. ${trustDemoOutcome(d)}`} onPress={() => { HapticsService.tap(); setDemo(d); }}>
            <GlassPanel radius={20} padding={14}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                <View style={{ flex: 1, gap: 3 }}>
                  <T style={{ color: colors.luster, fontSize: 15, fontWeight: '700' }}>{trustDemoTitle(d)}</T>
                  <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>{trustDemoDetail(d)}</T>
                </View>
                <View style={{ paddingHorizontal: 9, paddingVertical: 5, borderRadius: 999, backgroundColor: d === 'autoApproved' ? colors.luster : d === 'impostor' ? alpha(colors.luster, 0.14) : alpha(colors.habanero, 0.35) }}>
                  <T style={{ color: d === 'autoApproved' ? colors.depths : colors.luster, fontSize: 10, fontWeight: '800', letterSpacing: 0.8 }}>{trustDemoOutcome(d)}</T>
                </View>
              </View>
            </GlassPanel>
          </Pressable>
        ))}
      </View>
      {target && (
        <View style={{ gap: 10 }}>
          <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Group decision</Eyebrow>
          <Pressable accessibilityRole="button" onPress={() => { HapticsService.tap(); store.forceTradeoff(target.id); }}>
            <GlassPanel radius={20} padding={14}>
              <View style={{ gap: 3 }}>
                <T style={{ color: colors.luster, fontSize: 15, fontWeight: '700' }}>{`Force a trade-off on ${Destinations.named(target.destinationID)?.city ?? ''}`}</T>
                <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>Ranks so the leading option is one traveler's last choice.</T>
              </View>
            </GlassPanel>
          </Pressable>
        </View>
      )}
      <View style={{ gap: 10 }}>
        <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Session</Eyebrow>
        <CTAButton icon="refresh" title="RESET DEMO DATA" onPress={() => {
          HapticsService.tap();
          Alert.alert('Reset ROME WITH SOFIA and clear bookings?', undefined, [
            { text: 'Reset demo', style: 'destructive', onPress: () => { store.resetDemo(); HapticsService.success(); } },
            { text: 'Cancel', style: 'cancel' },
          ]);
        }} />
        <CTAButton icon="play" kind="ghost" title="REPLAY ONBOARDING" onPress={() => { HapticsService.tap(); store.restartOnboarding(); router.dismissAll(); }} />
        <CTAButton icon="sparkles" kind="ghost" title="REPLAY MORNING GREETING" onPress={() => { HapticsService.tap(); useRouterState.getState().setTab('home'); useRouterState.getState().bumpReplayGreeting(); router.dismissAll(); }} />
      </View>
      <TrustDemoSheet demo={demo} onClose={() => { getTripStore().dismissCheck(); setDemo(undefined); }} />
    </DarkScreen>
  );
}

/** A standalone trust check, outside any trip. */
function TrustDemoSheet({ demo, onClose }: { demo?: TrustDemo; onClose: () => void }) {
  const active = useTripStore((s) => s.activeCheck);
  const run = active && active.tripID === undefined ? active : undefined;
  const [why, setWhy] = useState<EvaluationResult | undefined>();
  useEffect(() => { if (demo) void getTripStore().runTrustDemo(demo); }, [demo]);
  return (
    <SheetModal visible={!!demo} onClose={onClose}>
      <NightBackdrop glow={0.3} showStars={false} />
      {demo && (
        <View style={{ flex: 1 }}>
          <View style={{ flex: 1, padding: 20, gap: 18 }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Trust demo</Eyebrow>
              <Pressable accessibilityRole="button" accessibilityLabel="Done" onPress={onClose} style={{ minWidth: 44, minHeight: 44, alignItems: 'flex-end', justifyContent: 'center' }}>
                <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>Done</T>
              </Pressable>
            </View>
            <Display size={32} tracking={-1} color={colors.luster}>{trustDemoTitle(demo)}</Display>
            <Body size={15} opacity={0.7}>{trustDemoDetail(demo)}</Body>
            <TrustCheckPanel run={run} onWhy={() => run?.result && setWhy(run.result)} />
            {run?.result?.decision === 'autoApproved' && <StatusBanner icon="check" title="AUTO-APPROVED" message="Artemis would book this without asking." />}
            {run?.result?.decision === 'approvalRequired' && <ApprovalRequiredPanel result={run.result} onBack={() => {}} />}
            {run?.result?.decision === 'blocked' && <BlockedPanel run={run} onBack={() => {}} />}
            <CTAButton kind="ghost" icon="refresh" title="RUN AGAIN" onPress={() => { HapticsService.tap(); void getTripStore().runTrustDemo(demo); }} />
            <Body size={12} opacity={0.45}>Nothing is booked or charged. Each layer's badge says whether it was answered live or simulated.</Body>
          </View>
          <WhySheet result={why} onClose={() => setWhy(undefined)} />
        </View>
      )}
    </SheetModal>
  );
}


/** Which of the three sponsor services are real in this build, and which are stand-ins. */
function LiveServices() {
  const financial = useTripStore((s) => s.financial);
  const rows: { name: string; detail: string; live: boolean | 'device' }[] = [
    { name: 'GoDaddy ANS', detail: liveServices.identity ? 'Identity checked against the ANS test registry' : 'Simulated identity registry', live: liveServices.identity },
    { name: 'Policy rules', detail: 'Your limits and approval rules, evaluated on this device', live: 'device' as const },
    {
      name: 'Capital One Nessie',
      detail: liveServices.financial && financial.source === 'nessie' ? `${financial.accountName} · ${usd(financial.availableBalance)} available (sandbox)` : liveServices.financial ? 'Sandbox account · not reachable right now' : 'Simulated account',
      live: liveServices.financial && financial.source === 'nessie',
    },
  ];
  return (
    <View style={{ gap: 10 }}>
      <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>Live services</Eyebrow>
      <GlassPanel radius={20} padding={14}>
        <View style={{ gap: 12 }}>
          {rows.map((r) => (
            <View key={r.name} style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <View style={{ flex: 1, gap: 2 }}>
                <T style={{ color: colors.luster, fontSize: 15, fontWeight: '700' }}>{r.name}</T>
                <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>{r.detail}</T>
              </View>
              <SourceChip source={r.live === 'device' ? 'device' : r.live ? 'live' : 'simulated'} />
            </View>
          ))}
        </View>
      </GlassPanel>
    </View>
  );
}

/** Which service answers a layer in this build. */
const layerStatus = (l: Layer): string =>
  l === 'identity' && liveServices.identity ? 'Checked live against the GoDaddy ANS registry (test environment)'
    : l === 'financial' && liveServices.financial ? 'Reads a live Capital One Nessie sandbox account'
      : l === 'policy' ? 'Evaluated on this device against your rules'
        : `Designed for ${layerIntegration(l)} · simulated here`;
