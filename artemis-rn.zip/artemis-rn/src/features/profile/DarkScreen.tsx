import React from 'react';
import { ScrollView, View } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { RoundIconButton } from '../../design/controls';
import { NightBackdrop } from '../../design/NightBackdrop';
import { Body, Display } from '../../design/text';
import { colors } from '../../design/theme';

/** The scaffold for every profile sub-screen: a big serif title, a quiet subtitle, and a back button. */
export function DarkScreen({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: colors.black }}>
      <NightBackdrop glow={0.3} showStars={false} />
      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingTop: insets.top + 60, paddingBottom: insets.bottom + 40, gap: 20 }} showsVerticalScrollIndicator={false}>
        <View style={{ gap: 8 }}>
          <Display size={36} tracking={-1} color={colors.luster} numberOfLines={2} adjustsFontSizeToFit minimumFontScale={0.7}>{title}</Display>
          {subtitle && <Body size={15} opacity={0.7}>{subtitle}</Body>}
        </View>
        {children}
      </ScrollView>
      <View style={{ position: 'absolute', top: insets.top + 8, left: 20 }}><RoundIconButton icon="chevronLeft" label="Back" onPress={() => router.back()} /></View>
    </View>
  );
}
