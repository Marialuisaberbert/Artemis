import React from 'react';
import { View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Display, Eyebrow } from '../../design/text';
import { alpha, colors } from '../../design/theme';

/** The heading every planning stage shares: a small eyebrow over a big serif line. */
export function StageTitle({ eyebrow, title, size = 40 }: { eyebrow: string; title: string; size?: number }) {
  return (
    <View style={{ gap: 8 }}>
      <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>{eyebrow}</Eyebrow>
      <Display size={size} tracking={-1} color={colors.luster}>{title}</Display>
    </View>
  );
}

/** The action pinned under a stage. */
export function StageFooter({ children }: { children: React.ReactNode }) {
  const insets = useSafeAreaInsets();
  return <View style={{ paddingHorizontal: 20, paddingBottom: Math.max(insets.bottom, 12), paddingTop: 8, gap: 10 }}>{children}</View>;
}

export const mono = (s: number) => ({ fontFamily: 'Menlo', fontSize: s, fontWeight: '600' as const });
