import React, { useEffect, useMemo, useState } from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import Animated, { Easing, FadeIn, FadeInDown, FadeOut, SharedValue, useAnimatedStyle, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import { CTAButton, GlassPanel } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { Eyebrow, Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { TravelerAvatar } from '../../design/widgets';
import { VennMark } from '../../design/VennMark';
import { overlapRows, OverlapRow } from '../../domain/matching/matchingService';
import { locationLabel, hotelStyleLabel, Strength, strengthLabel, windowLabel } from '../../domain/matching/preferences';
import { voice } from '../../domain/matching/traveler';
import { usd } from '../../domain/shared/money';
import { tripTravelers, memberIsInTrip, TripMember } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore } from '../../store/useTripStore';
import { useSharedProfile, useTrip } from '../../store/hooks';
import { StageFooter, StageTitle } from './ui';

const LINES = ['Comparing budgets…', 'Matching departure windows…', 'Weighing stops and flight time…', 'Checking hotel areas…'];
const SOLO_LINES = ['Reading your budget…', 'Matching your departure window…', 'Weighing stops and flight time…', 'Checking hotel areas…'];

/** The defining Artemis moment: private preferences converge into one shared profile. */
export function OverlapStage({ tripID }: { tripID: string }) {
  const reduce = useReducedMotion();
  const trip = useTrip(tripID);
  const [phase, setPhase] = useState<'finding' | 'revealed'>('finding');
  const [lineIndex, setLineIndex] = useState(0);
  const merge = useSharedValue(0);
  const { width } = useWindowDimensions();

  useEffect(() => {
    if (reduce) { merge.value = 1; setPhase('revealed'); return; }
    merge.value = withTiming(1, { duration: 2400, easing: Easing.bezier(0.5, 0, 0.2, 1) });
    let alive = true;
    const timers: ReturnType<typeof setTimeout>[] = [];
    for (let i = 1; i < LINES.length; i++) timers.push(setTimeout(() => alive && setLineIndex(i), 620 * i));
    timers.push(setTimeout(() => { if (alive) { HapticsService.success(); setPhase('revealed'); } }, 620 * (LINES.length - 1) + 800));
    return () => { alive = false; timers.forEach(clearTimeout); };
  }, [reduce, merge]);

  if (!trip) return null;
  const travelers = tripTravelers(trip);
  const solo = travelers.length === 1;
  const lines = solo ? SOLO_LINES : LINES;
  if (phase === 'revealed') return <Animated.View entering={FadeInDown.duration(550)} style={{ flex: 1 }}><Revealed tripID={tripID} /></Animated.View>;
  return (
    <Animated.View exiting={FadeOut} style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 30 }} accessible accessibilityLabel={solo ? 'Finding your matches' : 'Finding your overlap'}>
      {solo
        ? <SoloMark progress={merge} width={width - 24} height={230} label={travelers[0]?.firstName.toUpperCase() ?? 'YOU'} />
        : <VennMark progress={merge} width={width - 24} height={230} leftLabel={travelers[0]?.firstName.toUpperCase() ?? 'YOU'} rightLabel={travelers[1]?.firstName.toUpperCase() ?? ''} />}
      <View style={{ alignItems: 'center', gap: 10 }}>
        <T style={{ color: colors.luster, fontSize: 26, fontWeight: '800', letterSpacing: -0.4 }}>{solo ? 'FINDING YOUR MATCHES…' : 'FINDING YOUR OVERLAP…'}</T>
        <Animated.View key={lineIndex} entering={FadeIn.duration(400)}><T style={{ color: alpha(colors.luster, 0.65), fontSize: 15 }}>{lines[lineIndex]}</T></Animated.View>
      </View>
    </Animated.View>
  );
}

const dot = (s: Strength) => (s === 'must' ? colors.habanero : s === 'preferred' ? colors.aster : alpha(colors.luster, 0.4));

function Revealed({ tripID }: { tripID: string }) {
  const trip = useTrip(tripID);
  const profile = useSharedProfile(tripID);
  const [shown, setShown] = useState(0);
  const rows = useMemo(() => (profile ? overlapRows(profile) : []), [profile]);
  useEffect(() => {
    let i = 0;
    const t = setInterval(() => { i += 1; setShown(i); if (i >= Math.max(1, rows.length)) clearInterval(t); }, 160);
    return () => clearInterval(t);
  }, [rows.length]);
  if (!trip || !profile) return null;
  const people = trip.members.filter((m) => memberIsInTrip(m) && m.hasSubmittedPreferences);
  const strengths: Strength[] = ['must', 'preferred', 'nice'];
  return (
    <View style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 22 }} showsVerticalScrollIndicator={false}>
        <StageTitle eyebrow={people.length === 1 ? 'Your trip' : 'Overlap'} title={people.length === 1 ? 'Artemis read\nyour trip.' : 'Artemis found\nyour overlap.'} size={42} />
        {/* Each traveler, now visible to the others for the first time. */}
        <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}>{people.map((m) => <Summary key={m.traveler.id} member={m} />)}</View>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }} accessibilityElementsHidden>
          <View style={{ flex: 1, height: 1, backgroundColor: alpha(colors.luster, 0.2) }} />
          <Icon name="chevronDown" size={16} color={colors.habanero} strokeWidth={2.6} />
          <View style={{ flex: 1, height: 1, backgroundColor: alpha(colors.luster, 0.2) }} />
        </View>
        <View style={{ gap: 14 }}>
          <Eyebrow color={alpha(colors.luster, 0.6)} opacity={1}>{people.length === 1 ? 'What Artemis will match' : 'Your shared trip'}</Eyebrow>
          {strengths.map((s) => {
            const group = rows.filter((r) => r.strength === s);
            if (group.length === 0) return null;
            return (
              <View key={s} style={{ gap: 8 }}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: dot(s) }} />
                  <T style={{ color: alpha(colors.luster, 0.75), fontSize: 11, fontWeight: '800', letterSpacing: 1.6 }}>{strengthLabel(s)}</T>
                </View>
                {group.map((row) => {
                  const on = shown > rows.indexOf(row);
                  return <View key={row.id} style={{ opacity: on ? 1 : 0, transform: [{ translateY: on ? 0 : 14 }] }}><RowView row={row} /></View>;
                })}
              </View>
            );
          })}
        </View>
        {profile.conflicts.length > 0 && (
          <GlassPanel radius={18} padding={14} style={{ borderColor: alpha(colors.habanero, 0.5), backgroundColor: alpha(colors.habanero, 0.1) }}>
            <View style={{ gap: 8 }}>
              {profile.conflicts.map((c) => (
                <View key={c.id} style={{ flexDirection: 'row', gap: 10 }}>
                  <Icon name="exclamation" size={16} color={colors.habanero} strokeWidth={2.2} />
                  <View style={{ flex: 1 }}>
                    <T style={{ color: colors.habanero, fontSize: 15, fontWeight: '600' }}>{c.title}</T>
                    <T style={{ color: colors.habanero, opacity: 0.75, fontSize: 13 }}>{c.detail}</T>
                  </View>
                </View>
              ))}
            </View>
          </GlassPanel>
        )}
      </ScrollView>
      <StageFooter><CTAButton haptic title={people.length === 1 ? 'SEE YOUR BEST FLIGHTS  →' : 'SEE YOUR BEST MATCHES  →'} onPress={() => getTripStore().goTo('options', tripID)} /></StageFooter>
    </View>
  );
}

function Summary({ member }: { member: TripMember }) {
  const p = member.preferences;
  const line = (s: string) => <Mono key={s} size={12.5} color={alpha(colors.luster, 0.85)} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>{s}</Mono>;
  return (
    <GlassPanel radius={22} padding={14} style={{ flex: 1 }}>
      <View style={{ gap: 10 }} accessible>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <TravelerAvatar traveler={member.traveler} size={30} />
          <T style={{ color: colors.luster, fontSize: 11, fontWeight: '800', letterSpacing: 1.4 }}>{voice(member.traveler).toUpperCase()}</T>
        </View>
        {line(`${usd(p.flightBudget)} flight`)}
        {line(p.maxStops === 0 ? 'Nonstop' : `${p.maxStops} stop${p.maxStops === 1 ? '' : 's'} max`)}
        {line(windowLabel(p.departureWindow))}
        {line(`${usd(p.hotelBudget)} hotel`)}
        {line(`${locationLabel(p.location)} · ${hotelStyleLabel(p.hotelStyle)}`)}
      </View>
    </GlassPanel>
  );
}

function RowView({ row }: { row: OverlapRow }) {
  return (
    <GlassPanel radius={20} padding={14} style={row.strength === 'must' ? { backgroundColor: alpha(colors.royal, 0.4) } : undefined}>
      <View accessible accessibilityLabel={`${strengthLabel(row.strength).toLowerCase()}: ${row.title}, ${row.value}. ${row.detail}`} style={{ gap: 3 }}>
        <T style={{ color: alpha(colors.luster, 0.55), fontSize: 10.5, fontWeight: '800', letterSpacing: 1.4 }}>{row.title.toUpperCase()}</T>
        <T style={{ color: colors.luster, fontSize: 20, fontWeight: '600' }}>{row.value}</T>
        <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>{row.detail}</T>
      </View>
    </GlassPanel>
  );
}


/** One traveler: a single circle that draws itself in, with her name in it. */
function SoloMark({ progress, width, height, label }: { progress: SharedValue<number>; width: number; height: number; label: string }) {
  const d = Math.min(height, width * 0.52);
  const style = useAnimatedStyle(() => ({ opacity: 0.35 + 0.65 * progress.value, transform: [{ scale: 0.86 + 0.14 * progress.value }] }));
  return (
    <View style={{ width, height, alignItems: 'center', justifyContent: 'center' }} accessibilityElementsHidden importantForAccessibility="no-hide-descendants">
      <Animated.View style={[{ width: d, height: d, borderRadius: d / 2, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.10)', borderWidth: 1.2, borderColor: 'rgba(255,255,255,0.8)' }, style]}>
        <T style={{ color: '#fff', fontSize: 11, fontWeight: '600', letterSpacing: 2 }}>{label}</T>
      </Animated.View>
    </View>
  );
}
