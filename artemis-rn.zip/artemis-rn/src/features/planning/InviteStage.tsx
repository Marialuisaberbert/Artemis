import React from 'react';
import { Pressable, ScrollView, Share, View } from 'react-native';
import { GlassPanel } from '../../design/controls';
import { Icon, IconName } from '../../design/Icon';
import { Body, Eyebrow, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { TravelerAvatar } from '../../design/widgets';
import { fullName } from '../../domain/matching/traveler';
import { everyoneJoined, invitedMembers, Trip, TripMember, tripDestination } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { InviteChannel, inviteChannels, inviteChannelTitle } from '../../store/tripStore';
import { getTripStore, useTripStore } from '../../store/useTripStore';
import { useTrip } from '../../store/hooks';
import { CTAButton } from '../../design/controls';
import { StageFooter, StageTitle } from './ui';

const CHANNEL_ICON: Record<InviteChannel, IconName> = { messages: 'message', link: 'link', contacts: 'contacts' };

/** Bring the group in. Invites go out through Messages, a link or Contacts; in the prototype the friend accepts a moment later. */
export function InviteStage({ tripID }: { tripID: string }) {
  const trip = useTrip(tripID);
  if (!trip) return null;
  const names = invitedMembers(trip).map((m) => m.traveler.firstName);
  const title = everyoneJoined(trip) ? `${names.join(' & ')} joined` : names.length === 0 ? 'Invite\nfriends' : `Invite\n${names.join(' & ')}`;
  const subtitle = everyoneJoined(trip)
    ? "Everyone's here. Next, each of you sets your own preferences, privately."
    : names.length === 0
      ? 'Add a friend, or plan solo. Artemis works best when everyone says what matters.'
      : "Once they join, you'll each tell Artemis what matters. Nobody sees anyone else's answers until everyone has submitted.";
  const anyToInvite = trip.members.some((m) => m.invite === 'notInvited');
  const anyPending = trip.members.some((m) => m.invite === 'notInvited' || m.invite === 'invited');
  const store = getTripStore();
  return (
    <View style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 24 }} showsVerticalScrollIndicator={false}>
        <View style={{ gap: 10 }}>
          <StageTitle eyebrow={names.length === 0 ? "Who's coming?" : 'Plan together'} title={title} size={46} />
          <Body size={16} opacity={0.78}>{subtitle}</Body>
        </View>
        <View style={{ gap: 12 }}>{trip.members.map((m) => <MemberRow key={m.traveler.id} member={m} />)}</View>
        {anyPending && (
          <View style={{ gap: 12 }}>
            <Eyebrow color={alpha(colors.luster, 0.6)} opacity={1}>{anyToInvite ? 'Send an invitation' : 'Invitation sent'}</Eyebrow>
            <View style={{ flexDirection: 'row', gap: 10 }}>{inviteChannels.map((c) => <ChannelButton key={c} trip={trip} channel={c} />)}</View>
          </View>
        )}
        {trip.members.length === 1 && <AddFriends tripID={tripID} />}
      </ScrollView>
      <StageFooter>
        {everyoneJoined(trip) || trip.members.length === 1 ? (
          <CTAButton haptic title={trip.members.length === 1 ? 'CONTINUE SOLO' : 'SET YOUR PREFERENCES  →'} onPress={() => store.continueToPreferences(tripID)} />
        ) : trip.members.some((m) => m.invite === 'joined') ? (
          <CTAButton haptic kind="ghost" title="CONTINUE WITHOUT THE REST" onPress={() => store.goSolo(tripID)} />
        ) : (
          <>
            <View style={{ minHeight: 36, alignItems: 'center', justifyContent: 'center' }}>
              <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13, fontWeight: '600' }}>
                {trip.members.some((m) => m.invite === 'invited') ? 'Waiting for the invitation to be accepted…' : 'Invite your traveler to continue'}
              </T>
            </View>
            <CTAButton haptic kind="ghost" icon="person" title="PLAN SOLO INSTEAD" onPress={() => store.goSolo(tripID)} accessibilityLabel="Plan this trip on your own" />
          </>
        )}
      </StageFooter>
    </View>
  );
}

function MemberRow({ member }: { member: TripMember }) {
  const status = { you: 'You · organizer', joined: 'JOINED THE TRIP', invited: 'Invitation sent…', notInvited: 'Not invited yet' }[member.invite];
  const statusColor = member.invite === 'joined' ? colors.aster : member.invite === 'invited' ? colors.habanero : alpha(colors.luster, 0.6);
  const badge = member.invite === 'you' ? 'done' : member.invite === 'joined' ? 'joined' : member.invite === 'invited' ? 'pending' : 'none';
  return (
    <GlassPanel radius={22} padding={14} style={member.invite === 'joined' ? { backgroundColor: alpha(colors.royal, 0.35) } : undefined}>
      <View accessible accessibilityLabel={`${fullName(member.traveler)}, ${status}`} style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <TravelerAvatar traveler={member.traveler} size={54} badge={badge} />
        <View style={{ flex: 1, gap: 3 }}>
          <T style={{ color: colors.luster, fontSize: 17, fontWeight: '600' }}>{fullName(member.traveler)}</T>
          <T style={{ color: statusColor, fontSize: 13, fontWeight: '600', letterSpacing: 0.4 }}>{status}</T>
        </View>
        {member.invite === 'joined' && <Icon name="check" size={20} color={colors.aster} strokeWidth={2.6} />}
      </View>
    </GlassPanel>
  );
}

function ChannelButton({ trip, channel }: { trip: Trip; channel: InviteChannel }) {
  const pending = trip.members.find((m) => m.invite === 'notInvited' || m.invite === 'invited');
  const disabled = !pending;
  const send = async () => {
    if (!pending) return;
    if (pending.invite !== 'notInvited') { HapticsService.select(); return; }
    HapticsService.success();
    getTripStore().invite(pending.traveler.id, trip.id, channel);
    if (channel === 'link') {
      try { await Share.share({ message: `Join my trip to ${tripDestination(trip).city}. Plan our trip together on Artemis: https://artemis.example/join/${trip.id}` }); } catch { /* the share sheet is optional */ }
    }
  };
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={`Invite via ${inviteChannelTitle(channel)}`} disabled={disabled} onPress={send}
      style={{ flex: 1, minHeight: 84, borderRadius: 20, alignItems: 'center', justifyContent: 'center', gap: 8, opacity: disabled ? 0.5 : 1, backgroundColor: alpha(colors.luster, 0.08), borderWidth: 1, borderColor: alpha(colors.luster, 0.2) }}>
      <Icon name={CHANNEL_ICON[channel]} size={22} color={colors.luster} strokeWidth={1.9} />
      <T style={{ color: colors.luster, fontSize: 13, fontWeight: '600' }}>{inviteChannelTitle(channel)}</T>
    </Pressable>
  );
}

function AddFriends({ tripID }: { tripID: string }) {
  const friends = useTripStore((s) => s.friends());
  return (
    <View style={{ gap: 12 }}>
      <Eyebrow color={alpha(colors.luster, 0.6)} opacity={1}>Your friends</Eyebrow>
      {friends.map((f) => (
        <Pressable key={f.id} accessibilityRole="button" accessibilityLabel={`Add ${fullName(f)}`} onPress={() => { HapticsService.select(); getTripStore().addMember(f.id, tripID); }}>
          <GlassPanel radius={18} padding={10}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
              <TravelerAvatar traveler={f} size={40} />
              <T style={{ flex: 1, color: colors.luster, fontSize: 15, fontWeight: '600' }}>{fullName(f)}</T>
              <Icon name="plus" size={16} color={alpha(colors.luster, 0.7)} strokeWidth={2.4} />
            </View>
          </GlassPanel>
        </Pressable>
      ))}
    </View>
  );
}
