import React, { useState } from 'react';
import { View } from 'react-native';
import { CTAButton, GlassPanel, Hairline } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { RouteLine } from '../../design/RouteLine';
import { Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { MatchRing } from '../../design/widgets';
import type { GroupMatch, MatchReason, ScoredHotel } from '../../domain/matching/matchingService';
import { locationLabel, hotelStyleLabel } from '../../domain/matching/preferences';
import { usd } from '../../domain/shared/money';
import { hoursMinutes, timeZone, Zoned } from '../../domain/shared/time';
import {
  arrivalDayOffset, arrivalLocal, departureLocal, FlightOption, flightArrival, flightDeparture, flightDestination, flightDuration, flightOrigin,
  flightStops, layovers, routeCodes, stopsLabel,
} from '../../domain/trips/flights';
import { HapticsService } from '../../services/HapticsService';

interface Props {
  option: FlightOption;
  match: GroupMatch;
  rank?: number;
  isBest?: boolean;
  travelers?: number;
  outside?: boolean;
  onChooseAnyway?: () => void;
  /** Fixed width, or omit to fill the parent. */
  width?: number;
}

const Badge = ({ text, fill, ink }: { text: string; fill: string; ink: string }) => (
  <View style={{ alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, backgroundColor: fill }}>
    <T style={{ color: ink, fontSize: 10, fontWeight: '800', letterSpacing: 1.4 }}>{text}</T>
  </View>
);

const reasonIcon = (k: MatchReason['kind']) => (k === 'met' ? 'check' : k === 'partial' ? 'exclamation' : 'close');

/**
 * A flight, as it appears when the group is choosing: what it is, what it costs, and — most importantly — why it matches.
 * Every score is explained; nothing is an unexplained number.
 */
export function FlightOptionCard({ option, match, rank, isBest = false, travelers = 2, outside = false, onChooseAnyway, width }: Props) {
  const [measured, setMeasured] = useState(320);
  const inner = (width ?? measured) - 40;
  const otz = timeZone(flightOrigin(option).timeZoneID);
  const dtz = timeZone(flightDestination(option).timeZoneID);
  const l = layovers(option)[0];
  const stopText = flightStops(option) === 0 ? 'NONSTOP' : `${stopsLabel(option).toUpperCase()}\n${l ? `${l.airport.code} · ${hoursMinutes(l.duration)}` : ''}`;
  const dayOffset = arrivalDayOffset(option);
  const timeBlock = (time: string, city: string, sub: string, trailing = false) => (
    <View style={{ alignItems: trailing ? 'flex-end' : 'flex-start', gap: 2, flexShrink: 1 }}>
      <Mono size={20} weight="600" color={colors.luster} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.6}>{time}</Mono>
      <T numberOfLines={1} style={{ color: alpha(colors.luster, 0.65), fontSize: 13 }}>{city}</T>
      <T style={{ color: alpha(colors.luster, 0.45), fontSize: 11, fontWeight: '700', letterSpacing: 1 }}>{sub.toUpperCase()}</T>
    </View>
  );
  return (
    <View
      onLayout={width === undefined ? (e) => setMeasured(e.nativeEvent.layout.width) : undefined}
      style={{
        width, padding: 20, gap: 16, borderRadius: 30, backgroundColor: outside ? alpha(colors.habanero, 0.07) : alpha(colors.luster, 0.07),
        borderWidth: isBest ? 1.5 : 1, borderColor: isBest ? alpha(colors.habanero, 0.85) : alpha(colors.luster, 0.16), borderStyle: outside ? 'dashed' : 'solid',
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 }}>
        <View style={{ flex: 1, gap: 8 }}>
          {outside ? <Badge text={travelers === 1 ? 'OUTSIDE YOUR BUDGET' : 'OUTSIDE YOUR SHARED BUDGET'} fill={colors.habanero} ink={colors.depths} />
            : isBest ? <Badge text={travelers === 1 ? 'BEST MATCH' : 'BEST GROUP MATCH'} fill={colors.habanero} ink={colors.depths} />
            : rank ? <Badge text={`OPTION ${rank}`} fill={alpha(colors.luster, 0.12)} ink={colors.luster} /> : null}
          <T numberOfLines={2} adjustsFontSizeToFit minimumFontScale={0.7} style={{ color: colors.luster, fontSize: 21, fontWeight: '800', letterSpacing: -0.2 }}>{option.airline.toUpperCase()}</T>
          <Mono size={13} color={alpha(colors.luster, 0.6)}>{option.legs.map((l2) => l2.flightNumber).join(' + ') + (option.cabin === 'Economy' ? '' : ` · ${option.cabin}`)}</Mono>
        </View>
        <MatchRing percent={match.percent} size={64} />
      </View>

      <RouteLine codes={routeCodes(option)} position={flightStops(option) === 0 ? 0.5 : 0.62} width={inner} height={46} />

      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        {timeBlock(departureLocal(option), flightOrigin(option).city, Zoned.day(flightDeparture(option), otz))}
        <View style={{ alignItems: 'center', gap: 3 }}>
          <Mono size={15} weight="700" color={colors.luster}>{hoursMinutes(flightDuration(option))}</Mono>
          <T style={{ color: alpha(colors.luster, 0.6), fontSize: 10.5, fontWeight: '600', letterSpacing: 0.6, textAlign: 'center' }}>{stopText}</T>
        </View>
        {timeBlock(arrivalLocal(option) + (dayOffset > 0 ? ` +${dayOffset}` : ''), flightDestination(option).city, Zoned.day(flightArrival(option), dtz), true)}
      </View>

      <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 8 }}>
        <Mono size={34} weight="600" color={colors.luster} style={{ letterSpacing: -1 }}>{usd(option.farePerTraveler)}</Mono>
        <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13 }}>per traveler</T>
        <View style={{ flex: 1 }} />
        <T style={{ color: alpha(colors.luster, 0.8), fontSize: 13, fontWeight: '600' }}>{`${usd(option.farePerTraveler * travelers)} for ${travelers}`}</T>
      </View>

      <Hairline color={alpha(colors.luster, 0.14)} />

      <View style={{ gap: 9 }}>
        {match.reasons.slice(0, 5).map((r) => (
          <View key={r.text} accessible accessibilityLabel={`${r.kind === 'met' ? 'Matches' : r.kind === 'partial' ? 'Trade-off' : 'Not met'}: ${r.text}`} style={{ flexDirection: 'row', gap: 10 }}>
            <View style={{ width: 16, paddingTop: 3, alignItems: 'center' }}><Icon name={reasonIcon(r.kind)} size={13} color={r.kind === 'met' ? colors.aster : colors.habanero} strokeWidth={2.8} /></View>
            <T style={{ flex: 1, color: alpha(colors.luster, r.kind === 'met' ? 0.92 : 1), fontSize: 15 }}>{r.text}</T>
          </View>
        ))}
      </View>

      {outside && onChooseAnyway && (
        <CTAButton compact kind="ghost" title="CHOOSE ANYWAY  →" onPress={() => { HapticsService.warning(); onChooseAnyway(); }} style={{ alignSelf: 'center' }} />
      )}
    </View>
  );
}

/** A hotel the group would stay in, and why it fits. */
export function HotelStrip({ hotel, nights }: { hotel: ScoredHotel; nights: number }) {
  return (
    <GlassPanel radius={22} padding={14}>
      <View accessible style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <View style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: colors.royal, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="bed" size={20} color={colors.luster} strokeWidth={1.9} />
        </View>
        <View style={{ flex: 1, gap: 3 }}>
          <T style={{ color: alpha(colors.luster, 0.55), fontSize: 10, fontWeight: '800', letterSpacing: 1.5 }}>YOUR STAY</T>
          <T style={{ color: colors.luster, fontSize: 17, fontWeight: '600' }}>{hotel.hotel.name}</T>
          <T numberOfLines={2} style={{ color: alpha(colors.luster, 0.7), fontSize: 13 }}>
            {`${usd(hotel.hotel.nightlyRate)}/night · ${nights} nights · ${locationLabel(hotel.hotel.location)} · ${hotelStyleLabel(hotel.hotel.style)}`}
          </T>
        </View>
        <Mono size={15} weight="700" color={colors.habanero}>{`${hotel.percent}%`}</Mono>
      </View>
    </GlassPanel>
  );
}
