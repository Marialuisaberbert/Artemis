import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import Animated, { FadeInDown, FadeOut, useReducedMotion } from 'react-native-reanimated';
import { CTAButton, GlassPanel } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { Eyebrow, Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { TravelerAvatar } from '../../design/widgets';
import { usd } from '../../domain/shared/money';
import { hoursMinutes } from '../../domain/shared/time';
import { flightDuration, stopsLabel } from '../../domain/trips/flights';
import { hotelNights } from '../../domain/trips/itinerary';
import { memberIsInTrip, Trip, GroupDecision, travelerCount } from '../../domain/trips/trip';
import { voice } from '../../domain/matching/traveler';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore } from '../../store/useTripStore';
import { useFlightMatches, useGroupOrder, useHotelPick, useTrip } from '../../store/hooks';
import { FlightOptionCard, HotelStrip } from './FlightOptionCard';
import { StageFooter, StageTitle } from './ui';

/**
 * Two rankings become one group order. If the group agrees, Artemis says so; if it doesn't, Artemis lays out the trade-off
 * and lets the travelers choose. It never picks a "winner".
 */
export function DecisionStage({ tripID }: { tripID: string }) {
  const trip = useTrip(tripID);
  const reduce = useReducedMotion();
  const [revealed, setRevealed] = useState(false);
  const [choice, setChoice] = useState<string | undefined>();
  useEffect(() => {
    const t = setTimeout(() => { HapticsService.success(); setRevealed(true); }, reduce ? 200 : 3200);
    return () => clearTimeout(t);
  }, [reduce]);
  const decision = trip?.decision;
  if (!trip || !decision) return null;
  if (!revealed) return <Animated.View exiting={FadeOut} style={{ flex: 1 }}><Tally trip={trip} /></Animated.View>;
  return (
    <Animated.View entering={FadeInDown.duration(500)} style={{ flex: 1 }}>
      {decision.kind === 'aligned'
        ? <Aligned trip={trip} decision={decision} />
        : <Tradeoff trip={trip} decision={decision} choice={choice} onChoice={setChoice} />}
    </Animated.View>
  );
}

// MARK: - The tally

function Tally({ trip }: { trip: Trip }) {
  const order = useGroupOrder(trip.id);
  const shortName = (id: string) => trip.flightOptions.find((o) => o.id === id)?.shortName.toUpperCase() ?? id;
  return (
    <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 22 }} showsVerticalScrollIndicator={false}>
      <StageTitle eyebrow="Group order" title={'Combining your\nrankings…'} />
      <View style={{ flexDirection: 'row', gap: 10, alignItems: 'flex-start' }}>
        {trip.members.filter(memberIsInTrip).map((m) => (
          <GlassPanel key={m.traveler.id} radius={22} padding={14} style={{ flex: 1 }}>
            <View style={{ gap: 10 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                <TravelerAvatar traveler={m.traveler} size={28} />
                <T style={{ color: colors.luster, fontSize: 11, fontWeight: '800', letterSpacing: 1.4 }}>{voice(m.traveler).toUpperCase()}</T>
              </View>
              {m.ranking.map((id, i) => (
                <View key={id} style={{ flexDirection: 'row', gap: 8 }}>
                  <Mono size={13} weight="800" color={colors.habanero} style={{ width: 14 }}>{i + 1}</Mono>
                  <T style={{ color: colors.luster, fontSize: 15, fontWeight: '600' }}>{shortName(id)}</T>
                </View>
              ))}
            </View>
          </GlassPanel>
        ))}
      </View>
      <View style={{ gap: 10 }}>
        <Eyebrow color={alpha(colors.luster, 0.6)} opacity={1}>Group order</Eyebrow>
        {order.map((entry, i) => (
          <Animated.View key={entry.optionID} entering={FadeInDown.delay(200 + i * 200).duration(700)} style={{ gap: 6 }}>
            <GlassPanel radius={20} padding={14} style={i === 0 ? { backgroundColor: alpha(colors.royal, 0.5) } : undefined}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <Mono size={24} weight="800" color={i === 0 ? colors.habanero : alpha(colors.luster, 0.6)} style={{ width: 30 }}>{i + 1}</Mono>
                <T style={{ flex: 1, color: colors.luster, fontSize: 20, fontWeight: '800' }}>{shortName(entry.optionID)}</T>
                <Mono size={15} color={alpha(colors.luster, 0.7)}>{`${entry.points} pts`}</Mono>
              </View>
            </GlassPanel>
            {entry.brokenByMatch && <T style={{ color: alpha(colors.luster, 0.6), fontSize: 13, paddingLeft: 44 }}>Level on points. The stronger group match comes first.</T>}
          </Animated.View>
        ))}
      </View>
    </ScrollView>
  );
}

// MARK: - Aligned

function Aligned({ trip, decision }: { trip: Trip; decision: GroupDecision }) {
  const matches = useFlightMatches(trip.id)?.matches;
  const hotel = useHotelPick(trip.id);
  const option = trip.flightOptions.find((o) => o.id === decision.primaryOptionID);
  const match = matches?.find((m) => m.option.id === option?.id)?.match;
  if (!option) return null;
  return (
    <View style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 20 }} showsVerticalScrollIndicator={false}>
        <View style={{ gap: 10 }}>
          <StageTitle eyebrow={trip.members.filter(memberIsInTrip).length === 1 ? 'Best match' : 'Best group match'} title={'Artemis found\na match.'} size={42} />
          <T style={{ color: alpha(colors.luster, 0.85), fontSize: 19 }}>{trip.members.filter(memberIsInTrip).length === 1 ? 'It fits everything you asked for.' : "Both travelers' preferences align."}</T>
        </View>
        {match && <FlightOptionCard option={option} match={match} isBest travelers={travelerCount(trip)} />}
        <View style={{ gap: 8 }}>
          {decision.explanation.map((line) => (
            <View key={line} style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ width: 16, paddingTop: 4 }}><Icon name="check" size={12} color={colors.aster} strokeWidth={3} /></View>
              <T style={{ flex: 1, color: alpha(colors.luster, 0.85), fontSize: 15 }}>{line}</T>
            </View>
          ))}
        </View>
        {hotel && <HotelStrip hotel={hotel} nights={hotelNights(trip)} />}
      </ScrollView>
      <StageFooter><CTAButton haptic title="CONTINUE  →" onPress={() => getTripStore().chooseFlight(trip.id, decision.primaryOptionID)} /></StageFooter>
    </View>
  );
}

// MARK: - Trade-off

function Tradeoff({ trip, decision, choice, onChoice }: { trip: Trip; decision: GroupDecision; choice?: string; onChoice: (id: string) => void }) {
  const matches = useFlightMatches(trip.id)?.matches ?? [];
  const ids = [decision.primaryOptionID, decision.alternativeOptionID].filter((x): x is string => !!x);
  const options = ids.map((id) => matches.find((m) => m.option.id === id)).filter((m): m is NonNullable<typeof m> => !!m)
    .sort((a, b) => b.option.farePerTraveler - a.option.farePerTraveler);
  const chosen = options.find((o) => o.option.id === choice);
  const fact = (value: string, label: string) => (
    <View style={{ gap: 2, flexShrink: 1 }}>
      <Mono size={14} weight="700" color={colors.luster} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7}>{value}</Mono>
      <T style={{ color: alpha(colors.luster, 0.5), fontSize: 8.5, fontWeight: '800', letterSpacing: 1 }}>{label.toUpperCase()}</T>
    </View>
  );
  return (
    <View style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 20 }} showsVerticalScrollIndicator={false}>
        <View style={{ gap: 10 }}>
          <StageTitle eyebrow="Trade-off" title={'Artemis found\na trade-off.'} size={42} />
          <T style={{ color: alpha(colors.luster, 0.85), fontSize: 19 }}>You want different things. Artemis won't decide for you.</T>
        </View>
        {options.map((s, i) => {
          const selected = choice === s.option.id;
          return (
            <Pressable key={s.option.id} accessibilityRole="button" accessibilityState={{ selected }} onPress={() => { HapticsService.select(); onChoice(s.option.id); }}>
              <GlassPanel radius={26} padding={18} style={{ borderColor: selected ? colors.habanero : alpha(colors.luster, 0.18), backgroundColor: selected ? alpha(colors.royal, 0.55) : undefined }}>
                <View style={{ gap: 12 }}>
                  <T style={{ color: colors.habanero, fontSize: 11, fontWeight: '800', letterSpacing: 1.6 }}>{`OPTION ${i === 0 ? 'A' : 'B'}`}</T>
                  <T style={{ color: colors.luster, fontSize: 26, fontWeight: '800' }}>{s.option.shortName.toUpperCase()}</T>
                  <View style={{ flexDirection: 'row', gap: 18 }}>
                    {fact(usd(s.option.farePerTraveler), 'per traveler')}
                    {fact(stopsLabel(s.option), 'stops')}
                    {fact(hoursMinutes(flightDuration(s.option)), 'duration')}
                    {fact(`${s.match.percent}%`, 'match')}
                  </View>
                </View>
                {selected && <View style={{ position: 'absolute', top: -2, right: -2 }}><Icon name="check" size={22} color={colors.habanero} strokeWidth={3} /></View>}
              </GlassPanel>
            </Pressable>
          );
        })}
        <View style={{ gap: 8 }}>
          {decision.explanation.map((line) => (
            <View key={line} style={{ flexDirection: 'row', gap: 10 }}>
              <View style={{ width: 16, paddingTop: 4 }}><Icon name="arrowRight" size={12} color={colors.aster} strokeWidth={3} /></View>
              <T style={{ flex: 1, color: alpha(colors.luster, 0.85), fontSize: 15 }}>{line}</T>
            </View>
          ))}
        </View>
      </ScrollView>
      <StageFooter>
        <CTAButton haptic disabled={!choice} title={chosen ? `CONTINUE WITH ${chosen.option.shortName.toUpperCase()}  →` : 'CHOOSE ONE TO CONTINUE'}
          onPress={() => { if (choice) getTripStore().chooseFlight(trip.id, choice); }} />
      </StageFooter>
    </View>
  );
}
