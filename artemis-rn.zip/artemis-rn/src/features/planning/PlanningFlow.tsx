import React, { useEffect, useState } from 'react';
import { Modal, View } from 'react-native';
import { router } from 'expo-router';
import Animated, { FadeIn, FadeInDown, FadeOut } from 'react-native-reanimated';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { RoundIconButton } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { NightBackdrop } from '../../design/NightBackdrop';
import { PhotoBackdrop } from '../../design/PhotoView';
import { T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { TravelerAvatar } from '../../design/widgets';
import { isSoloPlanning, stageOrder, tripDays, tripDestination, tripTitle, dateRange, TripStage, memberIsInTrip } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { useTrip } from '../../store/hooks';
import { ConfirmationStage } from '../booking/ConfirmationStage';
import { TrustBookingView } from '../booking/TrustBookingView';
import { DecisionStage } from './DecisionStage';
import { InviteStage } from './InviteStage';
import { OptionsStage } from './OptionsStage';
import { OverlapStage } from './OverlapStage';
import { PlanningTrail } from './PlanningTrail';
import { PreferencesEntry, PreferencesStage } from './PreferencesStage';
import { RankingEntry, RankingStage } from './RankingStage';

export interface PhoneRequest {
  travelerID: string;
  kind: 'preferences' | 'ranking';
}

/** The destination comes into focus as the trip takes shape. */
const blurFor = (s: TripStage): number =>
  ({ draft: 22, inviting: 22, preferences: 18, overlap: 14, options: 10, ranking: 7, decision: 4, booking: 2, booked: 0 })[s];

/**
 * One continuous full-screen journey from "invite" to "booked". The destination stays behind every step, so the trip
 * feels like one place you are moving through, not a stack of forms.
 */
export function PlanningFlow({ tripID }: { tripID: string }) {
  const trip = useTrip(tripID);
  const insets = useSafeAreaInsets();
  const [phoneFor, setPhoneFor] = useState<PhoneRequest | undefined>();
  const stage = trip?.stage;
  useEffect(() => { if (stage) HapticsService.soft(); }, [stage]);
  if (!trip) return <View style={{ flex: 1, backgroundColor: '#000' }} />;
  const key = trip.stage === 'draft' ? stageOrder('inviting') : stageOrder(trip.stage);

  if (trip.stage === 'booked') {
    // Booked: the screen goes dark and the ticket arrives. No header, no trail.
    return <Animated.View entering={FadeIn.duration(600)} style={{ flex: 1, backgroundColor: '#000' }}><ConfirmationStage tripID={tripID} onClose={() => router.back()} /></Animated.View>;
  }
  const d = tripDestination(trip);
  return (
    <View style={{ flex: 1, backgroundColor: '#000' }}>
      <PhotoBackdrop destination={d} blur={blurFor(trip.stage)} dim={0.42} bottomScrim={0.7} />
      <View style={{ flex: 1, paddingTop: insets.top }}>
        <View style={{ paddingHorizontal: 20, paddingTop: 8, paddingBottom: 10, gap: 14 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <RoundIconButton icon="chevronDown" label="Close planning" onPress={() => router.back()} />
            <View style={{ flex: 1, gap: 1 }}>
              <T numberOfLines={1} style={{ color: colors.luster, fontSize: 13, fontWeight: '800', letterSpacing: 1.4 }}>{tripTitle(trip)}</T>
              <T style={{ color: alpha(colors.luster, 0.65), fontSize: 10.5, fontWeight: '600', letterSpacing: 1.4 }}>{`${dateRange(trip)} · ${tripDays(trip)} DAYS`}</T>
            </View>
            <View style={{ flexDirection: 'row' }}>
              {trip.members.map((m, i) => (
                <View key={m.traveler.id} style={{ marginLeft: i ? -8 : 0, opacity: memberIsInTrip(m) || m.invite === 'invited' ? 1 : 0.45, borderRadius: 18, borderWidth: 2, borderColor: colors.depths }}>
                  <TravelerAvatar traveler={m.traveler} size={34} badge={m.invite === 'invited' ? 'pending' : 'none'} />
                </View>
              ))}
            </View>
          </View>
          <PlanningTrail stage={trip.stage === 'draft' ? 'inviting' : trip.stage} solo={isSoloPlanning(trip)} />
        </View>
        <Animated.View key={key} entering={FadeInDown.duration(550)} exiting={FadeOut.duration(250)} style={{ flex: 1 }}>
          <StageView trip={trip.id} stage={trip.stage} onPhone={setPhoneFor} />
        </Animated.View>
      </View>
      <PhonePass tripID={tripID} request={phoneFor} onClose={() => setPhoneFor(undefined)} />
    </View>
  );
}

function StageView({ trip, stage, onPhone }: { trip: string; stage: TripStage; onPhone: (r: PhoneRequest) => void }) {
  switch (stage) {
    case 'draft':
    case 'inviting': return <InviteStage tripID={trip} />;
    case 'preferences': return <PreferencesStage tripID={trip} onPhone={onPhone} />;
    case 'overlap': return <OverlapStage tripID={trip} />;
    case 'options': return <OptionsStage tripID={trip} />;
    case 'ranking': return <RankingStage tripID={trip} onPhone={onPhone} />;
    case 'decision': return <DecisionStage tripID={trip} />;
    case 'booking': return <TrustBookingView tripID={trip} kind="flight" />;
    case 'booked': return null;
  }
}

/** A private moment: one traveler's screen, on someone else's turn. Preferences stay hidden until every traveler has submitted. */
function PhonePass({ tripID, request, onClose }: { tripID: string; request?: PhoneRequest; onClose: () => void }) {
  const trip = useTrip(tripID);
  const traveler = request ? trip?.members.find((m) => m.traveler.id === request.travelerID)?.traveler : undefined;
  return (
    <Modal visible={!!request} animationType="slide" presentationStyle="fullScreen" onRequestClose={onClose}>
      <GestureHandlerRootView style={{ flex: 1, backgroundColor: '#000' }}>
        <SafeAreaProvider>
          <PhonePassBody tripID={tripID} request={request} traveler={traveler} onClose={onClose} />
        </SafeAreaProvider>
      </GestureHandlerRootView>
    </Modal>
  );
}

function PhonePassBody({ tripID, request, traveler, onClose }: { tripID: string; request?: PhoneRequest; traveler?: { id: string; firstName: string; lastName: string; isYou: boolean; tint: number }; onClose: () => void }) {
  const insets = useSafeAreaInsets();
  if (!request || !traveler) return <View style={{ flex: 1, backgroundColor: '#000' }} />;
  const prefs = request.kind === 'preferences';
  return (
    <View style={{ flex: 1, backgroundColor: '#000', paddingTop: insets.top }}>
      <NightBackdrop glow={0.3} showStars={false} />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, paddingVertical: 8 }}>
        <RoundIconButton icon="close" label="Close" onPress={onClose} />
        <TravelerAvatar traveler={traveler} size={40} />
        <View style={{ flex: 1, gap: 1 }}>
          <T style={{ color: colors.luster, fontSize: 13, fontWeight: '800', letterSpacing: 1.4 }}>{`${traveler.firstName.toUpperCase()}'S ${prefs ? 'PREFERENCES' : 'RANKING'}`}</T>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
            <Icon name="shield" size={12} color={colors.habanero} strokeWidth={2.2} />
            <T style={{ color: colors.habanero, fontSize: 12, fontWeight: '600' }}>{`Private to ${traveler.firstName}`}</T>
          </View>
        </View>
      </View>
      {prefs
        ? <PreferencesEntry tripID={tripID} travelerID={traveler.id} submitLabel={`SUBMIT ${traveler.firstName.toUpperCase()}'S PREFERENCES`} onSubmitted={onClose} />
        : <RankingEntry tripID={tripID} travelerID={traveler.id} submitLabel={`SUBMIT ${traveler.firstName.toUpperCase()}'S RANKING`} onSubmitted={onClose} />}
    </View>
  );
}

