import React from 'react';
import { View } from 'react-native';
import { T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { soloTrail, stageOrder, stageTitle, stageTrail as fullTrail, TripStage } from '../../domain/trips/trip';

/** Where the group is on the way to a booking: invite, preferences, overlap, options, rank, decide, book. */
export function PlanningTrail({ stage, solo = false }: { stage: TripStage; solo?: boolean }) {
  const stageTrail = solo ? soloTrail : fullTrail;
  const idx = stageTrail.findIndex((s) => stageOrder(s) >= stageOrder(stage));
  const current = Math.min(stageTrail.length - 1, Math.max(0, idx === -1 ? stageTrail.length - 1 : idx));
  const done = stage === 'booked';
  const fill = (i: number) => (done || i < current ? alpha(colors.luster, 0.75) : i === current ? colors.habanero : alpha(colors.luster, 0.18));
  return (
    <View style={{ gap: 8 }} accessible accessibilityLabel={done ? 'Booked' : `Step ${current + 1} of ${stageTrail.length}: ${stageTitle(stageTrail[current])}`}>
      <View style={{ flexDirection: 'row', gap: 4 }}>
        {stageTrail.map((s, i) => <View key={s} style={{ flex: 1, height: 3, borderRadius: 2, backgroundColor: fill(i) }} />)}
      </View>
      <View style={{ flexDirection: 'row', gap: 4 }}>
        {stageTrail.map((s, i) => (
          <T key={s} numberOfLines={1} adjustsFontSizeToFit minimumFontScale={0.7} maxFontSizeMultiplier={1.15}
            style={{ flex: 1, textAlign: 'center', fontSize: 8.5, fontWeight: '800', letterSpacing: 0.6, color: i === current && !done ? colors.luster : alpha(colors.luster, i < current || done ? 0.6 : 0.35) }}>
            {stageTitle(s).toUpperCase()}
          </T>
        ))}
      </View>
    </View>
  );
}

