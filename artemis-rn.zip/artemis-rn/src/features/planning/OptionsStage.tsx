import React, { useRef, useState } from 'react';
import { ScrollView, View, useWindowDimensions } from 'react-native';
import { CTAButton } from '../../design/controls';
import { Body, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { overlapRows } from '../../domain/matching/matchingService';
import { hotelNights } from '../../domain/trips/itinerary';
import { travelerCount } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore } from '../../store/useTripStore';
import { useFlightMatches, useHotelPick, useSharedProfile, useTrip } from '../../store/hooks';
import { FlightOptionCard, HotelStrip } from './FlightOptionCard';
import { SpendingGuard } from './SpendingGuard';
import { StageFooter, StageTitle } from './ui';

/** Swipe through what fits the whole group. Every card says why. */
export function OptionsStage({ tripID }: { tripID: string }) {
  const trip = useTrip(tripID);
  const result = useFlightMatches(tripID);
  const hotel = useHotelPick(tripID);
  const profile = useSharedProfile(tripID);
  const { width } = useWindowDimensions();
  const [current, setCurrent] = useState(0);
  const cardW = width * 0.88;
  const last = useRef(0);
  if (!trip || !result) return null;
  const solo = travelerCount(trip) === 1;
  const mustHaves = solo && profile ? overlapRows(profile).filter((r) => r.strength === 'must').map((r) => r.value) : [];
  const cards = [...result.matches.map((s) => ({ s, outside: false })), ...result.outside.map((s) => ({ s, outside: true }))];
  return (
    <View style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ paddingTop: 8, paddingBottom: 20, gap: 18 }} showsVerticalScrollIndicator={false}>
        <View style={{ paddingHorizontal: 20, gap: 8 }}>
          <StageTitle eyebrow={travelerCount(trip) === 1 ? 'Your match' : 'Group match'} title="Your best matches." size={34} />
          <Body size={15} opacity={0.7}>
            {solo ? `${result.matches.length} flights fit your must-haves. Swipe to compare.` : `${result.matches.length} flights fit everyone's must-haves. Swipe to compare.`}
            {result.outside.length > 0 ? ` ${result.outside.length} more ${result.outside.length === 1 ? 'is' : 'are'} just outside ${solo ? 'your limits' : "the group's limits"}, so you can see what you'd be trading.` : ''}
          </Body>
          {mustHaves.length > 0 && (
            <View style={{ gap: 6, paddingTop: 4 }}>
              <T style={{ color: alpha(colors.luster, 0.55), fontSize: 10, fontWeight: '800', letterSpacing: 1.5 }}>YOUR MUST-HAVES</T>
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 6 }}>
                {mustHaves.map((m) => (
                  <View key={m} style={{ paddingHorizontal: 10, paddingVertical: 5, borderRadius: 999, borderWidth: 1, borderColor: alpha(colors.habanero, 0.6), backgroundColor: alpha(colors.habanero, 0.1) }}>
                    <T style={{ color: colors.luster, fontSize: 12, fontWeight: '600' }}>{m}</T>
                  </View>
                ))}
              </View>
            </View>
          )}
        </View>
        <ScrollView
          horizontal showsHorizontalScrollIndicator={false} snapToInterval={cardW + 14} decelerationRate="fast" contentContainerStyle={{ paddingHorizontal: 20, gap: 14, alignItems: 'flex-start' }}
          onMomentumScrollEnd={(e) => {
            const i = Math.round(e.nativeEvent.contentOffset.x / (cardW + 14));
            if (i !== last.current) { last.current = i; HapticsService.select(); }
            setCurrent(i);
          }}
        >
          {cards.map(({ s, outside }, i) => (
            <FlightOptionCard
              key={s.option.id} width={cardW} option={s.option} match={s.match} rank={outside ? undefined : i + 1} isBest={!outside && i === 0}
              travelers={travelerCount(trip)} outside={outside} onChooseAnyway={outside ? () => getTripStore().chooseFlight(tripID, s.option.id) : undefined}
            />
          ))}
        </ScrollView>
        <View style={{ flexDirection: 'row', gap: 6, justifyContent: 'center' }} accessibilityElementsHidden>
          {cards.map((c, i) => <View key={c.s.option.id} style={{ height: 4, borderRadius: 2, width: i === current ? 22 : 7, backgroundColor: i === current ? colors.habanero : alpha(colors.luster, 0.25) }} />)}
        </View>
        {hotel && <View style={{ paddingHorizontal: 20 }}><HotelStrip hotel={hotel} nights={hotelNights(trip)} /></View>}
        <View style={{ paddingHorizontal: 20 }}><SpendingGuard /></View>
      </ScrollView>
      <StageFooter>
        {solo
          ? <CTAButton haptic title={cards[current]?.outside ? 'CHOOSE THIS ONE ANYWAY  →' : 'BOOK THIS FLIGHT  →'} onPress={() => { const c = cards[current]; if (c) getTripStore().chooseFlight(tripID, c.s.option.id); }} />
          : <CTAButton haptic title="RANK YOUR OPTIONS  →" onPress={() => getTripStore().goTo('ranking', tripID)} />}
      </StageFooter>
    </View>
  );
}
