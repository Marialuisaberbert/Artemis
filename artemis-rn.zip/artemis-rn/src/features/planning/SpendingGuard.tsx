import React from 'react';
import { View } from 'react-native';
import { GlassPanel } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { usd } from '../../domain/shared/money';
import { useTripStore } from '../../store/useTripStore';
import { SourceChip } from '../booking/TrustPanels';

/** What Artemis's agent may spend on its own, and what is actually in the account. Reads the live account when there is one. */
export function SpendingGuard() {
  const policy = useTripStore((s) => s.policy);
  const financial = useTripStore((s) => s.financial);
  return (
    <GlassPanel radius={22} padding={14}>
      <View accessible accessibilityLabel={`Spending guard. Flights up to ${usd(policy.flightLimit)} book automatically. ${usd(financial.availableBalance)} available.`} style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
        <View style={{ width: 48, height: 48, borderRadius: 14, backgroundColor: colors.royal, alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="shield" size={20} color={colors.luster} strokeWidth={1.9} />
        </View>
        <View style={{ flex: 1, gap: 3 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <T style={{ color: alpha(colors.luster, 0.55), fontSize: 10, fontWeight: '800', letterSpacing: 1.5 }}>YOUR SPENDING GUARD</T>
            <SourceChip source={financial.source === 'nessie' ? 'live' : 'simulated'} />
          </View>
          <T style={{ color: colors.luster, fontSize: 16, fontWeight: '600' }}>{`Up to ${usd(policy.flightLimit)} a flight books on its own`}</T>
          <T numberOfLines={2} style={{ color: alpha(colors.luster, 0.7), fontSize: 13 }}>{`${usd(financial.availableBalance)} available in ${financial.accountName}. Anything above your limit asks you first.`}</T>
        </View>
      </View>
    </GlassPanel>
  );
}
