import React, { useState } from 'react';
import { ScrollView, View } from 'react-native';
import { CTAButton, GlassPanel, Hairline, SelectableChip } from '../../design/controls';
import { Icon, IconName } from '../../design/Icon';
import { Body, Eyebrow, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { BudgetSlider, HourRangeSlider, SegmentedPill, StarRating, StrengthChip, TravelerAvatar } from '../../design/widgets';
import {
  FieldStrengths, HotelStyle, hotelStyleLabel, hotelStyles, LocationPreference, locationLabel, locationPreferences, TravelPreferences,
} from '../../domain/matching/preferences';
import { fullName } from '../../domain/matching/traveler';
import { memberIsInTrip, TripMember } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore } from '../../store/useTripStore';
import { useTrip } from '../../store/hooks';
import { StageFooter, StageTitle } from './ui';
import type { PhoneRequest } from './PlanningFlow';

const Panel = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <GlassPanel radius={28} padding={20}>
    <View style={{ gap: 18 }}>
      <Eyebrow color={alpha(colors.luster, 0.62)} opacity={1}>{title}</Eyebrow>
      {children}
    </View>
  </GlassPanel>
);

const Row = ({ title, strength, onStrength, children }: { title: string; strength: FieldStrengths[keyof FieldStrengths]; onStrength: (s: FieldStrengths[keyof FieldStrengths]) => void; children: React.ReactNode }) => (
  <View style={{ gap: 12 }}>
    <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
      <Eyebrow color={alpha(colors.luster, 0.6)} opacity={1}>{title}</Eyebrow>
      <StrengthChip strength={strength} onChange={onStrength} />
    </View>
    {children}
  </View>
);

/**
 * Everything a traveler tells Artemis: budget, timing, stops, hotel, and what matters most. Each preference can be a
 * MUST HAVE, PREFERRED or NICE TO HAVE — tap the chip to change it.
 */
export function PreferencesEditor({ prefs, onChange }: { prefs: TravelPreferences; onChange: (p: TravelPreferences) => void }) {
  const set = (patch: Partial<TravelPreferences>) => onChange({ ...prefs, ...patch });
  const strength = (k: keyof FieldStrengths) => (s: FieldStrengths[keyof FieldStrengths]) => set({ strengths: { ...prefs.strengths, [k]: s } });
  const chips = <V extends string>(items: V[], label: (v: V) => string, value: V, pick: (v: V) => void) => (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
      {items.map((it) => <SelectableChip key={it} title={label(it)} selected={it === value} onPress={() => pick(it)} />)}
    </View>
  );
  return (
    <View style={{ gap: 16 }}>
      <Panel title="Flight">
        <BudgetSlider title="Budget, per traveler" value={prefs.flightBudget} min={200} max={1500} step={25} onChange={(v) => set({ flightBudget: v })}
          trailing={<StrengthChip strength={prefs.strengths.flightBudget} onChange={strength('flightBudget')} />} />
        <Hairline color={alpha(colors.luster, 0.12)} />
        <Row title="Departure" strength={prefs.strengths.departureWindow} onStrength={strength('departureWindow')}>
          <HourRangeSlider window={prefs.departureWindow} onChange={(w) => set({ departureWindow: w })} />
        </Row>
        <Hairline color={alpha(colors.luster, 0.12)} />
        <Row title="Maximum stops" strength={prefs.strengths.maxStops} onStrength={strength('maxStops')}>
          <SegmentedPill items={[{ value: 0, label: 'Nonstop' }, { value: 1, label: '1 stop' }, { value: 2, label: '2+' }]} selection={prefs.maxStops} onChange={(v) => set({ maxStops: v })} />
        </Row>
      </Panel>
      <Panel title="Hotel">
        <BudgetSlider title="Budget, per night" unit="/ night" value={prefs.hotelBudget} min={80} max={500} step={10} onChange={(v) => set({ hotelBudget: v })}
          trailing={<StrengthChip strength={prefs.strengths.hotelBudget} onChange={strength('hotelBudget')} />} />
        <Hairline color={alpha(colors.luster, 0.12)} />
        <Row title="Style" strength={prefs.strengths.hotelStyle} onStrength={strength('hotelStyle')}>
          {chips<HotelStyle>(hotelStyles, hotelStyleLabel, prefs.hotelStyle, (v) => set({ hotelStyle: v }))}
        </Row>
        <Hairline color={alpha(colors.luster, 0.12)} />
        <Row title="Location" strength={prefs.strengths.location} onStrength={strength('location')}>
          {chips<LocationPreference>(locationPreferences, locationLabel, prefs.location, (v) => set({ location: v }))}
        </Row>
      </Panel>
      <Panel title="What matters most">
        {([['Price', 'price'], ['Flight time', 'flightTime'], ['Hotel', 'hotel']] as const).map(([label, k]) => (
          <View key={k} style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <T style={{ color: colors.luster, fontSize: 16, fontWeight: '600' }}>{label}</T>
            <StarRating title={label} value={prefs.priorities[k]} onChange={(v) => set({ priorities: { ...prefs.priorities, [k]: v } })} />
          </View>
        ))}
      </Panel>
    </View>
  );
}

/** One traveler's preferences screen: the editor plus a private "submit". Used for you, and for a friend when the phone is passed. */
export function PreferencesEntry({ tripID, travelerID, submitLabel = 'SUBMIT PRIVATELY', onSubmitted }: { tripID: string; travelerID: string; submitLabel?: string; onSubmitted?: () => void }) {
  const trip = useTrip(tripID);
  const [submitting, setSubmitting] = useState(false);
  const prefs = trip?.members.find((m) => m.traveler.id === travelerID)?.preferences;
  if (!prefs) return null;
  return (
    <View style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 18 }} showsVerticalScrollIndicator={false}>
        <PreferencesEditor prefs={prefs} onChange={(next) => getTripStore().updatePreferences(tripID, travelerID, () => next)} />
      </ScrollView>
      <StageFooter>
        <CTAButton title={submitLabel} icon={submitLabel === 'FIND MY FLIGHTS' ? 'search' : 'shield'} disabled={submitting}
          onPress={async () => {
            if (submitting) return;
            setSubmitting(true);
            HapticsService.success();
            await getTripStore().submitPreferences(tripID, travelerID);
            setSubmitting(false);
            onSubmitted?.();
          }} />
      </StageFooter>
    </View>
  );
}

export function PreferencesStage({ tripID, onPhone }: { tripID: string; onPhone: (r: PhoneRequest) => void }) {
  const trip = useTrip(tripID);
  const you = trip?.members.find((m) => m.invite === 'you');
  if (!trip || !you) return null;
  if (!you.hasSubmittedPreferences) {
    return (
      <View style={{ flex: 1 }}>
        <View style={{ paddingHorizontal: 20, paddingBottom: 8, gap: 8 }}>
          <StageTitle eyebrow="Your preferences" title={'What matters\nto you?'} />
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
            <Icon name="shield" size={13} color={alpha(colors.luster, 0.7)} strokeWidth={2} />
            <T style={{ color: alpha(colors.luster, 0.7), fontSize: 13, fontWeight: '600' }}>{trip.members.filter(memberIsInTrip).length === 1 ? 'Just for you' : 'Private until everyone submits'}</T>
          </View>
        </View>
        <PreferencesEntry tripID={tripID} travelerID={you.traveler.id} submitLabel={trip.members.filter(memberIsInTrip).length === 1 ? 'FIND MY FLIGHTS' : undefined} />
      </View>
    );
  }
  return <Waiting members={trip.members.filter(memberIsInTrip)} kind="preferences" tripID={tripID} onPhone={onPhone} />;
}

/** Waiting for the others, with the two ways of running the demo on one phone. */
export function Waiting({ members, kind, tripID, onPhone }: { members: TripMember[]; kind: 'preferences' | 'ranking'; tripID: string; onPhone: (r: PhoneRequest) => void }) {
  const prefs = kind === 'preferences';
  const doneOf = (m: TripMember) => (prefs ? m.hasSubmittedPreferences : m.hasRanked);
  const waitingFor = members.find((m) => !m.traveler.isYou && !doneOf(m))?.traveler.firstName ?? 'everyone';
  const store = getTripStore();
  return (
    <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 22 }} showsVerticalScrollIndicator={false}>
      <View style={{ gap: 10 }}>
        <StageTitle eyebrow={prefs ? 'Submitted' : 'Ranked'} title={prefs ? 'Waiting for\neveryone.' : `Now\n${waitingFor}.`} size={44} />
        <Body size={16} opacity={0.78}>
          {prefs
            ? 'Your preferences are locked in and hidden. Once everyone has submitted, Artemis shows only where you overlap.'
            : "Your ranking is locked in. Artemis combines everyone's rankings into one group order."}
        </Body>
      </View>
      {members.map((m) => {
        const done = doneOf(m);
        const line = prefs ? (done ? 'Submitted · hidden until everyone is done' : "Hasn't submitted yet") : done ? 'Ranked' : "Hasn't ranked yet";
        const icon: IconName = done ? 'shield' : 'clock';
        return (
          <View key={m.traveler.id} style={{ gap: 10 }}>
            <GlassPanel radius={22} padding={14}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
                <TravelerAvatar traveler={m.traveler} size={50} badge={done ? 'done' : 'none'} />
                <View style={{ flex: 1, gap: 3 }}>
                  <T style={{ color: colors.luster, fontSize: 17, fontWeight: '600' }}>{fullName(m.traveler)}</T>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    <Icon name={icon} size={12} color={done ? colors.aster : colors.habanero} strokeWidth={2.2} />
                    <T style={{ color: done ? colors.aster : colors.habanero, fontSize: 13, fontWeight: '600', flexShrink: 1 }}>{line}</T>
                  </View>
                </View>
              </View>
            </GlassPanel>
            {!done && !m.traveler.isYou && (
              <View style={{ gap: 10 }}>
                <CTAButton haptic title={`HAND THE PHONE TO ${m.traveler.firstName.toUpperCase()}`} onPress={() => onPhone({ travelerID: m.traveler.id, kind })} />
                <CTAButton haptic compact kind="ghost" style={{ alignSelf: 'stretch' }}
                  title={prefs ? `FILL IN FOR ${m.traveler.firstName.toUpperCase()} · DEMO` : `USE ${m.traveler.firstName.toUpperCase()}'S PREFERENCES · DEMO`}
                  onPress={async () => {
                    if (prefs) await store.submitPreferences(tripID, m.traveler.id);
                    else { const order = store.suggestedRanking(tripID, m.traveler.id); store.setRanking(tripID, m.traveler.id, order); store.submitRanking(tripID, m.traveler.id); }
                  }} />
              </View>
            )}
          </View>
        );
      })}
    </ScrollView>
  );
}

