import React, { useState } from 'react';
import { Pressable, ScrollView, View } from 'react-native';
import Animated, { ZoomIn } from 'react-native-reanimated';
import { CTAButton, GlassPanel } from '../../design/controls';
import { Icon } from '../../design/Icon';
import { Body, Mono, T } from '../../design/text';
import { alpha, colors } from '../../design/theme';
import { usd } from '../../domain/shared/money';
import { hoursMinutes } from '../../domain/shared/time';
import { departureLocal, flightDuration, stopsLabel } from '../../domain/trips/flights';
import { memberIsInTrip } from '../../domain/trips/trip';
import { HapticsService } from '../../services/HapticsService';
import { getTripStore } from '../../store/useTripStore';
import { useFlightMatches, useTrip } from '../../store/hooks';
import type { ScoredFlight } from '../../domain/matching/matchingService';
import { StageFooter, StageTitle } from './ui';
import { Waiting } from './PreferencesStage';
import type { PhoneRequest } from './PlanningFlow';

/** Tap the options in the order you prefer them. Everyone ranks privately; Artemis builds the group order. */
export function RankingEntry({ tripID, travelerID, submitLabel = 'SUBMIT MY RANKING', onSubmitted }: { tripID: string; travelerID: string; submitLabel?: string; onSubmitted?: () => void }) {
  const matches = useFlightMatches(tripID)?.matches;
  const [order, setOrder] = useState<string[]>([]);
  if (!matches) return null;
  const toggle = (id: string) => { HapticsService.select(); setOrder((o) => (o.includes(id) ? o.filter((x) => x !== id) : [...o, id])); };
  return (
    <View style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingTop: 8, gap: 14 }} showsVerticalScrollIndicator={false}>
        <Body size={15} opacity={0.75}>Tap in order of preference. Your first tap is your #1.</Body>
        {matches.map((s) => <RankRow key={s.option.id} scored={s} rank={order.indexOf(s.option.id) + 1 || undefined} onPress={() => toggle(s.option.id)} />)}
        <Pressable accessibilityRole="button" accessibilityLabel="Suggest from my preferences" style={{ minHeight: 44, flexDirection: 'row', alignItems: 'center', gap: 8 }}
          onPress={() => { HapticsService.select(); setOrder(getTripStore().suggestedRanking(tripID, travelerID)); }}>
          <Icon name="sparkles" size={16} color={colors.aster} strokeWidth={2} />
          <T style={{ color: colors.aster, fontSize: 15, fontWeight: '600' }}>Suggest from my preferences</T>
        </Pressable>
      </ScrollView>
      <StageFooter>
        <CTAButton title={submitLabel} icon="shield" disabled={order.length !== matches.length}
          onPress={() => {
            HapticsService.success();
            const store = getTripStore();
            store.setRanking(tripID, travelerID, order);
            store.submitRanking(tripID, travelerID);
            onSubmitted?.();
          }} />
      </StageFooter>
    </View>
  );
}

function RankRow({ scored, rank, onPress }: { scored: ScoredFlight; rank?: number; onPress: () => void }) {
  const o = scored.option;
  return (
    <Pressable accessibilityRole="button" onPress={onPress} accessibilityLabel={`${o.shortName}, ${usd(o.farePerTraveler)}, ${stopsLabel(o)}, ${scored.match.percent} percent match`}
      accessibilityValue={{ text: rank ? `Ranked ${rank}` : 'Not ranked' }} accessibilityHint="Double tap to rank">
      <GlassPanel radius={24} padding={14} style={{ borderColor: rank ? alpha(colors.habanero, 0.6) : alpha(colors.luster, 0.16), backgroundColor: rank ? alpha(colors.royal, 0.4) : undefined }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
          <View style={{ width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: rank ? 'transparent' : alpha(colors.luster, 0.35), backgroundColor: rank ? colors.habanero : 'transparent' }}>
            {rank && <Animated.View entering={ZoomIn.duration(200)}><Mono size={20} weight="800" color={colors.depths}>{rank}</Mono></Animated.View>}
          </View>
          <View style={{ flex: 1, gap: 4 }}>
            <T style={{ color: colors.luster, fontSize: 20, fontWeight: '800', letterSpacing: -0.3 }}>{o.shortName.toUpperCase()}</T>
            <T style={{ color: alpha(colors.luster, 0.75), fontSize: 15 }}>{`${usd(o.farePerTraveler)} · ${stopsLabel(o)} · ${hoursMinutes(flightDuration(o))}`}</T>
            <T style={{ color: alpha(colors.luster, 0.55), fontSize: 13 }}>{`Departs ${departureLocal(o)}`}</T>
          </View>
          <View style={{ alignItems: 'flex-end' }}>
            <Mono size={20} weight="700" color={colors.luster}>{`${scored.match.percent}%`}</Mono>
            <T style={{ color: alpha(colors.luster, 0.5), fontSize: 9, fontWeight: '800', letterSpacing: 1.2 }}>MATCH</T>
          </View>
        </View>
      </GlassPanel>
    </Pressable>
  );
}

export function RankingStage({ tripID, onPhone }: { tripID: string; onPhone: (r: PhoneRequest) => void }) {
  const trip = useTrip(tripID);
  const you = trip?.members.find((m) => m.invite === 'you');
  if (!trip || !you) return null;
  if (!you.hasRanked) {
    return (
      <View style={{ flex: 1 }}>
        <View style={{ paddingHorizontal: 20, paddingBottom: 6 }}><StageTitle eyebrow="Your ranking" title={'Rank your\noptions.'} /></View>
        <RankingEntry tripID={tripID} travelerID={you.traveler.id} />
      </View>
    );
  }
  return <Waiting members={trip.members.filter(memberIsInTrip)} kind="ranking" tripID={tripID} onPhone={onPhone} />;
}
